package com.kochartech.devicemax.AsyncTask;

import android.content.Context;
import android.os.AsyncTask;

import com.kochartech.devicemax.Utility.MyDataBaseHandlerClass;

public class CreateTableAsync extends AsyncTask<Context,String, String>
{
	MyDataBaseHandlerClass myDataBase;
	protected String doInBackground(Context... params) 
	{	
		Context context  = params[0];
		myDataBase = new MyDataBaseHandlerClass(params[0], "operators.db",
				null, 1);
		myDataBase.getWritableDatabase();
		myDataBase.createTable(context);
		myDataBase.close();
		return null;
	}
}
