package com.kochartech.gizmodoctor.Activity;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;

public class CustomAdapter extends ArrayAdapter {

	private String TAG = "CustomAdapter";
	private Context context;
	private List<RowItem> rowItem;

	CustomAdapter(Context context, List<RowItem> rowItem) {
		
		super(context, R.layout.list_item , rowItem);		
		this.context = context;
		this.rowItem = rowItem;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
	
		LayoutInflater mInflater = (LayoutInflater) context
				.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.list_item, null);
		}
		
		ImageView imageView = (ImageView) convertView.findViewById(R.id.icon);
		TextView  textView = (TextView) convertView.findViewById(R.id.title);
		imageView.setImageResource(rowItem.get(position).getIcon());
		textView.setText(rowItem.get(position).getTitle());

		return convertView;
	}
}
