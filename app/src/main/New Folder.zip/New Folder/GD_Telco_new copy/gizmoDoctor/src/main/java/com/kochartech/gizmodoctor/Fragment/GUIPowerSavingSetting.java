package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckBox;
import android.widget.ListView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Adapter.PowerSavingSettingsAdapter;
import com.kochartech.gizmodoctor.HelperClass.FragmentTitles;
import com.kochartech.gizmodoctor.HelperClass.PowerSavingSettings;
import com.kochartech.gizmodoctor.POJO.PowerSavingSettingsDTO;

public class GUIPowerSavingSetting extends Fragment implements OnItemClickListener, MyFragment{

	private String TAG = GUIPowerSavingSetting.class.getSimpleName();
	private ListView listView;
	private PowerSavingSettings powerSavingSettings;
	private ArrayList<PowerSavingSettingsDTO> powerSavingSettingsList;
	private PowerSavingSettingsAdapter listViewAdapter;
	private Context context;
	private View rootView;
	private ViewType viewType;
	
	public GUIPowerSavingSetting(ViewType viewType) {
		this.viewType = viewType;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {		 
		initDataSet();		
		initUi(inflater, container) ;
		handleViewType();		
		return rootView;
	
	}
	public void initDataSet() {
		context = getActivity().getApplicationContext();
		powerSavingSettings = new PowerSavingSettings(context);
		powerSavingSettingsList = powerSavingSettings.getSettings();
		listViewAdapter = new PowerSavingSettingsAdapter(context, powerSavingSettingsList, viewType);		
	}

	public View initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_powersavingsetting, container, false);
		listView = (ListView) rootView.findViewById(R.id.listView);
		listView.setAdapter(listViewAdapter);		
		return rootView;
	}

	
	private void handleViewType() {
		
		if(viewType.getValue() == ViewType.COMPLETE.getValue()) {
			
		}
		else if(viewType.getValue() == ViewType.CUSTOM.getValue()) {
			listView.setOnItemClickListener(this);
		}
	}
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		LogWrite.d(TAG, "Click work");
		PowerSavingSettingsDTO powerSavingSettingsDTO = powerSavingSettingsList.get(position);
		LogWrite.d(TAG, "state: "+powerSavingSettingsDTO.getState());
//		inverse DTO state
		powerSavingSettingsDTO.setState(!powerSavingSettingsDTO.getState());
//		reflect state on check box
		CheckBox checkbox = (CheckBox) view.findViewById(R.id.checkbox);
		checkbox.setChecked(powerSavingSettingsDTO.getState());
//		update State in Preference
		powerSavingSettings.updateSettingInPreference(powerSavingSettingsDTO);
		
		LogWrite.d(TAG, "state: "+powerSavingSettingsDTO.getState());
		
		
	}
	
	public enum ViewType {
			COMPLETE (0),
			CUSTOM (1);
		    private final int viewType;       
		    private ViewType(int viewType) {
		    	this.viewType = viewType;
		    }
		    public int getValue() {
		    	return viewType;
		    }    	
	}

	@Override
	public String getTitle() {
		if(viewType.getValue() == ViewType.COMPLETE.getValue()) {
			return FragmentTitles.POWERSAVING_SETTINGS;
		}
		else if(viewType.getValue() == ViewType.CUSTOM.getValue()) {
			return FragmentTitles.CUSTOMSAVING_SETTINGS;
		}
		return null;
	}
}












