//package com.kochartech.gizmodoctor.Fragment;
//
//import java.util.ArrayList;
//
//import android.content.Context;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.preference.PreferenceManager;
//import android.support.v4.app.Fragment;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.ListView;
//import android.widget.TextView;
//
//import com.kochartech.BatteryInfo.adapter.App;
//import com.kochartech.devicemax.Activities.LogWrite;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.Adapter.BatteryAdapter;
//import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
//import com.kochartech.gizmodoctor.UpdateUi.UiRequireUpdate;
//import com.kochartech.gizmodoctor.UpdateUi.UiUpdateAsync;
//import com.kochartech.library.Battery.BatteryApps;
//import com.kochartech.library.Battery.KTInformation;
//
//public class BatteryDetailFragment extends Fragment implements UiRequireUpdate {
//	private static final String TAG = "PowerTop";
//	private static final double HIDE_UID_THRESHOLD = 0.1;
//	public static final int KEY_CURRENT_POWER = 0;
//	public static final int KEY_AVERAGE_POWER = 1;
//	public static final int KEY_TOTAL_ENERGY = 2;
//	private SharedPreferences prefs;
//	private Context context;
//	public  ArrayList<com.kochartech.library.Battery.App> appList = new ArrayList<com.kochartech.library.Battery.App>();
//	private ListView listView;
//	private View rootView;
//	private TextView temperatureTextView, voltageTextView, healthTextView,
//			technologyTextView;
//	private ImageView batteryInPercentage;
//	private int[] batteryImage = { R.drawable.battery_10,
//			R.drawable.battery_10, R.drawable.battery_20,
//			R.drawable.battery_30, R.drawable.battery_40,
//			R.drawable.battery_50, R.drawable.battery_60,
//			R.drawable.battery_70, R.drawable.battery_80,
//			R.drawable.battery_90, R.drawable.battery_100 };
//
//	private MyProgressDialog myProgressDialog;
//
//	BatteryAdapter customAppAdapter;
//
//	@Override
//	public View onCreateView(LayoutInflater inflater, ViewGroup container,
//			Bundle savedInstanceState) {
//		context = getActivity().getApplicationContext();
//
//		rootView = inflater.inflate(R.layout.battery_xml, container, false);
//
//		listView = (ListView) rootView
//				.findViewById(R.id.batteryDisplayListView);
//		temperatureTextView = (TextView) rootView
//				.findViewById(R.id.temperature);
//		voltageTextView = (TextView) rootView.findViewById(R.id.voltage);
//		healthTextView = (TextView) rootView.findViewById(R.id.health);
//		technologyTextView = (TextView) rootView.findViewById(R.id.technology);
//		batteryInPercentage = (ImageView) rootView
//				.findViewById(R.id.batteryInPercentage);
//
//		customAppAdapter = new 	BatteryAdapter(context, appList);
//		
//		listView.setAdapter(customAppAdapter);
//		prefs = PreferenceManager.getDefaultSharedPreferences(context);
//		// serviceIntent = new Intent(context, UMLoggerService.class);
//		// /// Changes By Aman
//		// context.startService(serviceIntent);
//		// conn = new CounterServiceConnection();
//		// if(savedInstanceState != null)
//		// {
//		// componentNames = savedInstanceState.getStringArray("componentNames");
//		// noUidMask = savedInstanceState.getInt("noUidMask");
//		// }
//		//
//		KTInformation information = KTInformation.getInstance();
//		information.calculate(context);
//		temperatureTextView.setText((information.getTemperature()) + " \u2103");
//		voltageTextView.setText("" + information.getVoltage() + " V");
//		healthTextView.setText("" + information.getHealth());
//		technologyTextView.setText(information.getTechnology());
//
//		int batteryImageIndex = getIndexForBatteryImage((int) information
//				.getBatteryLevel());
//
//		batteryInPercentage
//				.setBackgroundResource(batteryImage[batteryImageIndex]);
//
//		LogWrite.d(TAG, information.getBatteryLevel() + " %");
//		LogWrite.d(TAG, "" + information.getChargingState());
//		LogWrite.d(TAG, "" + information.getTemperature());
//		LogWrite.d(TAG, "" + information.getVoltage());
//		LogWrite.d(TAG, information.getTechnology());
//		LogWrite.d(TAG, "" + information.getHealth());
//
//		myProgressDialog = new MyProgressDialog(getActivity());
//		myProgressDialog.show();
//
//		uiUpdateAsync = UiUpdateAsync.getInstance();
//
//		return rootView;
//	}
//
//	private UiUpdateAsync uiUpdateAsync;
//
//	private int getIndexForBatteryImage(int batteryPercentage) {
//		return batteryPercentage / 10;
//	}
//
//	@Override
//	public void runInBackGround() {
//		// TODO Auto-generated method stub
//
//		try {
//			BatteryApps batteryApps = new BatteryApps(context);
//
//			ArrayList<com.kochartech.library.Battery.App> appList = batteryApps.refreshView();
//
//			this.appList.clear();
//			
//			if(appList != null)
//				this.appList.addAll(appList);
//		} catch (ExceptionDTO e) {
//			
//			LogWrite.d("Ansal","ExceptionDTO....."+e);
//		}
//
//	}
//
//	@Override
//	public void updateUI() {
//		// TODO Auto-generated method stub
//		if (myProgressDialog.isShowing())
//			myProgressDiaLogWrite.dismiss();
//		
//		
//		
//		customAppAdapter.notifyDataSetChanged();
//		
//	}
//	@Override
//	public void onDestroy() {
//		super.onDestroy();
//		uiUpdateAsync.stop();
//		LogWrite.d(TAG, "onDestroy :");
//		
//	
//	}
//
//	@Override
//	public void onStop() {
//		super.onStop();
//		uiUpdateAsync.stop();
//	
//	}
//
//	@Override
//	public void onResume() {
//		super.onResume();
//		uiUpdateAsync = uiUpdateAsync.start(this);
//	
//		
//		
//	}
//
//	@Override
//	public void onPause() {
//		super.onPause();
//		uiUpdateAsync.stop();
//		LogWrite.d(TAG, "onPause :");
//	
//	}
//
//}
