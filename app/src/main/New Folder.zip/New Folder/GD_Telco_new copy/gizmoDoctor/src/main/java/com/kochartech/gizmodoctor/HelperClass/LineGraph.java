package com.kochartech.gizmodoctor.HelperClass;


import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint.Align;
import android.util.DisplayMetrics;
import android.util.TypedValue;

public class LineGraph {

	SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss");
	private int lineWidthXYSeriesRenderer = 2;
	private int lineColorXYSeriesRenderer = Color.WHITE;
	private Context context;
	XYSeries xySeries;
	private XYSeriesRenderer renderer;
	XYMultipleSeriesRenderer mRenderer;
	XYMultipleSeriesDataset dataSet;
	int[] xAxisPoints =    {10,20,30,40,50,60,70,80,90,100};
    int[] pointsToDraw = {0,0,0,0,0,0,0,0,0,0};
    GraphicalView chartView;
	public LineGraph(Context context)
	{
		this.context = context;
		initXYSeriesObject();
		initXYSeriesRenderer();
		intiXYMultipleSeriesRenderer();
		initXYMultipleSeriesDataset();
	}
	private void initXYSeriesObject()
	{
		  xySeries = new XYSeries("CPUUsage");
		  for(int i=0;i<xAxisPoints.length;i++) 
		       	xySeries.add(xAxisPoints[i], pointsToDraw[i]);	      
	}
	private void initXYSeriesRenderer()
	{
//		   renderer = new XYSeriesRenderer();
//		   renderer.setLineWidth(5);
//		   renderer.setColor(Color.rgb(233,255,255));
//		   renderer.setFillBelowLine(true);
//		   renderer.setFillBelowLineColor(Color.rgb(17, 133, 180));
		   
		renderer = new XYSeriesRenderer();
		renderer.setLineWidth(lineWidthXYSeriesRenderer);
		renderer.setColor(lineColorXYSeriesRenderer);
//			xySeriesRenderer.setPointStrokeWidth(0);
//			xySeriesRenderer.setPointStyle(PointStyle.CIRCLE);
		renderer.setFillBelowLine(true);
		renderer.setFillBelowLineColor(Color.rgb(16,35,65));
//			xySeriesRenderer.setFillBelowLineColor(Color.argb(255,17, 133, 180));
//			xySeriesRenderer.setFillBelowLineColor(Color.parseColor("#111747"));
//			xySeriesRenderer.setFillBelowLineColor(R.drawable.gradient);
	}
//	private void intiXYMultipleSeriesRenderer()
//	{
//		 mRenderer = new XYMultipleSeriesRenderer();
////			To Disable ZOOm in out feature
//			     mRenderer.setPanEnabled(true, false);
//			     mRenderer.setZoomEnabled(false, false);
//			     
//			     //to Hide X axsis Labels
////			     mRenderer.setXLabels(10);
//			     
//			     mRenderer.setShowLegend(false);
////			     mRenderer.setLegendHeight(0);
//			     mRenderer.setMargins(new int[] { 20, 30, 0, 30 });
//			     
//			     mRenderer.setMarginsColor(Color.BLACK);
////			     mRenderer.
////			     mRenderer.setXLabelsAlign();
////			     mRenderer.setLegendHeight(0);
//			     mRenderer.addSeriesRenderer(renderer);
////			     mRenderer.setZoomEnabled(false);
////			     mRenderer.setXLabelsPadding(10);
////			     mRenderer.setYLabelsPadding(10);
//			     mRenderer.setYLabels(5);
//			     
//			     
//			     mRenderer.setXLabels(10);
//			     /*
//			      * set Color of The Margins 
//			      */
//			     mRenderer.setMarginsColor(Color.rgb(22,57,111));
//			     
//			     /*
//			      * User can not touch the Pan it helps 
//			      * Zoom in-out and also stop raphs moves forward and
//			      * backward with swipe
//			      */
//			     mRenderer.setPanEnabled(false, false);
//			     
//			     // Set Y axsis Min and Max value
//			     mRenderer.setYAxisMax(100);
//			     mRenderer.setYAxisMin(0);	
//			     mRenderer.setShowGrid(true); // we show the grid
//			     mRenderer.setGridColor(Color.rgb(126,199,226));
////			     mRenderer.setInScroll(true);
////			     mRenderer.setYLabelsAlign(Align.LEFT, 0);
//			     mRenderer.setApplyBackgroundColor(true);
//			     mRenderer.setBackgroundColor(Color.rgb(22,57,111));
//
//	}
	
	
	private void intiXYMultipleSeriesRenderer() {
		mRenderer = new XYMultipleSeriesRenderer();
		// To Disable ZOOm in out feature
		mRenderer.setPanEnabled(true, false);
		mRenderer.setZoomEnabled(false, false);

		// to Hide X axsis Labels
		// mRenderer.setXLabels(10);

		mRenderer.setShowLegend(false);
		// mRenderer.setLegendHeight(0);
		
		DisplayMetrics metrics1 = context.getResources().getDisplayMetrics();
		float left = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 20, metrics1);
		float right = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 30, metrics1);
		float top = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 30, metrics1);
		
		
		mRenderer.setMargins(new int[] { (int) left, (int) right, 0, (int) top });

		mRenderer.setYLabelsAlign(Align.RIGHT);
//		mRenderer.setMarginsColor(Color.BLACK);
		// mRenderer.
		// mRenderer.setXLabelsAlign();
		// mRenderer.setLegendHeight(0);
		mRenderer.addSeriesRenderer(renderer);
		// mRenderer.setZoomEnabled(false);
		// mRenderer.setXLabelsPadding(10);
		// mRenderer.setYLabelsPadding(10);
//		mRenderer.setYLabels(4);
//		mRenderer.addYTextLabel(100,"100%");
//		mRenderer.addYTextLabel(50,"50%");
//		mRenderer.addYTextLabel(25,"25%");
//		mRenderer.addYTextLabel(75,"75%");

	
		
//		mRenderer.addXTextLabel(100, "100%");

		
		mRenderer.setXLabels(0);
		mRenderer.setXAxisMax(100);
		
//		long currentTime = System.currentTimeMillis();
//		long firstTime = currentTime - (30*60*1000);
//		long seconfTime = currentTime -(60*60*1000);
//		long thirdTime = currentTime - (90*60*1000);
//		long fourthTime = currentTime - (120*60*1000);
		
	
		
//		String currrentString = format.format(currentTime);
//		String firstString    = format.format(firstTime);
//		String secondString   = format.format(seconfTime);
//		String thirdString    = format.format(thirdTime);
//		String fourthString    = format.format(fourthTime);
		
		
//		LogWrite.d("ASHISH", "currrentString:"+currrentString);
//		LogWrite.d("ASHISH", "firstString:"+firstString);
//		LogWrite.d("ASHISH", "secondString:"+secondString);
//		LogWrite.d("ASHISH", "thirdString:"+thirdString);
		
//		mRenderer.addXTextLabel(0, currrentString);
//		mRenderer.addXTextLabel(30, firstString);
//		mRenderer.addXTextLabel(60, secondString);
//		mRenderer.addXTextLabel(90,thirdString);
//		mRenderer.addXTextLabel(120, fourthString);
		
		
//		String[] xAxsisLabels = getXAxsisLabel();
		
//		for(int i=0 ; i<xAxsisLabels.length ; i++)
//		{
//			if(i == 0)
//				mRenderer.addXTextLabel(i, xAxsisLabels[i]);
//			else
//				mRenderer.addXTextLabel(i*diffXAxsisLabelsInMinutes, xAxsisLabels[i]);
//		}
//		mRenderer.addXTextLabel(0, "As");
//		mRenderer.addXTextLabel(10,"As");
//		mRenderer.addXTextLabel(20, "As");
//		mRenderer.addXTextLabel(30, "As");
//		mRenderer.addXTextLabel(40,"As");
//		mRenderer.addXTextLabel(50, "As");
//		mRenderer.addXTextLabel(60,"As");
//		mRenderer.addXTextLabel(70, "As");
//		mRenderer.addXTextLabel(80, "As");
//		mRenderer.addXTextLabel(90, "As");
//		mRenderer.addXTextLabel(100, "As");
		
		/*
		 * set Color of The Margins
		 */
//		mRenderer.setMarginsColor(Color.rgb(22, 57, 111));
		mRenderer.setMarginsColor(Color.parseColor("#00111747"));

		mRenderer.setAxesColor(Color.WHITE);
		
		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		float val = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 10, metrics);
		
		mRenderer.setLabelsTextSize(val);
		mRenderer.setAxisTitleTextSize(val);
		/*
		 * User can not touch the Pan it helps Zoom in-out and also stop raphs
		 * moves forward and backward with swipe
		 */
		mRenderer.setPanEnabled(false, false);

		mRenderer.setYLabelsColor(0,Color.WHITE);
		mRenderer.setXLabelsColor(Color.WHITE);
		
		// Set Y axsis Min and Max value
		mRenderer.setYAxisMax(100);
		mRenderer.setYAxisMin(0);
		
		mRenderer.setShowGrid(false); // we show the grid
		mRenderer.setShowGridX(false); // we show the grid
		mRenderer.setShowGridY(true); // we show the grid
		mRenderer.setGridColor(Color.WHITE);
//		mRenderer.setGridColor(Color.rgb(30,66,113));
		// mRenderer.setInScroll(true);
		// mRenderer.setYLabelsAlign(Align.LEFT, 0);
		mRenderer.setApplyBackgroundColor(true);
//		mRenderer.setBackgroundColor(bgXYMultipleSeriesRenderer);
		mRenderer.setBackgroundColor(Color.parseColor("#001E2140"));
	}
	
	private void initXYMultipleSeriesDataset()
	{
		dataSet = new XYMultipleSeriesDataset();
        dataSet.addSeries(xySeries);
	    chartView = ChartFactory.getLineChartView(context,dataSet, mRenderer);
	    chartView.setPadding(0, 0, 0,0);	    
	}
	
	public GraphicalView getView()
	{
		return chartView;
	}
	
	public void refresh(int newValue)
	{
//		if(xAxsisPoint.size() >= 10)
//			xAxsisPoint.remove(xAxsisPoint.size()-1);
//		xAxsisPoint.add(0,format.format(System.currentTimeMillis()));
//		
//		for(int i=0; i<xAxsisPoint.size(); i++)
//		{
//			mRenderer.addXTextLabel(i*10, xAxsisPoint.get(i));
//		}		
		
		for(int i=xAxisPoints.length-2;i>=0;i--)
			pointsToDraw[i+1] = pointsToDraw[i];
//		
		pointsToDraw[0] = newValue;
		xySeries.clear();
		
		for(int i=0;i<xAxisPoints.length;i++) {
	       	xySeries.add(xAxisPoints[i], pointsToDraw[i]);
		}

//		for(int i=0;i<xAxisPoints.length;i++) {
//			xySeries.add(xAxisPoints[i], pointsToDraw[i]);
//		}
		
		chartView.repaint();
	}
	
	public void setAxsisPoint(int[] xAxisPoints, int[] pointsToDraw)
	{
		this.xAxisPoints = xAxisPoints;
		this.pointsToDraw = pointsToDraw;	
	}
	
	ArrayList<String> xAxsisPoint = new ArrayList<String>();
}
