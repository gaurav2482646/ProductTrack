package com.kochartech.devicemax.AsyncTask;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.Context;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;

public class DownloadAsyncTask 
{
	private Context statsContext;
	private String tag = "DownloadAsyncTask";
	
	private String url ="http://202.164.36.66/1mb/1mb.zip";
	private static String latitude;
	private static String longitude;
	private int signalStrength;
	private String transferSize;
	private String downloadSpeed="NA",imei="NA",imsi="NA",fileTransferStatus="NA";
	private String phoneNumber;
	private String cellId="NA";
	private String lac="NA";
	private String latency="Failure";
	private String startDateTime="NA",endDateTime="NA";//stats start and end date time
	private String bearerInfo;
	private String networkName="NA";
	private String SERVERURL;
	public DownloadAsyncTask(Context context, String imeiNumber, int signal, String lat, String longi) 
	{
		statsContext = context;
		phoneNumber  = imeiNumber;
		SERVERURL    = context.getString(R.string.ServerUrl);
		signalStrength = signal;
		latitude = lat;
		longitude = longi;
		LogWrite.d(tag,"latitude ="+latitude);
		LogWrite.d(tag,"longitude ="+longitude);
		
		LogWrite.d(tag, "Phone Number for speed Test : " + phoneNumber);
		setIMEI(statsContext);
		LogWrite.d(tag,"IMEI ="+imei);
		setUrl();
		LogWrite.d(tag,"url ="+url);
		setTransferSize();
		LogWrite.d(tag,"transferSize ="+transferSize);
		setStartEndDateTimeAndPhoneNumber();
		LogWrite.d(tag,"phone Number ="+phoneNumber);
		setDownloadSpeed();//it set download speed and transfer status
		LogWrite.d(tag,"downloadSpeed ="+downloadSpeed);
		LogWrite.d(tag,"fileTransferStatus ="+fileTransferStatus);
		LogWrite.d(tag,"startDateTime ="+startDateTime);
		LogWrite.d(tag,"endDateTime ="+endDateTime);
		setCellIdAndLoc(statsContext);
		LogWrite.d(tag,"cellId ="+cellId);
		LogWrite.d(tag,"lac ="+lac);
		setLatency();
		LogWrite.d(tag,"letency ="+latency);
		setNetworkName(statsContext);
		LogWrite.d(tag,"networkName ="+networkName);
		setBearerInfo();
		LogWrite.d(tag,"bearerInfo ="+bearerInfo);
		
		
		String message="<SPDTST-1:<A1:"+imei+";";
		message+="B1:"+url+";";
		message+="C1:"+transferSize+";";
		message+="D1:"+startDateTime+";";
		message+="E1:"+endDateTime+";";
		message+="F1:"+fileTransferStatus+";";
		message+="G1:"+latency+";";
		message+="H1:"+latitude+";";				
		message+="I1:"+longitude+";";
		message+="J1:"+cellId+";";
		message+="K1:"+lac+";";
		message+="L1:"+networkName+";";
		message+="M1:"+signalStrength+";";
		message+="N1:"+bearerInfo+";";
		message+="O1:"+downloadSpeed+";";
		message+=">;>";
		sendTextMessage(phoneNumber, message);
		
	}
//	@Override
//	protected void onPreExecute() 
//	{
//		super.onPreExecute();
//		PhoneStateListener phonestate = new PhoneStateListener() 
//		{
//			public void onSignalStrengthChanged(int asu) 
//			{
//				signalStrength = asu;
//				int dbm = -113 + (2 * asu);
//				dbm = dbm * (-1);
//				if (dbm >= 60 && dbm < 70) {
//					dbm = 95;
//				} else if (dbm >= 70 && dbm < 87) {
//					dbm = 85;
//				} else if (dbm >= 87) {
//					dbm = 60;
//				}
//				signalStrength = dbm;
//			}
//		};
//		((android.telephony.TelephonyManager) statsContext.getSystemService(statsContext.TELEPHONY_SERVICE)).listen(phonestate,
//				PhoneStateListener.LISTEN_SIGNAL_STRENGTH);
//		setLatitudeAndLongitude();
//	}
//	@Override
//	protected Integer doInBackground(Context... params) 
//	{
//		setIMEI(statsContext);
//		LogWrite.d(tag,"IMEI ="+imei);
//		setUrl();
//		LogWrite.d(tag,"url ="+url);
//		setTransferSize();
//		LogWrite.d(tag,"transferSize ="+transferSize);
//		setStartEndDateTimeAndPhoneNumber();
//		LogWrite.d(tag,"phone Number ="+phoneNumber);
//		setDownloadSpeed();//it set download speed and transfer status
//		LogWrite.d(tag,"downloadSpeed ="+downloadSpeed);
//		LogWrite.d(tag,"fileTransferStatus ="+fileTransferStatus);
//		LogWrite.d(tag,"startDateTime ="+startDateTime);
//		LogWrite.d(tag,"endDateTime ="+endDateTime);
//		setCellIdAndLoc(statsContext);
//		LogWrite.d(tag,"cellId ="+cellId);
//		LogWrite.d(tag,"lac ="+lac);
//		setLatency();
//		LogWrite.d(tag,"letency ="+latency);
//		setNetworkName(statsContext);
//		LogWrite.d(tag,"networkName ="+networkName);
//		setBearerInfo();
//		LogWrite.d(tag,"bearerInfo ="+bearerInfo);
//		LogWrite.d(tag,"latitude ="+latitude);
//		LogWrite.d(tag,"latitude ="+latitude);
//		
//		String message="<SPDTST-1:<A1:"+imei+";";
//		message+="B1:"+url+";";
//		message+="C1:"+transferSize+";";
//		message+="D1:"+startDateTime+";";
//		message+="E1:"+endDateTime+";";
//		message+="F1:"+fileTransferStatus+";";
//		message+="G1:"+latency+";";
//		message+="H1:"+latitude+";";				
//		message+="I1:"+longitude+";";
//		message+="J1:"+cellId+";";
//		message+="K1:"+lac+";";
//		message+="L1:"+networkName+";";
//		message+="M1:"+signalStrength+";";
//		message+="N1:"+bearerInfo+";";
//		message+="O1:"+downloadSpeed+";";
//		message+=">;>";
//		sendTextMessage(phoneNumber, message);
//		return 0;
//	}
	public void setIMEI(Context context)
	{
		try 
		{
			TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			imei = telephonyManager.getDeviceId();
		} 
		catch (Exception e) 
		{
			LogWrite.d(tag,"ExceptionDTO =setIMEI = "+e);
		}  
	}
	public void setUrl()
	{
		url ="202.164.36.66/1mb/1mb.zip";
	}
	public void setTransferSize()
	{
		transferSize ="1Mb";
	}
	public void setStartEndDateTimeAndPhoneNumber()
	{
		try 
		{
			phoneNumber = imei;
		} 
		catch (Exception e) 
		{
			LogWrite.d(tag,"ExceptionDTO =setStartEndDateTime = "+e);
		}
	}
	public void setDownloadSpeed()
	{
		fileTransferStatus = "Failure";
		long startTime1,endTime1;
		LogWrite.d(tag,"getDowanloadSpeed  Work");
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cl = Calendar.getInstance();
		startDateTime = dateFormat.format(cl.getTime());
		startDateTime = startDateTime.replace(":","/");
		LogWrite.d(tag,"startDateTime  ="+startDateTime);
		final String filePath = "http://202.164.36.66/1mb/1mb.zip";
		int fileSize ;
		try
		{
			startTime1  = System.currentTimeMillis();
			URL url = new URL(filePath);
			URLConnection conection = url.openConnection();
			HttpURLConnection httpConn = (HttpURLConnection) conection;
			httpConn .setConnectTimeout(13*1000);
			httpConn.setReadTimeout(3*60*1000);
			LogWrite.d(tag,"Connection Status = "+httpConn.getResponseCode());
			if(httpConn.getResponseCode() == 200)
			{
				int lengthOfFile = httpConn.getContentLength();
				LogWrite.d(tag,"File Size = "+lengthOfFile);	
				fileSize = lengthOfFile / 1024;
				LogWrite.d(tag,"File Size = "+fileSize);
				InputStream inputStream = httpConn.getInputStream();
				DataInputStream dataInputStream = new DataInputStream(inputStream);
				byte[] buffer = new byte[1024];
				long total = 0;
				int length;
				while ((length = dataInputStream.read(buffer)) > 0) 
				{
					total += length;
				}	
				endTime1  = System.currentTimeMillis();
				long timeTaken = endTime1 - startTime1;
				
				long timeInSeconds = timeTaken / 1000;
				LogWrite.d(tag,"Time Taken inSeconds = "+timeTaken);
				LogWrite.d(tag,"File Size = "+fileSize);
				if(fileSize > 0)
				{
					downloadSpeed = ""+fileSize / timeInSeconds+" kbps";
					fileTransferStatus = "Success";
				}
				dataInputStream.close();		
				httpConn.disconnect();
			}    
		}
		catch (Exception e) 
		{
			LogWrite.d("Ashis1","ExceptionDTO =DownloadSpeed = "+e);
		}
			/* 
			 * Setting End Time
			 * 
			 */
			cl.setTime(new Date());
		    endDateTime = dateFormat.format(cl.getTime());
		    endDateTime = endDateTime.replace(":","/");
		    LogWrite.d("Ashis1","endDateTime  ="+endDateTime);
	}
	void setCellIdAndLoc(Context context) 
	{
		try 
		{
			final TelephonyManager telephony = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
			if (telephony.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) 
			{
				final GsmCellLocation location = (GsmCellLocation) telephony.getCellLocation();
				if (location != null) 
				{
					 lac=String.valueOf(location.getLac()); 						
				}
				int cellID = location.getCid();
				cellID = cellID & 0xffff;
				cellId=String.valueOf(cellID);
			} 
			else 
			{
//				showToast("Not on GSM Network", 2000);
			}
		}   
		catch (Exception e) 
		{
			LogWrite.d(tag,"ExceptionDTO =CellIdLoc = "+e);
		}  
	}
	public void setLatency()
	{
		String TAG ="LatencyTest";
		String ip = "202.164.36.66";
		String pingCmd = "ping -c 25 " + ip;
		try 
		{
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(pingCmd);
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String inputLine;
			String latencyResult = null;
			while ((inputLine = in.readLine()) != null)
			{
				latencyResult = inputLine;
			}
			String[] keyValue = latencyResult.split("=");
			String[] value = keyValue[1].split("/");
			latency = value[1];                  
		}
		catch (Exception e)
		{
			LogWrite.d(TAG, "ExceptionDTO..."+e);
		}	                
	}
	public void setNetworkName(Context context)
	{
		try 
		{
			networkName = ((android.telephony.TelephonyManager) context.getApplicationContext().getSystemService(context.TELEPHONY_SERVICE)).getNetworkOperatorName();
					
		}
		catch (Exception e) 
		{
			networkName = "NA";
			LogWrite.d(tag,"ExceptionDTO =setNetworkName = "+e);
		}
	}
	public void setBearerInfo()
	{
		TelephonyManager teleMan = (TelephonyManager)statsContext.getSystemService(statsContext.TELEPHONY_SERVICE);
		int networkType = teleMan.getNetworkType();
		switch (networkType)
		{
			case TelephonyManager.NETWORK_TYPE_CDMA:
				bearerInfo="CDMA";
				break;      
			case TelephonyManager.NETWORK_TYPE_EDGE:
				bearerInfo="EDGE";
			    break;
			case TelephonyManager.NETWORK_TYPE_GPRS:
				bearerInfo="GPRS";
			    break;      
			case TelephonyManager.NETWORK_TYPE_IDEN:
				bearerInfo="IDEN";
			    break;
			case TelephonyManager.NETWORK_TYPE_LTE:
				bearerInfo="LTE";
			    break;
			case TelephonyManager.NETWORK_TYPE_UMTS:
				bearerInfo="UMTS";
			    break;          
			default:
				bearerInfo="NA";					   
			    break;
		}
	}
	public void sendTextMessage(String address, String message)
	{
		String tag="statssendtextmessage";
		try
		{
			String messageToAppend, messageToSend = "";
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(SERVERURL);
			String outerBody = PreferenceManager.getDefaultSharedPreferences(statsContext.getApplicationContext()).getString("outerbodystart", "");
			String innerBody = PreferenceManager.getDefaultSharedPreferences(statsContext.getApplicationContext()).getString("innerbodystart", "");
			String outerBodyEnd = PreferenceManager.getDefaultSharedPreferences(statsContext.getApplicationContext()).getString("outerbodyend", "");
			String innerBodyEnd = PreferenceManager.getDefaultSharedPreferences(statsContext.getApplicationContext()).getString("innerbodyend", "");
			outerBodyEnd = ";>";
			innerBodyEnd = ";>";
			
			
			outerBody = "DM:1of1;UID:0_0;DT:<";
			innerBody = "MN:9958112020;CNo:1;CMD-1:SPDTST;CMDINF-1:";
			LogWrite.d(tag,"Outer ="+outerBody);
			LogWrite.d(tag,"Inner ="+innerBody);
			LogWrite.d(tag,"Messagae ="+message);
			messageToSend=outerBody+innerBody+message+innerBodyEnd+outerBodyEnd;
			LogWrite.d(tag, "sendresponse--"+"MessageID:"
					+ getRandomNumber()
					+ "MessageClass:EventMessageType:HSetToHTTPEvent:"
					+ "NewDMResponseChunkData:" + messageToSend
					+ "Mobile:" + phoneNumber
					+ "Content-Length:0\n");
			httppost.setEntity(new StringEntity("MessageID:"
							+ getRandomNumber()
							+ "\nMessageClass:Event\nMessageType:HSetToHTTP\nEvent:"
							+ "NewDMResponse\nChunkData:" + messageToSend
							+ "\nMobile:" + phoneNumber
							+ "\nContent-Length:0\n"));    
			HttpResponse resp = httpclient.execute(httppost);
			HttpEntity ent = resp.getEntity();
			
			LogWrite.d(tag,"StatusCode ="+resp.getStatusLine().getStatusCode());
			
            if(resp.getStatusLine().getStatusCode()==200)
            {
            	LogWrite.d(tag,"Stats Status ="+resp.getStatusLine().getStatusCode());
            }
            else
            {
            	
            }
	   }
	   catch(Exception e)
	   {
		   LogWrite.d(tag, "ExceptionDTO ="+e);
	   }
	}
	public String getRandomNumber() 
	{
		String finalRN = "";
		Random rd = new Random(10000);
		int randomNumber = rd.nextInt();
		String rn = Integer.toString(randomNumber);

		if (rn.startsWith("-"))
		{
			int index = rn.indexOf("-");
			finalRN = rn.substring(index + 1, rn.length());
			LogWrite.d(tag, "getRandomNumber-> " + finalRN);
			return finalRN;
		} 
		else 
		{
			return rn;
		}

		// return Integer.toString(randomNumber);
	}
}
