//ashish Sharma
package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.os.Bundle;

import com.kochartech.gizmodoctor.R;


/**
 * Called when the activity is first created. This Activity start the Alarm
 * Service for two other Classes i.e, {@link MDMMainActivity} &
 * {@link FtpUploadReceiver}. Respectively one is an Activity and other is a
 * BroadcastReceiver.
 * 
 * @see Activity
 * @see BroadcastReceiver
 * 
 * @author nishant.kumar
 * 
 */
public class AlarmActivity extends Activity {
	/** Called when the activity is first created. */
	
	String tag = "AlarmActivity";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register_user_layout);

		LogWrite.d(tag, "in on create");
		startAlert();
		finish();
	}

	/**
	 * Method which in turns starts the AlarmService.
	 * Now only used to start the Main Activity.
	 */
	public void startAlert() {

		Intent myintent = getIntent();
		String NumberToSend = myintent.getStringExtra("phoneNumber");

		Intent intent = new Intent(this, MDMMainActivity.class);
		intent.putExtra("sendPhoneNumber", NumberToSend);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(intent);
  
		finish();
//		Intent ftpIntent = new Intent(this, FtpUploadReceiver.class);
//
//		PendingIntent pendingIntent = PendingIntent.getActivity(
//				this.getApplicationContext(), 232323, intent, 0);
//		AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
//		PendingIntent pendingFtpIntent = PendingIntent.getBroadcast(
//				this.getApplicationContext(), 232324, ftpIntent, 0);
//
//		alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis() + (0 * 1000), (30 * 1000 * 60),pendingIntent);
//		alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis() + (5 * 1000), (30 * 1000 * 60),pendingFtpIntent);

	}

}