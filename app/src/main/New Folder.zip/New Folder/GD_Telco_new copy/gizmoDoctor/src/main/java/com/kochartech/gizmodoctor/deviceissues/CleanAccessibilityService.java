package com.kochartech.gizmodoctor.deviceissues;

import java.util.List;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.kochartech.devicemax.Activities.LogWrite;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
@SuppressLint("InlinedApi")
public class CleanAccessibilityService extends AccessibilityService {
	private String TAG = CleanAccessibilityService.class.getSimpleName();
	// private final AccessibilityServiceInfo info = new
	// AccessibilityServiceInfo();
	boolean kk = false;

	// private ArrayList<AccessibilityNodeInfo> buttonNodes;

	private static final String TEXT_UNINSTALL = "Uninstall";
	private static final String TEXT_FORCE_STOP = "Force stop";
	private static final String TEXT_OK = "Ok";

	// private static final String TEXT_CANCEL = "Cancel";
	// private static final String TEXT_OFF = "OFF";
	// private static final String TEXT_ON = "ON";
	// private boolean check;

	@Override
	public void onAccessibilityEvent(AccessibilityEvent event) {
		LogWrite.i(TAG, "ACC::onAccessibilityEvent: " + event.getEventType());
		ActionPerformPrefrence actionPerformPrefrence = new ActionPerformPrefrence(
				getApplicationContext());
		LogWrite.e(TAG,
				"Action ::: " + actionPerformPrefrence.getActionToPerform());
		if (actionPerformPrefrence.getActionToPerform() != ActionPerformPrefrence.ACTION_NO) {
			// TYPE_WINDOW_STATE_CHANGED == 32
			// if (AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED == event
			// .getEventType()) {

			if (actionPerformPrefrence.getActionToPerform() == ActionPerformPrefrence.ACTION_GPS) {
				AccessibilityNodeInfo nodeInfo = event.getSource();
				LogWrite.i(TAG, "ACC::onAccessibilityEvent: nodeInfo="
						+ nodeInfo);
				if (nodeInfo == null)
					return;

				AccessibilityNodeInfo info = nodeInfo.getChild(0);
				info.performAction(AccessibilityNodeInfo.ACTION_CLICK);
				List<AccessibilityNodeInfo> list = nodeInfo
						.findAccessibilityNodeInfosByViewId("com.android.settings:id/switch_widget");
				kk = true;
				LogWrite.e(TAG, "-------------------------1 : " + list.size());

				if (list.size() != 0) {
					if (kk == true) {
						// list =
						// nodeInfo.findAccessibilityNodeInfosByText(TEXT_OFF);
						for (AccessibilityNodeInfo node : list) {
							LogWrite.i(TAG,
									"ACC::onAccessibilityEvent: off switch "
											+ node);
							node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
							node.performAction(AccessibilityNodeInfo.ACTION_DISMISS);
						}
						kk = false;
					}
				}

			} else if (actionPerformPrefrence.getActionToPerform() == ActionPerformPrefrence.ACTION_FORCE_CLOSE) {

				AccessibilityNodeInfo nodeInfo = event.getSource();
				LogWrite.i(TAG, "ACC::onAccessibilityEvent: nodeInfo="
						+ nodeInfo);

				if (nodeInfo == null) {
					return;
				}

				// List<AccessibilityNodeInfo> list = nodeInfo
				// .findAccessibilityNodeInfosByViewId("com.android.settings:id/right_button");

				List<AccessibilityNodeInfo> list = nodeInfo
						.findAccessibilityNodeInfosByText(TEXT_FORCE_STOP);
				try {
					Thread.sleep(250);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (kk == true) {
					// list = nodeInfo
					// .findAccessibilityNodeInfosByViewId("android:id/button1");
					list = nodeInfo.findAccessibilityNodeInfosByText(TEXT_OK);
					for (AccessibilityNodeInfo node : list) {
						LogWrite.i(TAG, "ACC::onAccessibilityEvent: button1 "
								+ node);
						node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
					}

					kk = false;
				}

				if (kk == false) {
					for (AccessibilityNodeInfo node : list) {
						LogWrite.i(TAG,
								"ACC::onAccessibilityEvent: left_button "
										+ node);
						node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
						node.performAction(AccessibilityNodeInfo.ACTION_DISMISS);

						kk = true;
					}
				}
				performGlobalAction(GLOBAL_ACTION_BACK);
			} else if (actionPerformPrefrence.getActionToPerform() == ActionPerformPrefrence.ACTION_UNINSTALL) {
				AccessibilityNodeInfo nodeInfo = event.getSource();
				LogWrite.i(TAG, "ACC::onAccessibilityEvent: nodeInfo="
						+ nodeInfo);

				if (nodeInfo == null) {
					return;
				}
				// List<AccessibilityNodeInfo> list = nodeInfo
				// .findAccessibilityNodeInfosByViewId("com.android.settings:id/right_button");

				List<AccessibilityNodeInfo> list = nodeInfo
						.findAccessibilityNodeInfosByText(TEXT_UNINSTALL);

				if (kk == true) {
					// list = nodeInfo
					// .findAccessibilityNodeInfosByViewId("android:id/button1");
					list = nodeInfo.findAccessibilityNodeInfosByText(TEXT_OK);
					for (AccessibilityNodeInfo node : list) {
						LogWrite.i(TAG, "ACC::onAccessibilityEvent: button1 "
								+ node);
						node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
					}

					kk = false;
				}

				if (kk == false) {
					for (AccessibilityNodeInfo node : list) {
						LogWrite.i(TAG,
								"ACC::onAccessibilityEvent: left_button "
										+ node);
						node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
						kk = true;
					}
				}
			}

		}

		// }

		// forceStopApplication(event);

		// try {
		// LogWrite.i(TAG, "packageName: " + (String) event.getPackageName()
		// + "  classname: " + event.getClassName());
		// OnPackageChangeListener onPackageChangeListener = KTTopApplication
		// .getPackageChangeListener();
		// if (onPackageChangeListener != null)
		// onPackageChangeListener.onPackageChange((String) event
		// .getPackageName());
		// } catch (ExceptionDTO e) {
		// LogWrite.e(TAG, "exception: " + e.toString());
		// }

		// speakToUser("Location services enabled!");
	}

	// private void forceStopApplication(AccessibilityEvent event) {
	// AccessibilityNodeInfo rootNode = event.getSource();
	// buttonNodes = new ArrayList<AccessibilityNodeInfo>();
	//
	// findChildViews(rootNode);
	//
	// for (AccessibilityNodeInfo mNode : buttonNodes) {
	// if (mNode.getText() == null) {
	// return;
	// }
	// if (mNode.getText().toString().toUpperCase()
	// .contentEquals("FORCE STOP")) {
	// LogWrite.e(TAG, "Force stop button found....");
	// mNode.performAction(AccessibilityNodeInfo.ACTION_CLICK);
	// }
	// }
	// }

	// private void findChildViews(AccessibilityNodeInfo parentView) {
	//
	// if (parentView == null || parentView.getClassName() == null) {
	// LogWrite.d(TAG, "ParentView is null!");
	// return;
	// }
	//
	// int childCount = 0;
	// if (childCount == 0
	// && (parentView.getClassName().toString()
	// .contentEquals("android.widget.Button"))) {
	// buttonNodes.add(parentView);
	// LogWrite.e(TAG, "------ " + parentView.getText().toString());
	// } else {
	// for (int i = 0; i < childCount; i++) {
	// findChildViews(parentView.getChild(i));
	// }
	// }
	// }

	private static final String SCHEME = "package";

	private static final String APP_PKG_NAME_21 = "com.android.settings.ApplicationPkgName";

	private static final String APP_PKG_NAME_22 = "pkg";

	private static final String APP_DETAILS_PACKAGE_NAME = "com.android.settings";

	private static final String APP_DETAILS_CLASS_NAME = "com.android.settings.InstalledAppDetails";

	public static void showInstalledAppDetails(Context context,
			String packageName) {
		Intent intent = new Intent();
		final int apiLevel = Build.VERSION.SDK_INT;
		if (apiLevel >= 9) { // above 2.3
			intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
			Uri uri = Uri.fromParts(SCHEME, packageName, null);
			intent.setData(uri);
		} else { // below 2.3
			final String appPkgName = (apiLevel == 8 ? APP_PKG_NAME_22
					: APP_PKG_NAME_21);
			intent.setAction(Intent.ACTION_VIEW);
			intent.setClassName(APP_DETAILS_PACKAGE_NAME,
					APP_DETAILS_CLASS_NAME);
			intent.putExtra(appPkgName, packageName);
		}
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
	}

	@Override
	public void onInterrupt() {

	}

	@Override
	protected void onServiceConnected() {
		super.onServiceConnected();

		AccessibilityServiceInfo info = new AccessibilityServiceInfo();
		info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
		info.notificationTimeout = 100;
		info.feedbackType = AccessibilityEvent.TYPES_ALL_MASK;

		// Set the type of feedback your service will provide.
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
			info.feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK;
		} else {
			info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
			// info.feedbackType = AccessibilityServiceInfo.FEEDBACK_SPOKEN;
		}

		info.flags = AccessibilityServiceInfo.DEFAULT
				| AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
				| AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;

		setServiceInfo(info);

		info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
		//
		// setServiceInfo(info);
		LogWrite.i(TAG, "ACC::onServiceConnected: ");

		// LogWrite.e(TAG, "onServiceConnected");
		// AccessibilityServiceInfo info = new AccessibilityServiceInfo();
		// info.flags = AccessibilityServiceInfo.DEFAULT;
		// info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
		// info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
		// info.notificationTimeout = 100;
		// setServiceInfo(info);
	}
}