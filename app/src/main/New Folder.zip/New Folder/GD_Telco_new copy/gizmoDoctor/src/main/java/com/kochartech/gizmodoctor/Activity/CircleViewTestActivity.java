package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.CustomView.CircleView;

public class CircleViewTestActivity extends Activity implements OnClickListener
{
	private String tag = "CircleViewTestActivity";
	private CircleView circleView,circleView2;
	Handler handler = new Handler()
	{
		public void handleMessage(android.os.Message msg) 
		{
			
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.circleviewtestactivity);
		circleView = (CircleView) findViewById(R.id.circleView);		
		circleView.setOnClickListener(this);
		
		circleView.animateProgress(40);
		
		circleView2 = (CircleView) findViewById(R.id.circleView1);		
		circleView2.setOnClickListener(this);
		
		circleView2.animateProgress(90);
//		handler.postDelayed(new Runnable() {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				circleView.incrementProgress();
//				handler.post(this);
//			}
//		},1000);
		
	}
	@Override
	public void onClick(View v) {
		
		Toast.makeText(this,"Circle is Clicked", Toast.LENGTH_LONG).show();
	}
}
