package com.kochartech.gizmodoctor.DataBase;

public class AppInfo {
	private int rowId;
	private String appName;
	private String pkName;

	public AppInfo() {

	}

	public AppInfo(int rowId, String appName, String pkName) {
		this.rowId = rowId;
		this.appName = appName;
		this.pkName = pkName;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getPkName() {
		return pkName;
	}

	public void setPkName(String pkName) {
		this.pkName = pkName;
	}

}
