package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.kochartech.gizmodoctor.R;

public class DialogActivity extends Activity implements OnClickListener {

	private String tag = "MyHiddenActivity";
	int width = 0, height = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// dialog = new Dialog(this);
		// dialog.setTitle(R.string.PackageAdded_dialog_lable);

		setContentView(R.layout.dialog_activity);
		// Display display = ((WindowManager)
		// getSystemService(Context.WINDOW_SERVICE))
		// .getDefaultDisplay();
		// height = display.getHeight();
		// width = display.getWidth();
		Button button = (Button) findViewById(R.id.ok_button);
		button.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.ok_button)
			finish();

	}
}
