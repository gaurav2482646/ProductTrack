package com.kochartech.devicemax.Activities;
//package com.kochar.MDMS.Activities;
//
//import java.io.File;
//import java.util.List;
//import java.util.Timer;
//import java.util.TimerTask;
//
//import android.app.Activity;
//import android.app.ActivityManager;
//import android.app.ActivityManager.RunningAppProcessInfo;
//import android.app.ActivityManager.RunningTaskInfo;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.os.Environment;
//import android.preference.PreferenceManager;
//
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.Window;
//import android.view.WindowManager;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Toast;
//
//import com.kochar.MDMS.Services.ServiceEg;
//
//public class DisplayPasswordScreen extends Activity {
//	Button Ok, Yes, No, ChangePassword;
//	EditText getPasswordData;
//	SharedPreferences.Editor editor;
//	SharedPreferences preferences;
//	// String password="KipL4321";
//	String password = "1234";
//	int Count = 0;
//	String imei = null;
//	int incorrectPasswordCount = 0;
//	boolean f = true;
//	Timer timer = null;
//
//	private static DisplayPasswordScreen displayPasswordScreen = null;
//
//	public static DisplayPasswordScreen getInstance() {
//		return displayPasswordScreen;
//	}
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		super.onCreate(savedInstanceState);
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		SharedPreferences sharedPreferences = null;
//		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
//		imei = sharedPreferences.getString("imei", null);
//		displayPasswordScreen = this;
//		display();
//		timer = new Timer("IncorrectPasswordAttemptCounter");
//		timer.schedule(new TimerTask() {
//
//			@Override
//			public void run() {
//				resetIncorrectPasswordVariable();
//
//			}
//		}, (1000 * 60 * 1));
//
//	}
//
//	void resetIncorrectPasswordVariable() {
//		incorrectPasswordCount = 0;
//		// Toast.makeText(this, "Password Variable reset", 2000).show();
//		LogWrite.d("DisplayPasswordScreen", "Password Variable reset");
//	}
//
//	void display() {
//		setContentView(R.layout.lockscreen);
//		Ok = (Button) findViewById(R.id.Ok);
//		getPasswordData = (EditText) findViewById(R.id.Password);
//		getPasswordData.setText("");
//		preferences = getSharedPreferences("Preferecnes", 0);
//		editor = preferences.edit();
//		editor.putString("password", password);
//		editor.commit();
//		Ok.setOnClickListener(new OnClickListener() {
//			public void onClick(View v) {
//				String getPassword = preferences.getString("password", "");
//				LogWrite.d("---------------", getPassword + "       "
//						+ getPasswordData.getText().toString());
//				if (getPasswordData.getText().toString().equals(getPassword)) {
//					ServiceEg.ScreenLockFlag = false;
//					MyPreference.setBoolean(getApplicationContext(),"LCKHSET",false);
//					try
//					{
////						LogWrite.d("unlock App id", "1");
////						ActivityManager actvityManager = (ActivityManager)getApplicationContext().getSystemService(Activity.ACTIVITY_SERVICE);
////						LogWrite.d("unlock App id", "2"+actvityManager);
////						actvityManager.moveTaskToFront(ApplicationUnblockInfo.getAppId(), ActivityManager.MOVE_TASK_NO_USER_ACTION);
////						LogWrite.d("unlock App id", "3");
//						
////						ServiceEg.setActivePackage(actvityManager.getRunningTasks(2).get(0).baseActivity.getPackageName());
//						
//						
//						
//						
//					}
//					catch(ExceptionDTO e)
//					{
//						LogWrite.d("unlock App id", "ExceptionDTO..."+e);
//					}
//					finish();
//				} else if (ServiceEg.ScreenLockFlag) {
//					incorrectPasswordCount++;
//					Toast.makeText(
//							getApplicationContext(),
//							"Invalid Device Password " + incorrectPasswordCount,
//							Toast.LENGTH_SHORT).show();
//					if (incorrectPasswordCount == 5) {
//
//						String getFiles = Environment
//								.getExternalStorageDirectory().toString()
//								+ "/files_telynet/";
//						File mfile = new File(getFiles);
//						DeleteRecursive(mfile);
//
//						/************************************************************************************/
//					}// End if(incorrectPasswordCount==5)
//				}
//
//			}
//		});
//	}
//
//	void DeleteRecursive(File fileOrDirectory) {
//		if (fileOrDirectory.isDirectory())
//			for (File child : fileOrDirectory.listFiles())
//				DeleteRecursive(child);
//		Boolean deleted = fileOrDirectory.delete();
//		// LogWrite.d("Display password screen", deleted+"<<>>");
//		Toast.makeText(getApplicationContext(),
//				"files are deleted==" + deleted, Toast.LENGTH_LONG).show();
//	}
//
//	@Override
//	public void onBackPressed() {
//		return;
//	}
//
//	@Override
//	public void onAttachedToWindow() {
//		super.onAttachedToWindow();
//		if (ServiceEg.ScreenLockFlag)
//			this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
//	}
//}
