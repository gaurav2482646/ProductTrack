package com.kochartech.devicemax.Utility;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.TrafficStats;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;

public class MyDataBaseHandlerClass extends SQLiteOpenHelper
{
	private String tag = "MyDataBaseHandlerClass"; 
	private SQLiteDatabase dba;
	public MyDataBaseHandlerClass(Context context, String name,	CursorFactory factory, int version) 
	{
		super(context, name, factory, version);
	}

	@Override
	public void onCreate(SQLiteDatabase arg0) {}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2){	}
	
	@Override
	public void onOpen(SQLiteDatabase db) 
	{
		dba= db;
		super.onOpen(db);
	}
	
//	public void 
//	createTable()
//	{
////		String[] strings = {"Gmail~com.google.android.gm~0~1",
////				"Browser~com.android.browser~0~1",
////				"Map~com.google.android.apps.maps~0~1",
////				"Market~com.google.android.finsky~0~1",
////				"Email~com.android.email~0~1",
////				"File manager~com.motorola.filemanager~0~1",
////				"YouTube~com.google.android.youtube~0~1",
////				"Inbuilt Camera app~com.sec.android.app.camera~0~1"};
//		String[] strings = {"Gmail~com.google.android.gm~0",
//				"Browser~com.android.browser~0",
//				"Map~com.google.android.apps.maps~0",
//				"Market~com.google.android.finsky~0",
////				"Market~com.android.vending~0",
//				"Email~com.android.email~0",
////				"File manager~com.motorola.filemanager~0",
////				"File manager~com.motorola.vending~0",
//				"YouTube~com.google.android.youtube~0",
//				"Inbuilt Camera app~com.sec.android.app.camera~0",
////				"Inbuilt Camera app~com.android.camera~0"
//				};
//		try
//		{
////			dba.execSQL("CREATE TABLE IF NOT EXISTS AppsTable (AppName TEXT, AppPackageName TEXT PRIMARY KEY," +
////					" AppStatus INT, AppTimerStatus INT)");
//			dba.execSQL("CREATE TABLE IF NOT EXISTS AppsTable (AppName TEXT, AppPackageName TEXT PRIMARY KEY," +
//			" AppStatus INT)");
//			for (int i = 0; i < strings.length; i++) 
//			{
//				AddApplicationInfo(strings[i].split("~")[0], strings[i].split("~")[1],
//						Integer.parseInt(strings[i].split("~")[2]));
//			}
//		}
//		catch (ExceptionDTO e)
//		{
//			LogWrite.e(tag,e+"");
//		}
//	}
	public void createTable(Context context)
	{
		String tag = "createTable";
		LogWrite.d(tag, "Create Table Method enters");
//		LogWrite.d(tag, "Restart Flag ----> " + BootReceiver.restartFlag);
//		if(!BootReceiver.restartFlag)
//		{
//			LogWrite.d(tag, "Table going to be deleted");
//			dba.execSQL("DROP TABLE IF EXISTS AppsTable");
//		}
		try
		{
			dba.execSQL("CREATE TABLE IF NOT EXISTS AppsTable (AppName TEXT, AppPackageName TEXT PRIMARY KEY," +
					" AppStatus INT, previousDataUsed TEXT, PresentDataUsed TEXT,thirdParty TEXT,AppSize TEXT)");
			PackageManager pm = context.getPackageManager();
	        final IntentFilter filter = new IntentFilter(Intent.ACTION_MAIN);
	        filter.addCategory(Intent.CATEGORY_LAUNCHER);

	        List<IntentFilter> filters = new ArrayList<IntentFilter>();
	        filters.add(filter);

	        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
	        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

	        List<ResolveInfo> list = pm.queryIntentActivities(mainIntent, 0);    
			
			
			LogWrite.d(tag, "internal Apps ="+list.size());
//			Toast.makeText(, "Size ="+list.size(),Toast.LENGTH_LONG);
			for (int n = 0; n < list.size(); n++)
			{
				LogWrite.d("Application Installed", list.get(n).loadLabel(pm).toString());
				//
				if ((list.get(n).activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 1)
				{
					// 1 to unblock apps  0 to block third party app
					if (!list.get(n).loadLabel(pm).toString().equalsIgnoreCase(context.getString(R.string.app_name)))
					{
//						boolean hasInternetPer = getPermissionsForPackage(pm, list.get(n).activityInfo.packageName);
//						if(hasInternetPer)
//						{
							
							String className  = list.get(n).activityInfo.applicationInfo.className;
							String packageName = list.get(n).activityInfo.packageName;
							LogWrite.d(tag, "*************************************");
							LogWrite.d(tag, "Class Name ----> " + className);
							LogWrite.d(tag, "Package Name ----> " + packageName);
							LogWrite.d(tag, "*************************************");
							long rxTx = 0;
							try
							{
								long rx = TrafficStats.getUidRxBytes(list.get(n).activityInfo.applicationInfo.uid);
								long tx = TrafficStats.getUidTxBytes(list.get(n).activityInfo.applicationInfo.uid);
								rxTx = rx + tx;
								if(rxTx<0)
								{
									rxTx = 0;
								}
							}
							catch(Exception e)
							{
								rxTx = 0;
							}
							LogWrite.d(tag, "Current Data Usage -----> " + rxTx);
							AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
							list.get(n).activityInfo.packageName,
							1,
							0,
							0,
							"E",rxTx);
//						}
					}
				}
				//to block some apps given in the list
				else
				{
//					boolean hasInternetPer = getPermissionsForPackage(pm, list.get(n).activityInfo.packageName);
//					if(hasInternetPer)
//					{
						LogWrite.d(tag, "Has Internet Permissions");
						String className  = list.get(n).activityInfo.applicationInfo.className;
						String packageName = list.get(n).activityInfo.packageName;
						LogWrite.d(tag, "*************************************");
						LogWrite.d(tag, "Class Name ----> " + className);
						LogWrite.d(tag, "Package Name ----> " + packageName);
						LogWrite.d(tag, "*************************************");
						long rx = TrafficStats.getUidRxBytes(list.get(n).activityInfo.applicationInfo.uid);
						long tx = TrafficStats.getUidTxBytes(list.get(n).activityInfo.applicationInfo.uid);
						long rxTx = rx + tx;
						if(rxTx<0)
						{
							rxTx = 0;
						}
						LogWrite.d(tag, "Current Data Usage -----> " + rxTx);
						AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
								list.get(n).activityInfo.packageName,
								1,
								0,
								0,
								"I",rxTx);
//					}
				}
			}
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,"ExceptionDTO ----> " + e.toString());
		}
	}
//	public void updateAppUsageMeth(Context context) 
//	{
//		try 
//		{
//			LogWrite.d(tag, "inside the updateappusagemethod");
//			PackageManager packageManager = context.getPackageManager();
//			for (ApplicationInfo app : packageManager.getInstalledApplications(0)) 
//			{
//				
//				int uid = app.uid ;
//				long toSend = 0;
//				long currentUsage = getCurrentUsage(uid);
//				int preUsageFromDb = 0;
//
//				boolean hasInternetPer = getPermissionsForPackage(packageManager, app.packageName);
//				if (currentUsage > 0) 
//				{
//					if (hasInternetPer) 
//					{
//						MyDataBaseHandlerClass.intializeDB(context);
//						int[] usage = DBService.objectDBHandler.getAppPreviousUsage(app.packageName);
//						preUsageFromDb = usage[0];
//						LogWrite.d(tag, " previous usage fetched from db " +	 preUsageFromDb + "app name "+
//								app.loadLabel(packageManager).toString() );
//						toSend = usage[1];
//
//						if (preUsageFromDb <= currentUsage)
//						{
//							toSend += currentUsage - preUsageFromDb;
//							// LogWrite.d(TAG, "if " + app.loadLabel(getPackageManager()).toString());
//						} 
//						else 
//						{
//							toSend += currentUsage;
//							//LogWrite.d(TAG, "else "+ app.loadLabel(getPackageManager()).toString());
//						}
//						LogWrite.d(tag,"app Usage to send " + toSend);
//						ContentValues values = new ContentValues();
//						values.put(AppTable.APP_USAGE_TO_SEND, toSend);
//						values.put(AppTable.PREVIOUS_DATA_USAGE, currentUsage);
//						DBService.objectDBHandler.updateAppDataUsage(app.packageName, values);
//						// obj.getAllApps();
//
//					}
//				}
//			}
//		}
//		catch (ExceptionDTO e)
//		{
//			
//		}
//	} // END UPDATE APP METHOD
//	public static final boolean getPermissionsForPackage(PackageManager pm, String packageName)
//	{
//		try 
//		{
//			// LogWrite.d(TAG, "me=="+packageName);
//			ArrayList<PermissionInfo> retval = new ArrayList<PermissionInfo>();
//			PackageInfo packageInfo = pm.getPackageInfo(packageName,PackageManager.GET_PERMISSIONS);
//			if (packageInfo.requestedPermissions != null) 
//			{
//				for (String permName : packageInfo.requestedPermissions)
//				{
//					String per = pm.getPermissionInfo(permName,	PackageManager.GET_META_DATA) + "";
//					if (per.contains("android.permission.INTERNET")) {
//								return true;
//					}
//					retval.add(pm.getPermissionInfo(permName,PackageManager.GET_META_DATA));
//				}
//			} else {
//					// LogWrite.d(TAG,
//					// "packageInfo.requestedPermissions==="+packageInfo.requestedPermissions);
//				}
//			return false;
//		} catch (ExceptionDTO e) {}
//		return false;
//	}	
	
//	public void updateTable(Context context)
//	{
//		LogWrite.d(tag, "Update Table Method enters");
//		PackageManager pm = RegisterUserActivity.GetInstance().getPackageManager();
//		final IntentFilter filter = new IntentFilter(Intent.ACTION_MAIN);
//		filter.addCategory(Intent.CATEGORY_LAUNCHER);
//		
//		List<IntentFilter> filters = new ArrayList<IntentFilter>();
//		filters.add(filter);
//		
//		Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
//		mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
//
//		List<ResolveInfo> list = pm.queryIntentActivities(mainIntent, 0);	
//		LogWrite.d("Application Installed", "internal Apps ="+list.size());
//		for (int n = 0; n < list.size(); n++)
//		{
//			LogWrite.d("Application Installed", list.get(n).loadLabel(pm).toString());
//			//
//			if ((list.get(n).activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 1)
//			{
//				// 1 to unblock apps  0 to block third party app
//				if (!list.get(n).loadLabel(pm).toString().equalsIgnoreCase(RegisterUserActivity.GetInstance().getString(R.string.app_name)))
//				{
//					String className  = list.get(n).activityInfo.applicationInfo.className;
//					String packageName = list.get(n).activityInfo.packageName;
//					LogWrite.d(tag, "*************************************");
//					LogWrite.d(tag, "Class Name ----> " + className);
//					LogWrite.d(tag, "Package Name ----> " + packageName);
//					LogWrite.d(tag, "*************************************");
//					long rxTx = 0;
//					try
//					{
//						long rx = TrafficStats.getUidRxBytes(list.get(n).activityInfo.applicationInfo.uid);
//						long tx = TrafficStats.getUidTxBytes(list.get(n).activityInfo.applicationInfo.uid);
//						rxTx = rx + tx;
//						if(rxTx<0)
//						{
//							rxTx = 0;
//						}
//					}
//					catch(ExceptionDTO e)
//					{
//						rxTx = 0;
//					}
//					LogWrite.d(tag, "Current Data Usage -----> " + rxTx);
//					updateAppDataUsage(packageName, ""+rxTx);
//				}
//				//to block some apps given in the list
//				else
//				{
//					String className  = list.get(n).activityInfo.applicationInfo.className;
//					String packageName = list.get(n).activityInfo.packageName;
//					LogWrite.d(tag, "*************************************");
//					LogWrite.d(tag, "Class Name ----> " + className);
//					LogWrite.d(tag, "Package Name ----> " + packageName);
//					LogWrite.d(tag, "*************************************");
//					long rx = TrafficStats.getUidRxBytes(list.get(n).activityInfo.applicationInfo.uid);
//					long tx = TrafficStats.getUidTxBytes(list.get(n).activityInfo.applicationInfo.uid);
//					long rxTx = rx + tx;
//					if(rxTx<0)
//					{
//						rxTx = 0;
//					}
//					LogWrite.d(tag, "Current Data Usage -----> " + rxTx);
//					updateAppDataUsage(packageName, ""+rxTx);
//				}
//			}
//		}
//	}
	/*
     * Get all installed application on mobile and return a list
     * @param   c   Context of application
     * @return  list of installed applications
     */
//    public static List<ResolveInfo> getInstalledApplication(Context c) 
//    {
//    	PackageManager packageManager = c.getPackageManager();
//        final IntentFilter filter = new IntentFilter(Intent.ACTION_MAIN);
//        filter.addCategory(Intent.CATEGORY_LAUNCHER);
//
//        List<IntentFilter> filters = new ArrayList<IntentFilter>();
//        filters.add(filter);
//
//        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
//        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
//
//        List<ResolveInfo> appList = packageManager.queryIntentActivities(mainIntent, 0);    
//        return appList;
//    }
//	public void AddApplicationInfo(String AppName, String AppPackageName, int AppStatus, int AppTimerStatus)
	public void AddApplicationInfo(String AppName, String AppPackageName, int AppStatus, long previousDataUse, long presentDataUse,String internalExternal,long appSize)
	{
		String tag = "createTable";
		try
		{
//            LogWrite.d(tag, "Insert Done----->"+AppPackageName+" status"+AppStatus);
//			
//			LogWrite.d(tag,"app name -------->"+AppName);
//			LogWrite.d(tag,"appSize  -------->"+appSize);
			
//			dba.execSQL("INSERT INTO AppsTable values('"+AppName+"' , '"+AppPackageName+"' ,"+AppStatus+","+AppTimerStatus+" )");
			dba.execSQL("INSERT INTO AppsTable values('"+AppName+"' , '"+AppPackageName
					+"' ,"+AppStatus+" ,'"+previousDataUse+"' ,'"+presentDataUse+"', '"+internalExternal+"', '"+appSize+"')");
//			LogWrite.d(tag, "Insert Done----->"+AppPackageName+" status"+AppStatus);
//			LogWrite.d(tag,"Previous Data Usage -------->"+previousDataUse);
//			LogWrite.d(tag,"Present Data Usage -------->"+presentDataUse);
//			LogWrite.d(tag,"app name -------->"+AppName);
//			LogWrite.d(tag,"appSize  -------->"+appSize);
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
	}
	public long getLastUsage(String packageName)
	{
		Cursor c=dba.rawQuery("select AppSize from AppsTable where AppPackageName = '"+packageName +"'",null);
		c.moveToFirst();
		if(c!=null)
		return c.getInt(0);
		return 0;
	}
	public long getRestartUsage(String packageName)
	{
		Cursor c=dba.rawQuery("select PresentDataUsed from AppsTable where AppPackageName = '"+packageName +"'",null);
		c.moveToFirst();
		if(c!=null)
		return c.getInt(0);
		return 0;
	}
	public void updateAppDataUsage(String packageName , String appUsage)
	{
		LogWrite.d(tag, "Update App Data Usage Enters");
		LogWrite.d(tag, "Package Name : " + packageName);
		LogWrite.d(tag, "APP Usage 	 : " + appUsage);
		try
		{		
			dba.execSQL("update AppsTable set AppSize ='" + appUsage +"' where AppPackageName like +'"+packageName+ "' " );
		}
		catch(Exception ex)
		{
			Log.e(tag,"ExceptionDTO While Update : " +  ex.toString());
		}
		LogWrite.d(tag, "Update App Data Usage Enters");
	}
	public void updateRestartDataUsage(String packageName , String appUsage)
	{
		try
		{		
			dba.execSQL("update AppsTable set PresentDataUsed ='" + appUsage +"' where AppPackageName like +'"+packageName+ "' " );
		}
		catch(Exception ex)
		{
			LogWrite.d(tag, ex.toString());
		}	
	}
	
	public void updatePreviousAppDataUsage(String packageName,String previousDataUsed)
	{
		try
		{
			dba.execSQL("update AppsTable set previousDataUsed ='" + previousDataUsed +"' where AppPackageName like +'"+packageName+ "' " );
		}
		catch(Exception ex)
		{
			LogWrite.d("error during previous data updation", ex.toString());
		}
	}
	public Cursor getPreviousData(String packageName)
	{
		Cursor c=dba.rawQuery("SELECT PresentDataUsed FROM AppsTable WHERE AppPackageName='"+packageName+"'",null);
		return c;
	}
	public Cursor getAppPackage()
	{
		Cursor c=dba.rawQuery("SELECT AppPackageName FROM AppsTable" ,null);
		return c;
	}
	
	public String[] GetApplicationsFromDataBase()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.query("AppsTable",null , null, null, null, null,"AppName");
			string = new String[c.getCount()];
			c.moveToFirst();
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					LogWrite.d("in database class", c.getString(0)+"~"+c.getInt(2)+"~"+c.getInt(4)+"~"+c.getString(5));
//					if(c.getInt(4)>0)
//					{
					string[j] = c.getString(0)+"~"+c.getInt(2)+"~"+c.getInt(4)+"~"+c.getString(5);
					LogWrite.d(tag+"data usage greater than zero",string[j]);
				//	}
					//LogWrite.d("app status<<<<<<<<<",c.getString(0)+"  "+c.getString(3));
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	
	/*
	 *  instead of datausage it gives app size
	 */
	public String[] SpiceGetApplicationsFromDataBase()
	{
		String[] string=null;
		try
		{
			LogWrite.d("SpiceGetApplicationsFromDataBase", "Start");
			Cursor c=dba.query("AppsTable",null , null, null, null, null,"AppName");
			string = new String[c.getCount()];
			c.moveToFirst();
			LogWrite.d("SpiceGetApplicationsFromDataBase", "Size : "+c.getCount());
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					LogWrite.d("in database class", c.getString(0)+"~"+c.getInt(2)+"~"+c.getInt(6)+"~"+c.getString(5));
//					if(c.getInt(4)>0)
//					{
					string[j] = c.getString(0)+"~"+c.getInt(2)+"~"+c.getInt(6)+"~"+c.getString(5);
					LogWrite.d(tag+"data usage greater than zero",string[j]);
				//	}
					//LogWrite.d("app status<<<<<<<<<",c.getString(0)+"  "+c.getString(3));
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
//	public String[] GetApplicationsFromDataBaseInUnBlockedTime()
//	{
//		String[] string=null;
//		try
//		{
////			Cursor c=dba.query("AppsTable",null , null, null, null, null,"AppName");
//			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+" AND AppTimerStatus="+0+"", null);
//			string = new String[c.getCount()];
//			if(c.moveToFirst())
//			{
//				for (int j = 0; j < string.length; j++) 
//				{
//					string[j] = c.getString(1);
////					LogWrite.d(tag, "-->"+string[j]);
//					c.moveToNext();
//				}
//			}
//			c.close();
//		}
//		catch (ExceptionDTO e)
//		{
//			LogWrite.d(tag,e.toString());
//		}
//		return string;
//	}
	
	public String[] GetApplicationsFromDataBaseInBlockedTime()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+"", null);
			string = new String[c.getCount()];
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					string[j] = c.getString(1);
//					LogWrite.d(tag, "-->"+string[j]);
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	/**********************************************************/
	public String[] GetpackageFromDataBaseTime()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable ", null);
			string = new String[c.getCount()];
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					string[j] = c.getString(1);
//					LogWrite.d(tag, "-->"+string[j]);
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	
	public String[] GetApplicationFromDataBaseTime2()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable ", null);
			string = new String[c.getCount()];
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					string[j] = c.getString(0);
//					LogWrite.d(tag, "-->"+string[j]);
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	
	/*******************************************************************************/
	public void UpdateAppStatus(String app_name,int status)
	{
		try
		{
			LogWrite.d(tag, "UPDATE AppsTable SET AppStatus="+status+" WHERE AppName='"+app_name+"'");
			dba.execSQL("UPDATE AppsTable SET AppStatus="+status+" WHERE AppName='"+app_name+"'");
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+"", null);
			if(c.moveToFirst())
			{
				for (int j = 0; j < c.getCount(); j++) 
				{
					LogWrite.d(tag, "-->"+c.getString(1)+ "   " +c.getString(2));
					c.moveToNext();
				}
			}	
			c.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void updatePresentDataCounter(String AppPackageName, long PresentDataUsed)
	{
		try
		{
//			LogWrite.d(tag, dba+"");
			
			Cursor c1=dba.rawQuery("SELECT previousDataUsed FROM AppsTable WHERE AppPackageName='"+AppPackageName+"'", null);
			long previousDataUse =0;
			if(c1!=null)
			{
				c1.moveToFirst();
				
				
				previousDataUse = Long.parseLong(c1.getString(0));
			}
//			int previousDataUse =0;
			
			LogWrite.d(tag, "UPDATE AppsTable SET PresentDataUsed='"+(PresentDataUsed+previousDataUse)+"' WHERE AppPackageName='"+AppPackageName+"'");
//			dba.execSQL("UPDATE AppsTable SET PresentDataUsed="+(PresentDataUsed+previousDataUse)+" WHERE AppPackageName='"+AppPackageName+"'");
//			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+"", null);
//			c.close();
		}
		catch (Exception e) 
		{
			Log.e(tag, e.toString());
		}
	}
	
	public void DeleteApp(String appname)
	{
		try
		{
			LogWrite.d(tag, "Delete from AppsTable WHERE AppName='"+appname+"'");
			dba.execSQL("Delete from AppsTable WHERE AppName='"+appname+"'");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void DeleteAppbyPackage(String package_name)
	{
		try
		{
			LogWrite.d(tag, "Delete from AppsTable WHERE AppPackageName='"+package_name+"'");
			dba.execSQL("Delete from AppsTable WHERE AppPackageName='"+package_name+"'");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}