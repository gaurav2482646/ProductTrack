package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;

import com.kochartech.gizmodoctor.POJO.KeyValueDTO;

public class GUISetNotificationPreference extends MyPreference {

	// private final String PREFERENCE_NAME = "gizmodoctor";
	// private final int PREFERENCE_MODE = 0;

	private final String KEY_BATTERY_LEVEL = "gui_battery_level";
	// private final String KEY_BATTERY_LVELE_LIMIT = "gui_battey_level_limit";
	private final String KEY_BATTERY_TEMPERATURE = "gui_battery_temperature";
	// private final String KEY_BATTERY_TEMPERATURE_LIMIT =
	// "gui_battery_temperature_limit";
	private final String KEY_CPU_TEMPERATURE = "gui_cpu_temperature";
	private final String KEY_DATA_CONNECTION = "gui_data_connection";
	private final String KEY_RAM_USAGE = "gui_ram_usage";
	private final String KEY_RAM_USAGE_LIMIT = "gui_ram_usage_limit";
	private final String KEY_CPU_USAGE = "gui_cpu_usage";
	private final String KEY_CPU_USAGE_LIMIT = "gui_cpu_usage_limit";
	private final String KEY_SETTING_NOTIFY = "gui_setting_notify";
	private final String KEY_SETTING_COUNT_TO_NOTIFY = "gui_setting_count_to_notify";

	public final boolean DEFAULTVALUE = true;
	public final int DEFAULTVALUE_LEVELLIMIT = 10;
	public final int DEFAULTVALUE_BATTERYTEMPLIMIT = 40;
	public final int DEFAULTVALUE_CPUTEMPLIMIT = 65;
	public final int DEFAULTVALUE_RAMLIMIT = 80;
	public final int DEFAULTVALUE_CPULIMIT = 80;

	// private Context context;
	// private SharedPreferences myPreference;
	// private Editor editor;

	public GUISetNotificationPreference(Context context) {
		super(context);
		// this.context = context;
		// myPreference = context.getSharedPreferences(PREFERENCE_NAME,
		// PREFERENCE_MODE);
		// editor = myPreference.edit();
	}

	public void setCPUTemperature(boolean value) {
		editor.putBoolean(KEY_CPU_TEMPERATURE, value).commit();
	}

	public boolean getCPUTemperature() {
		return myPreference.getBoolean(KEY_CPU_TEMPERATURE, DEFAULTVALUE);
	}

	public int getCPUTemperatureThresholdLimit() {
		return DEFAULTVALUE_CPUTEMPLIMIT;
	}

	public void setBatteryLevel(boolean value) {
		editor.putBoolean(KEY_BATTERY_LEVEL, value).commit();
	}

	public boolean getBatteryLevel() {
		return myPreference.getBoolean(KEY_BATTERY_LEVEL, DEFAULTVALUE);
	}

	public int getBatteryLevelThresholdLimit() {
		return DEFAULTVALUE_LEVELLIMIT;
	}

	public void setBatteryTemperature(boolean value) {
		editor.putBoolean(KEY_BATTERY_TEMPERATURE, value).commit();
	}

	public boolean getBatteryTemperature() {
		return myPreference.getBoolean(KEY_BATTERY_TEMPERATURE, DEFAULTVALUE);
	}

	public int getBatteryTemperatureThresholdLimit() {
		return DEFAULTVALUE_BATTERYTEMPLIMIT;
	}

	public void setDataConnection(boolean value) {
		editor.putBoolean(KEY_DATA_CONNECTION, value).commit();
	}

	public boolean getDataConnection() {
		return myPreference.getBoolean(KEY_DATA_CONNECTION, DEFAULTVALUE);
	}

	// ram notification on/off
	public void setRAMUsageNotification(boolean value) {
		editor.putBoolean(KEY_RAM_USAGE, value).commit();
	}

	public boolean isRAMUsageNotificationOn() {
		return myPreference.getBoolean(KEY_RAM_USAGE, false);
	}

	public void setRAMThreashHoldLimit(int value) {
		editor.putInt(KEY_RAM_USAGE_LIMIT, value).commit();
	}

	public int getRAMThreashHoldLimit() {
		return myPreference.getInt(KEY_RAM_USAGE_LIMIT, DEFAULTVALUE_RAMLIMIT);
	}

	public KeyValueDTO getKEYRAMThreashHoldLimit() {
		KeyValueDTO keyValueDTO = new KeyValueDTO(KEY_RAM_USAGE_LIMIT,
				getRAMThreashHoldLimit());
		return keyValueDTO;
	}

	// cpu notification on/off
	public void setCPUUsageNotification(boolean value) {
		editor.putBoolean(KEY_CPU_USAGE, value).commit();
	}

	public boolean isCPUUsageNotificationOn() {
		return myPreference.getBoolean(KEY_CPU_USAGE, false);
	}

	public void setCPUThreashHoldLimit(int value) {
		editor.putInt(KEY_CPU_USAGE_LIMIT, value).commit();
	}

	public int getCPUThreashHoldLimit() {
		return myPreference.getInt(KEY_CPU_USAGE_LIMIT, DEFAULTVALUE_CPULIMIT);
	}

	public KeyValueDTO getKEYCPUThreashHoldLimit() {
		KeyValueDTO keyValueDTO = new KeyValueDTO(KEY_CPU_USAGE_LIMIT,
				getCPUThreashHoldLimit());
		return keyValueDTO;
	}

	// Setting Notification on/off
	public void setSettingNotification(boolean value) {
		editor.putBoolean(KEY_SETTING_NOTIFY, value).commit();
	}

	public boolean isSettingNotificationOn() {
		return myPreference.getBoolean(KEY_SETTING_NOTIFY, DEFAULTVALUE);
	}

	public void setSettingKeyToNotify(int value) {
		editor.putInt(KEY_SETTING_COUNT_TO_NOTIFY, value).commit();
	}

	public int getSettingKeyToNotify() {
		return myPreference.getInt(KEY_SETTING_COUNT_TO_NOTIFY, 0);
	}
}
