package com.kochartech.devicemax.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.kochartech.devicemax.Activities.RecieverActivity;

public class Service2 extends BroadcastReceiver 
{
	Context context = null;
	@Override
	public void onReceive(Context _context, Intent intent) 
	{
		Intent in = new Intent(_context,RecieverActivity.class);
		in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		_context.startActivity(in);
	}

}
