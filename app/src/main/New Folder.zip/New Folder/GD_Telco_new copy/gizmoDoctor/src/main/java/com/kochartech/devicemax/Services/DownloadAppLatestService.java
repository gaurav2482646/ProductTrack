package com.kochartech.devicemax.Services;

/**
 * Created by gauravjeetsingh on 29/3/18.
 */

import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.app.DownloadManager.Request;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.widget.Toast;

import java.io.File;

public class DownloadAppLatestService extends Service {
    private static final String TAG = "DownloadAppService";
    public static DownloadManager downloadMgr;
    public static long enqueueID;
    public static boolean flag = false;
    static String fileURL;
    static String appName = "";

    @Override
    public IBinder onBind(Intent arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        Log.d(TAG, "onstart command");
        try {
            Log.d(TAG, " DownloadAppLatestService in on receive");
            new DownloadApp(getApplicationContext(), intent.getStringExtra("AppPath")).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } catch (Exception e) {
            Log.d(TAG, "Exception DownloadAppLatestService: " + e.toString());
        }
        return Service.START_STICKY;
    }
    @Override
    public void onDestroy() {
        Log.d(TAG, "on destroy called. ");
        super.onDestroy();
    }

    protected int installNormal(String appPath, Context context) {
        try {
            Log.d(TAG, "apppath: " + appPath);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            if (Build.VERSION.SDK_INT > 23) {
                Log.d(TAG, "if");
                Uri apkURI = FileProvider.getUriForFile(context, context.getPackageName() + ".provider", new File(appPath));
                intent.setDataAndType(apkURI, "application/vnd.android.package-archive");

            } else {
                Log.d(TAG, "else");
                intent.setDataAndType(Uri.fromFile(new File(appPath)), "application/vnd.android.package-archive");
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(intent);

            return 1;
        } catch (Exception e) {
            Log.d(TAG, "exception while install normal: " + e.toString());
            return 0;
        }
    }

    private void isDirectoryPresent(String directoryPath) {
        try {
            File file = new File(directoryPath);
            boolean flag = file.exists();
            Log.d(TAG, directoryPath + " exist is  " + flag);
            if (!flag) {
                file.mkdirs();
            }
        } catch (Exception ex) {
            Log.d(TAG, ex.toString());
        }
    }

    class DownloadApp extends AsyncTask<Object, String, String> {
        Context context;

        public DownloadApp(Context context, String filePath) {
            this.context = context;

            fileURL = filePath;

        }

        @Override
        protected String doInBackground(Object... params) {
            try {
                appName = fileURL.substring(fileURL.lastIndexOf("/") + 1, fileURL.length());

                Log.d(TAG, "appname: " + appName + "   file to dowload " + fileURL);

                //fileURL = "http://mdm.kochar.co:8080/Applications/Apps/104/Android/orderpad.apk";

                downloadMgr = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

                Request request = new Request(Uri.parse(fileURL));

                request.setTitle("Downloading:" + appName);

                String destinationFileName = fileURL.substring(fileURL.lastIndexOf("/") + 1);

                destinationFileName = destinationFileName.replace(" ", "_");

                String destinationPath = Environment.getExternalStorageDirectory() + "/MDM";

                isDirectoryPresent(destinationPath);

                Log.d(TAG, "00");

                Uri destination = Uri.fromFile(new File(destinationPath + File.separator + destinationFileName));

                Log.d(TAG, "11");

                request.setDestinationUri(destination);

                Log.d(TAG, "12");

                enqueueID = downloadMgr.enqueue(request);

                Log.d(TAG, "enque id " + enqueueID);

                publishProgress(appName + " Downloading has started");


            } catch (Exception e) {
                publishProgress("Exception: " + e.toString());

                Log.e(TAG, "exception: " + e.toString());
            }
            return "";
        }

        @Override
        protected void onProgressUpdate(String... values) {

            super.onProgressUpdate(values);
            Toast.makeText(context, values[0], Toast.LENGTH_LONG).show();

        }
    }

    public class BroadcastAsync extends AsyncTask<Object, String, String> {
        Context context;
        Intent intent = null;

        public BroadcastAsync(Context context, Intent intent) {
            this.context = context;
            this.intent = intent;
        }

        @Override
        protected void onProgressUpdate(String... values) {

            super.onProgressUpdate(values);
            Toast.makeText(context, values[0], Toast.LENGTH_LONG).show();


        }

        @Override
        protected String doInBackground(Object... params) {
            try {
                Log.d(TAG, "on recieve ");
                String action = intent.getAction();
                Log.d(TAG, "action " + action);
                if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                    Query query = new Query();
                    query.setFilterById(enqueueID);
                    //downloadMgr = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    Cursor cursor = downloadMgr.query(query);
                    if (cursor.moveToFirst()) {
                        int columnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);

                        if (DownloadManager.STATUS_SUCCESSFUL == cursor.getInt(columnIndex)) {
                            Log.d(TAG, "Download is complete");
                            publishProgress(appName + " has downloaded successfully");


                            String localUri = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
                            Log.d(TAG, "Download is complete AT" + localUri + " Path: " + Uri.parse(localUri).getPath());
                            String uriString = Uri.parse(localUri).getPath();
                            File file = new File(uriString);

                            if (file.exists()) {
                                Log.d(TAG, "File exists");
                                Log.d(TAG, "File size>" + file.length());

                                // to install apk
                                Thread.sleep(2 * 1000);
                                int resultNormal = installNormal(uriString, context);
                                if (resultNormal == 1) {
                                    Log.d(TAG, "installNormal instllation has successfully ");
                                } else {
                                    Log.d(TAG, "installNormal instllation has failed");

                                }
                            } else {
                                Log.e(TAG, "File not exists");
                            }

                            // stopSelf();

                        } else if (DownloadManager.STATUS_FAILED == cursor.getInt(columnIndex)) {
                            Log.d(TAG, cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_REASON)));
                            Toast.makeText(context, "Download failed ", Toast.LENGTH_LONG).show();
                            publishProgress("Download failed");
                        } // end else if status== failed
                    } // end if c.moveTonext
                } else {
                    Log.d(TAG, "file not downloaded");
                }

//       stopSelf();
            } catch (Exception ex) {
                Log.e(TAG, "error " + ex.toString());
            }
            return "";
        }

    }


}