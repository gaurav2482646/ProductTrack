package com.kochartech.gizmodoctor.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;

public class MobileInfoAdapter extends BaseAdapter {
	private Context context;
	private String[] infoTypeStringArray, infoValueStringArray;
	private LayoutInflater infaltor;
	private boolean gpsFlag = false;
	private int[] icons = { R.drawable.deviceinfo_brand,
			R.drawable.deviceinfo_model, R.drawable.deviceinfo_osversion,
			R.drawable.deviceinfo_carrier, R.drawable.deviceinfo_network,
			R.drawable.deviceinfo_ram, R.drawable.deviceinfo_storage,
			R.drawable.deviceinfo_imei, R.drawable.deviceinfo_battery,
			R.drawable.appversion };

	public MobileInfoAdapter(Context context, String[] infoType,
			String[] infoValue, boolean gpsFlag) {
		this.context = context;
		this.gpsFlag = gpsFlag;
		this.infoTypeStringArray = infoType;
		this.infoValueStringArray = infoValue;
		infaltor = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return infoTypeStringArray.length;
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return infoTypeStringArray[arg0];
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int arg0, View arg1, ViewGroup arg2) {
		View view = arg1;
		TextView infoType, infoValue;
		ImageView imageView;

		view = infaltor.inflate(R.layout.rowui_deviceinfo_adapter, arg2, false);

		imageView = (ImageView) view.findViewById(R.id.icon);
		infoType = (TextView) view.findViewById(R.id.mobileinfo_infotype);
		infoValue = (TextView) view.findViewById(R.id.mobileinfo_infovalue);
		if (gpsFlag) {
			imageView.setVisibility(View.GONE);
			infoType.setTextColor(Color.parseColor("#7F7F7F"));
		} else {
			imageView.setImageResource(icons[arg0]);
		}
		infoType.setText(infoTypeStringArray[arg0]);
		infoValue.setText(infoValueStringArray[arg0]);

		return view;
	}

}
