package com.kochartech.gizmodoctor.Fragment;

import java.text.SimpleDateFormat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.DataBase.AppInfo;
import com.kochartech.gizmodoctor.DataBase.AppUsageInfo;
import com.kochartech.gizmodoctor.DataBase.DataSource_AppsInfo;
import com.kochartech.gizmodoctor.DataBase.DataSource_CPUUsage;
import com.kochartech.gizmodoctor.DataBase.DataSource_RAMUsage;
import com.kochartech.gizmodoctor.HelperClass.LineGraph2;
import com.kochartech.gizmodoctor.HelperClass.SettingsToast;

public class GUIUsageStats extends Fragment implements MyFragment,
		OnClickListener {

	public static final String KEY_APPNAME = "appname";
	public static final String KEY_PKGNAME = "pkgname";
	private String appName = null;
	private String TAG = "GUIUsageStats";
	private Context context;
	private View rootView;
	private LinearLayout container_LineGraphCPU, container_LineGraphRAM;
	private DataSource_CPUUsage dsCPUUsage;
	private DataSource_RAMUsage dsRAMUsage;
	private DataSource_AppsInfo dsAppInfo;
	private SimpleDateFormat timeForamt = new SimpleDateFormat("dd/mm/yy");
	private PackageManager pm;
	private PackageInfo pkgInfo;
	private String appInstallTime, appVersion;
	private Button btForceStop;
	private String pkgName;
	private SettingsToast settingToast;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		LogWrite.d(TAG, "onCreate Work");
		initDataSet();
		// initDataSetLineGraphRAM();
		initUi(inflater, container);

		return rootView;
	}

	public String getAppFirstInstallTime() {
		String appInstallTime = "NA";
		if (pkgInfo != null) {
			long applicationInstallTime = pkgInfo.firstInstallTime;
			appInstallTime = timeForamt.format(applicationInstallTime);
		}
		return appInstallTime;
	}

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		pm = context.getPackageManager();

		try {

			Bundle bundle = getArguments();
			Object value = getValue(bundle, KEY_APPNAME);
			Object pkgName = getValue(bundle, KEY_PKGNAME);
			if (pkgName != null) {
				this.pkgName = (String) pkgName;
				LogWrite.d(TAG, "pkgName: " + pkgName);
			}
			if (value != null) {
				this.appName = (String) value;
				LogWrite.d(TAG, "AppName: " + appName);

				dsAppInfo = DataSource_AppsInfo.getInstance(context);
				appInfo = dsAppInfo.queryAppInfo(this.appName);
				try {
					pkgInfo = pm.getPackageInfo(appInfo.getPkName(), 0);
					appInstallTime = getAppFirstInstallTime();
				} catch (NameNotFoundException e) {
				}

				/*
				 * CPU Usage Detail
				 */
				dsCPUUsage = DataSource_CPUUsage.getInstance(context);
				appCPUUsageInfo = dsCPUUsage.queryAppDetail(appInfo.getRowId());

				/*
				 * RAM Usage Detail
				 */
				dsRAMUsage = DataSource_RAMUsage.getInstance(context);
				appRAMUsageInfo = dsRAMUsage.queryAppDetail(appInfo.getRowId());

				// appInfo = dsAppInfo.queryAppInfo(appName);
				//
				// if (appInfo != null) {
				// LogWrite.d(TAG, "appInfo != null");
				// String name = appInfo.getAppName();
				// String pkgName = appInfo.getPkName();
				// int rowId = appInfo.getRowId();
				// LogWrite.d(TAG, name + ":" + pkgName + ":" + rowId);
				// }
				//

				// if (appCPUUsageInfo != null) {
				// LogWrite.d(TAG, "appCPUUsageInfo != null");
				// LogWrite.d(TAG, "appId: " + appCPUUsageInfo.getAppId());
				// ArrayList<AppUsageDTO> dtoList =
				// appCPUUsageInfo.getAppUsage();
				// LogWrite.d(TAG, "num diagnose: " + dtoList.size());
				//
				// for (AppUsageDTO appDTO : dtoList) {
				// int appUsage = appDTO.getAppUsage();
				// long usageTime = appDTO.getUsageTime();
				// LogWrite.d(TAG, appUsage + ":" + usageTime);
				// }
				// }

				// if (appRAMUsageInfo != null) {
				// LogWrite.d(TAG, "appRAMUsageInfo != null");
				// LogWrite.d(TAG, "appId: " + appRAMUsageInfo.getAppId());
				// ArrayList<AppUsageDTO> dtoList =
				// appRAMUsageInfo.getAppUsage();
				// LogWrite.d(TAG, "num diagnose: " + dtoList.size());
				//
				// for (AppUsageDTO appDTO : dtoList) {
				// int appUsage = appDTO.getAppUsage();
				// long usageTime = appDTO.getUsageTime();
				// LogWrite.d(TAG, appUsage + ":" + usageTime);
				// }
				// }
			}
		} catch (Exception e) {
			LogWrite.d("init", "ExceptionDTO.. " + e);
		}

	}

	private TextView labelCPUTxtView, labelRAMTxtView;

	// private TextView appNameTxtView;
	public void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_appusagedetail,
				container, false);

		labelCPUTxtView = (TextView) rootView.findViewById(R.id.labelCPUUsage);
		labelRAMTxtView = (TextView) rootView.findViewById(R.id.labelRAMUsage);

		labelCPUTxtView.setText(appName + ": CPU Usage");
		labelRAMTxtView.setText(appName + ": RAM Usage");

		container_LineGraphCPU = (LinearLayout) rootView
				.findViewById(R.id.containerLineGraph_CPUUsage);
		container_LineGraphRAM = (LinearLayout) rootView
				.findViewById(R.id.containerLineGraph_RAMUsage);

		cpuLineGrapph = new LineGraph2(context);
		ramLineGraph = new LineGraph2(context);

		container_LineGraphCPU.addView(cpuLineGrapph.getView(),
				new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.FILL_PARENT,
						LinearLayout.LayoutParams.FILL_PARENT, 1));
		container_LineGraphRAM.addView(ramLineGraph.getView(),
				new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.FILL_PARENT,
						LinearLayout.LayoutParams.FILL_PARENT, 1));

		// int numOfDiagnose = appRAMUsageInfo.getAppUsage().size();

		cpuLineGrapph.setAxsisPoint(appCPUUsageInfo.getAppUsage());
		cpuLineGrapph.refresh(false);

		ramLineGraph.setAxsisPoint(appRAMUsageInfo.getAppUsage());
		ramLineGraph.refresh(false);

		btForceStop = (Button) rootView.findViewById(R.id.btForceStop);
		btForceStop.setOnClickListener(this);

		if (appName.equalsIgnoreCase("Android System")
				|| appName.equalsIgnoreCase("System UI")) {
			btForceStop.setEnabled(false);
		}

	}

	public Object getValue(Bundle bundle, String Key) {
		Object value = null;
		if (bundle != null) {
			if (bundle.containsKey(Key))
				value = bundle.getString(Key);
		}
		return value;

	}

	private AppInfo appInfo;
	private AppUsageInfo appCPUUsageInfo, appRAMUsageInfo;
	private LineGraph2 cpuLineGrapph, ramLineGraph;

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "Application Usage";
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		if (v.getId() == R.id.btForceStop) {
			try {
				Intent intent = new Intent(
						android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
				intent.setData(Uri.parse("package:" + pkgName));
				// intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.addCategory(Intent.CATEGORY_DEFAULT);
				LogWrite.d(TAG, "pkgName:" + pkgName);
				startActivity(intent);
				LogWrite.d(TAG, "Activity Started Sucessfully");

				settingToast = new SettingsToast(getActivity());
				settingToast.show(0);
			} catch (Exception e) {
				LogWrite.d(TAG, "" + e.getMessage());
			}
		}
	}

	private void setToastVisibilty(boolean flag) {
		if (settingToast != null) {
			settingToast.setToastVisibility(flag);
		}
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		setToastVisibilty(false);
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		setToastVisibilty(true);
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		setToastVisibilty(false);
	}
}
