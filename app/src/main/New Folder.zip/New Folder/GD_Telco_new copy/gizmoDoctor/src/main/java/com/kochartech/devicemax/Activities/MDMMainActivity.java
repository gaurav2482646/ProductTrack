package com.kochartech.devicemax.Activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.AsyncTask.Status;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.preference.PreferenceManager;
import android.provider.Browser;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.support.v4.app.Fragment;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.kochartech.MyLibs.StorageInfo;
import com.kochartech.devicemax.APNPackage.APNReader;
import com.kochartech.devicemax.DualSimPackage.TelephonyInfo;
import com.kochartech.devicemax.Receivers.StartTestReceiver;
import com.kochartech.devicemax.Services.DownloadAppLatestService;
import com.kochartech.devicemax.ToastPackage.SettingsToast;
import com.kochartech.devicemax.Utility.APNProfileManipulator;
import com.kochartech.devicemax.Utility.CameraDTO;
import com.kochartech.devicemax.Utility.Filename;
import com.kochartech.devicemax.Utility.GetHandsetInfoRemoteMax;
import com.kochartech.devicemax.Utility.HandsetLocation;
import com.kochartech.devicemax.Utility.LocationHelperClass;
import com.kochartech.devicemax.Utility.MonitorDTO;
import com.kochartech.devicemax.Utility.MyDataBaseHandlerClass;
import com.kochartech.devicemax.Utility.OpenSettingsUtility;
import com.kochartech.devicemax.Utility.Response;
import com.kochartech.devicemax.dm.ConvertHashTableToString;
import com.kochartech.devicemax.dm.DmCommand;
import com.kochartech.devicemax.dto.AckCommand;
import com.kochartech.devicemax.dto.AckDTO;
import com.kochartech.devicemax.dto.AppConstant;
import com.kochartech.devicemax.dto.AppDTO;
import com.kochartech.devicemax.dto.Apps;
import com.kochartech.devicemax.dto.CommandDTO;
import com.kochartech.devicemax.dto.ResponseDTO;
import com.kochartech.devicemax.dto.SendResponseDTO;
import com.kochartech.gizmodoctor.Activity.BringApplicationToForeground;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.DataBase.AppInfo;
import com.kochartech.gizmodoctor.DataBase.AppUsageInfo;
import com.kochartech.gizmodoctor.DataBase.DataSource_AppsInfo;
import com.kochartech.gizmodoctor.DataBase.DataSource_BatteryUsage;
import com.kochartech.gizmodoctor.DataBase.DataSource_CPUUsage;
import com.kochartech.gizmodoctor.DataBase.DataSource_DischargeRate;
import com.kochartech.gizmodoctor.DataBase.DataSource_RAMUsage;
import com.kochartech.gizmodoctor.Fragment.AccelerometerBallTestFragment;
import com.kochartech.gizmodoctor.Fragment.CameraTestFragment;
import com.kochartech.gizmodoctor.Fragment.DisplayFragment;
import com.kochartech.gizmodoctor.Fragment.KeysTestFragment;
import com.kochartech.gizmodoctor.Fragment.MicTestActivity;
import com.kochartech.gizmodoctor.Fragment.MultiTouchTestFragment;
import com.kochartech.gizmodoctor.Fragment.MyFragment;
import com.kochartech.gizmodoctor.Fragment.ProximitySensorTestFragment;
import com.kochartech.gizmodoctor.Fragment.SoundTestActivity;
import com.kochartech.gizmodoctor.Fragment.TouchTestFragment;
import com.kochartech.gizmodoctor.HelperClass.HardwareUtility;
import com.kochartech.gizmodoctor.HelperClass.HardwareUtility.HardwareType;
import com.kochartech.gizmodoctor.POJO.AppUsageDTO;
import com.kochartech.gizmodoctor.Preferences.MonitoringPreference;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.deviceissues.AccessibilityHelper;
import com.kochartech.gizmodoctor.deviceissues.ActionPerformPrefrence;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager.Process;
import com.kochartech.gizmodoctor.deviceissues.RunningAppDTO;
import com.kochartech.library.Application.KTInstalled;
import com.kochartech.library.Battery.KTBatteryInfo;
import com.kochartech.library.CPU.KTApplicationInfo;
import com.kochartech.library.CPU.KTUsageCPU;
import com.kochartech.library.Device.KTDeviceInfo;
import com.kochartech.library.Memory.KTUsageRAM;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

enum Commands {
    START_SESSION, OPEN_SETTING, GET_APP, END_SESSION, HANDSET_INFO, INSTALL_APP, UNINSTALL_APP, HARDWARE_TEST, GET_LOCATION, FLAG_SETTING, HARDWARE_INFO
}

/**
 * Main Class to be shown when user Installs Application. Responsible for almost
 * all functionality of the application.
 */
@SuppressWarnings("deprecation")
public class MDMMainActivity extends Fragment implements OnClickListener,
        MyFragment, OnCommandListener {

    public static Activity mdmActivity;
    public static int signalStrength;//TODO
    public static boolean longAsyncFlag = true;
    // ------ SINGLETON-------
    public static MDMMainActivity ins;
    static int[] response;
    static String strTest = "";
    static String[] arrayMessagepart = new String[10];
    private static String app_name = "";
    private static int timeoutCount = 0;
    // End
    private static String tag = "MDMMainActivity1";
    private final LocationListener locationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            if (location != null) {
                LogWrite.d(tag,
                        "12 location.getAccuracy->" + location.getAccuracy());
                LogWrite.d(tag,
                        "12 location.getAltitude->" + location.getAltitude());
                LogWrite.d(tag,
                        "12 location.getBearing->" + location.getBearing());
                LogWrite.d(tag, "12 location.getExtras->"
                        + location.getExtras().keySet());
                LogWrite.d(tag,
                        "12 location.getLatitude->" + location.getLatitude());
                LogWrite.d(tag,
                        "12 location.getLongitude->" + location.getLongitude());
                LogWrite.d(tag,
                        "12 location.getProvider->" + location.getProvider());
                LogWrite.d(tag, "12 location.getSpeed->" + location.getSpeed());
                LogWrite.d(tag, "12 location.getTime->" + location.getTime());
            } else {
                LogWrite.d(tag, "nulllllllllllllllllllllllllllllllll");
            }

        }

        public void onProviderDisabled(String provider) {
            LogWrite.d(tag, provider + "<<<<<<<<<<<<<<<<<<<<");
        }

        public void onProviderEnabled(String provider) {
            LogWrite.d(tag, provider + "<<<<<");
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
            LogWrite.d(tag,
                    provider + "<<<<<" + status + "----" + extras.keySet());
        }
    };
    public boolean forceLock = false;
    public boolean session = true;
    Dialog alertDialog;
    // ------ INTEGERS-------
    int currentflagApp = 0;
    int countPendingRequest = 0;
    int cNo = 0;
    int seqNo = 0, msgParts = 0;
    int uidCounter = 0;
    int seqCounter = 0;
    int sleepInterval = 20000;
    boolean roamingStatus = false;
    boolean monitoringDisabled = false;
    String data = "";
    String mobileNumber = "";
    String UID = "";
    String model;
    String brand;
    String command = "";
    String uidComaparitive = "", masterUid = "";
    String dummy = "";
    String phoneNumberToSend = "";
    String SERVERURL = "";
    String logtoShow = "";
    // ------ ASYNCTASK-------
    MyLongRunningTask ob = null;
    Context context;
    // ------ SHARED PREFERENCES-------
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences = null;
    MyDataBaseHandlerClass myDataBase = null;
    // UI controls
    Button exitButton = null;
    ScrollView scrollview = null;
    // ------MAIN METHOD STARTS HERE-------
    // public BatteryChangeReceiver batteryChangeReceiver;
    SettingsToast settingsToast;
    // KTBatteryApps batteryApps;
    Fragment fragment;
    View rootView;
    Dialog error_dialog = null;
    // boolean sendTextMsgToSleep = false;
    private boolean isToLogError = true;
    private int batteryLevel = 0;
    // ------ LONG-------
    private long enqueue;
    // ------ BOOLEAN-------
    private boolean settingErrorFlag = false;
    // ------ STRINGS-------
    private String softwareVersion = "";
    private String Id = "";
    private String currentOperatorName = "";
    private String IMSI = "";
    private String networkState = "";
    // For app Version Variables declaration
    private String appVersion = "";
    // For Mobile Number SharePreferences
    private SharedPreferences mobilePreferences;
    private String hardware_name = "";
    private Response jsonResponse = new Response();

    // ------URI-------
    // public static final Uri APN_TABLE_URI = Uri
    // .parse("content://telephony/carriers");
    // public static final Uri PREFERRED_APN_URI = Uri
    // .parse("content://telephony/carriers/preferapn");
//    private MonitorDTO monitorDTO = new MonitorDTO();
    SendResponseDTO sendHWTestResponseDTO;

    // "http://192.161.0.207/gh_crm_service/GHCRMService.svc/ghcrmclient/gizmodoctor/savehardwaretestresponse";
    private List<ResponseDTO> mResponseDTOList;
    private String server_url; // =
    // ------ HASH TABLE-------
    private Hashtable<String, String> htDMCommand;

    // @Override
    // public View onCreateView(LayoutInflater inflater, ViewGroup container,
    // Bundle savedInstanceState) {
    // // TODO Auto-generated method stub
    // return super.onCreateView(inflater, container, savedInstanceState);
    // }
    // ------ BROADCAST RECIEVER-------
    private BroadcastReceiver infoReceiver = null;
    private TextView logText = null;
    private WifiManager wifi;
    // @Override
    // public boolean isToUpdateUi() {
    // // TODO Auto-generated method stub
    // return false;+
    // }
    private boolean optimizingFlag = false;
    // private EditText editText_PhoneNumber;

    // private Button btConnect,btDisconnect;
    // private boolean iSR(Context context)
    // {
    // String sClassName;
    // ActivityManager manager = (ActivityManager) context
    // .getSystemService(Context.ACTIVITY_SERVICE);
    // for (RunningServiceInfo service : manager
    // .getRunningServices(Integer.MAX_VALUE))
    // {
    // sClassName = service.service.getClassName();
    // }
    // return false;
    // }

    // public static APNOperations apnOperations;
    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */

    // @Override
    // protected void onStart()
    // {
    // super.onStart();
    // LogWrite.d(tag, "onStart >: apn operations");
    // }

    public static MDMMainActivity GetIns() {

        if (ins == null) {
            ins = new MDMMainActivity();
        }
        return ins;
    }

    /**
     * Starts Session with the Service on Permitted by the User. Called if
     * ResponseDTO found with <b>STRTSESS</b><br>
     *
     * @return
     */
    public static int isDeviceRooted() {
        try {
            java.lang.Process process = Runtime.getRuntime().exec("su");
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }

    public static int getCellID(Context context) {
        int ci = 0;
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);
            String NetworkMode = getNetworkMode(context);
            // LogWrite.d(TAG, "NetworkMode=="+NetworkMode);
            if (NetworkMode.equalsIgnoreCase("GSM")) {
                GsmCellLocation location = (GsmCellLocation) telephonyManager
                        .getCellLocation();
                int CELLID = location.getCid();
                ci = CELLID & 0xffff;
            } else if (NetworkMode.equalsIgnoreCase("CDMA")) {
                CdmaCellLocation location1 = (CdmaCellLocation) telephonyManager
                        .getCellLocation();
                int cellID = location1.getBaseStationId();
                ci = cellID & 0xffff;
            }
            System.out.println("ci===" + ci);
        } catch (Exception e) {

            e.printStackTrace();
        }

        /*
         * if(ci==0) { cell=""; } else { cell=""+ci; }
         */
        return ci;

    }

    // @Override
    // public void onBackPressed()
    // {
    // super.onBackPressed();
    // }

    // @Override
    // public boolean onKeyDown(int keyCode, KeyEvent event)
    // {
    // LogWrite.d(tag, "Test back" + "not back" + event);
    // if (keyCode == KeyEvent.KEYCODE_BACK)
    // {
    // LogWrite.d(tag, "Test back" + "back");
    // return false;
    // }
    // LogWrite.d(tag, "Test back" + "not back");
    // return super.onKeyDown(keyCode, event);
    // }

    public static String getNetworkMode(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);
            int phoneType = telephonyManager.getPhoneType();
            switch (phoneType) {
                case TelephonyManager.PHONE_TYPE_NONE:
                    return "NONE";

                case TelephonyManager.PHONE_TYPE_GSM:
                    return "GSM";

                case TelephonyManager.PHONE_TYPE_CDMA:
                    return "CDMA";
            }
        } catch (Exception e) {
            LogWrite.d("GetHandsetInfo", "exception " + e);
        }
        return "";
    }

    public static int getLocationAreaCode(Context context) {
        int loc = -1;
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);
            String NetworkMode = getNetworkMode(context);
            if (NetworkMode.equalsIgnoreCase("GSM")) {
                GsmCellLocation location = (GsmCellLocation) telephonyManager
                        .getCellLocation();
                loc = location.getLac();
            } else if (NetworkMode.equalsIgnoreCase("CDMA")) {
                CdmaCellLocation location1 = (CdmaCellLocation) telephonyManager
                        .getCellLocation();
                loc = location1.getNetworkId();
            }
            return loc;
        } catch (Exception e) {

            e.printStackTrace();
        }

        return loc;
    }

    /**
     * Retrieves User Location Address by manipulating Latitude & longitude.
     *
     * @param lat
     * @param lon
     * @return String
     */
    public static String getUserLocation(String lat, String lon) {
        String userlocation = null;
        String readUserFeed = readUserLocationFeed(lat.trim() + ","
                + lon.trim());
        try {
            JSONObject Strjson = new JSONObject(readUserFeed);
            JSONArray jsonArray = new JSONArray(Strjson.getString("results"));
            userlocation = jsonArray.getJSONObject(1)
                    .getString("formatted_address").toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.i("User Location ", userlocation);
        return userlocation;
    }

    public static String readUserLocationFeed(String address) {
        String TAG = "readUserLocationFeed";
        StringBuilder builder = new StringBuilder();
        HttpClient client = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(
                "http://maps.google.com/maps/api/geocode/json?latlng="
                        + address + "&sensor=false");
        try {
            HttpResponse response = client.execute(httpGet);
            StatusLine statusLine = response.getStatusLine();
            int statusCode = statusLine.getStatusCode();
            if (statusCode == 200) {
                HttpEntity entity = response.getEntity();
                InputStream content = entity.getContent();
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(content));
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
            } else {
                LogWrite.d(TAG, "Failed to download file");
            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return builder.toString();
    }

    static void encrypt() throws IOException, NoSuchAlgorithmException,
            NoSuchPaddingException, InvalidKeyException {
        // Here you read the cleartext.
        FileInputStream fis = new FileInputStream(
                Environment.getExternalStorageDirectory() + "/cleartext.txt");
        // This stream write the encrypted text. This stream will be wrapped by
        // another stream.
        FileOutputStream fos = new FileOutputStream(
                Environment.getExternalStorageDirectory() + "/encrypted.txt");

        // Length is 16 byte
        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(),
                "AES");
        // Create cipher
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, sks);
        // Wrap the output stream
        CipherOutputStream cos = new CipherOutputStream(fos, cipher);
        // Write bytes
        int b;
        byte[] d = new byte[8];
        while ((b = fis.read(d)) != -1) {
            cos.write(d, 0, b);
        }
        // Flush and close streams.
        cos.flush();
        cos.close();
        fis.close();
    }

    /*
     * Decrypt Files
     */
    static void decrypt() throws IOException, NoSuchAlgorithmException,
            NoSuchPaddingException, InvalidKeyException {
        FileInputStream fis = new FileInputStream(
                Environment.getExternalStorageDirectory() + "/encrypted.txt");

        FileOutputStream fos = new FileOutputStream(
                Environment.getExternalStorageDirectory() + "/decrypted.txt");
        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(),
                "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, sks);
        CipherInputStream cis = new CipherInputStream(fis, cipher);
        int b;
        byte[] d = new byte[8];
        while ((b = cis.read(d)) != -1) {
            fos.write(d, 0, b);
        }
        fos.flush();
        fos.close();
        cis.close();
    }

    public static boolean isOnline(Context con, String url) {

        ConnectivityManager cm = (ConnectivityManager) con
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            LogWrite.d(tag, "Network is Connected.... ");
            if (url != null) {

                return pingURLforCheck(url);
            } else {
                return true;
            }
        } else {
            LogWrite.d(tag, "Network is Connected.... ");
            return false;
        }
    }

    public static boolean pingURLforCheck(String u) {
        try {
            URL url = new URL("http://" + u);
            HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
            urlc.setConnectTimeout(500); // Time is in Milliseconds to wait for
            // ping response
            urlc.connect();
            if (urlc.getResponseCode() == 200) {
                Log.i(tag,
                        "* ping  with ResponseCode: " + urlc.getResponseCode());
                return true;
            } else {
                Log.i(tag, "* Connection is too slow with ResponseCode: "
                        + urlc.getResponseCode());
                return false;
            }
        } catch (MalformedURLException e1) {
            Log.e(tag, "Error in URL to ping" + e1);
            return false;
        } catch (IOException e) {
            Log.e(tag, "Error in ping" + e);
            return false;
        }
    }

    public static boolean isLocationEnabled(Context mContext) {
        LocationManager locationMgr = (LocationManager) mContext
                .getSystemService(Context.LOCATION_SERVICE);
        boolean GPS_Sts = locationMgr
                .isProviderEnabled(LocationManager.NETWORK_PROVIDER)
                || locationMgr.isProviderEnabled(LocationManager.GPS_PROVIDER);
        return GPS_Sts;
    }

    private static String getAddressByLatLng(Context context, String lat, String lng) {
        String address = "";
        Log.d(tag, "getAddressByLatLng: called");
    /*
    to get the address by giving lat and lng
     */
        try {
            Geocoder geocoder = new Geocoder(context, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(Double.valueOf(lat), Double.valueOf(lng), 1);
            if (addresses != null && addresses.size() > 0) {
                Log.e(tag, "onLocationChanged: " + addresses.get(0).toString() + " size " + addresses.get(0).getAddressLine(0));
                address = addresses.get(0).getAddressLine(0);
            /*for (int i=0 ; i < addresses.get(0).getMaxAddressLineIndex(); i++)
            {
                address = addresses.get(0).getAddressLine(i);
                Log.e(tag,"Address: "+address);
            }*/
            }

        } catch (Exception e) {
            Log.e(tag, "exception: " + e.toString());
        }
        return address;
    }

    @Override
    public String getTitle() {
        // TODO Auto-generated method stub
        return "Device Remote";
    }

    public void onClick(View view) {
        // if (view.getId() == R.id.btConnect) {
        //
        // LinearLayout liearLayout = (LinearLayout)
        // rootView.findViewById(R.id.uiConnect);
        // liearLayout.setVisibility(LinearLayout.GONE);
        //
        //
        // LinearLayout liearLayout1 = (LinearLayout)
        // rootView.findViewById(R.id.uiDisconnect);
        // liearLayout1.setVisibility(LinearLayout.VISIBLE);
        //
        // phoneNumberToSend = editText_PhoneNumber.getText().toString();
        // addtoLog("Session Number: " + phoneNumberToSend);
        //
        // sharedPreferences = PreferenceManager
        // .getDefaultSharedPreferences(context);
        // boolean threadStatus = sharedPreferences.getBoolean(
        // "threadrunning", false);
        // if (!threadStatus) {
        // ob = new MyLongRunningTask();
        // /*
        // * Ashish*******************************
        // */
        // AsyncTask<Activity, String, String> result = ob
        // .execute(mdmActivity);
        // threadStatus = true;
        // LogWrite.d("thread status", "we start it");
        // editor = sharedPreferences.edit();
        // editor.putBoolean("threadrunning", true);
        // editor.commit();
        // }
        // // when activity is started again ,not for the very first time
        // else {
        // // when thread stopped in-between running state,then it will be
        // // started again
        // if (ob != null) {
        // Status st = ob.getStatus();
        // LogWrite.d("thread status is true",
        // "and object is not null");
        // if (st == Status.FINISHED || st == Status.PENDING) {
        // AsyncTask<Activity, String, String> result = ob
        // .execute(mdmActivity);
        // LogWrite.d("thread status is true",
        // "and is finished or pending");
        // }
        // }
        // // when activity is started (when oncreate is called for first
        // // time )i.e activity launched
        // else {
        // ob = new MyLongRunningTask();
        // AsyncTask<Activity, String, String> result = ob
        // .execute(mdmActivity);
        // LogWrite.d("thread status is true",
        // "and object is  null so we initialize it");
        // }
        //
        // }
        // }
        // else if (view.getId() == R.id.btDisconnect) {
        //
        // }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().getWindow().setFlags(0xFFFFFFFF,
                LayoutParams.FLAG_KEEP_SCREEN_ON);
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        // requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Startup Work
        // new CreateTableAsync().execute(getApplicationContext());

        fragment = this;

        LayoutInflater layoutInflator = (LayoutInflater) getActivity()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        rootView = layoutInflator.inflate(R.layout.activity_mdmmain, container,
                false);

        // setContentView(R.layout.main);
        mdmActivity = getActivity();
        context = getActivity();
        monitoringDisabled = false;
        LogWrite.d(tag, "Inside Oncreate..");
        settingsToast = SettingsToast.openSingleInstance();
        ins = this;

        // try
        // {
        // batteryChangeReceiver = new BatteryChangeReceiver();
        // registerReceiver(batteryChangeReceiver,new
        // IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        //
        // }
        // catch (ExceptionDTO e1)
        // {
        // // TODO Auto-generated catch block
        // e1.printStackTrace();
        // }

        // ------RETRIEVE SERVER URL-------
        SERVERURL = AppConstant.SERVER_URL;
        server_url = getString(R.string.HardwareUrl).trim();
        Bundle bundle = getArguments();
        // Intent myintent = getIntent();
        // Intent myintent1 = getIntent();

        try {
            phoneNumberToSend = bundle.getString("phoneNumber");
        } catch (Exception e) {

        }
        /*
         * Ashish
         */
        // getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
        // WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        exitButton = (Button) rootView.findViewById(R.id.btDisconnect);
        logText = (TextView) rootView.findViewById(R.id.log_text);

        logText.setEnabled(false);
        scrollview = (ScrollView) rootView.findViewById(R.id.scroll_view);
        logText.setMovementMethod(new ScrollingMovementMethod());

        addtoLog("Connecting...");
        SharedPreferences preferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        String mobileString = preferences.getString("ph", "");
        addtoLog("Session Number: " + mobileString);
        /*
         * Ashish
         */
        exitButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                try {
                    LogWrite.d(tag, "Exit button is preessed...");
                    new AlertDialog.Builder(v.getContext())
                            .setTitle("GizmoDoctor")
                            .setMessage(
                                    "Are you sure you want to end the session?")
                            .setPositiveButton("Yes",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(
                                                DialogInterface dialog,
                                                int whichButton) {
                                            Intent in = new Intent();
                                            in.putExtra("name", "blank");
                                            // getAcsetResult(1, in);
                                            if (ob != null) {
                                                ob.cancel(true);
                                                sharedPreferences = PreferenceManager
                                                        .getDefaultSharedPreferences(context);
                                                editor = sharedPreferences
                                                        .edit();
                                                editor.putBoolean(
                                                        "threadrunning", false);
                                                editor.commit();
                                                LogWrite.d(tag,
                                                        "Stopping running network service on Exit.");
                                            } else {
                                                LogWrite.d(tag,
                                                        "Service Already stopped. No need to stop on Exit.");
                                            }
                                            // LogWrite.d(tag,"Unregistering reciever.....");
                                            if (infoReceiver != null) {
                                                context.unregisterReceiver(infoReceiver);
                                                infoReceiver = null;
                                            }
                                            LogWrite.d(tag,
                                                    "Battery Reciever Unregistered");
                                            // Here I am Setting the Requestcode
                                            // 1,
                                            // you can put according to your
                                            // requirement
                                            // boolean flag =
                                            // iSR(getApplicationContext());
                                            // if(flag)
                                            // stopService(new
                                            // Intent(getApplicationContext(),ServiceEg.class));
                                            RegisterUserActivity.promptNumberActivity = null;
                                            DecisionMakerActivity.activityStatusFlag = false;
                                            // Intent intent = new
                                            // Intent(getApplicationContext(),
                                            // DiagnosisService.class);
                                            // stopService(intent);
                                            // RegisterUserActivity.GetInstance().stopAlarmDiagnosis(getApplicationContext());
                                            // // Intent intent1 = new
                                            // Intent(getApplicationContext(),
                                            // GpsProviderService.class);
                                            // // stopService(intent1);
                                            // RegisterUserActivity.GetInstance().stopServiceAlarm(getApplicationContext());
                                            // RegisterUserActivity.GetInstance().stopBackUpAlarm(getApplicationContext());
                                            // RegisterUserActivity.GetInstance();
                                            // if(batteryChangeReceiver!=null)
                                            // {
                                            // LogWrite.d(tag,
                                            // "Exit Button Clickd  -----------------5");
                                            // unregisterReceiver(batteryChangeReceiver);
                                            // LogWrite.d(tag,
                                            // "Exit Button Clickd  -----------------6");
                                            // }
                                            // mdmActivity.finish();

                                            // NavDrawerActivity activity =
                                            // (NavDrawerActivity)
                                            // getActivity();
                                            // activity.removeFragment(fragment);

                                            // getActivity().getFragmentManager().
                                            FragmentListener fragmentListener = (FragmentListener) getActivity();
                                            fragmentListener
                                                    .onItemClicked(
                                                            FragmentListener.actionRemove,
                                                            fragment);

                                        }
                                    })
                            .setNeutralButton("No",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(
                                                DialogInterface dlg, int sumthin) {
                                            DecisionMakerActivity.activityStatusFlag = true;
                                        }
                                    }).show();
                } catch (Exception e) {
                    LogWrite.d("AAshish", "ExceptionDTO..." + e);
                }
            }
        });// Exit Button Finish*****************

        LogWrite.d(tag, "1 pressed...");
        if (((android.telephony.TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId() != null) {
            Id = ((android.telephony.TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId(); // imei
        } else {
            Id = "";
            WifiManager wifiManager = (WifiManager) context
                    .getSystemService(Context.WIFI_SERVICE);

            WifiInfo wiFiInfo = (WifiInfo) wifiManager.getConnectionInfo();

            Id = wiFiInfo.getMacAddress();

            Id = Id.replace(":", "");
        }

        /*
         * Ashish **********
         */
        softwareVersion = android.os.Build.VERSION.RELEASE;
        // App Version Name Aman
        try {
            PackageInfo pinfo = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), 0);
            // int versionNumber = pinfo.versionCode;
            appVersion = pinfo.versionName;
        } catch (Exception e) {
            LogWrite.d(tag, "App Version ExceptionDTO ---> " + e.toString());
        }
        // End App Version

        currentOperatorName = ((android.telephony.TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE))
                .getNetworkOperatorName();
        model = android.os.Build.MODEL;
        brand = android.os.Build.BRAND;
        if (((android.telephony.TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE)).getSubscriberId() != null) {
            IMSI = ((android.telephony.TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE))
                    .getSubscriberId();
        } else {
            IMSI = "0";
        }

        /*
         * Ashish Sharma***************
         */
        try {
            infoReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context arg, Intent intent) {
                    int rawlevel = intent.getIntExtra("level", -1);
                    int scale = intent.getIntExtra("scale", -1);

                    if (rawlevel >= 0 && scale > 0) {
                        batteryLevel = (rawlevel * 100) / scale;
                    }
                }
            };
            IntentFilter informationfilter = new IntentFilter(
                    Intent.ACTION_BATTERY_CHANGED);
            mdmActivity.registerReceiver(infoReceiver, informationfilter);
            PhoneStateListener phonestate = new PhoneStateListener() {
                public void onSignalStrengthChanged(int asu) {
                    signalStrength = asu;
                    int dbm = -113 + (2 * asu);
                    dbm = dbm * (-1);
                    if (dbm >= 60 && dbm < 70) {
                        dbm = 95;
                    } else if (dbm >= 70 && dbm < 87) {
                        dbm = 85;
                    } else if (dbm >= 87) {
                        dbm = 60;
                    }
                    signalStrength = dbm;
                }
            };
            // unregisterReceiver(infoReceiver);
            sharedPreferences = PreferenceManager
                    .getDefaultSharedPreferences(context);
            boolean threadStatus = sharedPreferences.getBoolean(
                    "threadrunning", false);
            // when app is started for very first time
            /*
             * Ashish*************************************
             */
            if (!threadStatus) {
                ob = new MyLongRunningTask();
                /*
                 * Ashish*******************************
                 */
                AsyncTask<Activity, String, String> result = ob
                        .execute(mdmActivity);
                threadStatus = true;
                LogWrite.d("thread status", "we start it");
                editor = sharedPreferences.edit();
                editor.putBoolean("threadrunning", true);
                editor.commit();
            }
            // when activity is started again ,not for the very first time
            else {
                // when thread stopped in-between running state,then it will be
                // started again
                if (ob != null) {
                    Status st = ob.getStatus();
                    LogWrite.d("thread status is true",
                            "and object is not null");
                    if (st == Status.FINISHED || st == Status.PENDING) {
                        AsyncTask<Activity, String, String> result = ob
                                .execute(mdmActivity);
                        LogWrite.d("thread status is true",
                                "and is finished or pending");
                    }
                }
                // when activity is started (when oncreate is called for first
                // time )i.e activity launched
                else {
                    ob = new MyLongRunningTask();
                    AsyncTask<Activity, String, String> result = ob
                            .execute(mdmActivity);
                    LogWrite.d("thread status is true",
                            "and object is  null so we initialize it");
                }

            }

            /*
             * Ashish*************************
             */
            ((android.telephony.TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE)).listen(
                    phonestate, PhoneStateListener.LISTEN_SIGNAL_STRENGTH);

        } catch (Exception exc) {
            Toast.makeText(mdmActivity, exc.toString(), Toast.LENGTH_SHORT)
                    .show();
        }
        // finish();

        // btConnect = (Button) rootView.findViewById(R.id.btConnect);
        // btConnect.setOnClickListener(this);
        // btDisconnect = (Button) rootView.findViewById(R.id.btDisconnect);

        // editText_PhoneNumber = (EditText)
        // rootView.findViewById(R.id.editText_PhoneNumber);
        // btDisconnect.setOnClickListener(this);

        // getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        return rootView;
    }// ******** onCreate Finsih

    // @Override
    // public void onDetach() {
    // // TODO Auto-generated method stub
    // super.onDetach();
    // Toast.makeText(context,"onDetach Work", Toast.LENGTH_LONG).show();
    // if (ob != null)
    // {
    // ob.cancel(true);
    // sharedPreferences =
    // PreferenceManager.getDefaultSharedPreferences(context);
    // editor = sharedPreferences.edit();
    // editor.putBoolean("threadrunning", false);
    // editor.commit();
    // LogWrite.d(tag, "Stopping running network service on Exit.");
    // }
    // else
    // {
    // LogWrite.d(tag, "Service Already stopped. No need to stop on Exit.");
    // }
    // LogWrite.d(tag,"Unregistering reciever.....");
    // context.unregisterReceiver(infoReceiver);
    // RegisterUserActivity.promptNumberActivity = null;
    // DecisionMakerActivity.activityStatusFlag = false;
    // }
    public void onDestroy() {

        // Toast.makeText(context,"onDestroy Work", Toast.LENGTH_LONG).show();
        ob.cancel(true);
        try {
            if (infoReceiver != null)
                context.unregisterReceiver(infoReceiver);
            // Intent startMain = new Intent(Intent.ACTION_MAIN);
            // startMain.addCategory(Intent.CATEGORY_HOME);
            // startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // startMain.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            // startActivity(startMain);

            // mdmActivity.finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
        setCount(10000);
        super.onDestroy();

    }

    public int getCount() {
        return countPendingRequest;
    }

    public void setCount(int countPendingRequest) {
        this.countPendingRequest = countPendingRequest;
    }

    @Override
    public void onResume() {
        super.onResume();
        LogWrite.d("tag>>>>>", "On resume called");
        longAsyncFlag = true;
        if (mdmActivity == null) {
            mdmActivity = MDMMainActivity.GetIns().getActivity();
        }
        MyLongRunningTask task = new MyLongRunningTask();
        task.execute(mdmActivity);

        // SettingsToast settingsToast = new SettingsToast();
        //
        // final InputMethodManager imm = (InputMethodManager)
        // getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        // imm.hideSoftInputFromWindow(getActivity().getWindow().getDecorView().getWindowToken(),
        // 0);

        settingsToast = SettingsToast.openSingleInstance();
        settingsToast.setActivityActiveState(false);
        if (!monitoringDisabled) {
            checkforMobileData();
        }
    }

    @Override
    public void onPause() {
        // SettingsToast settingsToast = new SettingsToast();
        longAsyncFlag = false;
        settingsToast = SettingsToast.openSingleInstance();
        settingsToast.setActivityActiveState(false);
        super.onPause();

        // Toast.makeText(getActivity(), "onPause", Toast.LENGTH_LONG).show();
    }

    /*
     * gsm cell id, -1 if unknown, 0xffff max legal value
     */

    /**
     * Parses the message according to the Message given and Make Decision.
     *
     * @param message
     */
    public void processCommand(String message, Context context) {
        String tag = "processCommand";
        LogWrite.d(tag, "Message is " + message);
        htDMCommand = new ConvertHashTableToString().putInHashTable(message);
        try {
            LogWrite.d(tag, "DATA   -> processCommand Start");
            LogWrite.d(tag, "DATA   -> " + htDMCommand.get("CMD-" + 1));
        } catch (Exception e) {
            LogWrite.d(tag, "DATA   -> Exceptionnm" + e);
        }
        LogWrite.d(tag, "----------------------------------------------");
        // get no of commandsgyui./tycD-1:STRTSESS;CMDINF-1:<>;
        cNo = Integer.parseInt(htDMCommand.get("CNo"));
        String messageInAction = "MN:" + htDMCommand.get("MN") + ";CNo:" + cNo
                + ";";

        boolean flag = true; // this flag is to test whether acknowledgment will
        // be sent or not
        for (int i = 1; i <= cNo; i++) {
            command = htDMCommand.get("CMD-" + i);
            mobileNumber = htDMCommand.get("MN");
            LogWrite.d(tag, "-----------------------" + command);
            if (command.equals("STRTSESS")) {
                try {
                    LogWrite.d(tag, "DATA   -> StartSession Work");
                    addtoLog("Connected Success.");
                    addtoLog("Start Session Received.");
                    LogWrite.d(tag, "mobileNumber-> " + mobileNumber);
                    try {
                        mdmActivity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                startActivity(new Intent(mdmActivity,
                                        MyHiddenActivity.class));
                            }
                        });
                    } catch (Exception e) {
                        LogWrite.e(tag, "ExceptionDTO...." + e);
                    }
                    // startActivity(new Intent(MDMMainActivity.this,
                    // MyHiddenActivity.class));
                    // new AlertDialog.Builder(ins)
                    // .setTitle("Device Max")
                    // .setMessage(
                    // "Do You want to give remote access of your device through device max application?")
                    // .setPositiveButton("Yes",
                    // new DialogInterface.OnClickListener() {
                    // public void onClick(
                    // DialogInterface dialog,
                    // int whichButton) {
                    // createStartSessiondata();
                    //
                    // }
                    // })
                    // .setNeutralButton("No",
                    // new DialogInterface.OnClickListener() {
                    // public void onClick(
                    // DialogInterface dlg, int sumthin) {
                    // Toast.makeText(
                    // getApplicationContext(),
                    // "Application Denied Access ",
                    // Toast.LENGTH_SHORT).show();
                    // finish();
                    // }
                    // }).show();         // startActivity(new Intent(MDMMainActivity.this,

                } catch (Exception ex) {
                    Toast.makeText(mdmActivity, ex.toString(),
                            Toast.LENGTH_SHORT).show();
                }
            } // end if start session
            else if (command.equals("HNSTINFO")) {
                LogWrite.d("HandsetInfo", "Found");
                createStartSessiondata1();
            } else if (command.equals("MONTRAPP")) {
                LogWrite.d(tag, "Monitoring App Command Received....");
                addtoLog("Device in Monitoring for 24 hours from now.");
                MonitoringPreference prefrence = new MonitoringPreference(
                        context);
                prefrence.resetAll();
                prefrence.setMonitoringStartStatus(true);
            }/*
             * else if (command.equals("KILLAPP")) { tag = "KILLAPP";
             * LogWrite.d(tag, "Kill Apps Command Received...."); String appName
             * = htDMCommand.get("Q1"); LogWrite.d(tag, "htDmCommand : " +
             * appName); addtoLog("Kill Application requested by Server.");
             *
             * try { KillProcess process = new KillProcess(context); if
             * (appName.equals("ALL")) { process.killAll(); } else { String
             * processName = process.getProcessName(appName);
             * process.killProcess(processName); } } catch (ExceptionDTO e) {
             * LogWrite.e(tag, "KillAppException : " + e.toString());
             * addtoLog("Could not Kill Application."); }
             *
             * }
             */ else if (command.equals("KILLAPP")) {
                tag = "OptimizeDevice";
                LogWrite.d(tag, "Kill Apps Command Received....");
                String appName = htDMCommand.get("Q1");
                LogWrite.d(tag, "htDmCommand : " + appName);
                addtoLog("Optimizing device requested by Server.");
                if (appName.equals("ALL")) {
                    optimizingDevice();
                }

                // try {
                // KillProcess process = new KillProcess(context);
                // if (appName.equals("ALL")) {
                // process.killAll();
                // } else {
                // String processName = process.getProcessName(appName);
                // process.killProcess(processName);
                // }
                // } catch (ExceptionDTO e) {
                // LogWrite.e(tag, "KillAppException : " + e.toString());
                // addtoLog("Could not Kill Application.");
                // }

            } else if (command.equals("HWTEST")) {
                tag = "HardwareTest";
                LogWrite.d(tag,
                        "Hardware Test Command Received Command Received....");
                String hardware = htDMCommand.get("A1");
                LogWrite.d(tag, "Hardware : " + hardware);
                addtoLog(hardware + " hardware test requested by Server.");
                String uid = htDMCommand.get("UID");
                String[] uids = uid.split("_");
//                monitorDTO.setSessionId(Long.parseLong(uids[0]));
//                monitorDTO.setMessageId(Long.parseLong(uids[1]));

//                checkHardwareTest(monitorDTO, hardware);
            } else if (command.equals("EDTPRF")) {
                // String tag ="EDTTest";
                flag = false;
                addtoLog("Edit APN Profile requested by server.");
                int id = editProfileCommandResponse();
                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                if (id == 1) {
                    addtoLog("APN Profile edited successfully.");
                    messageInAction += ";CMDINF-" + i + ":<1>;";
                } else {
                    addtoLog("Could not edit APN Profile.");
                    messageInAction += ";CMDINF-" + i + ":<0>;";
                }
                LogWrite.d("EDTTest", "MessageTest");
                LogWrite.d("Editprofile Message ===", messageInAction);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } // end else if edit profile

            else if (command.equals("SPDTST")) {
                flag = true;
                LogWrite.d(tag, "Speed Test Command Enters");
                String commandStatus = htDMCommand.get("A1");
                LogWrite.d(tag, "Command Status -----------> " + commandStatus);
                if (commandStatus.equalsIgnoreCase("start")) {
                    SharedPreferences sharePrefernce = PreferenceManager
                            .getDefaultSharedPreferences(mdmActivity);
                    Editor editor = sharePrefernce.edit();
                    editor.putInt("count", 0);
                    editor.commit();
                    LogWrite.d(tag, "Speed Test Starts");
                    setSpeedPreferences(messageInAction);
                    startSpeedTest();
                } else if (commandStatus.equalsIgnoreCase("stop")) {
                    LogWrite.d(tag, "Speed Test Stop");
                    Intent startTestIntent = new Intent(mdmActivity,
                            StartTestReceiver.class);
                    AlarmManager alarmManager = (AlarmManager) context
                            .getSystemService(Context.ALARM_SERVICE);
                    PendingIntent pendingstartTestIntent = PendingIntent
                            .getBroadcast(context, 232324, startTestIntent, 0);
                    alarmManager.cancel(pendingstartTestIntent);
                    SharedPreferences sharePrefernce = PreferenceManager
                            .getDefaultSharedPreferences(context);
                    Editor editor = sharePrefernce.edit();
                    editor.putInt("count", 0);
                    editor.commit();
                    LogWrite.d("Ashis1", "Receiver Stoped ");
                }
                addtoLog("Speed Test " + commandStatus + "+ed by server.");
            } // end else if SpeedTest

            else if (command.equals("GETHIST")) {
                flag = false;
                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                messageInAction += ";CMDINF-" + i + ":";
                messageInAction += getbrowserHistoryUpdated();
                addtoLog("Browser History information requested and sent to server.");

            } else if (command.equals("CRTPRF")) {
                flag = false;
                addtoLog("Create APN Profile requested by server.");
                try {
                    createProfileCommandResponse();

                    messageInAction += "CMD-" + i + ":";
                    messageInAction += htDMCommand.get("CMD-" + i);
                    messageInAction += ";CMDINF-" + i + ":<1>;";

                } catch (Exception ex) {
                    Toast.makeText(mdmActivity, ex.toString(), 2000).show();
                }

            } // end else if crt prf
            else if (command.equals("DELPRF")) {
                addtoLog("Delete APN Profile requested by server.");
                boolean deleteFlagResponse = false;
                flag = false;
                int resp = 2;

                String profileName;

                // fetching the no of profiles to delete

                int profileCount = Integer
                        .parseInt(htDMCommand.get("DPRCount"));
                int[] response = new int[profileCount + 1];
                if (profileCount >= 1) {
                    for (int ii = 1; ii <= profileCount; ii++) {
                        profileName = htDMCommand.get("DA" + ii);
                        if (profileName != null) {
                            resp = APNProfileManipulator.GetInstance(
                                    mdmActivity).deleteCommandResponse(
                                    profileName);
                            response[ii] = resp;
                            Log.i(tag, "delete");
                        }

                    }
                    for (int k = 1; k <= profileCount; k++) {
                        if (response[k] == 0) {
                            deleteFlagResponse = true;
                        }
                    }
                    messageInAction += "CMD-" + i + ":";
                    messageInAction += htDMCommand.get("CMD-" + i);
                    if (deleteFlagResponse == true) {
                        messageInAction += ";CMDINF-" + i + ":<0>;";

                    } else {
                        messageInAction += ";CMDINF-" + i + ":<1>;";
                    }
                }

            } // end else if del profile

            else if (command.equals("DELALLPRF")) {
                addtoLog("Delete APN Profile requested by server.");
                flag = false;
                APNProfileManipulator.GetInstance(mdmActivity).deleteAll();
                // deleteAll();

                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                messageInAction += ";CMDINF-" + i + ":<1>;";
            } // end else if delall profile

            else if (command.equals("GETAPPS")) {

                flag = false;
                MyDataBaseHandlerClass myDataBase = new MyDataBaseHandlerClass(
                        context, "operators.db", null, 1);
                myDataBase.getWritableDatabase();
                myDataBase.createTable(context);
                myDataBase.close();
                // getApps();
                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                messageInAction += ";CMDINF-" + i + ":";
                // command=htDMCommand.get("CMD-"+i);
                messageInAction += getAppsNew();

                LogWrite.d("Remote", "GetApps:" + messageInAction);
                addtoLog("Application information requested by and sent to server.");
                // finish();
            } // end if getapps
            else if (command.equals("ENDSESS")) {
                addtoLog("End Session requested by server.");

                mdmActivity.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        // TODO Auto-generated method stub

                        // Intent intent = new Intent(Intent.ACTION_MAIN);
                        // intent.addCategory(Intent.CATEGORY_HOME);
                        // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        // intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        // startActivity(intent);

                        FragmentListener fragmentListener = (FragmentListener) getActivity();
                        fragmentListener.onItemClicked(
                                FragmentListener.actionRemove,
                                new MDMMainActivity());
                        // mdmActivity.finish();
                        // System.exit(-1);
                    }
                });
                // Intent intent = new Intent(Intent.ACTION_MAIN);
                // intent.addCategory(Intent.CATEGORY_HOME);
                // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                // intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                // startActivity(intent);

                // android.os.Process.killProcess(android.os.Process.myPid());
                // System.runFinalizersOnExit(true);

            } // end if endsess
            else if (command.equals("UPDAPP")) {
                addtoLog("Update Application requested by server.");
            } else if (command.equals("INSAPPS")) {
                final String TAG1 = "InstalApp";
                addtoLog("Install application requested by server.");
                // String fileName="";
                LogWrite.d(TAG1, "IN command " + command);
                flag = false;
                boolean installFlagResponse = false;
                int installAppCount = Integer.parseInt(htDMCommand
                        .get("IAPCount"));
                LogWrite.d(TAG1, "--------------------1");
                int[] response = new int[installAppCount + 1];
                LogWrite.d(TAG1, "--------------------2");
                for (int count = 1; count <= installAppCount; count++) {
                    // final int currentCount = count;
                    String url = htDMCommand.get("IAPB" + count);
                    LogWrite.d(TAG1, "--------------------3");
                    final String fileURL = "http://" + url;
                    LogWrite.d(TAG1, fileURL);
                    String fileName = fileURL.substring(fileURL
                            .lastIndexOf("/") + 1);
                    LogWrite.d(TAG1, "<<LLLLLLLL>>" + fileName);

                    SharedPreferences sharedPreferences = context
                            .getSharedPreferences("GetFile", 0);
                    Editor editor = sharedPreferences.edit();
                    editor.putString("FileName", fileName);
                    editor.commit();
                    String softwareVersion = android.os.Build.VERSION.RELEASE;
                    String deviceVersion = 2.3 + "";
                    LogWrite.d(TAG1, "software version==" + softwareVersion
                            + "given version ==" + deviceVersion);

                    LogWrite.d(TAG1, " File name is " + fileName);

                    URL urls = null;
                    try {
                        urls = new URL(fileURL);
                    } catch (MalformedURLException e1) {
                        LogWrite.d(TAG1,
                                "MalformedURLException : " + e1.toString());
                    }

                    int length;

                    InputStream inputStream = null;
                    try {
                        inputStream = urls.openStream();
                    } catch (IOException e) {

                        e.printStackTrace();
                    }

                    DataInputStream dataInputStream = new DataInputStream(
                            inputStream);

                    byte[] buffer = new byte[1024];

                    String destinationPath = context.getFilesDir() + "/";

                    isDirectoryPresent(destinationPath);

                    File file = new File(destinationPath + File.separator
                            + fileName);

                    LogWrite.d(tag, "path " + file.getAbsolutePath());

                    FileOutputStream fileOutputStream = null;
                    try {
                        fileOutputStream = context.openFileOutput(fileName,
                                Context.MODE_WORLD_WRITEABLE
                                        | Context.MODE_WORLD_READABLE);
                    } catch (FileNotFoundException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    try {
                        while ((length = dataInputStream.read(buffer)) > 0) {
                            fileOutputStream.write(buffer, 0, length);
                        }
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    // LogWrite.d(tag, "File downloaded at " + getFilesDir() +
                    // "/"
                    // + fileName);

                    try {
                        fileOutputStream.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(
                            Uri.fromFile(new File(context.getFilesDir() + "/"
                                    + fileName)),
                            "application/vnd.android.package-archive");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    response[count] = 1;
                }// End for loop(installAppCount)

                for (int k = 1; k <= installAppCount; k++) {

                    if (response[k] == 0) {

                        installFlagResponse = true;

                    }
                }
                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                if (installFlagResponse == true) {
                    messageInAction += ";CMDINF-" + i + ":<0>;";

                } else {
                    messageInAction += ";CMDINF-" + i + ":<1>;";
                }

            } // end else if install app
            else if (command.equals("UNIAPPS")) {
                addtoLog("Uninstall Application requested by server.");
                LogWrite.d(tag, "IN command " + command);
                flag = false;
                getApps();
                boolean unInstallFlagResponse = false;
                String appName = "";
                int unInstallAppCount = Integer.parseInt(htDMCommand
                        .get("UAPCount"));
                int[] response = new int[unInstallAppCount + 1];
                for (int count = 1; count <= unInstallAppCount; count++) {
                    appName = htDMCommand.get("UAPA" + count);
                    LogWrite.d(tag, "App Name ----> " + appName);
                    // response[count] = unInstallApp(appName);
                    // response[count] = unInstallRooted(appName);
                    response[count] = unInstallApp(appName);
                    LogWrite.d(tag, "response[count] ----> " + response[count]);
                    if (response[count] == 1) {
                        LogWrite.d(tag, "response[count] = 1");
                        app_name = appName;
                        myDataBase = new MyDataBaseHandlerClass(context,
                                "operators.db", null, 1);
                        myDataBase.getWritableDatabase();
                        myDataBase.DeleteApp(appName);
                        myDataBase.close();
                        unInstallFlagResponse = false;
                    }

                }
                for (int k = 1; k <= unInstallAppCount; k++) {
                    if (response[k] == 0) {
                        unInstallFlagResponse = true;
                    }
                }
                LogWrite.d(tag, "---------->" + messageInAction);
                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                LogWrite.d(tag, "---------->" + messageInAction);
                if (unInstallFlagResponse == true) {
                    addtoLog("Could not Uninstall Application.");
                    messageInAction += ";CMDINF-" + i + ":<0>;";
                } else {

                    addtoLog("Application Uninstalled.");
                    messageInAction += ";CMDINF-" + i + ":<1>;";
                }

                LogWrite.d(tag, "---------->" + messageInAction);

            } // end else if command.equals(UNIAPP)

            else if (command.equals("LOCK")) {
                addtoLog("Lock command requested by server.");
            }// end else if lock

            // else if (command.equals("WIPHSET")) {
            // flag = false;
            // addtoLog("Wipe Handset requested by server.");
            // // Toast.makeText(getApplicationContext(), "WIPHSET--->   ",
            // // Toast.LENGTH_LONG).show();
            // LogWrite.d(tag, "---------->" + messageInAction);
            // messageInAction += "CMD-" + i + ":";
            // messageInAction += htDMCommand.get("CMD-" + i);
            // if (htDMCommand.get("A1").equals("1")) {
            // Intent in = new Intent(this,
            // DeviceAdminSamplee.Controller.class);
            // in.putExtra("value", 1);
            // in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // startActivity(in);
            // messageInAction += ";CMDINF-" + i + ":<1>;";
            // } else {
            // messageInAction += ";CMDINF-" + i + ":<0>;";
            // }
            // LogWrite.d(tag, "---------->" + messageInAction);
            //
            // }// end else if wipe
            else if (command.equals("LCKHSET")) {
                // addtoLog("Lock Handset requested by server.");
                // flag = false;
                // // Toast.makeText(getApplicationContext(), "LCKHSET--->   ",
                // // Toast.LENGTH_LONG).show();
                // LogWrite.d(tag, "---------->" + messageInAction);
                // messageInAction += "CMD-" + i + ":";
                // LogWrite.d(tag, htDMCommand.toString());
                // messageInAction += htDMCommand.get("CMD-" + i);
                // if (htDMCommand.get("A1").equals("1")) {
//                 ServiceEg.ScreenLockFlag = true;
                //
//                 MyPreference.setBoolean(getApplicationContext(),"LCKHSET",true);
                //
                // forceLock = true;
                // // ServiceEg.ScreenLockFlag = true;
                // addtoLog("Handset Locked.");
//                 Intent intent = new Intent(getApplicationContext(),
//                 DisplayPasswordScreen.class);
                // intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                // | Intent.FLAG_ACTIVITY_CLEAR_TOP
                // | Intent.FLAG_ACTIVITY_NEW_TASK);
                // // getApplicationContext().startActivity(intent);
                // messageInAction += ";CMDINF-" + i + ":<1>;";
                // } else if (htDMCommand.get("A1").equals("0")) {
                // ServiceEg.ScreenLockFlag = false;
                // MyPreference.setBoolean(getApplicationContext(),"LCKHSET",false);
                // // ServiceEg.ScreenLockFlag = true;
                // messageInAction += ";CMDINF-" + i + ":<0>;";
                // }
                // LogWrite.d(tag, "---------->" + messageInAction);
            }// end else if wipe

            // else if (command.equals("FLAGAPPS")) {
            // addtoLog("Lock/Unlock Application requested by server.");
            // getApps();
            // flag = false;
            // // Toast.makeText(getApplicationContext(), "FLGAPPS--->   ",
            // // Toast.LENGTH_LONG).show();
            // LogWrite.d(tag, "---------->" + messageInAction);
            // messageInAction += "CMD-" + i + ":";
            // LogWrite.d(tag, htDMCommand.toString());
            // messageInAction += htDMCommand.get("CMD-" + i);
            // int AppCount = 1;
            // boolean AppFlag = true;
            // myDataBase = new MyDataBaseHandlerClass(
            // getApplicationContext(), "operators.db", null, 1);
            // myDataBase.getWritableDatabase();
            // // LogWrite.d(tag, AppFlag+"<-------------"
            // // +htDMCommand.contains("A"+AppCount+""));
            // LogWrite.d(tag, htDMCommand.toString());
            // while (AppFlag) {
            // String str = "A" + AppCount;
            // // LogWrite.d(tag, str);
            //
            // if (htDMCommand.containsKey(str)) {
            // myDataBase.UpdateAppStatus(htDMCommand.get("A"
            // + AppCount), Integer.parseInt(htDMCommand
            // .get("C" + AppCount)));
            //
            // if (Integer.parseInt(htDMCommand.get("C" + AppCount)) == 1)
            // {
            // addtoLog(htDMCommand.get("A"+ AppCount)+" Unlocked." );
            // } else
            // {
            // addtoLog(htDMCommand.get("A"+ AppCount)+" Locked." );
            // }
            //
            // AppCount++;
            // } else {
            // AppFlag = false;
            // }
            // }
            // myDataBase.close();
            //
            // messageInAction += ";CMDINF-" + i + ":<1>;";
            //
            // LogWrite.d(tag, "---------->" + messageInAction);
            // }// end else if wipe

            else if (command.equals("FLGSTG")) {
                flag = false;
                String setting = "";
                // String enableDisable="";
                LogWrite.d(tag, "Ready To FLGSTG");
                int onOffCount = Integer.parseInt(htDMCommand.get("FTCount"));
                LogWrite.d(tag, onOffCount + "  count");
                for (int count = 1; count <= onOffCount; count++) {
                    setting = htDMCommand.get("FA" + count);
                    LogWrite.d(tag, onOffCount + "  count" + setting);
                    int enableDisable = Integer.parseInt(htDMCommand.get("FB"
                            + count));
                    if (setting.equals("BT")) {
                        LogWrite.d(tag, "setting " + setting);
                        if (enableDisable == 0) {
                            addtoLog("Disable bluetooth requested by server");
                            enableBlueTooth(0);
                        } else {
                            addtoLog("Enable bluetooth requested by server");
                            enableBlueTooth(1);
                        }
                    } else if (setting.equals("TH")) {
                        LogWrite.d(tag, "setting " + setting);
                        if (enableDisable == 0) {
                            addtoLog("Disable Tethering requested by server");
                            USBTethering(false);

                            // ;
                        } else {
                            addtoLog("Enable Tethering requested by server");
                            USBTethering(true);
                            // checkUSBTethering();
                        }
                    } else if (setting.equals("HS")) {
                        LogWrite.d(tag, "setting " + setting);
                        if (enableDisable == 0) {
                            addtoLog("Disable Hotspot requested by server");
                            HotSpot(false);
                        } else {
                            addtoLog("Enable Hotspot requested by server");
                            if (isWiFiEnabled() == 1) {
                                enableWiFi(0);
                            }
                            HotSpot(true);
                        }
                    } else {
                        LogWrite.d(tag, "setting " + setting);
                        if (enableDisable == 0) {
                            addtoLog("Disable WIFI requested by server");
                            enableWiFi(0);
                        } else {
                            addtoLog("Enable WIFI requested by server");
                            if (checkHotspot() == 1) {
                                HotSpot(false);
                            }
                            enableWiFi(1);
                        }
                    }
                    // response[count]=unInstallApp(appName);
                }

                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                messageInAction += ";CMDINF-" + i + ":<1>;";

            } // end flgstg

            else if (command.equals("OPNSTG")) {
                addtoLog("Open Settings requested by server");
                flag = false;
                LogWrite.d(tag, "setting " + command);
                String settingToOpen = "";
                int openCount = Integer.parseInt(htDMCommand.get("STCount"));
                LogWrite.d(tag, "setting open coutn " + openCount);
                for (int count = 1; count <= openCount; count++) {
                    settingToOpen = htDMCommand.get("SA" + count);
                    LogWrite.d(tag, "setting " + settingToOpen);
                    OpenSettingsUtility.getOpenSettingsUtility().openSetting(
                            mdmActivity, settingToOpen, context);
                    // ---------Removing for TRIAL
                    // openSetting(settingToOpen);
                }
                if (OpenSettingsUtility.getOpenSettingsUtility()
                        .isSettingErrorFlag()) {
                    messageInAction += "CMD-" + i + ":";
                    messageInAction += htDMCommand.get("CMD-" + i);
                    messageInAction += ";CMDINF-" + i + ":<0>;";
                    // settingErrorFlag = false;
                    OpenSettingsUtility.getOpenSettingsUtility()
                            .setSettingErrorFlag(false);
                } else {
                    messageInAction += "CMD-" + i + ":";
                    messageInAction += htDMCommand.get("CMD-" + i);
                    messageInAction += ";CMDINF-" + i + ":<1>;";
                }

            } else if (command.equals("PING")) {
                addtoLog("PING information requested by server.");
                flag = false;
                String pingResponse = "";
                LogWrite.d(tag, "PING " + command);
                String pingURl = "";
                int pingCount = Integer.parseInt(htDMCommand.get("PNCount"));
                LogWrite.d(tag, "setting open coutn " + pingCount);
                for (int count = 1; count <= pingCount; count++) {
                    pingURl = htDMCommand.get("PNA" + count);
                    LogWrite.d(tag, "setting " + pingURl);

                    ConnectivityManager connManager = (ConnectivityManager) context
                            .getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo mWifi = connManager
                            .getNetworkInfo(ConnectivityManager.TYPE_WIFI);

                    if (mWifi.isConnected()) {
                        LogWrite.d(tag, "Wifi is Connected......");
                        if (isOnline(mdmActivity, pingURl)) {
                            LogWrite.d(tag, "Wifi is Connected & online......");
                            pingResponse = ping(pingURl);
                            addtoLog("PING information sent to server.");
                        } else {
                            LogWrite.d(tag,
                                    "Wifi is Connected & but not online......");
                            pingResponse = "A1:" + pingURl
                                    + ";B1:8;C1:0;D1:100;E1:N/A;F1:N/A;G1:N/A;";
                            addtoLog("PING information sent to server.");
                        }

                    } else {
                        LogWrite.d(tag,
                                "Mobile Network is Connected & online......");
                        pingResponse = ping(pingURl);
                        addtoLog("PING information sent to server.");
                    }

                }
                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                messageInAction += ";CMDINF-" + i + ":<PN-1:<" + pingResponse
                        + ">;>;";
            } else if (command.equals("TRCRT")) {
                flag = false;
                addtoLog("Traceroute information requested by server.");
                String pingResponse = "";
                LogWrite.d(tag, "PING " + command);
                String pingURl = "";
                int pingCount = Integer.parseInt(htDMCommand.get("TCCount"));
                LogWrite.d(tag, "setting open coutn " + pingCount);
                for (int count = 1; count <= pingCount; count++) {
                    pingURl = htDMCommand.get("TCA" + count);
                    LogWrite.d(tag, "setting " + pingURl);
                    ConnectivityManager connManager = (ConnectivityManager) context
                            .getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo mWifi = connManager
                            .getNetworkInfo(ConnectivityManager.TYPE_WIFI);

                    if (mWifi.isConnected()) {
                        LogWrite.d(tag, "Wifi is Connected......");
                        if (isOnline(context, pingURl)) {
                            LogWrite.d(tag, "Wifi is Connected & online......");
                            pingResponse = traceroute(pingURl);
                            addtoLog("TraceRoute information sent to server.");
                        } else {
                            LogWrite.d(tag,
                                    "Wifi is Connected & but not online......");
                            pingResponse = "gaurav";
                            addtoLog("TraceRoute information sent to server.");
                        }

                    } else {
                        LogWrite.d(tag,
                                "Mobile Network is Connected & online......");
                        pingResponse = traceroute(pingURl);
                        addtoLog("TraceRoute information sent to server.");
                    }

                }
                messageInAction += "CMD-" + i + ":";
                messageInAction += htDMCommand.get("CMD-" + i);
                messageInAction += ";CMDINF-" + i + ":<TC-1:<A1:" + pingURl
                        + ";B1:";//
                if (pingResponse.equals("gaurav")) {
                    messageInAction += "0;C1:error;";
                } else if (pingResponse.contains(".")) {
                    messageInAction += "0;C1:" + pingResponse + ";";

                } else {

                    messageInAction += "1";
                }
                messageInAction += ">;>;";

            } else if (command.equals("GETCORDS")) {
                flag = true;
                addtoLog("Location information requested by server.");
                LogWrite.d(tag, "********************************************");
                LogWrite.d(tag, "entered in GETCORDS");
                // ConnectivityManager connManager = (ConnectivityManager)
                // getSystemService(CONNECTIVITY_SERVICE);
                // NetworkInfo mWifi = connManager
                // .getNetworkInfo(ConnectivityManager.TYPE_WIFI);

                // if (mWifi.isConnected()) {
                // LogWrite.d(tag, "Wifi is Connected......");
                // if (isOnline(ins, "www.google.com")) {
                // LogWrite.d(tag, "Wifi is Connected & online......");
                // // getGPSCordinates();
                // getLocationByNetworkProvider();
                // addtoLog("Location information sent to server.");
                // } else {
                // LogWrite.d(tag, "Wifi is Connected & but not online......");
                // String messageToSend;
                // messageToSend = "MN:" + htDMCommand.get("MN")
                // + ";CNo:1;CMD-1:GETCORDS;CMDINF-1"
                // + ":<GP-1:<A1:" + "No Internet Connectivity"
                // + ";B1:" + "No Internet Connectivity" + ";>;>;";
                // addtoLog("Could not send Location Information.");
                // try {
                // sendTextMessage(mobileNumber, messageToSend);
                // } catch (ExceptionDTO e) {
                // e.printStackTrace();
                // }
                // }
                //
                // } else {
                // LogWrite.d(tag,
                // "Mobile Network is Connected & online......");
                // getGPSCordinates();
                // TelephonyManager telMgr = (TelephonyManager)
                // getSystemService(Context.TELEPHONY_SERVICE);
                // int simState = telMgr.getSimState();
                // if(simState == TelephonyManager.SIM_STATE_READY)
                // {
                if (checkforMobileData()) {
                    // getLocationByNetworkProvider();
                    LogWrite.d("Loc--", "Http ok");
                    mdmActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            getLocationByNetworkProvider("1");
                        }
                    });

                    addtoLog("Location information sent to server.");
                } else {
                    String messageToSend;
                    messageToSend = "MN:" + htDMCommand.get("MN")
                            + ";CNo:1;CMD-1:GETCORDS;CMDINF-1" + ":<GP-1:<A1:"
                            + "0" + ";B1:" + "0" + ";>;>;";
                    addtoLog("Could not send Location Information.");
                    try {
                        sendTextMessage(mobileNumber, messageToSend);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                // }

            }
            LogWrite.d(tag, "IF da funda khatam...");

        } // end for

        if (flag == false) {
            Log.i("Operation on apn ", "entered into flag");
            LogWrite.d("EDTTest", "need to send message");
            // breakMsgToSend(messageInAction, true);
            try {
                LogWrite.d("EDTTest", "start");
                sendTextMessage(mobileNumber, messageInAction);
                LogWrite.d("EDTTest", "Finish");
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            messageInAction = "";
            flag = true;
        }
        LogWrite.d(tag, "Process command da funda khatam...");
    }

    /*
     * returns the network mode
     */

    public void createStartSessiondata(boolean denied, String commandID) {
        final String tag = "createStartSessiondata";
        LogWrite.d(tag, "DATA   -> StartSession");
        // addtoLog("Device information requested by and sent to server.");
        SendResponseDTO responseToServerDTO = new SendResponseDTO();
        responseToServerDTO.setMessageCommandId(commandID);
        responseToServerDTO.setCommandKey("SS");
        responseToServerDTO.setMAC(phoneNumberToSend);

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("__type", "StartSessionReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
            jsonObject.put("Permission", !denied);
            responseToServerDTO.setResponse(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        final String sendToServerString = responseToServerDTO.toJSON().toString();
//        final String sendToServerString = new Gson().toJson(responseToServerDTO).replaceAll("\\\\", "");
        Log.d(tag, "createStartSessiondata: Sending JSON: " + sendToServerString);
        final String[] response = {null};
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    response[0] = postRequestOkhttp(AppConstant.SEND_RESPONSE_URL, sendToServerString);
                    Log.d(tag, "createStartSessiondata: Response of Server " + response[0]);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
//        getAppsMobile("121");
        Log.d(tag, "createStartSessiondata: Response of Server " + response[0]);
    }

    /**
     * send the handsetInfo in json format to the webservice
     */
    public void sendHandsetInfo(String commandID) {
        APNReader apnReader = APNReader.getInstance(context);

        ArrayList<String> arrayApn = apnReader.getAllAPN(context);

        int signal = (signalStrength);
        if (signal >= 100) {
            signal = 95;
        }
        KTBatteryInfo ktInformation = KTBatteryInfo.getInstance();
        ktInformation.calculate(getActivity());


        String defaultApnName = apnReader.getPreferAPN(context);
        LogWrite.d(tag, "Preffered APN is  " + defaultApnName);
        for (int i = 0; i < arrayApn.size(); i++) {

            String apn = arrayApn.get(i);
            String defaultProfileCheck = "";
            if (apn.equals(defaultApnName)) {
                defaultProfileCheck = "1";
            } else {
                defaultProfileCheck = "0";
            }

            LogWrite.d(tag, "No IP & port");
            break;
        }
        GetHandsetInfoRemoteMax getHandsetInfoRemoteMax = new GetHandsetInfoRemoteMax(phoneNumberToSend);
        GetHandsetInfoRemoteMax getHandsetInfoRemoteMax1 = getHandsetInfoRemoteMax.getHandsetInfoDTO(getActivity());
//                String hardwareInfo = getHandsetInfoRemoteMax1.toJSONObject(denied).toString();

//                responseToServerDTO.setResponse(hardwareInfo);
//                String messageToSend = new Gson().toJson(responseToServerDTO);

        try {
            JSONObject hInfoJson = getHandsetInfoRemoteMax1.toJSONObject();
            SendResponseDTO responseToServerDTO = new SendResponseDTO();
            responseToServerDTO.setMessageCommandId(commandID);
            responseToServerDTO.setCommandKey("HINFO");
            responseToServerDTO.setMAC(phoneNumberToSend);
            responseToServerDTO.setResponse(hInfoJson);
            String msgToSend = responseToServerDTO.toJSON().toString();
            LogWrite.d(tag, "Sending HandsetInfo to service : " + msgToSend);
            String serviceResponse = postRequestOkhttp(AppConstant.SEND_RESPONSE_URL, msgToSend);
            addtoLog("Device information requested by and sent to server.");
//          postRequestOkhttp(AppConstant.SEND_RESPONSE_URL,new Gson().toJson(responseToServerDTO));
            Log.d(tag, "sendHandsetInfo: Reponse Received :" + serviceResponse);
        } catch (IOException e) {
            e.printStackTrace();
            addtoLog("Device information requested failed.");
        }
    }

    //handsetInfo in string fomat
    public String createStartSessiondata1() {
        LogWrite.d(tag, "DATA   -> StartSession");
        addtoLog("Device information requested by and sent to server.");
        String messageToSend = "";
        boolean LocationServiceInfoFlag = false;
        KTBatteryInfo ktInformation = KTBatteryInfo.getInstance();
        ktInformation.calculate(getActivity());
        try {
            // following code is for fetchin memory details.
            LogWrite.d("HandsetInfo", "Try Block Enters");
            long freeMemory = 0;
            long mbTotal = 0;
            try {
                List<StorageInfo> storageList = StorageInfo.getStorageList();
                for (StorageInfo storageInfo : storageList) {
                    if (storageInfo.isInternalStorage()) {
                        LogWrite.d("HandsetInfo", " ....................... "
                                + storageInfo.path);
                        StatFs stat = new StatFs(storageInfo.path);

                        LogWrite.d("HandsetInfo", " ....................... 2");
                        long bytesAvailable = (long) stat.getFreeBlocks()
                                * (long) stat.getBlockSize();
                        LogWrite.d("HandsetInfo", " ....................... 3");
                        long usedMemory = (long) stat.getBlockCount()
                                * (long) stat.getBlockSize();
                        long totalMemory = bytesAvailable + usedMemory;
                        LogWrite.d("HandsetInfo", " ....................... 4");
                        freeMemory = bytesAvailable / 1048576;
                        LogWrite.d("HandsetInfo", " ....................... 5");
                        mbTotal = totalMemory / 1048576;

                        float freeGB = (float) freeMemory / 1024;
                        DecimalFormat twoDForm = new DecimalFormat("#.##");
                        freeGB = Float.valueOf(twoDForm.format(freeGB));
                        float totalGB = (float) mbTotal / 1024;
                        totalGB = Float.valueOf(twoDForm.format(totalGB));
                        LogWrite.d("HandsetInfo", freeGB + "/" + totalGB);

                        break;
                    }
                }

            } catch (Exception e2) {
                // TODO Auto-generated catch block
                e2.printStackTrace();
            }

            long freeMemorySD = 0;
            long mbTotalSD = 0;
            try {
                List<StorageInfo> storageList = StorageInfo.getStorageList();
                for (StorageInfo storageInfo : storageList) {
                    if (storageInfo.isExternalStorage()) {

                        String path = storageInfo.path;
                        if (storageInfo.path.contains("media_rw")) {
                            String[] arrayString = storageInfo.path.split("/");
                            ArrayList<String> arrayList = new ArrayList<String>();
                            boolean startSavingToListFlag = false;
                            for (int i = 0; i < arrayString.length; i++) {
                                if (arrayString[i].equals("media_rw")) {
                                    startSavingToListFlag = true;
                                } else {
                                    if (startSavingToListFlag) {
                                        String folder = arrayString[i].trim();
                                        arrayList.add(folder);
                                    }
                                }
                            }
                            path = "/storage/";
                            for (String string : arrayList) {
                                path += string;
                            }
                        }
                        // path = "/storage/extSdCard";
                        LogWrite.d("HandsetInfo", " ....................... "
                                + path);
                        StatFs statSD = new StatFs(path);
                        long bytesAvailableSD = (long) statSD.getFreeBlocks()
                                * (long) statSD.getBlockSize();
                        LogWrite.d("HandsetInfo", " ....................... 7");
                        long usedMemorySD = (long) statSD.getBlockCount()
                                * (long) statSD.getBlockSize();
                        LogWrite.d("HandsetInfo", " ....................... 8");
                        // long totalMemorySD = bytesAvailableSD + usedMemorySD;
                        freeMemorySD = bytesAvailableSD / 1048576;
                        LogWrite.d("HandsetInfo", " ....................... 9");
                        mbTotalSD = usedMemorySD / 1048576;
                        LogWrite.d("HandsetInfo", " ....................... 10");

                        float freeGB = (float) freeMemorySD / 1024;
                        DecimalFormat twoDForm = new DecimalFormat("#.##");
                        freeGB = Float.valueOf(twoDForm.format(freeGB));
                        float totalGB = (float) mbTotalSD / 1024;
                        totalGB = Float.valueOf(twoDForm.format(totalGB));
                        LogWrite.d("HandsetInfo", freeGB + "/" + totalGB);
                        break;
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }

            // got mobile network code of the default apn
            // String ids = APNProfileManipulator.GetInstance(ins).getIDS();
            LogWrite.d("HandsetInfo", " ....................... 11");

            APNReader apnReader = new APNReader().getInstance(context);

            ArrayList<String> arrayApn = apnReader.getAllAPN(context);

            // Dual SIM
            TelephonyInfo telephonyInfo = TelephonyInfo.getInstance(context);
            int dualSimStatus = telephonyInfo.isDualSIM();
            String isDataState = telephonyInfo.isDataReady();
            String imsi1 = telephonyInfo.getIMSI1();
            String imsi2 = telephonyInfo.getIMSI2();
            String preferredSim = "";
            try {
                if (dualSimStatus == 1) {
                    if (isDataState.equals("0")) {
                        preferredSim = imsi1;
                    }
                    if (isDataState.equals("1")) {
                        preferredSim = imsi2;
                    }
                }
            } catch (Exception e) {
                preferredSim = "";
            }

            // if (ids.length() != 0)
            // {
            // LogWrite.d("HandsetInfo", "----------------------- if Enters");
            // // LogWrite.d(tag, "ids > 0 ");
            // // here i have : seperated id's of apn's whose mnc equals the
            // // default apn's mnc
            // ids = ids.substring(0, ids.length() - 1);
            // LogWrite.d("HandsetInfo", " ....................... 12");
            // String idArray[] = ids.split(":");
            // LogWrite.d("HandsetInfo", " ....................... 13");
            // splitted ids on : and nwo i have String array of ids of
            // Access Points
            // now i will get array size and loop until i get names and apns
            // of all profiles of current operator
            // int idArraySize = idArray.length;  // if (ids.length() != 0)
            // {
            // LogWrite.d("HandsetInfo", "----------------------- if Enters");
            // // LogWrite.d(tag, "ids > 0 ");
            // // here i have : seperated id's of apn's whose mnc equals the
            // // default apn's mnc
            // ids = ids.substring(0, ids.length() - 1);
            // LogWrite.d("HandsetInfo", " ....................... 12");
            // String idArray[] = ids.split(":");
            // LogWrite.d("HandsetInfo", " ....................... 13");
            // splitted ids on : and nwo i have String array of ids of
            // Access Points
            // now i will get array size and loop until i get names and apns
            // of all profiles of current operator
            // int idArraySize = idArray.length;  // if (ids.length() != 0)
            // {

            LogWrite.d("HandsetInfo", " ....................... 14");
            int signal = (signalStrength);
            LogWrite.d("HandsetInfo", " ....................... 15");
            if (signal >= 100) {
                LogWrite.d("HandsetInfo", " ....................... 16");
                signal = 95;
            }
            LogWrite.d("HandsetInfo", " ....................... 17");

            /**
             * Added for
             */
            double dischargeFormatDouble = 0;
            // String dischargeFormat = null;
            try {
                DataSource_DischargeRate dischargeRate = DataSource_DischargeRate
                        .getInstance(context);
                float discharge = dischargeRate.getDischargeRate();
                DecimalFormat twoDForm = new DecimalFormat("#.##");
                dischargeFormatDouble = Double.valueOf(twoDForm
                        .format(discharge));
                // dischargeFormat = "" + dischargeFormatDouble;

                // DecimalFormat df = new DecimalFormat();
                // df.setMinimumFractionDigits(2);
                // dischargeFormat = df.format(discharge);
            } catch (Exception e1) {
                // dischargeFormat = "0.00";
                e1.printStackTrace();
            }

            KTUsageRAM ktUsageRAM = new KTUsageRAM(context);
            KTUsageCPU ktCPUUsage = new KTUsageCPU(context);
            ktCPUUsage.refresh(5);
            float usedRamUsage = ktUsageRAM.getMeoryInfo().getUsed();
            int totalRamUsage = (int) ktUsageRAM.getMeoryInfo().getTotal();
            int ramPercentage = (int) ((usedRamUsage * 100) / totalRamUsage);
            int cpuUsage = ktCPUUsage.getTotalCPUUsage();

            int brightness = 0;
            // Calculate the brightness percentage
            try {
                brightness = android.provider.Settings.System.getInt(
                        context.getContentResolver(),
                        android.provider.Settings.System.SCREEN_BRIGHTNESS);
            } catch (SettingNotFoundException e) {
                brightness = 0;
            }
            LogWrite.e("Aman", "Brightness : " + brightness);
            int perc = (brightness * 100 / 255);
            LogWrite.e("Aman", "Percentage : " + perc);

            messageToSend = "MN:" + htDMCommand.get("MN")
                    + ";CNo:1;CMD-1:HNSTINFO;CMDINF-1:<HT:<" + "A:" + Id
                    + ";B:" + brand + ";C:" + model + ";D:" + IMSI + ";E:"
                    + mbTotal + ";F:" + freeMemory + ";G:" + batteryLevel
                    + ";H:Android" + softwareVersion + ";I:" + freeMemorySD
                    + ";J:" + mbTotalSD + ";K:"
                    + ktInformation.getTemperature() + ";L:"
                    + isBlueToothEnabled() + ";M:" + isWiFiEnabled() + ";N:"
                    + isGpsEnabled() + ";O:" + checkUSBTethering() + ";P:"
                    + checkHotspot() + ";Q:" + getLocationServicesInfo()
                    + ";R:" + isDeviceRooted() + ";S:" + setBearerInfo(context)
                    + ";T:" + getDataRoamingStatus(context) + ";U:"
                    + dualSimStatus + ";V:" + preferredSim + ";W:"
                    + dischargeFormatDouble + ";X:" + ramPercentage + ";Y:"
                    + cpuUsage + ";Z:" + perc + ";>;" + "NW:<A:"
                    + currentOperatorName + ";D:" + isRoamingStatus() + ";E:"
                    + signal + ";C:" + getCellId() + ";>;" + "PR-" + (1) + ":<";
            // messageToSend= "MN:" + htDMCommand.get("MN") +
            // ";CNo:1;CMD-1:CRTPRF;CMDINF-1:<PR-"+(idArraySize)+":<";
            /*
             * here using method getNameAPNCurrentFromId we willget : seprated
             * string of name apn profile whose id we are sending to method
             */
            // LogWrite.d("HandsetInfo", " ....................... 18");
            // String defaultApnName =
            // APNProfileManipulator.GetInstance(ins).APNFetcher();
            // LogWrite.d("HandsetInfo", " ....................... 19");
            String defaultApnName = apnReader.getPreferAPN(context);
            LogWrite.d(tag, "Preffered APN is  " + defaultApnName);

            for (int i = 0; i < arrayApn.size(); i++) {
                LogWrite.d("HandsetInfo", "loop enter");
                // String strNameApnCurrent = APNProfileManipulator
                // .GetInstance(ins).getNameApnCurrentFromId(
                // idArray[i]);
                // LogWrite.d("HandsetInfo", " ....................... 20");
                // strNameApnCurrent = strNameApnCurrent.substring(0,
                // strNameApnCurrent.length() - 1);
                // LogWrite.d("HandsetInfo", " ....................... 21");
                // String apnData[] = strNameApnCurrent.split("~");
                // LogWrite.d("HandsetInfo", " ....................... 22");
                // String name = apnData[0];
                // LogWrite.d("HandsetInfo", " ....................... 23");
                String apn = arrayApn.get(i);
                LogWrite.d("HandsetInfo", " ....................... 24");
                String defaultProfileCheck = "";
                LogWrite.d("HandsetInfo", " ....................... 25");
                if (apn.equals(defaultApnName)) {
                    defaultProfileCheck = "1";
                } else {
                    defaultProfileCheck = "0";
                }
                LogWrite.d("HandsetInfo", " ....................... 26");
                // if (apnData.length >= 4)
                // {
                // String ip = apnData[3];
                // String port = apnData[4];
                // LogWrite.d(tag, "IP -----> " + ip);
                // LogWrite.d(tag, "Port -----> " + port);
                // messageToSend += "A" + (i + 1) + ":" + name + ";C"
                // + (i + 1) + ":" + apn + ";K" + (i + 1) + ":"
                // + defaultProfileCheck + ";H" + (i + 1) + ":"
                // + ip + ";I" + (i + 1) + ":" + port + ";";
                // }
                // else
                // {
                LogWrite.d(tag, "No IP & port");
                messageToSend += "A" + (i + 1) + ":" + "Empty" + ";C" + (i + 1)
                        + ":" + apn + ";K" + (i + 1) + ":"
                        + defaultProfileCheck + ";";
                break;
                // }
            }
            messageToSend += ">;>;";
            // breakMsgToSend(messageToSend, true);
            LogWrite.d("HandsetInfo", " ....................... 27");
            sendTextMessage(mobileNumber, messageToSend);
            // heading.setText(messageToSend);
            // } // end of ids lenght != 0
            // else
            // {
            // LogWrite.d("HandsetInfo", " Else Enters");
            // int signal = (signalStrength);
            // LogWrite.d("HandsetInfo", " ....................... 13");
            // if (signal >= 100)
            // {
            // signal = 95;
            // }
            // LogWrite.d("HandsetInfo", " ....................... 14");
            // // Toast.makeText(getApplicationContext(), "Signal  " + signal ,
            // // 2000).show();
            // messageToSend = "MN:" + htDMCommand.get("MN")
            // + ";CNo:1;CMD-1:HNSTINFO;CMDINF-1:<HT:<A:" + Id + ";B:"
            // + brand + ";C:" + model + ";" + "D:" + IMSI + ";E:"
            // + mbTotal + ";F:" + freeMemory + ";G:" + batteryLevel
            // + ";K:"+appVersion+";H:Android" + softwareVersion + ";L:"
            // + isBlueToothEnabled() + ";M:" + isWiFiEnabled()
            // + ";N:" + isGpsEnabled() + ";I:" + freeMemorySD + ";J:"
            // + mbTotalSD + ";" + "O:" + checkUSBTethering() + ";"
            // + "P:" + checkHotspot() + ";R:" + isDeviceRooted() + ";"
            // + "S:" + setBearerInfo(getApplicationContext())+";"
            // + "T:" + getDataRoamingStatus(getApplicationContext()) +";"
            // + "U:" + dualSimStatus +";"
            // + "V:" + preferredSim +";"
            // + ">;"
            // + "NW:<A:"
            // + currentOperatorName + ";D:" + isRoamingStatus()
            // + ";E:" + signal + ";C:" + getCellId() + ";>;" + "PR-0"
            // + ":<>;>;";
            // // breakMsgToSend(messageToSend, true);
            // sendTextMessage(mobileNumber, messageToSend);
            // LogWrite.d("HandsetInfo", " ....................... 15");
            // messageToSend = "";
            // }// else
        } catch (Exception ex) {
            // Toast.makeText(getApplicationContext(), ">>>>>"+ex.toString(),
            // 2000).show();
            LogWrite.e("HandsetInfo", "ExceptionDTO.." + ex);
        }

        return messageToSend;
    }

    //Trun on/off some settings in mobile
    void flagSetting(String setting, boolean status) {

        // String enableDisable="";
        LogWrite.d(tag, "Ready To FLGSTG");
        Log.d(tag, "flagSetting: Setting = " + setting + " Status = " + status);
        int enableDisable = status ? 1 : 0;
        if (setting.equals("BT")) {
            LogWrite.d(tag, "setting " + setting);
            if (enableDisable == 0) {
                addtoLog("Disable bluetooth requested by server");
                enableBlueTooth(0);
            } else {
                addtoLog("Enable bluetooth requested by server");
                enableBlueTooth(1);
            }
        } else if (setting.equals("TH")) {
            LogWrite.d(tag, "setting " + setting);
            if (enableDisable == 0) {
                addtoLog("Disable Tethering requested by server");
                USBTethering(false);

                // ;
            } else {
                addtoLog("Enable Tethering requested by server");
                USBTethering(true);
                // checkUSBTethering();
            }
        } else if (setting.equals("HS")) {
            LogWrite.d(tag, "setting " + setting);
            if (enableDisable == 0) {
                addtoLog("Disable Hotspot requested by server");
                HotSpot(false);
            } else {
                addtoLog("Enable Hotspot requested by server");
                if (isWiFiEnabled() == 1) {
                    enableWiFi(0);
                }
                HotSpot(true);
            }
        } else if (setting.equals("WIFI")) {
            LogWrite.d(tag, "setting " + setting);
            if (enableDisable == 0) {
                addtoLog("Disable WIFI requested by server");
                enableWiFi(0);
            } else {
                addtoLog("Enable WIFI requested by server");
                if (checkHotspot() == 1) {
                    HotSpot(false);
                }
                enableWiFi(1);
            }
        }
        // response[count]=unInstallApp(appName);


    }

    /**
     * Profile name apn and whether it should be default or not will be done
     * here. we can set a simple profile as default profile and do vice versa
     * Called if ResponseDTO found with <b>EDTPRF</b><br>
     *
     * @return {@link Integer}
     */
    public int editProfileCommandResponse() {
        /*
         * Profile name apn and whether it should be default or not will be done
         * here. we can set a simple profile as default profile and do vice
         * versa
         */
        boolean editFlagResponse = false;
        int responseArray[] = {};
        int id = 2;
        try {
            int count = Integer.parseInt(htDMCommand.get("EPRCount"));
            responseArray = new int[count + 1];
            String profileName = "", apnAddress = "", defaultProfileCheck = "";
            String ip = "";
            String port = "";
            if (count >= 1) {
                for (int j = 1; j <= count; j++) {
                    profileName = htDMCommand.get("EA" + j);
                    apnAddress = htDMCommand.get("EC" + j);
                    defaultProfileCheck = htDMCommand.get("EK" + j);
                    if (profileName == null) {
                        profileName = "";
                    }
                    if (apnAddress == null) {
                        apnAddress = "";
                    }
                    ip = htDMCommand.get("EH" + j);
                    if (ip == null) {
                        ip = "";
                    }
                    port = htDMCommand.get("EI" + j);
                    if (port == null) {
                        port = "";
                    }
                    if (profileName != null && apnAddress != null) {
                        if (defaultProfileCheck != null) {
                            // id = updateAPN(profileName, apnAddress, true, ip,
                            // port);
                            id = APNProfileManipulator.GetInstance(context)
                                    .updateAPN(profileName, apnAddress, true,
                                            ip, port);

                            LogWrite.d(tag, "Edit Apn ResponseDTO =" + id);
                            responseArray[j] = id;
                        } else {
                            // id = updateAPN(profileName, apnAddress, false,
                            // ip,
                            // port);
                            id = APNProfileManipulator.GetInstance(context)
                                    .updateAPN(profileName, apnAddress, false,
                                            ip, port);
                            LogWrite.d(tag, "Edit Apn ResponseDTO =" + id);
                            responseArray[j] = id;
                        }
                    }
                }
                // breakMsgToSend(actualCmdFrmServer);
            }

            for (int k = 1; k <= count; k++) {
                if (responseArray[k] == 0) {
                    editFlagResponse = true;
                }
            }
            if (editFlagResponse == true) {
                return 0;
            } else {
                return 1;
            }
        } catch (Exception e) {
            // Toast.makeText(getApplicationContext(), e.toString(),
            // Toast.LENGTH_LONG).show();
            LogWrite.d(tag, e.toString());
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Retrieves Browser History. Called if ResponseDTO found with <b>GETHIST</b><br>
     */

    private String getbrowserHistoryUpdated() {
        String TAG = "Browser history";
        String messageToSend = "";
        Hashtable<String, String> ht = new Hashtable<String, String>();

        Cursor cursor = context.getContentResolver().query(
                Browser.BOOKMARKS_URI, null, null, null, null);
        int visitsIdx = (cursor.getColumnIndex(Browser.BookmarkColumns.VISITS));

        cursor.moveToFirst();

        while (!cursor.isAfterLast()) {
            String url = cursor.getString(1);

            int visitsNo = cursor.getInt(visitsIdx);

            String visitss = cursor.getString(2);
            //
            // LogWrite.d(TAG,"url == "+url);
            // LogWrite.d(TAG,"visitss =="+visitss);
            //
            // if(url.equalsIgnoreCase(visitss))
            // {
            // LogWrite.d(TAG,"Equal  ==yes");
            // }

            // LogWrite.d(TAG,"URL "+url +" visits "+ cursor.getString(2)
            // +"user entered "+cursor.getString(9)
            // +" bookmark "+cursor.getString(4));

            if (url != null) {
                LogWrite.d(TAG, "URL " + url);
                LogWrite.d("visits are", visitsNo + "<<??>>");
                if (url.contains("//")) {

                    int indexDBLSlash = url.indexOf("//");
                    String strWithoutDBLSlash = url
                            .substring((indexDBLSlash + 2));
                    if (strWithoutDBLSlash.contains("/")) {
                        int indexOfSigleSlash = strWithoutDBLSlash.indexOf("/");
                        String strWithoutSingleSlash = strWithoutDBLSlash
                                .substring(0, indexOfSigleSlash);
                        ht.put("" + strWithoutSingleSlash, " ");
                    }
                } else if (visitss.contains("//")) {

                    int indexDBLSlash = visitss.indexOf("//");
                    String strWithoutDBLSlash = visitss
                            .substring((indexDBLSlash + 2));
                    if (strWithoutDBLSlash.contains("/")) {
                        int indexOfSigleSlash = strWithoutDBLSlash.indexOf("/");
                        String strWithoutSingleSlash = strWithoutDBLSlash
                                .substring(0, indexOfSigleSlash);
                        ht.put("" + strWithoutSingleSlash, " ");
                    }
                }
            }// end if(url!=null)
            cursor.moveToNext();

        }

        cursor.close();

        Enumeration<String> e = ht.keys();
        String brStr = "";
        int count = 1;
        while (e.hasMoreElements()) {
            String element = e.nextElement();
            brStr += "A" + count + ":" + element + ";";
            LogWrite.d(TAG, " ht " + element);
            count++;
        }

        LogWrite.d(TAG, ">>>>>>>>>>>>>" + ht.size() + "     >>>>>>>    ");
        if (ht.size() == 0) {
            // messageToSend = "<HI-" + 1 + ":<";
            // messageToSend += "A1:Unable to fetch browser history;";
            // messageToSend += ">;>;";
            messageToSend = "<>;";

        } else {
            LogWrite.d(TAG, ">>>>>>>>>>>>>" + count + "     >>>>>>>    "
                    + brStr);
            messageToSend = "<HI-" + (count - 1) + ":<";
            messageToSend += brStr;
            messageToSend += ">;>;";
        }

        return messageToSend;

    }

    /**
     * Create Profile.<br>
     * Called if ResponseDTO found with <b>CRTPRF</b><br>
     * get the default apn and get its mnc
     *
     * @return {@link Boolean}
     */
    public boolean createProfileCommandResponse() {
        /*
         * get the default apn and get its mnc
         */
        // mnc=getDefaultAPNMnc();
        addtoLog("Creating APN Profile.");
        // Toast.makeText(this,"Yesy", Toast.LENGTH_LONG).show();
        try {
            int count = Integer.parseInt(htDMCommand.get("CPRCount"));
            LogWrite.d(tag, "cmd from server contain Key CPRCount ="
                    + htDMCommand.get("CPRCount"));

            // LogWrite.d(tag,"cmd from server contain Key PR ="+htDMCommand.get("PR"));
            //
            // int count = Integer.parseInt(htDMCommand.get("PR"));
            if (count >= 1) {
                for (int j = 1; j <= count; j++) {
                    // ip is actually proxy field in Access point name in apn
                    String profileName = "", apnAddress = "", defaultProfileCheck = "";
                    String ip = "";
                    String port = "";
                    profileName = htDMCommand.get("CA" + j);
                    if (profileName == null) {
                        profileName = "";
                    }
                    LogWrite.d(tag, "cmd from server 1");
                    // Toast.makeText(this, "Profile Name to cretea" +
                    // profileName, 2000).show();
                    apnAddress = htDMCommand.get("CC" + j);
                    if (apnAddress == null) {
                        apnAddress = "";
                    }

                    LogWrite.d(tag, "cmd from server 2");
                    ip = htDMCommand.get("CH" + j);

                    if (ip == null) {
                        ip = "";
                    }

                    LogWrite.d(tag, "cmd from server 3");
                    port = htDMCommand.get("CI" + j);
                    if (port == null) {
                        port = "";
                    }

                    LogWrite.d(tag, "cmd from server 4");
                    // Toast.makeText(this, "apn addres " + profileName,
                    // 2000).show();

                    defaultProfileCheck = htDMCommand.get("CK" + j);
                    LogWrite.d(tag,
                            "cmd from server CK = " + htDMCommand.get("CK" + j));
                    LogWrite.d(tag, "cmd from server 5");

                    // Toast.makeText(this, "CK1" + defaultProfileCheck,
                    // 2000).show();
                    // mccS=htDMCommand.get("CM"+j);
                    // if(mccS==null){
                    // mccS="";
                    // }
                    // mncS=htDMCommand.get("CN"+j);
                    // if(mncS==null){
                    // mncS="";
                    // }
                    if (profileName != null && apnAddress != null && ip != null
                            && port != null) {
                        // int id = InsertAPN(profileName, apnAddress, ip,
                        // port);

                        LogWrite.d(tag, "cmd from server 6");
                        int id = APNProfileManipulator.GetInstance(context)
                                .InsertAPN(profileName, apnAddress, ip, port);
                        // as they are not sending K1 i.e. information of
                        // profile default status

                        LogWrite.d(tag, "cmd from server 7");
                        if (id != 0) {
                            LogWrite.d(tag, "cmd from server 8");
                            if (defaultProfileCheck != null) {
                                LogWrite.d(tag, "cmd from server 9");
                                if (htDMCommand.get("CK" + j).equals("1")) {
                                    LogWrite.d(tag, "cmd from server 10");
                                    // boolean b = SetDefaultAPN(id);
                                    boolean b = APNProfileManipulator
                                            .GetInstance(context)
                                            .SetDefaultAPN(id);
                                    if (b) {
                                    } else {
                                    }
                                }
                            }
                        }
                    }
                }
            }
            addtoLog("APN Profile Created Successfully.");
            return true;
        } catch (Exception e) {
            // Toast.makeText(getApplicationContext(), e.toString(),
            // Toast.LENGTH_LONG).show();
            addtoLog("Could not Create APN Profile.");
            // return false;
        }
        return false;
    }

    public String getAppsNew() {
        String tag = "GetApps";
        String messageToSend = "";
        String appsStr = "";
        int app_count = 1;
        try {
            KTUsageCPU cpuUsage = new KTUsageCPU(context);
            KTUsageRAM ramUsage = new KTUsageRAM(context);
            cpuUsage.refresh(15);

            ArrayList<KTApplicationInfo> cpuAppProcesses = (ArrayList<KTApplicationInfo>) cpuUsage
                    .refresh(25);
            Collections.sort(cpuAppProcesses,
                    new Comparator<KTApplicationInfo>() {
                        @Override
                        public int compare(KTApplicationInfo s1,
                                           KTApplicationInfo s2) {
                            return s1.getAppName().compareToIgnoreCase(
                                    s2.getAppName());
                        }
                    });
            ArrayList<com.kochartech.library.Memory.KTApplicationInfo> ramAppProcesses = (ArrayList<com.kochartech.library.Memory.KTApplicationInfo>) ramUsage
                    .getPerAppUsage();
            for (int i = 0; i < cpuAppProcesses.size(); i++) {
                KTApplicationInfo ktApplicationInfo = cpuAppProcesses.get(i);
                String appName = ktApplicationInfo.getAppName();
                String processName = ktApplicationInfo.getProcessName();
                String[] percentageSplit = ktApplicationInfo.getUsage().split(
                        "%");
                String CPU_USAGE = percentageSplit[0];
                long RAM_USAGE = getAppRamUsage(ramAppProcesses, processName);
                // String[] percentageSplit1 =
                // getAppBatteryUsage(batteryAppsList,
                // processName).split("%");
                float BATTERY_USAGE = 0;
                try {
                    BATTERY_USAGE = Float
                            .parseFloat(getAppBatteryUsage(processName));
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                String app_type = getAppType(context, processName);
                if (app_type.equals("Internal")) {
                    app_type = "I";
                } else if (app_type.equals("External")) {
                    app_type = "E";
                } else {
                    app_type = "S";
                }
                appsStr += "A" + app_count + ":" + appName + ";C" + app_count
                        + ":" + "1" + ";D" + app_count + ":" + BATTERY_USAGE
                        + ";G" + app_count + ":" + RAM_USAGE + ";H" + app_count
                        + ":" + CPU_USAGE + ";F" + app_count + ":"
                        + processName + ";E" + app_count + ":" + app_type + ";";
                app_count++;
            }

            messageToSend = "<AP-" + (app_count - 1) + ":<";
            messageToSend += appsStr;
            messageToSend += ">;>;";

            LogWrite.d(tag, "---------------------" + messageToSend);
        } catch (Exception ex) {
            Toast.makeText(context, ex.toString(), Toast.LENGTH_SHORT).show();
        }
        return messageToSend;
    }

    public String getAppsMobile(String commandID) {
        String tag = "GetApps";
        String messageToSend = "";
        String appsStr = "";
        int app_count = 1;
        Log.d(tag, "getAppsMobile: starts");
        //List<Apps> appDTOArrayList = new ArrayList<>();
        List<Apps> appsList = new ArrayList<>();
        JSONArray appJsonArray = new JSONArray();
        JSONObject appJsonObject = null;
        Apps appObject = null;
        try {
            KTUsageCPU cpuUsage = new KTUsageCPU(context);
            KTUsageRAM ramUsage = new KTUsageRAM(context);

            cpuUsage.refresh(15);

            ArrayList<KTApplicationInfo> cpuAppProcesses = (ArrayList<KTApplicationInfo>) cpuUsage
                    .refresh(25);

            Collections.sort(cpuAppProcesses,
                    new Comparator<KTApplicationInfo>() {
                        @Override
                        public int compare(KTApplicationInfo s1,
                                           KTApplicationInfo s2) {
                            return s1.getAppName().compareToIgnoreCase(s2.getAppName());
                        }
                    });
            ArrayList<com.kochartech.library.Memory.KTApplicationInfo> ramAppProcesses = (ArrayList<com.kochartech.library.Memory.KTApplicationInfo>) ramUsage
                    .getPerAppUsage();
            for (int i = 0; i < cpuAppProcesses.size(); i++) {
                KTApplicationInfo ktApplicationInfo = cpuAppProcesses.get(i);
                String appName = ktApplicationInfo.getAppName();
                String processName = ktApplicationInfo.getProcessName();
                String[] percentageSplit = ktApplicationInfo.getUsage().split(
                        "%");
                String CPU_USAGE = percentageSplit[0];
                long RAM_USAGE = getAppRamUsage(ramAppProcesses, processName);
                // String[] percentageSplit1 =
                // getAppBatteryUsage(batteryAppsList,
                // processName).split("%");
                float BATTERY_USAGE = 0;
                try {
                    BATTERY_USAGE = Float
                            .parseFloat(getAppBatteryUsage(processName));
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                String app_type = getAppType(context, processName);
                if (app_type.equals("Internal")) {
                    app_type = "I";
                } else if (app_type.equals("External")) {
                    app_type = "E";
                } else {
                    app_type = "S";
                }

                appsStr += "A" + app_count + ":" + appName + ";C" + app_count
                        + ":" + "1" + ";D" + app_count + ":" + BATTERY_USAGE
                        + ";G" + app_count + ":" + RAM_USAGE + ";H" + app_count
                        + ":" + CPU_USAGE + ";F" + app_count + ":"
                        + processName + ";E" + app_count + ":" + app_type + ";";
             /*   appObject = new Apps();
                appObject.setAppName(appName);
                appObject.setAppType(app_type);
                appObject.setAppBatteryUsage(String.valueOf(BATTERY_USAGE));
                appObject.setAppCpuUsage(String.valueOf(RAM_USAGE));
                appObject.setProcessName(processName);
                appsList.add(appObject);*/
                appJsonObject = new JSONObject();
                appJsonObject.put("__type", "GetAppReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
                appJsonObject.put("AppName", appName);
                appJsonObject.put("AppType", app_type);
                appJsonObject.put("AppBatteryUsage", String.valueOf(BATTERY_USAGE));
                appJsonObject.put("AppCpuUsage", (String.valueOf(RAM_USAGE)));
                appJsonObject.put("ProcessName", processName);
                appJsonArray.put(appJsonObject);
                app_count++;

            }
            Log.d(tag, "getAppsMobile: Apps :->" + appJsonArray.toString());
            AppDTO appDTO = new AppDTO();
            appDTO.setApps(appsList);
            String appList = new Gson().toJson(appDTO);
            JSONObject jsonObjectApps = new JSONObject(appList);
//            SendResponseDTO toServerDTO = new SendResponseDTO();
//            toServerDTO.setCommandKey("GETAPP");
//            toServerDTO.setMAC(phoneNumberToSend);
//            toServerDTO.setMessageCommandId("1");
//            toServerDTO.setResponse(appJsonArray.toString());
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("MessageCommandId", commandID);
            jsonObject.put("CommandKey", "GetApp");
            jsonObject.put("MAC", phoneNumberToSend);
            jsonObject.put("Response", appJsonArray);
//            String jsonToSend = new Gson().toJson(jsonObject.toString()).replaceAll("\\\\", "");
            Log.d(tag, "getAppsMobile : Json sent:-> " + jsonObject.toString());
            String s = postRequestOkhttp(AppConstant.SEND_RESPONSE_URL, jsonObject.toString());
            Log.d(tag, "getAppsMobile: response of service " + s);
//            messageToSend = "<AP-" + (app_count - 1) + ":<";
//            messageToSend += appsStr;
//            messageToSend += ">;>;";

//            LogWrite.d(tag, "----------Apps Sent Are-----------" + jsonToSend);
        } catch (Exception ex) {
            Toast.makeText(context, ex.toString(), Toast.LENGTH_SHORT).show();
        }
        return messageToSend;
    }

    private long getAppRamUsage(
            ArrayList<com.kochartech.library.Memory.KTApplicationInfo> ramAppProcesses,
            String packageName) {
        for (int i = 0; i < ramAppProcesses.size(); i++) {
            com.kochartech.library.Memory.KTApplicationInfo appInfo = ramAppProcesses
                    .get(i);
            if (appInfo.getProcessName().equals(packageName)) {
                return appInfo.getUsage();
            }
        }
        return 0;
    }

    private String getAppBatteryUsage(String packageName) {
        DataSource_AppsInfo dsApps = DataSource_AppsInfo.getInstance(context);
        DataSource_BatteryUsage batteryUsage = DataSource_BatteryUsage
                .getInstance(context);
        List<AppInfo> apps = dsApps.queryAllRecord();
        LogWrite.d(tag, "AppsInDB: numApps: " + apps.size());
        for (AppInfo appInfo : apps) {
            LogWrite.e(tag, "*******************************");
            int rowId = appInfo.getRowId();
            String processName = appInfo.getPkName();
            if (processName.equals(packageName)) {
                AppUsageInfo batteryUsageInfo = batteryUsage
                        .queryAppDetail(rowId);
                ArrayList<AppUsageDTO> batteryUsageList = batteryUsageInfo
                        .getAppUsage();
                AppUsageDTO batteryUsageDTO = batteryUsageList.get(0);
                String BATTERY_USAGE = batteryUsageDTO.getAppUsageString();
                return BATTERY_USAGE;
            }
        }
        return "0.0";
    }

    /**
     * Fetch 3rd party application installed on device. Called when ResponseDTO
     * contains <b>GETAPPS</b> and <b>UNIAPPS</b>
     */
    public String getApps() {
        String tag = "GetApps";
        String messageToSend = "";
        String appsStr = "";
        int app_count = 1;
        try {

            DataSource_AppsInfo dsApps = DataSource_AppsInfo
                    .getInstance(context);
            List<AppInfo> apps = dsApps.queryAllRecord();
            LogWrite.d(tag, "AppsInDB: numApps: " + apps.size());
            DataSource_CPUUsage cpuUsage = DataSource_CPUUsage
                    .getInstance(context);
            DataSource_RAMUsage ramUsage = DataSource_RAMUsage
                    .getInstance(context);
            DataSource_BatteryUsage batteryUsage = DataSource_BatteryUsage
                    .getInstance(context);
            for (AppInfo appInfo : apps) {
                LogWrite.e(tag, "*******************************");
                int rowId = appInfo.getRowId();
                String appName = appInfo.getAppName();
                String processName = appInfo.getPkName();
                LogWrite.e(tag, "===========================");
                LogWrite.d("Ashish", "RowId : " + rowId);
                LogWrite.d("Ashish", "AppName : " + appName);
                LogWrite.d("Ashish", "ProcessName : " + processName);

                AppUsageInfo ramUsageInfo = ramUsage.queryAppDetail(rowId);
                ArrayList<AppUsageDTO> ramUsageList = ramUsageInfo
                        .getAppUsage();
                AppUsageDTO ramUsageDTO = ramUsageList.get(0);
                LogWrite.d("Ashish", "RAM Usage : " + ramUsageDTO.getAppUsage());
                LogWrite.d("Ashish",
                        "Date :"
                                + convertLongToDate(ramUsageDTO.getUsageTime()));
                int RAM_USAGE = ramUsageDTO.getAppUsage();

                AppUsageInfo cpuUsageInfo = cpuUsage.queryAppDetail(rowId);
                ArrayList<AppUsageDTO> cpuUsageList = cpuUsageInfo
                        .getAppUsage();
                AppUsageDTO cpuUsageDTO = cpuUsageList.get(0);
                LogWrite.d("Ashish", "CPU Usage : " + cpuUsageDTO.getAppUsage());
                LogWrite.d("Ashish",
                        "Date :"
                                + convertLongToDate(cpuUsageDTO.getUsageTime()));
                int CPU_USAGE = cpuUsageDTO.getAppUsage();

                AppUsageInfo batteryUsageInfo = batteryUsage
                        .queryAppDetail(rowId);
                ArrayList<AppUsageDTO> batteryUsageList = batteryUsageInfo
                        .getAppUsage();
                AppUsageDTO batteryUsageDTO = batteryUsageList.get(0);
                LogWrite.d(
                        "Ashish",
                        "Battery Usage : "
                                + batteryUsageDTO.getAppUsageString());
                LogWrite.d("Ashish", "Date :"
                        + convertLongToDate(batteryUsageDTO.getUsageTime()));
                String BATTERY_USAGE = batteryUsageDTO.getAppUsageString();
                String app_type = "I";
                if (CPU_USAGE != 0 || !BATTERY_USAGE.equals("0")
                        || RAM_USAGE != 0) {
                    LogWrite.d(tag, "AppName : " + appName);
                    LogWrite.d(tag, "ProcessName : " + processName);
                    LogWrite.d(tag, "Cpu Usage : " + CPU_USAGE);
                    LogWrite.d(tag, "Battery Usage : " + BATTERY_USAGE);
                    LogWrite.d(tag, "RAM Usage : " + RAM_USAGE);

                    app_type = getAppType(context, processName);
                    if (app_type.equals("Internal")) {
                        app_type = "I";
                    } else if (app_type.equals("External")) {
                        app_type = "E";
                    } else {
                        app_type = "S";
                    }

                    appsStr += "A" + app_count + ":" + appName + ";C"
                            + app_count + ":" + "1" + ";D" + app_count + ":"
                            + BATTERY_USAGE + ";G" + app_count + ":"
                            + RAM_USAGE + ";H" + app_count + ":" + CPU_USAGE
                            + ";F" + app_count + ":" + processName + ";E"
                            + app_count + ":" + app_type + ";";
                    app_count++;
                }
                // String RAM_USAGE = ramUsage.getRecord(rowId);
                // if (RAM_USAGE.equals("0"))
                // continue;
                // String CPU_USAGE = cpuUsage.getRecord(rowId);
                // String BATTERY_USAGE = batteryUsage.getRecord(rowId);
                // if (!CPU_USAGE.equals("0") || !BATTERY_USAGE.equals("0")
                // || !RAM_USAGE.equals("0")) {
                // // RAM = "X";
                // // CPU = "Y";
                // LogWrite.d(tag, "AppName : " + appName);
                // LogWrite.d(tag, "ProcessName : " + processName);
                // LogWrite.d(tag, "Cpu Usage : " + CPU_USAGE);
                // LogWrite.d(tag, "Battery Usage : " + BATTERY_USAGE);
                // LogWrite.d(tag, "RAM Usage : " + RAM_USAGE);
                // RAM_USAGE += " Mb";
                // CPU_USAGE += " %";
                // appsStr += "A" + app_count + ":" + appName + ";C"
                // + app_count + ":" + "1" + ";D" + app_count + ":"
                // + 0 + ";G" + app_count + ":"
                // + 0 + ";H" + app_count + ":" + 0
                // + ";F" + app_count + ":" + processName + ";E"
                // + app_count + ":" + "I" + ";";
                // appsStr +=
                // "A" + i + ":" + app.getAppName() + ";" +
                // "C" + i + ":" + "1" +
                // ";D" + i + ":" + appPercentage +
                // ";E" + i + ":" + "I" + ";";
                // app_count++;
                // }
            }
            messageToSend = "<AP-" + (app_count - 1) + ":<";
            messageToSend += appsStr;
            messageToSend += ">;>;";
            // int appCount = 1;
            // final PackageManager packageManager =
            // context.getPackageManager();
            // List<ApplicationInfo> installedApplications =
            // packageManager.getInstalledApplications(PackageManager.GET_META_DATA);

            // for (ApplicationInfo appInfo : installedApplications)
            // {
            // LogWrite.d("OUTPUT", "Package name : " + appInfo.packageName);
            // LogWrite.d("OUTPUT", "Name: " +
            // appInfo.loadLabel(packageManager));
            // if(appInfo.loadLabel(packageManager).equals(app_name))
            // {
            // myDataBase = new MyDataBaseHandlerClass(getApplicationContext(),
            // "operators.db", null, 1);
            // myDataBase.getWritableDatabase();
            // myDataBase.AddApplicationInfo(app_name,
            // appInfo.packageName,
            // 1,
            // 0,
            // 0,
            // "E", AppSizer.getSize(RegisterUserActivity.GetInstance(),
            // appInfo.packageName));
            // myDataBase.close();
            // }
            // }
            // myDataBase = new MyDataBaseHandlerClass(context,
            // "operators.db", null, 1);
            // myDataBase.getWritableDatabase();
            // try {
            // // String[] string = myDataBase.GetApplicationsFromDataBase();
            // String[] string = myDataBase.SpiceGetApplicationsFromDataBase();
            // // LogWrite.d("Remote","Number of Apps:"+string.length);
            // for (int i = 1; i <= string.length; i++) {
            // // LogWrite.d("Ashish", "---------"+string[i]);
            // appsStr += "A" + i + ":" + string[i - 1].split("~")[0] + ";"
            // + "C" + i + ":" + string[i - 1].split("~")[1] + ";D"
            // + i + ":" + string[i - 1].split("~")[2] + ";" + ";E"
            // + i + ":" + string[i - 1].split("~")[3] + ";";

            // }
            // app.getAppPercentage().split("%")[0]
            // ArrayList<App> arrayList =BatteryStats.refreshView();
            // ArrayList<KTApplicationDTO> arrayList =
            // batteryApps.refreshView();
            // DataSource_DischargeRate obj = DataSource_DischargeRate
            // .getInstance(getActivity());
            // // obj.open();
            // double dischargeRate = obj.getDischargeRate();
            //
            // LogWrite.d("AAnsal", "dischargeRate: " + dischargeRate);
            // if (dischargeRate == 0)
            // dischargeRate = .33;
            // for (int i = 0; i < arrayList.size(); i++) {
            // KTApplicationDTO app = arrayList.get(i);
            // LogWrite.d("AAnsal", "AppName: " + app.getAppName());
            // LogWrite.d("AAnsal", "Percentage: " + app.getAppPercentage());
            // if (app.getAppName().equalsIgnoreCase("GizmoDoctor"))
            // arrayList.remove(i);
            // }
            // for (int i = 1; i < arrayList.size(); i++) {
            // KTApplicationDTO app = arrayList.get(i);
            //
            // if (app.getAppName().equalsIgnoreCase("GizmoDoctor"))
            // continue;
            //
            // String appPercentage = "";
            // try {
            // Float ff = Float
            // .valueOf(app.getAppPercentage().split("%")[0]
            // .trim());
            // LogWrite.d("AAnsal", "ff: " + ff);
            // LogWrite.d("AAnsal", "AppName: " + app.getAppName());
            // if (dischargeRate > 0) {
            // appPercentage = String.valueOf(new DecimalFormat(
            // "##.##").format((dischargeRate / 100) * ff));
            //
            // LogWrite.d("AAnsal", "appPercentage: " + appPercentage);
            // } else {
            // appPercentage = "NA";
            // }
            // // appPercentage = Math.round(ff);
            // } catch (ExceptionDTO e) {
            // LogWrite.d("AAnsal", "E: " + e);
            // }
            //
            // LogWrite.d("AAnsal", "appPer: " + appPercentage);
            // appsStr += "A" + i + ":" + app.getAppName() + ";" + "C" + i
            // + ":" + "1" + ";D" + i + ":" + appPercentage + ";E" + i
            // + ":" + "I" + ";";
            // }

            // myDataBase.close();
            LogWrite.d(tag, "---------------------" + messageToSend);
        } catch (Exception ex) {
            Toast.makeText(context, ex.toString(), Toast.LENGTH_SHORT).show();
        }
        return messageToSend;
    }

    private String getAppType(Context context, String package_name) {
        KTInstalled installed = new KTInstalled(context);
        ArrayList<com.kochartech.library.Application.KTApplicationInfo> appsList = installed
                .getInstalledApps();
        for (com.kochartech.library.Application.KTApplicationInfo ktApplicationInfo : appsList) {
            if (ktApplicationInfo.getPackageName().equals(package_name)) {
                return ktApplicationInfo.getAppType();
            } else
                continue;
        }
        return "";
    }

    /**
     * Ping the Network for the stated URL.
     *
     * @param url
     * @return
     */
    public String ping(String url) {
        String toSend = "A1:" + url + ";B1:8;C1:0;D1:100;E1:N/A;F1:N/A;G1:N/A;";
        String str = "";
        // Hashtable<String, String> pingKeyValues=new Hashtable<String,
        // String>();
        String[] arr = new String[7];
        String[] arr1 = {"A1:", "B1:", "C1:", "D1:", "E1:", "F1:", "G1:"};

        int count = 0;
        try {
            LogWrite.d(tag, "Before execute...");

            java.lang.Process process = Runtime.getRuntime().exec(
                    "/system/bin/ping -c 8 " + url);

            InputStream inputStream = process.getInputStream();

            // LogWrite.d(tag, inputStream.toString());

            LogWrite.d(tag, "after process");
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    inputStream));

            LogWrite.d(tag, " reader ");

            int i;
            char[] buffer = new char[1024];
            StringBuffer output = new StringBuffer();

            // LogWrite.d(tag,
            // " output " + output.toString() + " " + reader.read(buffer));
            if (reader.read(buffer) > 0) {
                LogWrite.d(tag, " output " + output.toString() + " output ");

            } else {
                LogWrite.d(tag, " output is less than 0 " + output.toString()
                        + " ");
            }
            while ((i = reader.read(buffer)) > 0) {
                LogWrite.d(tag, "inside while ");

                output.append(buffer, 0, i);
            }

            LogWrite.d(tag, " reader before   ");
            reader.close();

            LogWrite.d(tag, " reader close   ");

            // body.append(output.toString()+"\n");
            if (output != null) {
                LogWrite.d(tag, " output lenght" + output.length());
                str = output.toString();
                // LogWrite.d(TAG, str);
                int indexDash = str.lastIndexOf("---");
                // body.append(indexDash+""+str.length());

                String statStrings = str.substring(indexDash + 3, str.length());

                int indexMs = statStrings.indexOf("ms");
                LogWrite.d(tag, "stat strings gaurav" + statStrings);
                String pingStats = statStrings.substring(0, indexMs);
                String[] pingStatsArr = pingStats.split(",");

                arr[count] = url;
                count++;
                // LogWrite.d(TAG,"ji"+pingStatsArr[0]);
                String dummy = "";
                // dummy=dummy.substring(0,dummy.indexOf("packets"));

                // arr[count]="gaurav"+pingStatsArr[1];
                arr[count] = "8";

                count++;
                dummy = pingStatsArr[1];
                dummy = dummy.substring(0, dummy.indexOf("received"));
                arr[count] = dummy;
                count++;
                dummy = dummy.trim();
                if (dummy.equalsIgnoreCase("0")) {
                    return "A1:" + url
                            + ";B1:8;C1:0;D1:100;E1:N/A;F1:N/A;G1:N/A;";
                }

                dummy = pingStatsArr[2];
                dummy = dummy.substring(0, dummy.indexOf("%"));
                arr[count] = dummy;
                count++;

                LogWrite.d(tag, "Value: " + pingStats);
                String minAvgMax = statStrings.substring(statStrings
                        .indexOf("=") + 1);
                LogWrite.d(tag, "min avg max: " + minAvgMax);

                String[] minAvg = minAvgMax.split("/");

                arr[count] = minAvg[2];
                count++;
                arr[count] = minAvg[0];
                count++;
                arr[count] = minAvg[1];
                count++;

                for (String stt : arr) {
                    LogWrite.d(tag, "stt " + stt);
                }

                for (int in = 0; in < 7; in++) {
                    toSend += arr1[in] + arr[in] + ";";
                }

                LogWrite.d(tag, "hello " + toSend);

            }// end if output !=null
            else {
                LogWrite.d(tag, "else part output is null ");
            }

            return toSend;

        } catch (Exception e) {
            LogWrite.d(tag, "exception in ping " + e.toString());
            return "A1:" + url + ";B1:8;C1:0;D1:100;E1:N/A;F1:N/A;G1:N/A;";
            // e.printStackTrace();
        }
        // return toSend;

    }

    /**
     * Retrieves the GPS Coordinates of the device.
     */
    // public void getGPSCordinates() {
    // String TAG = "getGPSCordinates";
    // String display;
    // try {
    // GetHandsetInfo handsetInfo = new GetHandsetInfo(
    // getApplicationContext());
    //
    // int cellID = handsetInfo.getCellID();
    // int lac = handsetInfo.getLocationAreaCode();
    // display = "cellID:" + cellID + "\nlac:" + lac + "\n";
    // LogWrite.d(TAG, display);
    //
    //
    // if (cellID != 0 && lac != -1) {
    //
    // LogWrite.d(TAG, cellID + " lac  " + lac);
    // Findlocation objectFindLocation = new Findlocation();
    // objectFindLocation.execute(handsetInfo);
    // }
    //
    // } catch (ExceptionDTO e) {
    // Toast.makeText(this, e.toString(), 2000).show();
    //
    // LogWrite.d(TAG, "error==" + e.toString());
    // e.printStackTrace();
    // }
    // }
    public void sendLocationFromMyLocationListener(String latitudeLongitueString) {
        String messageToSend = "";
        String[] strings = latitudeLongitueString.split("~");

        LogWrite.d(tag, strings[0] + "  " + strings[1]);

        messageToSend = "MN:" + htDMCommand.get("MN")
                + ";CNo:1;CMD-1:GETCORDS;CMDINF-1" + ":<GP-1:<A1:" + strings[0]
                + ";B1:" + strings[1] + ";>;>;";
        try {
            sendTextMessage(mobileNumber, messageToSend);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getLocationByNetworkProvider(final String commandID) {
        final String tag = "GetMyLocation";
        LogWrite.d(tag, "getLocationByNetworkProvider Work");
        LocationManager locationManager = (LocationManager) context
                .getSystemService(Context.LOCATION_SERVICE);
        LogWrite.d(tag, "1");
        SendResponseDTO sendResponseDTO = new SendResponseDTO();
        sendResponseDTO.setCommandKey(commandID);
        sendResponseDTO.setCommandKey("LOC");
        if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            try {
                LogWrite.d(tag, "Network Provider");
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER, 1000, 1000,
                        new LocationListener() {
                            public void onStatusChanged(String provider,
                                                        int status, Bundle extras) {
                                // TODO Auto-generated method stub

                            }

                            public void onProviderEnabled(String provider) {
                                // TODO Auto-generated method stub

                            }

                            public void onProviderDisabled(String provider) {
                                // TODO Auto-generated method stub

                            }

                            public void onLocationChanged(Location location) {
                                String locationCoordinates = "";
                                double latitude;
                                double longitude;
                                try {

                                    latitude = location.getLatitude();
                                    longitude = location.getLongitude();
                                    if (latitude == -1 || longitude == -1) {
                                        LogWrite.d(tag, "inside the if  ");
                                        getCordinates(context, commandID);
                                    } else {
                                        LogWrite.d(tag,
                                                "onLocationChanged Work");
                                        String latitudeLongiTude = 0 + "~" + 0;
                                        latitudeLongiTude = location
                                                .getLatitude()
                                                + "~"
                                                + location.getLongitude();
                                        LogWrite.d(tag, "latitudeLongiTude = "
                                                + latitudeLongiTude);
                                        new Findlocation().execute(latitudeLongiTude, commandID);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
            } catch (Exception e) {
                LogWrite.d(tag, "ExceptionDTO " + e);
                String messageToSend;
                //Failed to find location , send default location

//                messageToSend = "MN:" + htDMCommand.get("MN")
//                        + ";CNo:1;CMD-1:GETCORDS;CMDINF-1" + ":<GP-1:<A1:"
//                        + "0" + ";B1:" + "0" + ";>;>;";
                try {
                    JSONObject responseLoc = new JSONObject();
                    responseLoc.put("__type", "LocateReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
                    responseLoc.put("Address", "null");
                    responseLoc.put("Latitude", -1);
                    responseLoc.put("Longitude", -1);
                    addtoLog("Could not send Location Information.");
                    sendResponseDTO.setResponse(responseLoc);
                    String s = postRequestOkhttp(AppConstant.SEND_RESPONSE_URL, sendResponseDTO.toJSON().toString());
                    Log.d(tag, "getLocationByNetworkProvider:Location failed response  ");
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        } else {
            try {
                getCordinates(context, commandID);
            } catch (Exception e) {
                LogWrite.d(tag, "ExceptionDTO " + e);
                try {
                    JSONObject responseLoc = new JSONObject();
                    responseLoc.put("__type", "LocateReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
                    responseLoc.put("Address", "null");
                    responseLoc.put("Latitude", -1);
                    responseLoc.put("Longitude", -1);
                    addtoLog("Could not send Location Information.");
                    sendResponseDTO.setResponse(responseLoc);
                    String s = postRequestOkhttp(AppConstant.SEND_RESPONSE_URL, sendResponseDTO.toJSON().toString());
                    Log.d(tag, "getLocationByNetworkProvider:Location failed response  ");
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }

        }

        LogWrite.d(tag, "2");
        LogWrite.d(tag, "get Location ends");
    }

    public void getCordinates(Context context, String commandID) {
        String display;
        String locationCoordinates = null;
        try {
            // GetHandsetInfo handsetInfo = new GetHandsetInfo(context);
            long cellID = getCellID(context);
            int lac = getLocationAreaCode(context);
            display = "cellID:" + cellID + "\nlac:" + lac + "\n";
            LogWrite.d(tag, display);
            if (cellID != 0 && lac != -1) {
                LogWrite.d(tag, "cellid: " + cellID + " location:  " + lac);
                HandsetLocation handsetLocation = new HandsetLocation();
                locationCoordinates = handsetLocation.getLocation(context);
            } else {
                locationCoordinates = "0~0";
            }
            new Findlocation().execute(locationCoordinates, commandID);
        } catch (Exception e) {
            LogWrite.d(tag, "error==" + e.toString());
            e.printStackTrace();
        }
    }

    /**
     * Retrieves Latitude and Longitude of Current Location using CEllID, LAC.
     *
     * @param aCellID
     * @param aLAC
     * @return String
     * @throws Exception
     */

    public String LatitudeLongitudeClass(int aCellID, int aLAC)
            throws Exception {
        // String TAG = "LatitudeLongitudeClass";
        LogWrite.d(tag, " LatitudeLongitudeClass:> " + aCellID + "  a lac "
                + aLAC);
        String result = "";
        String latitudteLongitudeString = "";
        String baseURL = "http://www.google.com/glm/mmap";

        HttpClient client = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(baseURL);
        httpPost.setEntity(new LocationHelperClass(aCellID, aLAC));
        HttpResponse response = client.execute(httpPost);
        StatusLine statusLine = response.getStatusLine();
        HttpEntity resEntity = response.getEntity();
        if (resEntity != null) {

            // LogWrite.d(TAG,"RESPONSE"+EntityUtils.toString(resEntity));

        }
        InputStream response2 = resEntity.getContent();
        DataInputStream dis = new DataInputStream(response2);
        // Read some prior data
        dis.readShort();
        dis.readByte();
        // Read the error-code
        int errorCode = dis.readInt();
        LogWrite.d(tag, "LatitudeLongitudeClass:> errorcode==" + errorCode);
        if (errorCode == 0) {
            double lat = (double) dis.readInt() / 1000000D;
            double lng = (double) dis.readInt() / 1000000D;
            LogWrite.d(tag, "LatitudeLongitudeClass:> lat==" + lat + "lng="
                    + lng);
            // Read the rest of the data
            dis.readInt();
            dis.readInt();
            dis.readUTF();
            result = "lat:" + lat + "\nlng:" + lng + "\n";
            latitudteLongitudeString = lat + "~" + lng;
            String ad = getUserLocation(lat + "", lng + "");
            result += "add:" + ad;
            LogWrite.d(tag, "LatitudeLongitudeClass:> before load");
            // webView.loadUrl("https://maps.google.com/maps?q=" + lat + "," +
            // lng);
            LogWrite.d(tag, "LatitudeLongitudeClass:> after load");
        }
        LogWrite.d(tag, "LatitudeLongitudeClass:> statusLine%%%%%%%%%%%%%%%%%"
                + statusLine);
        return latitudteLongitudeString;

    }

    /**
     * Traces Route of the IPHost provided.
     *
     * @param hostIP
     * @return
     */
    public String traceroute(String hostIP) {
        // String tag = "taceroute method";
        int strarCount = 0;
        String LastTraceIP = "";
        try {

            String ip = "";
            int hopCount = 1;
            Runtime r = Runtime.getRuntime();
            StringBuffer pingResult;
            try {
                while (true) {
                    pingResult = new StringBuffer();
                    String pingCmd = "ping -t " + hopCount + " -c 1 " + hostIP;
                    java.lang.Process p = r.exec(pingCmd);
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(p.getInputStream()));
                    String inputLine;
                    LogWrite.d(tag, "Ping********" + "before while");
                    while ((inputLine = in.readLine()) != null) {
                        pingResult.append(inputLine);
                    }
                    LogWrite.d(tag, "pingResult===" + pingResult);
                    String s = new String(pingResult);
                    if (s.contains("From")) {
                        int from_pos = s.indexOf("From");
                        int icmp_pos = s.indexOf("icmp_seq");

                        ip = s.substring(from_pos + 5, icmp_pos - 1);
                        LogWrite.d(tag, "ip======" + ip);
                        LogWrite.d(tag, hopCount + "    " + ip);
                        LastTraceIP = ip;
                        strarCount = 0;

                    } else if (s.contains("min")) {
                        LogWrite.d(tag, "if reached destination");
                        LogWrite.d(tag, hopCount + "    " + hostIP
                                + "Traceroute Complete");
                        return "success";

                    } else {
                        ip = "*";
                        strarCount++;
                        if (strarCount == 5) {
                            return LastTraceIP;
                        }
                        LogWrite.d(tag, hopCount + "    " + ip);

                        LogWrite.d(tag, "does not contains from");
                    }
                    LogWrite.d(tag, "hostIP==" + hostIP + "==ip" + ip + "==="
                            + hostIP.equals(ip));
                    hopCount++;
                    LogWrite.d(tag, "hop count===" + hopCount);
                    LogWrite.d(tag, "Ping********" + "after while");
                }
            } catch (UnknownHostException e) {
                System.out.println("&&&&tttt&&&&" + e.toString());
                LogWrite.d(tag, "-----1---------->" + e.toString());
            } catch (Exception e) {
                System.out.println("&&&&tttt&&&&" + e.toString());
                LogWrite.d(tag, "-----2---------->" + e.toString());
            }
        } catch (Exception e) {
            LogWrite.d(tag, "Error==" + e.toString());
            e.printStackTrace();
        }
        return "gaurav";
    }

    /*
     * Get Files From sd card
     */

    /**
     * Enables/Disables bluetooth on the choice entered.<br>
     * 0: Disable Bluetooth.<br>
     * 1: Enable Bluetooth.
     *
     * @param choice
     */
    public void enableBlueTooth(int choice) {
        BluetoothAdapter blueToothAdapter = BluetoothAdapter
                .getDefaultAdapter();
        if (choice == 0) {
            if (blueToothAdapter.isEnabled()) {
                blueToothAdapter.disable();//
                addtoLog("Bluetooth disabled.");
            }
        } else {
            if (!blueToothAdapter.isEnabled()) {
                blueToothAdapter.enable();//
                addtoLog("Bluetooth enabled.");
            }
        }
    }

    /**
     * Enables/Disables WIFI on the choice entered.<br>
     * 0: Disable WIFI.<br>
     * 1: Enable WIFI.
     *
     * @param choice
     */
    public void enableWiFi(int choice) {
        WifiManager wifiManager = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        if (choice == 0) {

            if (wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(false);
                addtoLog("WIFI Disabled.");
            }
        } else {

            if (!wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(true);
                addtoLog("WIFI Enabled.");
            }
        }
    }

    /**
     * To check whether BlueTooth is enabled/disabled.
     */
    public int isBlueToothEnabled() {
        LogWrite.d("BT", "isBlueToothEnabled");
        BluetoothAdapter blueToothAdapter = BluetoothAdapter
                .getDefaultAdapter();
        LogWrite.d("BT", "BT :" + blueToothAdapter);
        if (blueToothAdapter.isEnabled()) {
            LogWrite.d("BT", "BT :" + blueToothAdapter);
            return 1;
        } else {
            return 0;
        }

    }

    /**
     * To check whether wifi is enabled/disabled.
     */
    public int isWiFiEnabled() {
        LogWrite.d("HandsetInfo", "isWiFiEnabled");
        WifiManager wifiManager = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        if (wifiManager.isWifiEnabled()) {
            return 1;
        } else {
            return 0;
        }
    }

    /*
     * Encrypt Files
     */

    /**
     * To check whether GPS is enableddisabled.
     */
    public int isGpsEnabled() {
        LogWrite.d("HandsetInfo", "isGpsEnabled");
        final LocationManager manager = (LocationManager) context
                .getSystemService(Context.LOCATION_SERVICE);

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            return 0;
        } else {
            return 1;
        }

    }

    /**
     * UnInstalls the application provided as the parameter and returns<br>
     * 1:If Uninstalls successfully.<br>
     * 0: If Unsuccessful.
     *
     * @param appName
     * @return {@link Integer}
     */
    public int unInstallApp(String appName) {
        String TAG = "unInstallApp";
        LogWrite.d(TAG, "in uninsatll " + appName);
        Log.d(TAG, "unInstallApp: " + appName);
        String packageName = "";
        boolean flag = false;
        try {
            PackageManager pm = context.getPackageManager();
            // Intent intent = new Intent(Intent.ACTION_MAIN, null);
            // intent.addCategory(Intent.CATEGORY_LAUNCHER);
            {
                List<ApplicationInfo> list = context.getPackageManager()
                        .getInstalledApplications(
                                PackageManager.GET_UNINSTALLED_PACKAGES);
                for (int n = 0; n < list.size(); n++) {
                    if ((list.get(n).flags & ApplicationInfo.FLAG_SYSTEM) != 1) {
                        if (list.get(n).loadLabel(pm).toString()
                                .equalsIgnoreCase(appName)) {
                            LogWrite.d(TAG, "Equal " + appName + " "
                                    + list.get(n).loadLabel(pm).toString());
                            packageName = list.get(n).packageName;
                            flag = true;
                        } else {
                            LogWrite.d(TAG, "not Equal " + appName + " "
                                    + list.get(n).loadLabel(pm).toString());
                        }
                    }
                }
            }
            // uninstall app
            if (flag) {
                Uri uri = Uri.parse("package:" + packageName);
                Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, uri);
                uninstallIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(uninstallIntent);
                return 1;
            }

            // breakMsgToSend(messageToSend, true);
        } catch (Exception ex) {
            Toast.makeText(context, ex.toString(), 4000).show();
            return 0;
        }
        return 0;
    }

    public int unInstallRooted(String appName) {
        PackageManager pm = context.getPackageManager();
        String packageName = "";
        boolean flag = false;
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        {
            List<ApplicationInfo> list = context.getPackageManager()
                    .getInstalledApplications(
                            PackageManager.GET_UNINSTALLED_PACKAGES);
            for (int n = 0; n < list.size(); n++) {
                if ((list.get(n).flags & ApplicationInfo.FLAG_SYSTEM) != 1) {
                    if (list.get(n).loadLabel(pm).toString().equals(appName)) {
                        LogWrite.d("AppCMP", "Equal " + appName + " "
                                + list.get(n).loadLabel(pm).toString());
                        packageName = list.get(n).packageName;
                        flag = true;
                    } else {
                        // LogWrite.d("AppCMP","not Equal "+ appName + " "+
                        // list.get(n).loadLabel(pm).toString());
                    }

                }
            }
            if (!flag) {
                LogWrite.d("AppCmp", "Unable to uninstall app as no such app");
            }
        }

        if (flag) {
            java.lang.Process process;
            try {
                process = Runtime.getRuntime().exec("su");
                DataOutputStream os = new DataOutputStream(
                        process.getOutputStream());
                os.writeBytes("mount -o rw,remount /data; \n");
                // os.writeBytes("rm -rf /data/app/com.kochar.test-1.apk; \n");
                // os.writeBytes("rm -rf /data/app/com.kochar.dm-1.apk; \n");
                os.writeBytes("pm uninstall " + packageName + "; \n");
                // 05-08 14:30:36.180: D/RootedUninstallActivity(10301):
                // PkgName==com.kochar.test

                /*
                 * os.writeBytes("mount -o remount,rw -t rfs /dev/stl5 /system; \n"
                 * );
                 * os.writeBytes("rm -r /data/app/com.kochar.test-1.apk; \n");
                 * os
                 * .writeBytes("mount -o remount,ro -t rfs /dev/stl5 /system; \n"
                 * ); os.writeBytes("pm uninstall com.kochar.test; \n");
                 */
                return 1;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            return 0;
        }

        return 0;
    }

    /*
     * check whether device is in Roaming N/W
     */

    public int getLocationServicesInfo() {
        Dialog dialog;
        LogWrite.d("HandsetInfo", "getLocationServicesInfo");
        boolean gps_enabled = false, network_enabled = false;
        LocationManager lm = null;
        lm = (LocationManager) context
                .getSystemService(Context.LOCATION_SERVICE);
        network_enabled = lm
                .isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if ((!network_enabled)) {
            return 1;
        } else {
            // Toast.makeText(getApplicationContext(),
            // "enabled",Toast.LENGTH_LONG).show();
            return 1;
        }
    }

    // Sending SMS COde:

    public void fetchfiles() {
        String path = Environment.getExternalStorageDirectory().toString();
        // getFiles(path);
        getFiles(path, "txt");
    }

    public void getFiles(String path) {
        File mfile = new File(path);
        File[] files = mfile.listFiles();

        LogWrite.d(tag, "list" + mfile.listFiles().length);
        for (int i = 0; i < mfile.listFiles().length; i++) {
            File file = files[i];
            /*
             * if(files[i].isHidden()) {
             * //System.out.prinln("hidden path files.."
             * +list[i].getAbsolutePath());
             * LogWrite.d(TAG,"hidden path files.."+files[i].getAbsolutePath());
             * } else {
             * LogWrite.d(TAG,"else path files.."+list[i].getAbsolutePath()); }
             */

            // path.add(file.getPath());
            if (!file.isHidden()) {
                if (file.isDirectory()) {
                    LogWrite.d(tag, file.getAbsolutePath() + "/");
                    getFiles(file.getAbsolutePath() + "/");
                } else {
                    LogWrite.d(tag, file.getAbsolutePath());
                    addtoList(file);
                }
            }

        }

    }

    // public void sendTextMessage(String address, String message)
    // throws ExceptionDTO {
    // final String tag = "SendTextMessage";
    // String messageToAppend, messageToSend = "";
    // try {
    // URL url;
    // try {
    // url = new URL(SERVERURL);
    // // url = new
    // // URL("http://202.164.36.66/mdmswebsf/mdmshandler.ashx");
    // // url = new
    // // URL("http://192.165.0.15/mdmswebsf/mdmshandler.ashx");
    // LogWrite.d(tag, "msggg isssssss" + message);
    // messageToAppend = "DM:1of1;UID:" + htDMCommand.get("UID")
    // + ";DT:<";
    // messageToSend += messageToAppend + message + ">;";
    //
    // // LogWrite.d("Editprofile Message ===", messageInAction);
    //
    // URLConnection conn = url.openConnection();
    // final HttpURLConnection httpConn = (HttpURLConnection) conn;
    // httpConn.setDoInput(true);
    // httpConn.setDoOutput(true);
    // httpConn.setAllowUserInteraction(true);
    // httpConn.setRequestProperty("Content-Type", "text/plain");
    // httpConn.setRequestMethod("POST");
    // OutputStreamWriter os = new OutputStreamWriter(
    // httpConn.getOutputStream());
    // httpConn.connect();
    // LogWrite.d("Editprofile Message ===",
    // "MessageID:"
    // + getRandomNumber()
    // + "MessageClass:EventMessageType:HSetToHTTPEvent:"
    // + "NewDMResponseChunkData:" + messageToSend
    // + "Mobile:" + phoneNumberToSend + "Content-Length:0");
    //
    // LogWrite.d(tag,
    // ("MessageID:"
    // + getRandomNumber()
    // + "\nMessageClass:Event\nMessageType:HSetToHTTP\nEvent:"
    // + "NewDMResponse\nChunkData:" + messageToSend
    // + "\nMobile:" + phoneNumberToSend + "\nContent-Length:0\n"));
    // os.write("MessageID:"
    // + getRandomNumber()
    // + "\nMessageClass:Event\nMessageType:HSetToHTTP\nEvent:"
    // + "NewDMResponse\nChunkData:" + messageToSend
    // + "\nMobile:" + phoneNumberToSend
    // + "\nContent-Length:0\n");
    // Calendar c = Calendar.getInstance();
    // // WriteToFile("ResponseDTO sent at:"+c.getTime());
    // LogWrite.d(tag,
    // "-----------------------------------2------------------------------------------------");
    // os.close();
    // // ins.runOnUiThread(new Runnable() {
    // //
    // // @Override
    // // public void run() {
    // // // TODO Auto-generated method stub
    // // String data = httpConn.getHeaderField("DMLogs");
    // // LogWrite.d(tag, "DMLogs====->" + data);
    // //
    // // }
    // // });
    // String data = httpConn.getHeaderField("DMLogs");
    // LogWrite.d(tag, "DMLogs====->" + data);
    // LogWrite.d(tag,
    // "----------------------------------3-------------------------------------------------");
    // } catch (ExceptionDTO e) {
    // e.printStackTrace();
    // }
    // } catch (ExceptionDTO ex) {
    // Toast.makeText(getApplicationContext(),
    // "Exc send text message " + ex.toString(),
    // Toast.LENGTH_SHORT).show();
    // }
    // }

    public void getFiles(String path, String Selection) {
        File mfile = new File(path);
        File[] files = mfile.listFiles();

        // LogWrite.d(TAG, "list" + mfile.listFiles().length);
        for (int i = 0; i < mfile.listFiles().length; i++) {
            File file = files[i];
            /*
             * if(files[i].isHidden()) {
             * //System.out.println("hidden path files.."
             * +list[i].getAbsolutePath());
             * LogWrite.d(TAG,"hidden path files.."+files[i].getAbsolutePath());
             * } else {
             * LogWrite.d(TAG,"else path files.."+list[i].getAbsolutePath()); }
             */

            // path.add(file.getPath());
            if (!file.isHidden()) {
                if (file.isDirectory()) {
                    // LogWrite.d(TAG, file.getAbsolutePath() + "/");
                    getFiles(file.getAbsolutePath() + "/", Selection);
                } else {
                    // LogWrite.d(TAG, file.getAbsolutePath());
                    Filename filename = new Filename(file.getAbsolutePath(),
                            '/', '.');
                    LogWrite.d(tag, "ext==" + filename.extension()
                            + "Selection==" + Selection);
                    if (Selection.equals(filename.extension())) {
                        LogWrite.d(tag, "match==" + file.getAbsolutePath());
                        addtoList(file);
                    } else {
                        LogWrite.d(tag, "not match==" + file.getAbsolutePath());
                    }
                }
            }

        }

    }

    public void addtoList(File file) {

        // Book aBookDetail = new Book();
        // //aBookDetail.setBookIsbn(i);
        // aBookDetail.setBookName(file.getName());
        // aBookDetail.setBookPath(file.getAbsolutePath());
        //
        // bookArray.add(aBookDetail);
    }

    /*
     * Fetch Cell Id & Location area code
     */
    int getCellId() {
        try {
            LogWrite.d("HandsetInfo", "getCellId");
            final TelephonyManager telephony = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);
            if (telephony.getSimSerialNumber() == null) {
                return 0;
            } else {
                // if (telephony.getPhoneType() ==
                // TelephonyManager.PHONE_TYPE_GSM)
                // {
                final GsmCellLocation location = (GsmCellLocation) telephony
                        .getCellLocation();
                if (location != null) {
                    // locale="LAC: " + location.getLac() + " CID: " +
                    // location.getCid();
                    // body.setText("LAC: " + location.getLac() + " CID: " +
                    // location.getCid());
                }
                int cellId = location.getCid();
                cellId = cellId & 0xffff;
                // body.setText(cellId+"");
                return cellId;
                // }
                // else
                // {
                // // showToast("Not on GSM Network", 2000);
                // }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;

    }

    public String isRoamingStatus() {
        // String Roaming="01";
        // String notRoaming="02";
        LogWrite.d("HandsetInfo", "isRoamingStatus");
        TelephonyManager telephonyManager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager.isNetworkRoaming()) {
            networkState = "RNG";
        } else {
            networkState = "HNW";
        }
        return networkState;

    }

    /**
     * flag was introduced to identify the acknowledgement to be sent to the
     * server in commands except startsession
     */

    public void breakMsgToSend(String message, Boolean flag) {
        try {
            int messageSubPartCount = 0;
            String org = message;
            String arrOfMessageSubParts[] = new String[40];
            ArrayList<String> parts = new ArrayList<String>();
            int totalMessageLength = org.length();
            int var = 120;
            int totalMessageSubParts = (int) Math
                    .ceil((float) totalMessageLength / var);
            String duplicate;
            duplicate = org;
            int duplicateLength = duplicate.length();
            String messageSubPart = "";
            String messageToAppend;
            String messageToSend = "";
            LogWrite.d(tag, "message is breaking here..");
            while (duplicateLength > var) {
                messageSubPart = duplicate.substring(0, var);
                arrOfMessageSubParts[messageSubPartCount] = messageSubPart;
                // Updating all values
                messageSubPartCount++;
                duplicate = duplicate.substring(var, duplicateLength);
                duplicateLength = duplicate.length();
            }

            if (duplicateLength > 0) {
                arrOfMessageSubParts[messageSubPartCount] = duplicate;
            } else {
                messageSubPartCount--;
            }
            LogWrite.d(tag, "Something is send after this...");
            if (flag == true) {
                for (int i = 0; i < totalMessageSubParts; i++) {
                    messageToAppend = "DM:" + (i + 1) + "of"
                            + totalMessageSubParts + ";UID:"
                            + htDMCommand.get("UID") + ";DT:<";
                    messageToSend += messageToAppend + arrOfMessageSubParts[i]
                            + ">;";
                    parts.add(messageToSend);
                    messageToSend = "";
                }
            } else {
                for (int i = 0; i < totalMessageSubParts; i++) {
                    // consider using 0
                    messageToAppend = "DM:" + (i + 1) + "of"
                            + totalMessageSubParts + ";UID:"
                            + htDMCommand.get("UID") + ";DT:<";
                    messageToSend += arrOfMessageSubParts[i] + ">;";
                    parts.add(messageToSend);
                    messageToSend = "";
                }
            }
            LogWrite.d(tag, "Something is send after this...");
            for (int i = 0; i < parts.size(); i++) {
                if (i == 0) {
                    // this will be removed once messages are sent without
                    // breaking
                    Thread.sleep(10000);
                }
                sendTextMessage(mobileNumber, parts.get(i));
            }
        } catch (Exception e) {
            Toast.makeText(context, "brk msg ExceptionDTO " + e.toString(),
                    Toast.LENGTH_LONG).show();
        }
    }

    public void sendTextMessage(String address, final String message) {
        // if(isToSleep)
        // {
        // try {
        // Thread.sleep(1000);
        // } catch (InterruptedException e1) {
        // // TODO Auto-generated catch block
        // e1.printStackTrace();
        // }
        // }
        new Thread(new Runnable() {

            @Override
            public void run() {
                String tag = "sendtextmessage";
                try {
                    LogWrite.d(tag, "Message =" + message);
                    ServerResponse.set(message);

                    String messageToAppend, messageToSend = "";
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost(SERVERURL);
                    messageToAppend = "DM:1of1;UID:" + htDMCommand.get("UID")
                            + ";DT:<";
                    messageToSend += messageToAppend + message + ">;";
                    LogWrite.d(tag, "Server URL : " + SERVERURL);
                    LogWrite.d(tag, "sendresponse--" + "MessageID:"
                            + getRandomNumber()
                            + "MessageClass:EventMessageType:HSetToHTTPEvent:"
                            + "NewDMResponseChunkData:" + messageToSend
                            + "Mobile:" + phoneNumberToSend
                            + "Content-Length:0\n");
                    httppost.setEntity(new StringEntity(
                            "MessageID:"
                                    + getRandomNumber()
                                    + "\nMessageClass:Event\nMessageType:HSetToHTTP\nEvent:"
                                    + "NewDMResponse\nChunkData:"
                                    + messageToSend + "\nMobile:"
                                    + phoneNumberToSend
                                    + "\nContent-Length:0\n"));
                    HttpResponse resp = httpclient.execute(httppost);
                    HttpEntity ent = resp.getEntity();

                    LogWrite.d(tag, "StatusCode ="
                            + resp.getStatusLine().getStatusCode());

                    if (resp.getStatusLine().getStatusCode() == 200) {
                        // ServerResponse.set("");
                        LogWrite.d(tag, "Send Successfully!");
                    } else {
                        // Thread.sleep(2000);
                        // sendTextMessage(address,message);
                        LogWrite.d(tag, "Sending Failed!");
                    }

                } catch (Exception e) {
                    LogWrite.d(tag, "ExceptionDTO =::" + e);
                }

            }
        }).start();

    }

    /**
     * Divides data into small KEY:VALUE pair and make decision using
     * <p>
     * {@code processCommand()} method.
     *
     * @param response
     */
    public void makeDecision(String response, Context context) {
        String key = "", value = "";
        String message;
        String remainingMessage = "";
        String TagMakeDecision = "MakeDecision";
        String tag = "MakeDecision";
        try {
            // LogWrite.d(tag, TagMakeDecision+ " MAke Decision Called ");
            int index = response.indexOf("ChunkData");
            int indexOfMessageId = response.indexOf("MessageID");
            // LogWrite.d(tag, TagMakeDecision+ " index of mess id-> " +
            // indexOfMessageId);
            message = response.substring(index + 10, indexOfMessageId);
            LogWrite.d(tag, " Message-: " + message);

            // ChunkData:DM:1of1;UID:23204_186843;DT:<MN:9958112020;CNo:1;CMD-1:STRTSESS;CMDINF-1:
            // <HT:<A:352337040725012;B:samsung;C:GT-I5801;D:405180010771617;E:194;F:160;G:50;K:1.0;
            // H:Android2.2;L:0;M:0;N:1;I:0;J:0;O:0;P:0;Q:1;>;NW:<A:Reliance;D:HNW;E:95;C:11541;>;
            // PR-3:<A1:Netconnect;C1:rcomnet;K1:1;A2:Reliance
            // MMS;C2:rcommms;K2:0;A3:vodafone;C3:gprs.com;K3:0;>;>;>;

            if (message.contains("KOCHAR-DM"))// Kochar-D
            {
                LogWrite.d(tag, TagMakeDecision + "contains kochar dm  ");
                String messagePart = message;
                String dm = "DM";
                String uId = "UID";
                messagePart = messagePart.substring(10, messagePart.length());
                LogWrite.d(tag, TagMakeDecision + " message part "
                        + messagePart);
                key = "";
                char[] charArray = messagePart.toCharArray();
                int arrayLength = charArray.length;

                for (int i = 0; i < arrayLength; i++) {
                    if (charArray[i] == ':') // for-if 1
                    {
                        // LogWrite.d(tag, TagMakeDecision+ " : encountered " +
                        // key);
                        if (key.equals(dm)) {
                            // LogWrite.d(tag, TagMakeDecision+
                            // " : key == dm ");
                            i++;
                            while (charArray[i] != ';') {
                                value += charArray[i];
                                i++;
                            }
                            String seqPrt[] = value.split("of");
                            seqNo = Integer.parseInt(seqPrt[0]);
                            msgParts = Integer.parseInt(seqPrt[1]);
                            key = "";
                            value = "";
                            // LogWrite.d(tag, TagMakeDecision+ "  seq :"+ seqNo
                            // +
                            // ", msgpart " + msgParts);
                        }// if
                    }// fro-if 1
                    else if (key.equals(uId)) {
                        i++;
                        while (charArray[i] != ';') {
                            value += charArray[i];
                            i++;
                        }
                        uidCounter++;
                        // LogWrite.d(tag,"uid counter " + i+ "****" +
                        // uidCounter);
                        if (uidCounter == 1) {
                            masterUid = value;
                            masterUid.split("_");
                        }
                        uidComaparitive = value;
                        // LogWrite.d(tag,"key+++value" + key + value);
                        key = "";
                        value = "";
                    } // end else if key.equals(uId))
                    else {
                        key += charArray[i];
                    }
                }// end for
                // LogWrite.d(tag, masterUid+"  "+uidComaparitive);
                // comparison of uid with master uid
                if (masterUid.equals(uidComaparitive)) {
                    // Toast.makeText(context1," uid comparison success ",
                    // 1000).show();
                    // LogWrite.d(tag, " Make decision. cmp success  ->"
                    // +msgParts);
                    if (msgParts != 1) {
                        // LogWrite.d(tag, TagMakeDecision+ " msg parts !=1  ");
                        // Toast.makeText(getApplicationContext()," msgparts!= 1",
                        // 1000).show();
                        seqCounter++;
                        AccumulateMessage(message.trim());
                    } else {
                        // LogWrite.d(tag, "msg parts equals 1  ");
                        seqCounter++;
                        arrayMessagepart[seqNo] = message;// messagePart.substring(0,messagePart.length()-2
                        // );
                        // remainingMessage=str;
                        // AccumulateMessage(message.trim());
                    }
                    if (seqCounter == msgParts) {
                        // LogWrite.d(tag, "seq == msg parts  ");
                        uidCounter = 0;
                        for (int i = 1; i <= msgParts; i++) {
                            remainingMessage += arrayMessagepart[i];
                        }
                        seqCounter = 0;
                        msgParts = 0;
                        seqNo = 0;
                        DmCommand formattedCommand = new DmCommand();

                        LogWrite.d(tag, "remaining msg " + remainingMessage);
                        Hashtable<String, String> hashTableData = formattedCommand
                                .parseCompleteMessage(remainingMessage);
                        /**
                         * fetching data part from the hashtable and removing it
                         * from the same. so that it can be forwarded to
                         * DMServer as an acknowledgement in case of commands
                         * except startSession
                         */
                        LogWrite.d(tag, "" + hashTableData.toString());
                        if (hashTableData.get("nothing") != null) {

                        } else {
                            ConvertHashTableToString ob1 = new ConvertHashTableToString();
                            String stringObtainedFromHashTable = ob1
                                    .createMessageFromHashtable(hashTableData);
                            LogWrite.d(TagMakeDecision, "string from ht "
                                    + stringObtainedFromHashTable);
                            processCommand(stringObtainedFromHashTable, context);
                        }
                    }
                }// end if master uid
                else {
                    // LogWrite.d(TagMakeDecision, "cmp not success   ");
                    Toast.makeText(context, "comparison not success ", 1000)
                            .show();
                    masterUid = "";
                    uidComaparitive = "";
                    seqNo = 0;
                    msgParts = 0;
                    remainingMessage = "";
                    uidCounter = 0;
                    seqCounter = 0;
                }

            }// if kocchar-DM
            // }//while if check
            else {
                // Toast.makeText(getApplicationContext(),
                // "**Cant recieve String from server", 1000).show();
                LogWrite.d(tag, "**Cant recieve String from server" + "#######");
            }
        }// try 1

        catch (Exception ex) {
            // textView.setText("error=="+ex.toString());
            Toast.makeText(context,
                    "Unable to make connection error==" + ex.toString(), 3000)
                    .show();
        } // catch 1
    }// make decision

    public void AccumulateMessage(String messagePart) {
        try {
            if (seqNo == 1) {
                arrayMessagepart[seqNo] = messagePart.substring(0,
                        messagePart.length() - 2);
                LogWrite.d(tag, seqNo + " " + arrayMessagepart[seqNo]);
                // Toast.makeText(getApplicationContext(),
                // arrayMessagepart[seqNo] , Toast.LENGTH_SHORT).show();
                // remainingMessage=messagePart.substring(0,messagePart.length()-2
                // );
            } else if (seqNo == msgParts) {
                int index = messagePart.indexOf("<");
                // Toast.makeText(context1, " Index of < ", 2000).show();
                arrayMessagepart[seqNo] = messagePart.substring(index + 1,
                        messagePart.length());
                LogWrite.d(tag, seqNo + " " + arrayMessagepart[seqNo]);
                // Toast.makeText(context1, "last part"+arrayMessagepart[seqNo]
                // ,Toast.LENGTH_SHORT).show();
            } else {
                int index = messagePart.indexOf("<");
                arrayMessagepart[seqNo] = messagePart.substring(index + 1,
                        messagePart.length() - 2);
                LogWrite.d(tag, seqNo + " " + arrayMessagepart[seqNo]);
                // Toast.makeText(context1, arrayMessagepart[seqNo] ,
                // Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ex) {
            Toast.makeText(context, "accumulate " + ex.toString(),
                    Toast.LENGTH_SHORT).show();
        }
    }// Acumulate msg

   /* void installApp(String appURl) {
        URL urls = null;
        try {
            urls = new URL(appURl);
        } catch (MalformedURLException e1) {
            LogWrite.d(tag,
                    "MalformedURLException : " + e1.toString());
        }

        int length;

        InputStream inputStream = null;
        try {
            inputStream = urls.openStream();
        } catch (IOException e) {

            e.printStackTrace();
        }

        DataInputStream dataInputStream = new DataInputStream(
                inputStream);

        byte[] buffer = new byte[1024];

        String destinationPath = context.getFilesDir() + "/";

        isDirectoryPresent(destinationPath);

        File file = new File(destinationPath + File.separator
                + fileName);

        LogWrite.d(tag, "path " + file.getAbsolutePath());

        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = context.openFileOutput(fileName,
                    Context.MODE_WORLD_WRITEABLE
                            | Context.MODE_WORLD_READABLE);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            while ((length = dataInputStream.read(buffer)) > 0) {
                fileOutputStream.write(buffer, 0, length);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // LogWrite.d(tag, "File downloaded at " + getFilesDir() +
        // "/"
        // + fileName);

        try {
            fileOutputStream.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(
                Uri.fromFile(new File(context.getFilesDir() + "/"
                        + fileName)),
                "application/vnd.android.package-archive");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        response[count] = 1;
    }
*/

    /*
     * taken from httpoperation class
     */
    public boolean doPost(String value, String className, Context context)
            throws ClientProtocolException, IOException {
        String responseString = "";
        LogWrite.d(tag, " in do post ");

        HttpURLConnection urlConnection = null;
        URL _url = null;

        try {
            _url = new URL(SERVERURL);

            // URL _url = new URL(WebServiceURL.SEND_RESPONSE.toString());
            urlConnection = (HttpURLConnection) _url.openConnection();
            urlConnection.setConnectTimeout(2 * 1000);
            urlConnection.setReadTimeout(2 * 1000);
            urlConnection.setRequestMethod("POST");
            urlConnection
                    .setRequestProperty("Content-Type", "application/json");
            // urlConnection.setRequestProperty("Content-Length",
            // value.length()+"" );
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            DataOutputStream dos = new DataOutputStream(
                    urlConnection.getOutputStream());
            byte[] bs = value.toString().getBytes();
            LogWrite.d(tag, "Sending JSON String ji->" + new String(bs));

            dos.write(bs);
            dos.flush();
            dos.close();

            LogWrite.d(tag, "ResponseDTO ->" + urlConnection.getResponseMessage());

            if (urlConnection.getResponseMessage().toLowerCase().equals("ok")) {
                // Logs.write("Sent successfully");
                InputStream is = urlConnection.getInputStream();
                long ch;
                StringBuffer b = new StringBuffer();
                while ((ch = is.read()) != -1) {
                    b.append((char) ch);
                }
                responseString = b.toString();
                LogWrite.d(tag, "responseString=" + responseString);

                makeDecision(responseString, context);
                bs = null;
                b = null;
                _url = null;
                urlConnection = null;

                /*
                 * to get current date and time
                 */
                // getDateTime(context);

                return true;

            } // data sent successfully
            // dos.close();

        } catch (SocketException e) {
            // Logs.write("Error: "+e.getMessage());
            LogWrite.d(tag, "responseString=" + e);
            _url = null;
            return false;

        } catch (Exception e) {
            // Logs.write("Error: "+e.getMessage());
            _url = null;
            LogWrite.d(tag, "responseString=" + e);
            Log.e(tag, "-->" + e);
            return false;
        }

        return false;
    }
    // =========================================

    public void extractCommand(ResponseDTO responseDTO) {
//        JSONObject outerObject = new JSONObject(data);
        try {
            JSONObject params = new JSONObject(responseDTO.getParams());
            Log.d(tag, "extractCommand: " + params.toString());
            String commandKey = responseDTO.getCommandKey();
            String MAC_ADDRESS = responseDTO.getMAC(); //This is MAC Address.
            String commandID = responseDTO.getMessageCommandId();
//            JSONObject params = new JSONObject();
            Log.d(tag, "extractCommand: Started");
            switch (commandKey) {
                case "SS"://StartSession
                    passCommand(Commands.START_SESSION, commandID);
                    break;
                case "HINFO"://HandsetInfo
//                    if (params.getBoolean("Ping")) {
                    passCommand(Commands.HANDSET_INFO, commandID);
//                    }
                    break;
                case "OPNSTG"://Open Settings
                    passCommand(Commands.OPEN_SETTING, commandID, params);
                    break;
                case "GETAPP"://Get Apps
                    passCommand(Commands.GET_APP, commandID);
                    break;
                case "FLGSTG"://Get Apps
                    passCommand(Commands.FLAG_SETTING, commandID, params);
                    break;
                case "ENDSESS"://Get Apps
                    passCommand(Commands.END_SESSION, commandID);
                    break;
                case "LOC":
                    passCommand(Commands.GET_LOCATION, commandID);
                    break;
                case "INAP":
                    passCommand(Commands.INSTALL_APP, commandID, params);
                    break;
                case "UA":
                    passCommand(Commands.UNINSTALL_APP, commandID, params);
                    break;
                case "HWTST":
                    passCommand(Commands.HARDWARE_TEST, commandID, params);
                    break;

//                case "LST"://Lost
//                    if (params.getBoolean("Lost")) {
//                        passCommand(Commands.ALARM_ON, commandID);
//                    } else {
//                        passCommand(Commands.ALARM_OFF, commandID);
//                    }
//                    break;
//                case "LK"://Lock
//                    if (params.getBoolean("Lock")) {
//                        passCommand(Commands.LOCK, commandID);
//                    } else {
//                        passCommand(Commands.UNLOCK, commandID);
//                    }
//                    break;
//                case "LOC"://Locate
//                    passCommand(Commands.LOCATE, commandID);
//                    break;
//                case "LT"://Location Track
//                    passCommand(Commands.LOCATE, commandID);
//                    break;
//                case "LR"://Location Track
//                    if (params.getBoolean("Track"))
//                        passCommand(Commands.LOC_TRACK, commandID);
//                    break;
                default:
                    Log.d(tag, "extractCommand: No Command Received");

            }
//            params.get("");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    void passCommand(Commands commands, final String commandID, JSONObject... params) {
        AckDTO ack = new AckDTO();
        switch (commands) {
            case START_SESSION: {
                Log.d(tag, "passCommand: Start Session");
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Session Started");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand: Ack Send");


                try {
                    LogWrite.d(tag, "DATA   -> StartSession Work");
                    addtoLog("Connected Success.");
                    addtoLog("Start Session Received.");
                    LogWrite.d(tag, "mobileNumber-> " + mobileNumber);
                    try {
                        mdmActivity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                startActivity(new Intent(mdmActivity,
                                        MyHiddenActivity.class).putExtra(MyHiddenActivity.commandID_TAG, commandID));
                            }
                        });
                    } catch (Exception e) {
                        LogWrite.e(tag, "ExceptionDTO...." + e);
                    }

                } catch (Exception ex) {
                    Toast.makeText(mdmActivity, ex.toString(),
                            Toast.LENGTH_SHORT).show();
                }
            }
            break;
            case OPEN_SETTING: {
                addtoLog("Open Settings requested by server");

                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Settings Received");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand:Open Settings Params:  " + params[0].toString());
                Log.d(tag, "passCommand: open setting  received from server");
                String actionSetting = null;
                try {
                    actionSetting = params[0].getString("ActionName");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                OpenSettingsUtility openSettingsUtility = new OpenSettingsUtility();
                openSettingsUtility.openSetting(getActivity(), actionSetting, getActivity().getApplicationContext());
                break;

            }
            case GET_APP:
                Log.d(tag, "passCommand: end session received");
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Apps Received");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand:GetApp Ack sent");
                getAppsMobile(commandID);
                addtoLog("Application information requested by and sent to server.");

                Log.d(tag, "passCommand: Apps sent");
                break;

            case HANDSET_INFO:
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("HandsetInfo Received");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand:Handset Ack sent");
                sendHandsetInfo(commandID);
                Log.d(tag, "passCommand: HandsetInfo sent");
                break;
            case INSTALL_APP:
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Install App Received");
                acknowledgeCommand(ack);
                addtoLog("Install Application requested by server.");

                JSONObject jsonObject = params[0];
                try {
                    String AppName = jsonObject.getString("AppName");
                    String AppDescription = jsonObject.getString("AppDescription");
                    String AppUrl = jsonObject.getString("AppUrl");
                    String AppVersion = jsonObject.getString("AppVersion");
                    Intent newDownloadServiceIntent = new Intent(getActivity(), DownloadAppLatestService.class);
                    newDownloadServiceIntent.putExtra("AppPath", AppUrl);
                    getActivity().startService(newDownloadServiceIntent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                Log.d(tag, "passCommand:INSTALL_APP Ack sent");
//                sendHandsetInfo(commandID);
                Log.d(tag, "passCommand: INSTALL_APP Received");
                break;
            case UNINSTALL_APP:
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Uninstall App Received");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand:UNINSTALL_APP Ack sent");
                addtoLog("Uninstall Application requested by server.");
                JSONObject jsonObject1 = params[0];
                try {
                    String appName = jsonObject1.getString("AppName");
                    int response;
                    response = unInstallApp(appName);
                    LogWrite.d(tag, "response of uninstall app----> " + response);
                    boolean unInstallFlagResponse = false;
                    if (response == 1) {
                        LogWrite.d(tag, "response = 1");
                        app_name = appName;
                        myDataBase = new MyDataBaseHandlerClass(context,
                                "operators.db", null, 1);
                        myDataBase.getWritableDatabase();
                        myDataBase.DeleteApp(appName);
                        myDataBase.close();
                        unInstallFlagResponse = false;
                    } else if (response == 0) {
                        unInstallFlagResponse = true;
                    }
                    if (unInstallFlagResponse) {
                        addtoLog("Could not Uninstall Application.");
                    } else {
                        addtoLog("Application Uninstalled.");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
//                sendHandsetInfo(commandID);
                Log.d(tag, "passCommand: UNINSTALL_APP Received");
                break;

            case END_SESSION:
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("EndSession Received");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand:Endsession Ack sent");
                addtoLog("End Session requested by server.");
                Log.d(tag, "passCommand: end session received");
                mdmActivity.runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        // TODO Auto-generated method stub

                        // Intent intent = new Intent(Intent.ACTION_MAIN);
                        // intent.addCategory(Intent.CATEGORY_HOME);
                        // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        // intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        // startActivity(intent);

                        FragmentListener fragmentListener = (FragmentListener) getActivity();
                        fragmentListener.onItemClicked(
                                FragmentListener.actionRemove,
                                new MDMMainActivity());
                        // mdmActivity.finish();
                        // System.exit(-1);
                    }
                });
                Log.d(tag, "passCommand: Apps sent");
                break;
            case FLAG_SETTING:
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Flag Setting Received");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand:Flag Setting Ack sent");
                addtoLog("Flag Setting requested by server.");
                JSONObject param = params[0];

                try {
                    flagSetting(param.getString("FeatureName"), param.getBoolean("Status"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.d(tag, "passCommand: Flag Setting received");

                break;
            case HARDWARE_TEST:
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Hardware Test Received");
                acknowledgeCommand(ack);
                Log.d(tag, "passCommand:HardwareTest Ack sent");
                try {
                    addtoLog(params[0].getString("TestName") + " hardware test requested by Server.");
                    MonitorDTO monitorDTO = new MonitorDTO();
                    //call this method with name of the test
                    checkHardwareTest(monitorDTO,params[0].getString("TestName"),commandID);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.d(tag, "passCommand: HardwareTest received");

                break;
            case GET_LOCATION: {
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("GetLocation Received");
                acknowledgeCommand(ack);
                addtoLog("Location information requested by server.");
                Log.d(tag, "passCommand: Ack sent");
                LogWrite.d(tag, "********************************************");
                LogWrite.d(tag, "entered in GETCORDS");
                if (checkforMobileData()) {
                    LogWrite.d(tag, "Http ok");
                    mdmActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            getLocationByNetworkProvider(commandID);
                        }
                    });
                    addtoLog("Location information sent to server.");
                } else {
                    addtoLog("Failed to send Location information to server.");

                    try {
                        SendResponseDTO sendResponseDTO = new SendResponseDTO();
                        sendResponseDTO.setCommandKey(commandID);
                        sendResponseDTO.setCommandKey("LOC");
                        JSONObject responseLoc = new JSONObject();
                        responseLoc.put("__type", "LocateReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
                        responseLoc.put("Address", "not found");
                        responseLoc.put("Latitude", -1);
                        responseLoc.put("Longitude", -1);
                        addtoLog("Could not send Location Information.");
                        sendResponseDTO.setResponse(responseLoc);
                        String s = postRequestOkhttp(AppConstant.SEND_RESPONSE_URL, sendResponseDTO.toJSON().toString());
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            }
            break;
        }
    }

    /*
     *Send Acknowledgement To the Server that the command is received
     * This starts off a network thread, with the object passed.
     * */
    public void acknowledgeCommand(AckDTO obj) {
        //start the network thread
        Log.d(tag, "acknowledgeCommand: thread start");
        new AckCommand(obj).start();
        Log.d(tag, "acknowledgeCommand: thread end");
    }

    String getRequestOkhttp(String url) throws IOException {
        final OkHttpClient client = new OkHttpClient();
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .get()
                .build();
        okhttp3.Response response = client.newCall(request).execute();
        return response.body().string();
    }

    String postRequestOkhttp(final String url, final String json) throws IOException {

        final OkHttpClient client = new OkHttpClient();
        final MediaType JSON
                = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        final okhttp3.Response response = client.newCall(request).execute();
        Log.d(tag, "post called with url: " + url + " '\njson: " + json + "\nResponse Code :" + response.code() + "\nResponse Body :" + response.body().toString());
        return response.body().string();
    }

    public void showToast(final String text, final int delay) {

        mdmActivity.runOnUiThread(new Runnable() {
            public void run() {

                Toast.makeText(context, text, delay).show();

            }
        });
    }

    /**
     * Generates a Random Number.
     *
     * @return String
     */
    public String getRandomNumber() {
        String finalRN = "";
        Random rd = new Random(10000);
        int randomNumber = rd.nextInt();
        String rn = Integer.toString(randomNumber);

        if (rn.startsWith("-")) {
            int index = rn.indexOf("-");
            finalRN = rn.substring(index + 1, rn.length());
            LogWrite.d(tag, "getRandomNumber-> " + finalRN);
            return finalRN;
        } else {
            return rn;
        }

        // return Integer.toString(randomNumber);
    }

    public void showToast(String messageText) {
        LayoutInflater inflator = mdmActivity.getLayoutInflater();
        View layout = inflator.inflate(R.layout.customizedtoast,
                (ViewGroup) mdmActivity.findViewById(R.id.toastLayoutId));
        ImageView image = (ImageView) layout.findViewById(R.id.toastImage);
        TextView text = (TextView) layout.findViewById(R.id.toastText);
        image.setImageResource(R.drawable.appicon);
        text.setText(messageText);
        Toast toast = new Toast(mdmActivity);
        toast.setDuration(4000);
        toast.setGravity(Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(layout);
        toast.show();
    }

    public int checkUSBTethering() {
        LogWrite.d("HandsetInfo", "checkUSBTethering");
        String tag = "usbTethering";
        try {
            ConnectivityManager cm = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);

            LogWrite.d(tag, "test enable usb tethering");
            String[] available = null;
            Method[] wmMethods = cm.getClass().getDeclaredMethods();
            for (Method method : wmMethods) {

                LogWrite.d(tag, method.getName());
                if (method.getName().equals("getTetheredIfaces")) {
                    try {
                        available = (String[]) method.invoke(cm);
                        LogWrite.d(tag, "available==" + available.length);
                        String kk = "";
                        for (int i = 0; i < available.length; i++) {
                            LogWrite.d(tag, "list of array:" + available[i]);
                            kk = kk + " " + available[i] + " ";
                        }
                        LogWrite.d(tag, "kk--" + kk);
                        if (available.length > 0) {
                            if (kk.contains("usb"))
                                return 1;
                            else
                                return 0;
                        } else {
                            return 0;
                        }
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        // return;
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                        // return;
                    } catch (InvocationTargetException e) {
                        LogWrite.d(tag, "eroor=34=" + e.toString());
                        e.printStackTrace();
                        // return;
                    }
                }
            }
        } catch (Exception e) {
            LogWrite.d(tag, "ExceptionDTO:>>> " + e.toString());
            e.printStackTrace();
        }
        return 0;
    }

    public int checkWiFITethering() {

        String tag = "wifitethering";
        try {
            ConnectivityManager cm = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);

            LogWrite.d(tag, "test enable usb tethering");
            String[] available = null;
            Method[] wmMethods = cm.getClass().getDeclaredMethods();
            for (Method method : wmMethods) {
                if (method.getName().equals("getTetheredIfaces")) {
                    try {
                        available = (String[]) method.invoke(cm);
                        LogWrite.d(tag, "available==" + available.length);
                        String kk = "";
                        for (int i = 0; i < available.length; i++) {
                            LogWrite.d(tag, "list of array:" + available[i]);
                            kk = kk + " " + available[i] + " ";
                        }
                        LogWrite.d(tag, "kk--" + kk);
                        if (available.length > 0) {
                            if (kk.contains("w10"))
                                return 1;
                            else
                                return 0;
                        } else {
                            return 0;
                        }
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                        // return;
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                        // return;
                    } catch (InvocationTargetException e) {
                        LogWrite.d(tag, "eroor=34=" + e.toString());
                        e.printStackTrace();
                        // return;
                    }
                }
            }
        } catch (Exception e) {
            LogWrite.d(tag, "ExceptionDTO:>>> " + e.toString());
            e.printStackTrace();
        }
        return 0;
    }

    int checkHotspot() {
        boolean state = false;
        LogWrite.d("HandsetInfo", "checkUSBTethering");
        WifiManager wifi = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        Method[] wmMethods = wifi.getClass().getDeclaredMethods();
        for (Method method : wmMethods) {
            if (method.getName().equals("isWifiApEnabled")) {

                try {
                    state = (Boolean) method.invoke(wifi);
                    if (state == true) {
                        // Toast.makeText(getApplicationContext(), "on",
                        // Toast.LENGTH_LONG).show();
                        return 1;
                    } else {
                        // Toast.makeText(getApplicationContext(), "off",
                        // Toast.LENGTH_LONG).show();
                        return 0;
                    }

                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
            }
        }
        return 0;
    }

    int HotSpot(boolean b) {
        wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        try {
            wifi.setWifiEnabled(false);
            Method method1 = wifi.getClass().getMethod("setWifiApEnabled",
                    WifiConfiguration.class, boolean.class);
            WifiConfiguration wifiConfig = new WifiConfiguration();
            wifiConfig.SSID = " DIY Phone Gadgets";
            wifiConfig.allowedAuthAlgorithms
                    .set(WifiConfiguration.AuthAlgorithm.OPEN);

            boolean state = (Boolean) method1.invoke(wifi, null, b); // true
            addtoLog("Hotspot " + (b ? "Enabled" : "Disabled"));
            LogWrite.d(tag, "state==" + state);
            return 1;
        } catch (Exception e) {
            Log.e(tag, e + "");
            return 0;
        }
    }

    int USBTethering(boolean b) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            LogWrite.d(tag, "test enable usb tethering");
            Method[] wmMethods = cm.getClass().getDeclaredMethods();
            String str = "";
            if (b) {
                str = "tether";
                addtoLog("Tethering enabled.");
            } else {
                str = "untether";
                addtoLog("Tethering disabled.");
            }

            for (Method method : wmMethods) {
                LogWrite.d("in usb tethering method", method.getName()
                        + "<<nn>>");
                if (method.getName().equals(str)) {
                    LogWrite.d(tag, "gg==" + method.getName());
                    LogWrite.d("in if", " case matches " + method.getName()
                            + "and str is " + str);
                    try {
                        Integer code = (Integer) method.invoke(cm, "usb0");
                        // code = (Integer) method.invoke(cm, "setting TH");
                        LogWrite.d(tag, "code===" + code);
                        return 1;
                    } catch (IllegalArgumentException e) {
                        LogWrite.d(tag, "eroor== gg " + e.toString());
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        LogWrite.d(tag, "eroor== gg " + e.toString());
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        LogWrite.d(tag, "eroor== gg " + e.toString());
                        e.printStackTrace();
                    }
                }
            }
            return 0;

        } catch (Exception e) {
            Log.e(tag, "" + e);
            return 0;
        }

    }

    public void WriteToFile(String getData) {
        File fob = new File(Environment.getExternalStorageDirectory(),
                "Dmlogs.txt");
        try {
            boolean append = true;

            FileWriter writer = new FileWriter(fob, append);
            BufferedWriter out = new BufferedWriter(writer);
            out.append(getData + "\n");
            writer.flush();
            out.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }// END OF WriteToFile METHOD

    void isDirectoryPresent(String directoryPath) {
        try {
            File file = new File(directoryPath);
            boolean flag = file.exists();
            LogWrite.d(tag, directoryPath + " exist is  " + flag);

            if (!flag) {
                file.mkdirs();
            }
        } catch (Exception ex) {
            LogWrite.d(tag, ex.toString());
        }
    }

    void showErrorDialog() {

        error_dialog = new Dialog(mdmActivity);
        error_dialog.setTitle("Mobile Search");
        error_dialog.setContentView(R.layout.warning_dialog_layout);
        error_dialog.show();
        Button ok = (Button) error_dialog
                .findViewById(R.id.CRMDialog_ok_button);
        Button cancel = (Button) error_dialog
                .findViewById(R.id.CRMDialog_cancel_button);

        ok.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                String url = ((EditText) error_dialog
                        .findViewById(R.id.CRMDialog_URL)).getText().toString();
                if (url.trim().length() > 0) {
                    insertURLtoFile(url);
                    error_dialog.dismiss();
                } else {
                    Toast.makeText(mdmActivity, "Please Enter URL first",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        cancel.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                error_dialog.dismiss();
            }
        });
    }

    protected void insertURLtoFile(String url) {
        try {
            FileWriter fileWritter = new FileWriter(
                    Environment.getExternalStorageDirectory() + "/DM/" + "URL"
                            + ".txt", false);

            if (fileWritter != null) {
                BufferedWriter bufferWritter = null;
                String ss = url;
                bufferWritter = new BufferedWriter(fileWritter, ss.length());
                bufferWritter.write(ss);
                bufferWritter.close();
            }
            Toast.makeText(mdmActivity, "URL Saved.", Toast.LENGTH_SHORT)
                    .show();
        } catch (IOException e) {
            LogWrite.d("ERROR Writing Logs:", "" + e.toString());
            e.printStackTrace();
        }

    }

    private void setSpeedPreferences(String messageFromProcesCommand) {
        String startDateTime, endDateTime;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        startDateTime = dateFormat.format(cal.getTime());
        cal.setTimeInMillis(System.currentTimeMillis() + 3 * 24 * 3600 * 1000);
        endDateTime = dateFormat.format(cal.getTime());

        // messageInAction += htDMCommand.get("CMD-" + i);
        // messageInAction += ";CMDINF-" + i + ":";
        // // command=htDMCommand.get("CMD-"+i);
        // messageInAction += getApps()
        //
        // "DM:1of1;UID:" + htDMCommand.get("UID")
        // + ";DT:<"

        SharedPreferences sharePerference = PreferenceManager.getDefaultSharedPreferences(context);
        Editor editor = sharePerference.edit();
        editor.putString("starttime", startDateTime);
        editor.putString("endtime", endDateTime);
        editor.putBoolean("enable", true);
        // editor.putString("uid",htDMCommand.get("UID"));

        editor.putString("outerbodystart",
                "DM:1of1;UID:" + htDMCommand.get("UID") + ";DT:<");
        editor.putString("outerbodyend", ">;");
        editor.putString("innerbodystart", messageFromProcesCommand + "CMD-"
                + 1 + ":" + htDMCommand.get("CMD-" + 1) + ";CMDINF-" + 1 + ":");
        editor.putString("innerbodyend", ";");
        editor.putLong("starttimeL", System.currentTimeMillis());
        editor.putLong("endtimeL", System.currentTimeMillis() + 3 * 24 * 3600
                * 1000);
        editor.putInt("interval", 5);

        editor.commit();
    }

    protected void startSpeedTest() {
        // String startDateTime,endDateTime;
        // DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        // Calendar cal = Calendar.getInstance();
        // startDateTime = dateFormat.format(cal.getTime());
        // cal.setTimeInMillis(System.currentTimeMillis()+3*24*3600*1000);
        // endDateTime = dateFormat.format(cal.getTime());
        //

        SharedPreferences sharePerference = PreferenceManager
                .getDefaultSharedPreferences(context);
        long startT = sharePerference.getLong("starttimeL", 0);
        long endT = sharePerference.getLong("endtimeL", 0);

        LogWrite.d("stats1", "startTime =" + startT);
        LogWrite.d("stats1", "endTime =" + endT);
        // sharePerference.edit().putString("starttime",startDateTime);
        // sharePerference.edit().putString("endtime",endDateTime);
        // sharePerference.edit().putLong("starttime",System.currentTimeMillis());
        // sharePerference.edit().putLong("endtime",System.currentTimeMillis()+3*24*3600*1000);
        // sharePerference.edit().putInt("interval",5);
        // sharePerference.edit().commit();

        Intent startTestIntent = new Intent(context, StartTestReceiver.class);
        // Intent stopTestIntent = new Intent(this, StopTestReceiver.class);

        AlarmManager alarmManager = (AlarmManager) context
                .getSystemService(Context.ALARM_SERVICE);
        PendingIntent pendingstartTestIntent = PendingIntent.getBroadcast(
                context, 232324, startTestIntent, 0);
        // PendingIntent pendingstopTestIntent =
        // PendingIntent.getBroadcast(this.getApplicationContext(), 232324,
        // stopTestIntent, 0);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis(), (30 * 60 * 1000L),
                pendingstartTestIntent);
    }

    public void addtoLog(final String message) {

        final String message1 = message.replace(" by and", " and");
        final String message2 = message1.replace("MDM",
                "Remote Call Assistance");
        mdmActivity.runOnUiThread(new Runnable() {
            public void run() {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm aa");
                String currentDateandTime = sdf.format(new Date());

                logText.append(Html.fromHtml("<font color=#FFE401><b>" + "["
                        + currentDateandTime + "] " + "</b></font>"
                        + "<font color=WHITE>" + message + "</font>" + "<br>"));

                // scrollview.post(new Runnable() {
                // public void run() {
                // // scrollview.scrollTo(0, logText.getBottom());
                // if(scrollview.isPressed())
                // {
                // //------- Do Nothing ---------
                // }
                // else
                // {
                // scrollview.smoothScrollBy(0, logText.getBottom());
                // }
                //
                // }
                // });

            }
        });
    }

    // void checkDataConnection()
    // {
    // if (checkforMobileData()) {
    //
    // // Toast.makeText(this, "Mobile data enabled", Toast.LENGTH_SHORT)
    // // .show();
    // if(isRoamingStat())
    // {
    // if(isDataRoamingEnabled(MDMMainActivity.this))
    // {
    // // Toast.makeText(this, "data roaming enabled",
    // Toast.LENGTH_SHORT).show();
    // }
    // else
    // {
    // //
    // showAlert("Your Network is in Roaming and Data Roaming is Disabled. Please Enable it to use internet.");
    //
    // }
    // }
    // else
    // {
    // LogWrite.d(">>>>>>>","Network not roaming");
    // }
    //
    // }
    // else if(!checkforMobileData())
    // {
    //
    // }
    // else
    // {
    //
    // }
    // }
    boolean checkforMobileData() {
        boolean enabled = true;
        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        if ((info == null || !info.isConnected() || !info.isAvailable())) {
            enabled = false;
        }
        return enabled;
    }

    public Boolean isDataRoamingEnabled(Context context) {
        try {
            // return true or false if data roaming is enabled or not
            return Settings.Secure.getInt(context.getContentResolver(),
                    Settings.Secure.DATA_ROAMING) == 1;
        } catch (SettingNotFoundException e) {
            // return null if no such settings exist (device with no radio
            // data?)
            return null;
        }
    }

    public void openSetting(String setting) {
        try {
            String settingToOpen = "Settings." + setting;
            LogWrite.d(">>>>>>>>", "setting " + settingToOpen);
            if (setting.equals("ACTION_SETTINGS")) {
                Intent intent = new Intent(Settings.ACTION_SETTINGS);
                startActivity(intent);
            } else {
                Toast.makeText(context, "Unable to open Requested Settings.",
                        Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // public void showAlert(String alertMessage)
    // {
    // alertDialog = new Dialog(ins);
    // alertDialog.setTitle("Alert");
    // alertDialog.setContentView(R.layout.dialog_layout);
    // alertDialog.show();
    // TextView alerttxt = (TextView) alertDialog.findViewById(R.id.alertText);
    // Button okButton = (Button) alertDialog.findViewById(R.id.okBtn);
    // Button canButton = (Button) alertDialog.findViewById(R.id.cancelBtn);
    // alerttxt.setText(alertMessage);
    // okButton.setOnClickListener(new OnClickListener()
    // {
    // public void onClick(View v)
    // {
    //
    // alertDiaLogWrite.dismiss();
    // openSetting("ACTION_SETTINGS");
    // }
    // });
    // canButton.setOnClickListener(new OnClickListener()
    // {
    // public void onClick(View v) {
    // alertDiaLogWrite.dismiss();
    // monitoringDisabled = true;
    //
    // }
    // });
    // }
    /*
     * check whether device is in Roaming N/W
     */

    public boolean isRoamingStat() {
        // String Roaming="01";
        // String notRoaming="02";
        TelephonyManager telephonyManager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager.isNetworkRoaming();

    }

    // public String setBearerInfo(Context context) {
    // String bearerInfo = "";
    //
    // TelephonyManager teleMan = (TelephonyManager) context
    // .getSystemService(Context.TELEPHONY_SERVICE);
    // if (teleMan.getSimSerialNumber() == null) {
    // if (isWifiNetwork(context)) {
    // bearerInfo = "WiFi";
    // } else {
    // bearerInfo = "Unknown";
    // }
    // } else {
    // int networkType = teleMan.getNetworkType();
    //
    // switch (networkType) {
    // case TelephonyManager.NETWORK_TYPE_1xRTT:
    // bearerInfo = "1xRTT";
    // break;
    // case TelephonyManager.NETWORK_TYPE_CDMA:
    // bearerInfo = "CDMA";
    // break;
    // case TelephonyManager.NETWORK_TYPE_EDGE:
    // bearerInfo = "EDGE";
    // break;
    // case TelephonyManager.NETWORK_TYPE_EHRPD:
    // bearerInfo = "eHRPD";
    // break;
    // case TelephonyManager.NETWORK_TYPE_EVDO_0:
    // bearerInfo = "EVDO rev. 0";
    // break;
    // case TelephonyManager.NETWORK_TYPE_EVDO_A:
    // bearerInfo = "EVDO rev. A";
    // break;
    // case TelephonyManager.NETWORK_TYPE_EVDO_B:
    // bearerInfo = "EVDO rev. B";
    // break;
    // case TelephonyManager.NETWORK_TYPE_GPRS:
    // bearerInfo = "GPRS";
    // break;
    // case TelephonyManager.NETWORK_TYPE_HSDPA:
    // bearerInfo = "HSDPA";
    // break;
    // case TelephonyManager.NETWORK_TYPE_HSPA:
    // bearerInfo = "HSPA";
    // break;
    // case TelephonyManager.NETWORK_TYPE_HSPAP:
    // bearerInfo = "HSPA+";
    // break;
    // case TelephonyManager.NETWORK_TYPE_HSUPA:
    // bearerInfo = "HSUPA";
    // break;
    // case TelephonyManager.NETWORK_TYPE_IDEN:
    // bearerInfo = "iDen";
    // break;
    // case TelephonyManager.NETWORK_TYPE_LTE:
    // bearerInfo = "LTE";
    // break;
    // case TelephonyManager.NETWORK_TYPE_UMTS:
    // bearerInfo = "UMTS";
    // break;
    // case TelephonyManager.NETWORK_TYPE_UNKNOWN:
    // bearerInfo = "NA";
    // break;
    // }
    // }
    // return bearerInfo;
    // }
    public String setBearerInfo(Context context) {
        String bearerInfo = "";

        TelephonyManager teleMan = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        // if (teleMan.getSimSerialNumber() == null) {
        // if (isWifiNetwork(context)) {
        // bearerInfo = "WiFi";
        // } else {
        // bearerInfo = "Unknown";
        // }
        // } else {
        // if (isWifiNetwork(context)) {
        // bearerInfo = "WiFi";
        // } else {
        int networkType = teleMan.getNetworkType();

        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_1xRTT:
                bearerInfo = "1xRTT";
                break;
            case TelephonyManager.NETWORK_TYPE_CDMA:
                bearerInfo = "CDMA";
                break;
            case TelephonyManager.NETWORK_TYPE_EDGE:
                bearerInfo = "EDGE";
                break;
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                bearerInfo = "eHRPD";
                break;
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
                bearerInfo = "EVDO rev. 0";
                break;
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
                bearerInfo = "EVDO rev. A";
                break;
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
                bearerInfo = "EVDO rev. B";
                break;
            case TelephonyManager.NETWORK_TYPE_GPRS:
                bearerInfo = "GPRS";
                break;
            case TelephonyManager.NETWORK_TYPE_HSDPA:
                bearerInfo = "HSDPA";
                break;
            case TelephonyManager.NETWORK_TYPE_HSPA:
                bearerInfo = "HSPA";
                break;
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                bearerInfo = "HSPA+";
                break;
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                bearerInfo = "HSUPA";
                break;
            case TelephonyManager.NETWORK_TYPE_IDEN:
                bearerInfo = "iDen";
                break;
            case TelephonyManager.NETWORK_TYPE_LTE:
                bearerInfo = "LTE";
                break;
            case TelephonyManager.NETWORK_TYPE_UMTS:
                bearerInfo = "UMTS";
                break;
            case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                bearerInfo = "Unknown";
                break;

            // }
            // }
        }
        return bearerInfo;
    }

    public int getDataRoamingStatus(Context context) {
        try {
            if (Settings.Secure.getInt(context.getContentResolver(),
                    Settings.Secure.DATA_ROAMING) == 1) {
                return 1;
            }
        } catch (SettingNotFoundException e) {
            Log.e(tag, "DataRoaming ExceptionDTO ---> " + e.toString());
        }
        return 0;
    }

    public int getRestrictedDataStatus(Context context) {
        try {
            final ConnectivityManager manager = (ConnectivityManager) context
                    .getApplicationContext().getSystemService(
                            Context.CONNECTIVITY_SERVICE);
            Boolean bgData = manager.getBackgroundDataSetting();
            if (bgData) {
                return 1;
            }
            return 0;
        } catch (Exception e) {
            LogWrite.d(tag, "RestrictedData ExceptionDTO ----> " + e.toString());
        }
        return 0;
    }

    private boolean isWifiNetwork(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
                .isConnected()) {
            return true;
        }
        return false;
    }

    private synchronized void optimizingDevice() {
        LogWrite.i(tag, "Going to optimizing device from list of apps");
        longAsyncFlag = false;
        optimizingFlag = true;
    }

    private synchronized void checkHardwareTest(MonitorDTO monitorDTO,
                                                String hardware_test, String commandId) throws JSONException {
        String[] softKeyTitles = context.getResources().getStringArray(
                R.array.soft_key_titles);
        String tag = "CheckHardware";
        long ONE_MINUTE = 20 * 1000;
        long INTERVAL = 5000;
        long CURRENT = 0;
        sendHWTestResponseDTO = new SendResponseDTO();
        sendHWTestResponseDTO.setMessageCommandId(commandId);
        sendHWTestResponseDTO.setCommandKey("HWTST");
        sendHWTestResponseDTO.setMAC(phoneNumberToSend);
        LogWrite.i(tag, "Going to check hardware: " + hardware_test);
        KTDeviceInfo deviceInfo = new KTDeviceInfo(context);
        HardwareUtility utility = new HardwareUtility(getActivity());
        hardware_name = hardware_test;
        if (hardware_test.equals(HardwareUtility.KEY_VIBRATION_HARDWARE)) {

            LogWrite.d(tag, "Going to check vibration");
            monitorDTO.setVibrateResponse(utility.vibrate() ? 1 : 0);
            LogWrite.d(tag, "Json String : " + monitorDTO.toString());

//            jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, monitorDTO.toString());
            sendHWTestResponseDTO.setResponse(new JSONObject(monitorDTO.toString()));
            jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, sendHWTestResponseDTO.toJSON().toString());


            hardware_name = "";
        } else if (hardware_test
                .equals(HardwareUtility.KEY_FLASH_LIGHT_HARDWARE)) {
            if (utility.hasFlash()) {
                boolean flag = utility.ledon();
                try {
                    synchronized (this) {
                        wait(2000);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (flag) {
                    utility.ledoff();
                    monitorDTO.setFlashlightResponse(1);
                    // flashlightResponse = "1";
                } else {
                    monitorDTO.setFlashlightResponse(0);
                    // flashlightResponse = "0";
                }
            } else {
                monitorDTO.setFlashlightResponse(0);
                // flashlightResponse = "0";
            }
            LogWrite.d(tag, "Json String : " + monitorDTO.toString());
//            jsonResponse.send(context, AppConstant.SEND_RESPONSE_URL, monitorDTO.toString());
            sendHWTestResponseDTO.setResponse(new JSONObject(monitorDTO.toString()));
            jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, sendHWTestResponseDTO.toJSON().toString());

            hardware_name = "";
        } else if (hardware_test.equals(HardwareUtility.KEY_TOUCH_HARDWARE)) {
            Bundle bundle = new Bundle();
            bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
            FragmentListener fragmentListener = (FragmentListener) getActivity();
            TouchTestFragment touchTestFragment = new TouchTestFragment(
                    TouchTestFragment.FRAGMENT_TYPE_SIMPLE_TOUCH, this);
            touchTestFragment.setArguments(bundle);
            fragmentListener.onItemClicked(FragmentListener.actionAdd,
                    touchTestFragment);
            startActivity(new Intent(getActivity(),
                    BringApplicationToForeground.class));
        } else if (hardware_test
                .equals(HardwareUtility.KEY_LONG_PRESS_HARDWARE)) {
            Bundle bundle = new Bundle();
            bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
            FragmentListener fragmentListener = (FragmentListener) getActivity();
            TouchTestFragment touchTestFragment = new TouchTestFragment(
                    TouchTestFragment.FRAGMENT_TYPE_LONG_TOUCH, this);
            touchTestFragment.setArguments(bundle);
            fragmentListener.onItemClicked(FragmentListener.actionAdd,
                    touchTestFragment);
            startActivity(new Intent(getActivity(),
                    BringApplicationToForeground.class));
        } else if (hardware_test
                .equals(HardwareUtility.KEY_ACCELEROMETER_HARDWARE)) {
            longAsyncFlag = false;
            // Bundle bundle = new Bundle();
            // bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
            // FragmentListener fragmentListener = (FragmentListener)
            // getActivity();
            // AccelerometerBallTestFragment accelerometerTestFragment = new
            // AccelerometerBallTestFragment(
            // this);
            // accelerometerTestFragment.setArguments(bundle);
            // fragmentListener.onItemClicked(FragmentListener.actionAdd,
            // accelerometerTestFragment);
            // startActivity(new Intent(getActivity(),
            // BringApplicationToForeground.class));
        } else if (hardware_test.equals(HardwareUtility.KEY_MIC_HARDWARE)) {
            LogWrite.i("Aman", "Mic going to be test...");
            longAsyncFlag = false;
            LogWrite.i("Aman", "Flag Change..." + longAsyncFlag);
        } else if (hardware_test.equals(HardwareUtility.KEY_SPEAKER_HARDWARE)) {
            LogWrite.i("Aman", "Speaker going to be test..." + longAsyncFlag);
            longAsyncFlag = false;
            LogWrite.i("Aman", "Flag Change..." + longAsyncFlag);
        } else if (hardware_test.equals(HardwareUtility.KEY_DISPLAY_HARDWARE)) {
            LogWrite.i("Aman", "Display going to be test...");
            Bundle bundle = new Bundle();
            bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
            FragmentListener fragmentListener = (FragmentListener) getActivity();
            DisplayFragment displayFrafment = new DisplayFragment(this);
            displayFrafment.setArguments(bundle);
            fragmentListener.onItemClicked(FragmentListener.actionAdd,
                    displayFrafment);
            startActivity(new Intent(getActivity(),
                    BringApplicationToForeground.class));
        } else if (hardware_test.equals(HardwareUtility.KEY_PROXIMITY_HARDWARE)) {
            Bundle bundle = new Bundle();
            bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
            FragmentListener fragmentListener = (FragmentListener) getActivity();
            ProximitySensorTestFragment proximityTestFragment = new ProximitySensorTestFragment(
                    this);
            proximityTestFragment.setArguments(bundle);
            fragmentListener.onItemClicked(FragmentListener.actionAdd,
                    proximityTestFragment);
            startActivity(new Intent(getActivity(),
                    BringApplicationToForeground.class));
        } else if (hardware_test.equals(HardwareUtility.KEY_MULTI_TOUCH)) {
            HardwareUtility hardwareUtility = new HardwareUtility(context,
                    HardwareType.HARDWARE_TOUCHSCREEN_MULTITOUCH);
            if (hardwareUtility.hasSystemFeature()) {
                Bundle bundle = new Bundle();
                bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
                FragmentListener fragmentListener = (FragmentListener) getActivity();
                MultiTouchTestFragment multiTouchTestFragment = new MultiTouchTestFragment(
                        this);
                multiTouchTestFragment.setArguments(bundle);
                fragmentListener.onItemClicked(FragmentListener.actionAdd,
                        multiTouchTestFragment);
                startActivity(new Intent(getActivity(),
                        BringApplicationToForeground.class));
            } else {
                monitorDTO.setMultiTouchResponse(0);
                LogWrite.d(tag, "Json String : " + monitorDTO.toString());
//                jsonResponse.send(context, AppConstant.SEND_RESPONSE_URL, monitorDTO.toString());
                sendHWTestResponseDTO.setResponse(new JSONObject(monitorDTO.toString()));
                jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, sendHWTestResponseDTO.toJSON().toString());

                hardware_name = "";
            }
        } else if (hardware_test.equals(HardwareUtility.KEY_WIFI_HARDWARE)) {
            boolean wifi_status = deviceInfo.isWifiEnabled();
            while (!wifi_status) {
                deviceInfo.setWifiEnabled(true);
                sleep(INTERVAL);
                wifi_status = deviceInfo.isWifiEnabled();
                CURRENT += INTERVAL;
                if (CURRENT > ONE_MINUTE)
                    break;
            }
            if (wifi_status) {
                monitorDTO.setWifiResponse(1);
            } else {
                OpenSettingsUtility settingsUtility = new OpenSettingsUtility();
                settingsUtility.openSetting(mdmActivity,
                        "ACTION_WIFI_SETTINGS", context);
                synchronized (this) {
                    try {
                        wait(20000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                wifi_status = deviceInfo.isWifiEnabled();
                if (wifi_status) {
                    monitorDTO.setWifiResponse(1);
                } else {
                    monitorDTO.setWifiResponse(0);
                }
            }
            LogWrite.d(tag, "Json String : " + monitorDTO.toString());
//            jsonResponse.send(context, AppConstant.SEND_RESPONSE_URL, monitorDTO.toString());
            sendHWTestResponseDTO.setResponse(new JSONObject(monitorDTO.toString()));
            jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, sendHWTestResponseDTO.toJSON().toString());

            hardware_name = "";
        } else if (hardware_test.equals(HardwareUtility.KEY_BLUETOOTH_HARDWARE)) {
            boolean bluetooth_status = deviceInfo.isBluetoothEnabled();
            while (!bluetooth_status) {
                deviceInfo.setBluetoothEnabled(true);
                sleep(INTERVAL);
                bluetooth_status = deviceInfo.isBluetoothEnabled();
                CURRENT += INTERVAL;
                if (CURRENT > ONE_MINUTE)
                    break;
            }
            if (bluetooth_status) {
                monitorDTO.setBluetoothResponse(1);
            } else {
                OpenSettingsUtility settingsUtility = new OpenSettingsUtility();
                settingsUtility.openSetting(mdmActivity,
                        "ACTION_BLUETOOTH_SETTINGS", context);
                synchronized (this) {
                    try {
                        wait(20000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                bluetooth_status = deviceInfo.isBluetoothEnabled();
                if (bluetooth_status) {
                    monitorDTO.setBluetoothResponse(1);
                } else {
                    monitorDTO.setBluetoothResponse(0);
                }
            }
            LogWrite.d(tag, "Json String : " + monitorDTO.toString());
//            jsonResponse.send(context, AppConstant.SEND_RESPONSE_URL, monitorDTO.toString());
            sendHWTestResponseDTO.setResponse(new JSONObject(monitorDTO.toString()));
            jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, sendHWTestResponseDTO.toJSON().toString());

            hardware_name = "";
        } else if (hardware_test.equals(HardwareUtility.KEY_GPS_HARDWARE)) {
            boolean gps_status = deviceInfo.isGPSEnabled();
            LogWrite.d(tag, "GPS Status : " + gps_status);
            LogWrite.d(tag, "isLocationEnabled : " + isLocationEnabled(context));
            while (!gps_status) {
                deviceInfo.setGPSEnabled(true);
                sleep(INTERVAL);
                gps_status = deviceInfo.isGPSEnabled();
                CURRENT += INTERVAL;
                if (CURRENT > ONE_MINUTE)
                    break;
            }
            if (gps_status) {
                monitorDTO.setGpsResponse(1);
            } else {
                LogWrite.d(tag, "isLocationEnabled : "
                        + isLocationEnabled(context));
                if (isLocationEnabled(context)) {
                    monitorDTO.setGpsResponse(1);
                } else {
                    OpenSettingsUtility settingsUtility = new OpenSettingsUtility();
                    settingsUtility.openSetting(mdmActivity,
                            "ACTION_LOCATION_SOURCE_SETTINGS", context);
                    synchronized (this) {
                        try {
                            wait(20000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    gps_status = deviceInfo.isGPSEnabled();
                    if (gps_status) {
                        monitorDTO.setGpsResponse(1);
                    } else {
                        if (isLocationEnabled(context)) {
                            monitorDTO.setGpsResponse(1);
                        } else {
                            monitorDTO.setGpsResponse(0);
                        }
                    }
                }
            }
            LogWrite.d(tag, "Json String : " + monitorDTO.toString());
//            jsonResponse.send(context, AppConstant.SEND_RESPONSE_URL, monitorDTO.toString());
            sendHWTestResponseDTO.setResponse(new JSONObject(monitorDTO.toString()));
            jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, sendHWTestResponseDTO.toJSON().toString());

            hardware_name = "";
        } else if (hardware_test.equals(HardwareUtility.KEY_POWER_KEY)) {
            // KeysTestFragment fragment = new KeysTestFragment();
            // fragment.setOnEventListener(this);
            // Intent keyScreenIntent = new Intent(getActivity(),
            // KeysTestFragment.class);
            // keyScreenIntent.putExtra("SoftKeyTest", softKeyTitles[0]);
            // keyScreenIntent.putExtra("IsFromCommand", true);
            // keyScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // getActivity().startActivity(keyScreenIntent);
            KeysTestFragment.startActivity(getActivity(), softKeyTitles[0],
                    true, this);
        } else if (hardware_test.equals(HardwareUtility.KEY_HOME_KEY)) {
            // KeysTestFragment fragment = new KeysTestFragment();
            // fragment.setOnEventListener(this);
            // Intent keyScreenIntent = new Intent(getActivity(),
            // KeysTestFragment.class);
            // keyScreenIntent.putExtra("SoftKeyTest", softKeyTitles[1]);
            // keyScreenIntent.putExtra("IsFromCommand", true);
            // keyScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // getActivity().startActivity(keyScreenIntent);
            KeysTestFragment.startActivity(getActivity(), softKeyTitles[1],
                    true, this);
        } else if (hardware_test.equals(HardwareUtility.KEY_MENU_KEY)) {
            // KeysTestFragment fragment = new KeysTestFragment();
            // fragment.setOnEventListener(this);
            // Intent keyScreenIntent = new Intent(getActivity(),
            // KeysTestFragment.class);
            // keyScreenIntent.putExtra("SoftKeyTest", softKeyTitles[2]);
            // keyScreenIntent.putExtra("IsFromCommand", true);
            // keyScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // getActivity().startActivity(keyScreenIntent);
            // if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
            KeysTestFragment.startActivity(getActivity(), softKeyTitles[2],
                    true, this);
            // } else {
            // monitorDTO.setMultiTouchResponse(0);
            // LogWrite.d(tag, "Json String : " + monitorDTO.toString());
            // jsonResponse.send(context, server_url, monitorDTO.toString());
            // }
        } else if (hardware_test.equals(HardwareUtility.KEY_BACK_KEY)) {
            // KeysTestFragment fragment = new KeysTestFragment();
            // fragment.setOnEventListener(this);
            // Intent keyScreenIntent = new Intent(getActivity(),
            // KeysTestFragment.class);
            // keyScreenIntent.putExtra("SoftKeyTest", softKeyTitles[2]);
            // keyScreenIntent.putExtra("IsFromCommand", true);
            // keyScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // getActivity().startActivity(keyScreenIntent);
            // if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
            KeysTestFragment.startActivity(getActivity(), softKeyTitles[3],
                    true, this);
            // } else {
            // monitorDTO.setMultiTouchResponse(0);
            // LogWrite.d(tag, "Json String : " + monitorDTO.toString());
            // jsonResponse.send(context, server_url, monitorDTO.toString());
            // }
        } else if (hardware_test.equals(HardwareUtility.KEY_VOLUME_UP_KEY)) {
            // KeysTestFragment fragment = new KeysTestFragment();
            // fragment.setOnEventListener(this);
            // Intent keyScreenIntent = new Intent(getActivity(),
            // KeysTestFragment.class);
            // keyScreenIntent.putExtra("SoftKeyTest", softKeyTitles[3]);
            // keyScreenIntent.putExtra("IsFromCommand", true);
            // keyScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // MDMMainActivity.this.startActivity(keyScreenIntent);
            KeysTestFragment.startActivity(getActivity(), softKeyTitles[4],
                    true, this);
        } else if (hardware_test.equals(HardwareUtility.KEY_VOLUME_DOWN_KEY)) {
            // KeysTestFragment fragment = new KeysTestFragment();
            // fragment.setOnEventListener(this);
            // Intent keyScreenIntent = new Intent(getActivity(),
            // KeysTestFragment.class);
            // keyScreenIntent.putExtra("SoftKeyTest", softKeyTitles[4]);
            // keyScreenIntent.putExtra("IsFromCommand", true);
            // keyScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            // MDMMainActivity.this.startActivity(keyScreenIntent);
            KeysTestFragment.startActivity(getActivity(), softKeyTitles[5],
                    true, this);
        } else if (hardware_test
                .equals(HardwareUtility.KEY_BACK_CAMERA_HARDWARE)) {
            LogWrite.d(tag, "Back Camera going to test");

            CameraDTO cameraDTO = new CameraDTO();
            cameraDTO.setMessageId(monitorDTO.getMessageId());
            cameraDTO.setSessionId(monitorDTO.getSessionId());
            cameraDTO.setType(HardwareUtility.KEY_BACK_CAMERA_HARDWARE);
            Bundle bundle = new Bundle();
            bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
            FragmentListener fragmentListener = (FragmentListener) getActivity();
            CameraTestFragment cameraTestFragment = new CameraTestFragment(
                    cameraDTO);
            cameraTestFragment.setArguments(bundle);
            fragmentListener.onItemClicked(FragmentListener.actionAdd,
                    cameraTestFragment);
            longAsyncFlag = false;
            LogWrite.i(tag, "Flag Change..." + longAsyncFlag);
        } else if (hardware_test
                .equals(HardwareUtility.KEY_FRONT_CAMERA_HARDWARE)) {
            LogWrite.d(tag, "Front Camera going to test");

            CameraDTO cameraDTO = new CameraDTO();
            cameraDTO.setMessageId(monitorDTO.getMessageId());
            cameraDTO.setSessionId(monitorDTO.getSessionId());
            cameraDTO.setType(HardwareUtility.KEY_FRONT_CAMERA_HARDWARE);
            Bundle bundle = new Bundle();
            bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND, true);
            FragmentListener fragmentListener = (FragmentListener) getActivity();
            CameraTestFragment cameraTestFragment = new CameraTestFragment(
                    cameraDTO);
            cameraTestFragment.setArguments(bundle);
            fragmentListener.onItemClicked(FragmentListener.actionAdd,
                    cameraTestFragment);
            longAsyncFlag = false;
            LogWrite.i(tag, "Flag Change..." + longAsyncFlag);
        }

    }

    @Override
    public void onCommand(boolean value) {
        LogWrite.e("Aman", "On Command Receive: " + value);

        // Toast.makeText(context,
        // "Hardware Name : " + hardware_name + " : Value : " + value,
        // Toast.LENGTH_SHORT).show();
        final MonitorDTO monitorDTO = new MonitorDTO();

        if (hardware_name.equals(HardwareUtility.KEY_TOUCH_HARDWARE)) {
            monitorDTO.setTouchResponse(value ? 1 : 0);
        } else if (hardware_name
                .equals(HardwareUtility.KEY_LONG_PRESS_HARDWARE)) {
            monitorDTO.setLongpressResponse(value ? 1 : 0);
        } else if (hardware_name
                .equals(HardwareUtility.KEY_ACCELEROMETER_HARDWARE)) {
            monitorDTO.setAcceleResponse(value ? 1 : 0);
            longAsyncFlag = true;
            MyLongRunningTask task = new MyLongRunningTask();
            task.execute(mdmActivity);
            AccelerometerBallTestFragment.clear();
        } else if (hardware_name.equals(HardwareUtility.KEY_PROXIMITY_HARDWARE)) {
            monitorDTO.setProximityResponse(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_MULTI_TOUCH)) {
            monitorDTO.setMultiTouchResponse(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_SPEAKER_HARDWARE)) {
            monitorDTO.setSpeakerTest(value ? 1 : 0);
            longAsyncFlag = true;
            MyLongRunningTask task = new MyLongRunningTask();
            task.execute(mdmActivity);
            // SoundTestFragment.clear();
        } else if (hardware_name.equals(HardwareUtility.KEY_MIC_HARDWARE)) {
            monitorDTO.setMicTest(value ? 1 : 0);
            longAsyncFlag = true;
            MyLongRunningTask task = new MyLongRunningTask();
            task.execute(mdmActivity);
        } else if (hardware_name.equals(HardwareUtility.KEY_POWER_KEY)) {
            monitorDTO.setPowerKeyTest(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_HOME_KEY)) {
            monitorDTO.setHomeKeyTest(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_MENU_KEY)) {
            monitorDTO.setMenuKeyTest(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_BACK_KEY)) {
            monitorDTO.setBackKeyTest(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_VOLUME_UP_KEY)) {
            monitorDTO.setVolumeUpKeyTest(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_VOLUME_DOWN_KEY)) {
            monitorDTO.setVolumeDownKeyTest(value ? 1 : 0);
        } else if (hardware_name.equals(HardwareUtility.KEY_DISPLAY_HARDWARE)) {
            monitorDTO.setDisplayTest(value ? 1 : 0);
        }
        LogWrite.d("Aman", "Json String : " + monitorDTO.toString());

        new Thread() {
            public void run() {
                try {
                    sendHWTestResponseDTO.setResponse(new JSONObject(monitorDTO.toString()));
                    jsonResponse.send(context,AppConstant.SEND_RESPONSE_URL, sendHWTestResponseDTO.toJSON().toString());
//                    jsonResponse.send(context, AppConstant.SEND_RESPONSE_URL,                            monitorDTO.toString());
                } catch (Exception e) {
                    LogWrite.e("Aman", "ExceptionDTO : ---> " + e.toString());
                }
                hardware_name = "";
            }
        }.start();

        // SendResponseAsync async = new
        // SendResponseAsync(context.getApplicationContext(), server_url,
        // monitorDTO.toString());
        // async.execute("");

        // String messageToSend = "MN:" + htDMCommand.get("MN")
        // + ";CNo:1;CMD-1:HWTEST;CMDINF-1:<HWTEST:<" + "A:"
        // + vibrateResponse + ";B:" + touchResponse + ";C:"
        // + longpressResponse + ";D:" + acceleResponse + ";E:"
        // + proximityResponse + ";F:" + flashlightResponse + ";G:"
        // + wifiResponse + ";H:" + gpsResponse + ";I:" + cameraResponse
        // + ";J:" + bluetoothResponse + ";>;";
        // sendTextMessage(mobileNumber, messageToSend);
    }

    private void sleep(long time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("SimpleDateFormat")
    private String convertLongToDate(long time) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        Date date = new Date(time);
        return sdf.format(date);
    }

    /**
     * Finds the Location based on CellId and LocationAreaCode.
     *
     * @author nishant.kumar
     */
    class Findlocation extends AsyncTask<String, String, String> {
        String TAG = "Findlocation";

        @Override
        protected String doInBackground(String... params) {
            // GetHandsetInfo handsetInfo = (GetHandsetInfo) params[0];
            // int cellID = handsetInfo.getCellID();
            // int lac = handsetInfo.getLocationAreaCode();
            // LogWrite.d(TAG, cellID + " lac  in dib" + lac);
            // try
            // {
            // String location = LatitudeLongitudeClass(cellID, lac);
            Log.d(TAG, "Find Location doInBackground: called");
            publishProgress(params[0], params[1]);
            // }
            // catch (ExceptionDTO e)
            // {
            // e.printStackTrace();
            // }

            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            String tag = "mdm location";
            String messageToSend = "";
            super.onProgressUpdate(values[0]);
            String locationCoordinates = values[0];
            String[] strings = locationCoordinates.split("~");
            String lat = strings[0];
            String lng = strings[1];
            String commandID = values[1];
            String address = getAddressByLatLng(getActivity().getApplicationContext(), lat, lng);
            try {
                SendResponseDTO sendResponseDTO = new SendResponseDTO();
                sendResponseDTO.setCommandKey(commandID);
                sendResponseDTO.setCommandKey("LOC");
                JSONObject responseLoc = new JSONObject();
                responseLoc.put("__type", "LocateReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
                responseLoc.put("Address", address);
                responseLoc.put("Latitude", lat);
                responseLoc.put("Longitude", lng);
                sendResponseDTO.setResponse(responseLoc);
                String s1 = sendResponseDTO.toJSON().toString();
                String s = postRequestOkhttp(AppConstant.SEND_RESPONSE_URL, s1);
                Log.d(TAG, "onProgressUpdate: Response of Send Location:->" + s + "\nLocJson Sent:->" + s1);
            } catch (Exception e1) {
                e1.printStackTrace();
                addtoLog("Could not send Location Information.");
            }
            LogWrite.d(tag, strings[0] + "  " + strings[1]);
           /* messageToSend = "MN:" + htDMCommand.get("MN")
                    + ";CNo:1;CMD-1:GETCORDS;CMDINF-1" + ":<GP-1:<A1:"
                    + strings[0] + ";B1:" + strings[1] + ";>;>;";
            LogWrite.d(tag, "Message to Send === " + messageToSend);
            try {
                sendTextMessage(mobileNumber, messageToSend);
            } catch (Exception e) {
                e.printStackTrace();
            }*/
        }

    }


    /**
     * AsyncTask to listen from the server and sending the IMEI to the service.
     *
     * @author aman.arora
     */
    class MyLongRunningTask extends AsyncTask<Activity, String, String> {

        @Override
        protected String doInBackground(Activity... params) {

            String tag = "MyLongRunningTask";
            Log.d(tag, "Long Asyn Flag : " + longAsyncFlag);
            mResponseDTOList = new ArrayList<>();
            while (longAsyncFlag) {
                try {

                    LogWrite.d(tag, "Long Asyn Flag : " + longAsyncFlag);
                    LogWrite.d(tag, "Start");
                    Calendar c = Calendar.getInstance();
                    // LogWrite.d(tag, "DATA   ->- ");
                    // LogWrite.d("iiinnn", "thread");
                    countPendingRequest++;
                    // LogWrite.d(tag, "count  " + countPendingRequest);
                    URL url;
                    String responseFromServer = "";
                    // LogWrite.d(tag, "In makeConnection()");
                    // LogWrite.d(tag, "DATA   ->-- ");
                    // OutputStream os;
                    url = new URL(SERVERURL + "/" + phoneNumberToSend);
                    String urlToRequest = SERVERURL + "/" + phoneNumberToSend;
                    LogWrite.d(tag, "SERVERURL  " + SERVERURL);
                    responseFromServer = getRequestOkhttp(urlToRequest);
//                    eText(ins,"ResponseDTO ="+responseFromServer,Toast.LENGTH_LONG).show();

                    LogWrite.d(tag, "CommandDTO =" + responseFromServer);
                    // LogWrite.d(tag, "DATA   ->---- ");
                    // LogWrite.d(tag, "DATA   -> " + responseFromServer);
                    // LogWrite.d(tag, "DATA   -> 1");
                    if (!responseFromServer.equals("")) {
                        Log.d(tag, "Received JSON Now Start Parse: ");
                        JSONObject jsonObject = new JSONObject(responseFromServer);
                        JSONArray jsonResponseArray = null;
                        Log.d(tag, "1...................: ");
                        if (!jsonObject.getString("Exception").equals("null")) {

                            JSONObject jsonExceptionObject = new JSONObject("Exception");

                        } else if (!jsonObject.getString("Response").equals("null")) {

                            jsonResponseArray = jsonObject.getJSONArray("Response");

                            for (int i = 0; i < jsonResponseArray.length()
                                    ; i++) {
                                Log.d(tag, "2...................: ");

                                JSONObject jsonResponse = jsonResponseArray.getJSONObject(i);
                                String MessageCommandId = jsonResponse.getString("MessageCommandId");
                                String CommandKey = jsonResponse.getString("CommandKey");
                                String MAC = jsonResponse.getString("MAC");
                                String Params = jsonResponse.getJSONObject("Params").toString();
                                ResponseDTO responseDTO = new ResponseDTO(Params, CommandKey, MAC, MessageCommandId);
                                Log.d(tag, "doInBackground: " + responseDTO.toString());

                                mResponseDTOList.add(responseDTO);

                                Log.d(tag, "3...................: ");
                            }


                            // LogWrite.d(tag, "DATA   -> 3");
                            // LogWrite.d(tag, "cmd from server" + responseFromServer);
                            LogWrite.d(tag, "KocharMessageFound =Yes");
                            if (!isToLogError)
                                isToLogError = true;
                            // publishProgress(responseFromServer);
                            LogWrite.d(tag, "Data --------------> " + responseFromServer);
//                            makeDecision(responseFromServer, context);
                            for (ResponseDTO responseDTO : mResponseDTOList) {
                                extractCommand(responseDTO);
                            }
                            timeoutCount = 0;

                        } else {
                            LogWrite.d(tag, "KocharMessageFound =No");
                            if (isToLogError) {
                                // addtoLog("Either Data Connection Unable or Incorrect Data received from server");
                                LogWrite.d(tag,
                                        "Either Data Connection Unable or Incorrect Data received from server");
                                // showToast(
                                // "Either Data Connection Unable or Incorrect Data received from server "
                                // + "Please check whether "
                                // + SERVERURL
                                // + " is available from browser",
                                // 5000);
                                isToLogError = false;
                                timeoutCount++;
                            }
                        }
                        // responseFromServer="";
                    } else {
                        LogWrite.d(tag, "Nothing from server");
                        timeoutCount++;
                        LogWrite.d(tag, "TimeOutCount ----> " + timeoutCount);
                        if (timeoutCount == 300) {
                            Intent in = new Intent();
                            in.putExtra("name", "blank");
                            // setResult(1, in);
                            if (ob != null) {
                                ob.cancel(true);
                                sharedPreferences = PreferenceManager
                                        .getDefaultSharedPreferences(context);
                                editor = sharedPreferences.edit();
                                editor.putBoolean("threadrunning", false);
                                editor.commit();
                                LogWrite.d(tag,
                                        "Stopping running network service on Exit.");
                            } else {
                                LogWrite.d(tag,
                                        "Service Already stopped. No need to stop on Exit.");
                            }
                            LogWrite.d(tag, "Unregistering reciever.....");
                            context.unregisterReceiver(infoReceiver);
                            RegisterUserActivity.promptNumberActivity = null;
                            DecisionMakerActivity.activityStatusFlag = false;
                            mdmActivity.finish();
                        }
                        // runOnUiThread(new Runnable() {
                        // public void run() {
                        //
                        // logText.append("Waiting for server"+"\n");
                        // scrollview.post(new Runnable() {
                        // public void run() {
                        // // scrollview.scrollTo(0, logText.getBottom());
                        // scrollview.smoothScrollBy(0, logText.getBottom());
                        // }
                        // });
                        // }
                        // });
                        // addtoLog("Waiting for server"+"\n");
//                        String dmLogs = httpConn.getHeaderField("DMLogs");
                        // WriteToFile(Calendar.getInstance().getTime() +" "+
                        // dmLogs);
                        // LogWrite.d(tag + "DMLogs===", Calendar.getInstance()
                        // .getTime() + " " + dmLogs);
                    }
                    // 2 sec delay
                } catch (java.net.SocketException se) {
                    LogWrite.d(tag, "SocketException " + se);
                    // se.printStackTrace();
                    if (isToLogError) {
                        addtoLog("Either Data Connection Unable or Incorrect Data received from server");
                        LogWrite.d(tag,
                                "Either Data Connection Unable or Incorrect Data received from server");
                        // showToast(
                        // "Either Data Connection Unable or Incorrect Data received from server "
                        // + "Please check whether "
                        // + SERVERURL
                        // + " is available from browser",
                        // 5000);
                        isToLogError = false;
                        publishProgress("Internet");
                    }

                } catch (Exception ex) {
                    // ex.printStackTrace();
                    LogWrite.d(tag, "ExceptionDTO " + ex);
                    // se.printStackTrace();
                    if (isToLogError) {
                        addtoLog("Either Data Connection Unable or Incorrect Data received from server");
                        LogWrite.d(tag,
                                "Either Data Connection Unable or Incorrect Data received from server");
                        // showToast(
                        // "Either Data Connection Unable or Incorrect Data received from server "
                        // + "Please check whether "
                        // + SERVERURL
                        // + " is available from browser",
                        // 5000);
                        isToLogError = false;
                        publishProgress("Internet");
                    }
                }

                if (isCancelled()) {
                    LogWrite.d(tag, "DATA   ->is Cannceled Work");
                    break;
                }
                try {
                    Thread.sleep(2000);
                } catch (Exception e) {
                }
                LogWrite.d(tag, "Finish");
            }
            return null;
        }

        public String traceroute(String hostIP) {
            String tag = "taceroute method";
            int strarCount = 0;
            String LastTraceIP = "";
            try {

                String ip = "";
                int hopCount = 1;
                Runtime r = Runtime.getRuntime();
                StringBuffer pingResult;
                try {
                    while (true) {
                        pingResult = new StringBuffer();
                        String pingCmd = "ping -t " + hopCount + " -c 1 "
                                + hostIP;
                        java.lang.Process p = r.exec(pingCmd);
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(p.getInputStream()));
                        String inputLine;
                        LogWrite.d(tag, "Ping********" + "before while");
                        while ((inputLine = in.readLine()) != null) {
                            pingResult.append(inputLine);
                        }
                        LogWrite.d(tag, "pingResult===" + pingResult);
                        String s = new String(pingResult);
                        if (s.contains("From")) {

                            int from_pos = s.indexOf("From");
                            int icmp_pos = s.indexOf("icmp_seq");
                            ip = s.substring(from_pos + 5, icmp_pos - 1);
                            LogWrite.d(tag, "ip======" + ip);
                            LogWrite.d(tag, hopCount + "    " + ip);
                            LastTraceIP = ip;
                            strarCount = 0;

                        } else if (s.contains("min")) {
                            LogWrite.d(tag, "if reached destination");
                            LogWrite.d(tag, hopCount + "    " + hostIP
                                    + "Traceroute Complete");
                            return "success";
                            // mAdapter.add(hopCount+"    "+ip);
                            // break;
                        } else {
                            ip = "*";
                            strarCount++;
                            if (strarCount == 5) {
                                return LastTraceIP;
                            }
                            LogWrite.d(tag, hopCount + "    " + ip);
                            // mAdapter.add(hopCount+"    "+ip);
                            LogWrite.d(tag, "does not contains from");

                        }

                        // System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^yyyyyyyyy---"+pingResult);
                        LogWrite.d(tag, "hostIP==" + hostIP + "==ip" + ip
                                + "===" + hostIP.equals(ip));
                        // s.contains("64 bytes from "+ip)

                        hopCount++;
                        LogWrite.d(tag, "hop count===" + hopCount);

                        LogWrite.d("Ping********", "after while");

                    }

                } catch (UnknownHostException e) {
                    System.out.println("&&&&tttt&&&&" + e.toString());
                    LogWrite.d(tag, "-----3---------->" + e.toString());
                } catch (Exception e) {
                    System.out.println("&&&&tttt&&&&" + e.toString());
                    LogWrite.d(tag, "-----4---------->" + e.toString());
                }
            } catch (Exception e) {
                // Toast.makeText(getApplicationContext(),
                // "Error=="+e.toString(),
                // Toast.LENGTH_LONG).show();
                LogWrite.d(tag, "Error==" + e.toString());
                e.printStackTrace();
            }

            return "gaurav";
        }

        protected void onProgressUpdate(String... result) {
            // setProgressPercent(progress[0]);
            if (result[0].equals("Internet")) {
                Intent intent = new Intent(context, DialogActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } else {
                try {
                    LogWrite.d(tag, "in onProgressUPdate");
                    // Toast.makeText(getApplicationContext(),
                    // "on progress update  " +result[0], 2000).show();
                    makeDecision(result[0], context);
                    // process();
                    // builder.show();
                } catch (Exception ex) {
                    Toast.makeText(context, "blank " + ex.toString(), 2000)
                            .show();
                }
            }
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
            LogWrite.d(tag, "STOPPING TASK  >>>>> Killing in Progress.");
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (!longAsyncFlag) {
                    if (hardware_name
                            .equals(HardwareUtility.KEY_ACCELEROMETER_HARDWARE)) {
                        Bundle bundle = new Bundle();
                        bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND,
                                true);
                        FragmentListener fragmentListener = (FragmentListener) getActivity();
                        AccelerometerBallTestFragment accelerometerTestFragment = new AccelerometerBallTestFragment(
                                MDMMainActivity.this);
                        accelerometerTestFragment.setArguments(bundle);
                        fragmentListener.onItemClicked(
                                FragmentListener.actionAdd,
                                accelerometerTestFragment);
                        // startActivity(new Intent(getActivity(),
                        // BringApplicationToForeground.class));
                    } else if (hardware_name
                            .equals(HardwareUtility.KEY_MIC_HARDWARE)) {
                        MicTestActivity.startActivity(
                                mdmActivity.getApplicationContext(), "MicTest",
                                true, MDMMainActivity.this, null);
                        // Bundle bundle = new Bundle();
                        // bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND,
                        // true);
                        // FragmentListener fragmentListener =
                        // (FragmentListener) getActivity();
                        // MicTestFragment micTestFragment = new
                        // MicTestFragment(
                        // MDMMainActivity.this);
                        // micTestFragment.setArguments(bundle);
                        // fragmentListener.onItemClicked(
                        // FragmentListener.actionAdd, micTestFragment);
                        // startActivity(new Intent(getActivity(),
                        // BringApplicationToForeground.class));
                    } else if (hardware_name
                            .equals(HardwareUtility.KEY_SPEAKER_HARDWARE)) {
                        SoundTestActivity.startActivity(context, "SoundTest",
                                true, MDMMainActivity.this, null);
                        // Bundle bundle = new Bundle();
                        // bundle.putBoolean(TouchTestFragment.KEY_ISFROMCOMMAND,
                        // true);
                        // FragmentListener fragmentListener =
                        // (FragmentListener) getActivity();
                        // SoundTestFragment soundTestFragment = new
                        // SoundTestFragment(
                        // MDMMainActivity.this);
                        // soundTestFragment.setArguments(bundle);
                        // fragmentListener.onItemClicked(
                        // FragmentListener.actionAdd, soundTestFragment);
                        // startActivity(new Intent(getActivity(),
                        // BringApplicationToForeground.class));
                    }

                    if (optimizingFlag) {
                        CleanAppAsyncTask cleanAppAsyncTask = new CleanAppAsyncTask(
                                context);
                        cleanAppAsyncTask.execute("");
                        optimizingFlag = false;
                    }
                }
            } catch (Exception e) {
                LogWrite.e("Aman",
                        "MyLongRunningTask ExceptionDTO :: " + e.toString());
            }
            super.onPostExecute(result);
        }
    }

    // @Override
// public void onActivityResult(int requestCode, int resultCode, Intent
// data) {
// if (requestCode == 112) {
// if (hardware_name.equals(HardwareUtility.KEY_POWER_KEY)) {
// if (resultCode == -1) {
// monitorDTO.setPowerKeyTest(data.getIntExtra("result", 0));
// }
// } else if (hardware_name.equals(HardwareUtility.KEY_HOME_KEY)) {
// if (resultCode == -1) {
// monitorDTO.setPowerKeyTest(data.getIntExtra("result", 0));
// }
// } else if (hardware_name.equals(HardwareUtility.KEY_MENU_KEY)) {
// if (resultCode == -1) {
// monitorDTO.setPowerKeyTest(data.getIntExtra("result", 0));
// }
// } else if (hardware_name.equals(HardwareUtility.KEY_VOLUME_UP_KEY)) {
// if (resultCode == -1) {
// monitorDTO.setPowerKeyTest(data.getIntExtra("result", 0));
// }
// } else if (hardware_name
// .equals(HardwareUtility.KEY_VOLUME_DOWN_KEY)) {
// if (resultCode == -1) {
// monitorDTO.setPowerKeyTest(data.getIntExtra("result", 0));
// }
// }
// LogWrite.d("Aman", "Json String : " + monitorDTO.toString());
//
// new Thread() {
// public void run() {
// try {
// jsonResponse.send(context, server_url,
// monitorDTO.toString());
// } catch (ExceptionDTO e) {
// LogWrite.e("Aman", "ExceptionDTO : ---> " + e.toString());
// }
// }
// }.start();
// }
// }
    private class CleanAppAsyncTask extends AsyncTask<String, Object, String> {
        private final String PUBLISH_ENABLE_ACCESSIBILITY = "enable_accessibility";
        // private final String PUBLISH_MANAGE_SETTINGS = "manage_settings";
        private final String PUBLISH_REMOVE_VIEW = "remove_view";
        private final String PUBLISH_TEST_START = "test_start";
        private final String PUBLISH_TEST_FINISH = "test_finish";
        WindowManager windowManager = null;
        View overlayView = null;
        private String TAG = CleanAppAsyncTask.class.getSimpleName();
        private Context context;
        private boolean isRunningFlag = true;
        private ArrayList<RunningAppDTO> arrayAppList;

        public CleanAppAsyncTask(Context context) {
            this.context = context;
            // this.newAppList = newAppList;
        }

        @Override
        protected String doInBackground(String... params) {
            if (isRunningFlag) {
                LogWrite.i(TAG, "doInBackground method enters!");
                AccessibilityHelper helper = new AccessibilityHelper(context);
                if (helper.isAccessibilityEnabled()) {
                    arrayAppList = new ArrayList<RunningAppDTO>();
                    List<Process> appList = ProcessManager.getRunningApps();
                    for (Process string : appList) {

                        if (!isExist(string.getPackageName(), arrayAppList)) {
                            if (!string.getPackageName().contains("com.kochar")) {
                                if (!isLauncherPackage(mdmActivity,
                                        string.getPackageName())) {
                                    String appName = getAppName(string
                                            .getPackageName());
                                    if (!appName.equals("")) {
                                        LogWrite.d(TAG, "ProcessName : "
                                                + string.getPackageName());
                                        LogWrite.d(TAG, "AppName : " + appName);
                                        RunningAppDTO appDTO = new RunningAppDTO();
                                        appDTO.setPackageName(string
                                                .getPackageName());
                                        appDTO.setAppName(appName);
                                        appDTO.setIcon(getAppIcon(string
                                                .getPackageName()));
                                        appDTO.setSelected(true);
                                        arrayAppList.add(appDTO);
                                    }
                                }
                            }
                        }
                    }
                    LogWrite.i(TAG, "arrayAppListSize : " + arrayAppList.size());
                    ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
                            context);
                    publishProgress(PUBLISH_TEST_START);
                    for (RunningAppDTO runningAppDTO : arrayAppList) {
                        if (runningAppDTO.isSelected()) {
                            actionPrefrence
                                    .setActionToPerform(ActionPerformPrefrence.ACTION_FORCE_CLOSE);
                            LogWrite.i(
                                    TAG,
                                    "PackageName : "
                                            + runningAppDTO.getPackageName());
                            // publishProgress(PUBLISH_MANAGE_SETTINGS + "::"
                            // + runningAppDTO.getPackageName());
                            publishProgress(runningAppDTO);
                            sleep(3);

                            publishProgress(PUBLISH_REMOVE_VIEW);
                            // performAction(context,
                            // runningAppDTO.getPackageName());
                        } else {
                            actionPrefrence
                                    .setActionToPerform(ActionPerformPrefrence.ACTION_NO);
                            LogWrite.e(
                                    TAG,
                                    "APP Name : "
                                            + runningAppDTO.getPackageName());
                        }
                    }
                    publishProgress(PUBLISH_TEST_FINISH);
                    isRunningFlag = false;
                } else {
                    publishProgress(PUBLISH_ENABLE_ACCESSIBILITY);
                }
            }
            return "";
        }

        @Override
        protected void onProgressUpdate(Object... values) {

            if (values[0] instanceof RunningAppDTO) {
                RunningAppDTO runningAppDTO = (RunningAppDTO) values[0];
                ImageView imageView = (ImageView) overlayView
                        .findViewById(R.id.app_icon);
                TextView messageView = (TextView) overlayView
                        .findViewById(R.id.app_message);
                imageView.setImageDrawable(runningAppDTO.getIcon());
                // messageView.setText("Stop " + runningAppDTO.getAppName()
                // + " from running");
                messageView.setText("Optimizing device! Please wait...");
                fadeOutAndHideImage(imageView);
                // ActivityOverlay.start(context);
                // if (actionPrefrence.getActionToPerform() ==
                // ActionPerformPrefrence.ACTION_GPS) {
                // Intent i = new Intent(
                // android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                // i.addCategory(Intent.CATEGORY_DEFAULT);
                // i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                // startActivity(i);
                // } else {
                Intent i = new Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.addCategory(Intent.CATEGORY_DEFAULT);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK
                        | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                i.setData(Uri.parse("package:" + runningAppDTO.getPackageName()));
                context.startActivity(i);
            } else {
                LogWrite.e(TAG, "----------onProgressUpdate");
                LogWrite.e(TAG, "----------Value : " + values[0].toString());
                if (values[0].equals(PUBLISH_ENABLE_ACCESSIBILITY)) {
                    Intent intent = new Intent(
                            Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    context.startActivity(intent);
                    // isWorking = false;
                    final ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
                            context);
                    actionPrefrence.clear();
                } else if (values[0].equals(PUBLISH_REMOVE_VIEW)) {

                    // ActivityOverlay.stop();
                } else if (values[0].equals(PUBLISH_TEST_START)) {
                    if (windowManager == null)
                        windowManager = getWindowMnagerNew();
                    if (overlayView == null)
                        overlayView = getOverlayView();
                    WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                            WindowManager.LayoutParams.MATCH_PARENT,
                            WindowManager.LayoutParams.MATCH_PARENT,
                            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
                            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                            PixelFormat.TRANSLUCENT);
                    windowManager.addView(overlayView, params);
                    LogWrite.e(TAG, "-------------------------------------A");
                    overlayView.setKeepScreenOn(true);
                } else if (values[0].equals(PUBLISH_TEST_FINISH)) {
                    windowManager.removeView(overlayView);
                    windowManager = null;
                    overlayView = null;
                    final ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
                            context);
                    actionPrefrence
                            .setActionToPerform(ActionPerformPrefrence.ACTION_NO);
                    // GUICleanActivity.this.finish();
                    // GUICleanActivityFinish.launch(context);
                    // overridePendingTransition(R.anim.fade_in,
                    // R.anim.fade_out);// GUICleanActivity.this.finish();
                    // GUICleanActivityFinish.launch(context);
                    // overridePendingTransition(R.anim.fade_in,
                    // R.anim.fade_out);// GUICleanActivity.this.finish();


                }
            }
            super.onProgressUpdate(values);
        }

        private boolean isLauncherPackage(Context context, String packageName) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            List<ResolveInfo> lst = context.getPackageManager()
                    .queryIntentActivities(intent, 0);
            if (!lst.isEmpty()) {
                for (ResolveInfo resolveInfo : lst) {
                    LogWrite.d(TAG, "New Launcher Found: "
                            + resolveInfo.activityInfo.packageName);
                    if (resolveInfo.activityInfo.packageName
                            .equals(packageName)) {
                        return true;
                    }
                }
            }
            return false;
        }

        private void fadeOutAndHideImage(final ImageView img) {
            Animation fadeOut = new AlphaAnimation(1, 0);
            fadeOut.setInterpolator(new AccelerateInterpolator());
            fadeOut.setDuration(2000);

            fadeOut.setAnimationListener(new AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    img.setVisibility(View.GONE);
                }

                public void onAnimationRepeat(Animation animation) {

                }

                public void onAnimationStart(Animation animation) {
                }
            });

            img.startAnimation(fadeOut);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            // GUICleanActivity.this.finish();
        }

        private Drawable getAppIcon(String packageName) {
            final PackageManager pm = mdmActivity.getPackageManager();
            ApplicationInfo ai;
            try {
                ai = pm.getApplicationInfo(packageName, 0);
            } catch (final NameNotFoundException e) {
                ai = null;
            }
            final Drawable appIcon = (ai != null ? pm.getApplicationIcon(ai)
                    : null);
            return appIcon;
        }

        private String getAppName(String packageName) {
            final PackageManager pm = mdmActivity.getPackageManager();
            ApplicationInfo ai;
            try {
                ai = pm.getApplicationInfo(packageName, 0);
            } catch (final NameNotFoundException e) {
                ai = null;
            }
            final String applicationName = (String) (ai != null ? pm
                    .getApplicationLabel(ai) : "");
            return applicationName;

        }

        private boolean isExist(String packageName,
                                ArrayList<RunningAppDTO> arrayAppList) {
            for (RunningAppDTO runningAppDTO : arrayAppList) {
                if (runningAppDTO.getPackageName().equals(packageName))
                    return true;
            }
            return false;
        }

        private View getOverlayView() {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final View overlayView = layoutInflater.inflate(R.layout.overlay,
                    null);
            return overlayView;
        }

        private WindowManager getWindowMnagerNew() {
            return (WindowManager) context
                    .getSystemService(Context.WINDOW_SERVICE);
        }

        private void sleep(long sec) {
            try {
                Thread.sleep(sec * 1000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}