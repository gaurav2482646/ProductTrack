//package com.kochartech.gizmodoctor.Fragment;
//
//import android.app.Activity;
//import android.content.Context;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.os.AsyncTask;
//import android.os.Bundle;
//import android.os.Vibrator;
//import android.support.v4.app.Fragment;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.ViewGroup;
//import android.view.WindowManager.LayoutParams;
//import android.view.animation.Animation;
//import android.view.animation.AnimationUtils;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.Activity.FragmentListener;
//import com.kochartech.gizmodoctor.Activity.OnCommandListener;
//import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
//import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
//import com.kochartech.gizmodoctor.HardwareModel.SoundMeter;
//
//public class MicTestFragment extends Fragment implements OnClickListener {
//	private String TAG = MicTestFragment.class.getSimpleName();
//
//	private static Activity activity;
//	private View rootView;
//	private TextView textView;
//	private ImageView fanImageView;
//
//	private boolean isFromCommand = false;
//	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
//	private OnCommandListener onCommandListener = null;
//	// private boolean isClickWork = false;
//
////	private SoundMeter meter;
//	private boolean soundCheck = false;
//
//	private CheckMicAsync async;
//
//	private Button okButton;
//
//	private CircularProgressBar timerProgress;
//
//	private boolean success = false;
//	private String FAILURE_MESSAGE = "Press OK if mic not working";
//
//	public MicTestFragment(OnCommandListener onCommandListener) {
//		this.onCommandListener = onCommandListener;
//	}
//
//	@Override
//	public View onCreateView(LayoutInflater inflater, ViewGroup container,
//			Bundle savedInstanceState) {
//		LogWrite.d(TAG, "OnCreate Method Enters.....");
//		getActivity().getWindow()
//				.setFlags(
//						0xFFFFFFFF,
//						LayoutParams.FLAG_FULLSCREEN
//								| LayoutParams.FLAG_KEEP_SCREEN_ON);
//
//		initDataSet();
//		initUi(inflater, container);
//		return rootView;
//	}
//
//	private void initDataSet() {
//		Bundle bundle = getArguments();
//		if (bundle != null) {
//			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
//				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
//			}
//		}
//	}
//
//	private void initUi(LayoutInflater inflater, ViewGroup container) {
//		activity = getActivity();
//		rootView = inflater.inflate(R.layout.fragment_mic, container, false);
//		textView = (TextView) rootView.findViewById(R.id.textView);
//		textView.setText(R.string.micro_phone_screen);
//		fanImageView = (ImageView) rootView.findViewById(R.id.fan_image);
//		fanImageView.setVisibility(View.VISIBLE);
////		meter = new SoundMeter();
//
//		okButton = (Button) rootView.findViewById(R.id.ok_button);
//		okButton.setOnClickListener(this);
//
//		timerProgress = (CircularProgressBar) rootView
//				.findViewById(R.id.circularprogressbar2);
//		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {
//
//			@Override
//			public void onAnimationStart() {
//			}
//
//			@Override
//			public void onAnimationProgress(int progress) {
//				timerProgress.setTitle(progress + "");
//				timerProgress.setSubTitle("");
//			}
//
//			@Override
//			public void onAnimationFinish() {
//				if (!success) {
//					textView.setText(FAILURE_MESSAGE);
//					textView.setTextAppearance(activity, R.style.textStyleRed);
//					okButton.setVisibility(View.VISIBLE);
//					timerProgress.setSubTitle("");
//					timerProgress.setVisibility(View.GONE);
////					try {
////						meter.stop();
////					} catch (ExceptionDTO e) {
////						LogWrite.e(TAG,
////								"TimerFinsihException : " + e.toString());
////					}
//				}
//			}
//		});
//	}
//
//	@Override
//	public void onDestroy() {
//		super.onDestroy();
//		LogWrite.d(TAG, "OnDestroy Method Enters.....");
//		// soundCheck = false;
//		// try {
//		// meter.stop();
//		// } catch (ExceptionDTO e) {
//		// LogWrite.e(TAG, "onDestroyStopExc : " + e.toString());
//		// e.printStackTrace();
//		// }
//		// if (getToSendFlag()) {
//		// if (onCommandListener != null) {
//		// onCommandListener.onCommand(getToSendFlag());
//		// }
//		// }
//		// appAlreadyWorkingFlag = false;
//		// LogWrite.i(TAG, "GetToSendFlag : " + appAlreadyWorkingFlag);
//		// inResumeFlag = false;
//	}
//
//	@Override
//	public void onPause() {
//		super.onPause();
//		LogWrite.d(TAG, "OnPause Method Enters.....");
//		// soundCheck = false;
//		// try {
//		// meter.stop();
//		// } catch (ExceptionDTO e) {
//		// LogWrite.e(TAG, "onPauseStopExc : " + e.toString());
//		// e.printStackTrace();
//		// }
//		// if (getToSendFlag()) {
//		// if (onCommandListener != null) {
//		// onCommandListener.onCommand(getToSendFlag());
//		// }
//		// }
//
//	}
//
//	@Override
//	public void onResume() {
//		super.onResume();
//		LogWrite.d(TAG, "OnResume Method Enters.....");
//		// LogWrite.i(TAG, "GetToSendFlag : " + appAlreadyWorkingFlag);
//		// if (!inResumeFlag) {
//		// if (!appAlreadyWorkingFlag) {
//		// soundCheck = true;
//		// meter.start();
//		// if (async == null) {
//		// async = new CheckMicAsync();
//		// async.execute("");
//		// }
//		// } else {
//		// FragmentListener fragmentListener = (FragmentListener) getActivity();
//		// fragmentListener.onItemClicked(FragmentListener.actionRemove,
//		// MicTestFragment.this);
//		// // fragmentListener.onItemClicked(FragmentListener.actionRemove,
//		// // SoundTestFragment.this);
//		// }
//		// inResumeFlag = true;
//		// }
//	}
//
//	private class CheckMicAsync extends AsyncTask<String, String, String> {
//		@Override
//		protected synchronized String doInBackground(String... params) {
//			while (soundCheck) {
//				LogWrite.d(TAG, "Thread is working");
////				int amplitude = (int) meter.getAmplitudeEMA();
////				LogWrite.d(TAG, "Amplitude: " + amplitude);
////				if (amplitude > 2) {
////					LogWrite.d(TAG,
////							"Mic is working : " + meter.getAmplitudeEMA());
////					publishProgress("a");
////					sleep(1000);
////					publishProgress("b");
////				}
//				sleep(2000);
//				// appAlreadyWorkingFlag = true;
//			}
//			return "";
//		}
//
//		@Override
//		protected void onProgressUpdate(String... values) {
//			String value = values[0];
//			if (value.equals("a")) {
//				Animation sampleFadeAnimation = AnimationUtils.loadAnimation(
//						activity, R.anim.anim_rotate);
//				sampleFadeAnimation.setRepeatCount(1);
//				fanImageView.startAnimation(sampleFadeAnimation);
//			} else if (value.equals("b")) {
//				try {
//
//					textView.setText(R.string.micro_phone_is_working_fine);
//					textView.setTextAppearance(getActivity(),
//							R.style.textStyleGreen);
//					success = true;
//					timerProgress.setVisibility(View.GONE);
//					if (isFromCommand) {
//						onCommandListener.onCommand(true);
//						FragmentListener fragmentListener = (FragmentListener) getActivity();
//						fragmentListener.onItemClicked(
//								FragmentListener.actionRemove,
//								MicTestFragment.this);
//					}
//					// isClickWork = true;
//					// setToSendFlag();
//				} catch (ExceptionDTO e) {
//
//				}
//			}
//
//			super.onProgressUpdate(values);
//		}
//
//		private void sleep(long time) {
//			try {
//				Thread.sleep(time);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
//	}
//
//	@Override
//	public void onClick(View v) {
//		Vibrator vibrator = (Vibrator) activity
//				.getSystemService(Context.VIBRATOR_SERVICE);
//		vibrator.vibrate(500);
//		textView.setText("Mic test fails.");
//		if (isFromCommand) {
//			onCommandListener.onCommand(false);
//			FragmentListener fragmentListener = (FragmentListener) getActivity();
//			fragmentListener.onItemClicked(FragmentListener.actionRemove, this);
//		}
//		okButton.setVisibility(View.GONE);
//
//	}
// }
