package com.kochartech.gizmodoctor.HelperClass;

public class StorageInfo 
{
	long free=0, total=0 ;

	public StorageInfo() {}
	public StorageInfo(long free, long total) {
		this.free  = free;
		this.total = total;
	}

	public long getFree() {
		return free;
	}

	public void setFree(long free) {
		this.free = free;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	
}
