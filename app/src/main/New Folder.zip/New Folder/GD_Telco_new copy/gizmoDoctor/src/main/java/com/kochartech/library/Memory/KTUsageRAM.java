package com.kochartech.library.Memory;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

import com.kochartech.gizmodoctor.deviceissues.ProcessManager;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager.Process;

/**
 * This class has been used to calculate RAM Usage.
 * 
 * @author aman.arora
 * 
 *         we skip the applications, that do not have application info.
 */
@SuppressLint("DefaultLocale")
public class KTUsageRAM extends KTUsage {
	String tag = "KTUsageRAM";
	// private Context context;
	// private List<KTApplicationInfo> runningAppUsageInfo = new
	// ArrayList<KTApplicationInfo>();
	// private PackageManager pkgManager;
	// private ActivityManager activityManager;
	private KTMemoryInfo ktMemoryInfo;

	/**
	 * Constructor
	 */
	public KTUsageRAM(Context context) {
		super(context);
		ktMemoryInfo = new KTMemoryInfo();
	}

	/**
	 * This Method returns list of KTApplicationInfo which contains info like
	 * Application Name, Icon, ProcessName , ProcessID, RAM Usage(in Bytes)
	 * 
	 * @return List of KTApplicationInfo
	 */
	public List<KTApplicationInfo> getPerAppUsage() {
		return refreshPerAppUsage();
		// return runningAppUsageInfo;
	}

	/**
	 * This Method refreshes list of KTApplicationInfo which contains info like
	 * Application Name, Icon, ProcessName , ProcessID, RAM Usage(in Bytes).
	 * 
	 * @return List of KTApplicationInfo
	 */
	public List<KTApplicationInfo> refreshPerAppUsage() {
		resetPerAppUsage();
		return calculatePerAppUsage();
	}

	/**
	 * This Method returns RAM Usage(in Bytes) of the corresponding ProcessName.
	 * 
	 * @param processName
	 * @return CurrentRamUsage(in Bytes) of respective processName
	 */
	public String getUsage(String processName) {
		for (KTApplicationInfo ktAppInfo : runningAppUsageInfo) {
			if (ktAppInfo.getProcessName().equals(processName)) {
				return String.valueOf(ktAppInfo.getUsage());
			}
		}
		return String.valueOf(0);
	}

	/**
	 * This Method returns instance of KTMemoryInfo Class which further provides
	 * us Total, current, used RAM Usage.
	 * 
	 * @return instance of KTMemoryInfo
	 */
	public KTMemoryInfo getMeoryInfo() {
		float totalMemory = geTotal();
		float totalAvail = getAvail();
		float used = totalMemory - totalAvail;
		ktMemoryInfo.setTotal(totalMemory);
		ktMemoryInfo.setFree(totalAvail);
		ktMemoryInfo.setUsed(used);

		return ktMemoryInfo;
	}

	private float geTotal() {
		float finaltotalRam = 0;
		try {

			RandomAccessFile reader = new RandomAccessFile("/proc/meminfo", "r"); // TOTAL
			String load;
			while ((load = reader.readLine()) != null) {
				if (load.contains("MemTotal")) {
					break;
				}
			}
			// //Log.d(tag, "FINAL:> " + string.toString());
			String totalRAM = load.trim().substring(9, load.indexOf("kB"));
			// //Log.d(tag, "TOTAL RAM IS:> " + totalRAM);
			long total = Long.parseLong(totalRAM.trim());
			finaltotalRam = (long) (total / 1024);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return finaltotalRam;
	}

	private float getAvail() {
		MemoryInfo mi = new MemoryInfo();
		ActivityManager activityManager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
		activityManager.getMemoryInfo(mi);
		float availableMegs = mi.availMem / (1024 * 1024);
		return availableMegs;
	}

	private List<KTApplicationInfo> calculatePerAppUsage() {
		List<KTApplicationInfo> runningAppUsageInfo = new ArrayList<KTApplicationInfo>();
		// List<RunningAppProcessInfo> runningAppProcesses = activityManager
		// .getRunningAppProcesses();

		List<Process> list = ProcessManager.getRunningApps();
		for (Process process : list) {
			if (!isExist(process.getPackageName(), runningAppUsageInfo)) {
				// if (process.getPackageName().toLowerCase().indexOf("kochar")
				// == -1) {
				String appName = getAppName(process.getPackageName());
				if (!appName.equals("")) {
					try {
						KTApplicationInfo ktAppInfo = new KTApplicationInfo();
						ktAppInfo.setPid(process.pid);
						ktAppInfo.setProcessName(process.getPackageName());
						ApplicationInfo appInfo = getApplicationInfo(ktAppInfo
								.getProcessName());
						// only include those applications that have application
						// info
						if (appInfo != null) {
							ktAppInfo.setAppName(getAppName(appInfo));
							ktAppInfo.setIcon(getAppIcon(appInfo));
							ktAppInfo.setUsage(Long.parseLong(getRAMUsage(ktAppInfo
									.getPid())));
							runningAppUsageInfo.add(ktAppInfo);
						}
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				// }
			}
		}

		// for (RunningAppProcessInfo runningAppProcessInfo :
		// runningAppProcesses) {
		// if (runningAppProcessInfo.processName.toLowerCase().indexOf(
		// "kochar") == -1) {
		// KTApplicationInfo ktAppInfo = new KTApplicationInfo();
		// ktAppInfo.setPid(runningAppProcessInfo.pid);
		// ktAppInfo.setProcessName(runningAppProcessInfo.processName);
		// ApplicationInfo appInfo = getApplicationInfo(ktAppInfo
		// .getProcessName());
		// // only include those applications that have application info
		// if (appInfo != null) {
		// ktAppInfo.setAppName(getAppName(appInfo));
		// ktAppInfo.setIcon(getAppIcon(appInfo));
		// ktAppInfo.setUsage(Long.parseLong(getRAMUsage(ktAppInfo
		// .getPid())));
		// runningAppUsageInfo.add(ktAppInfo);
		// }
		// }
		// }

		return runningAppUsageInfo;
	}

	private void resetPerAppUsage() {
		runningAppUsageInfo.clear();
	}

	private String getRAMUsage(int pid) {
		int pids[] = new int[1];
		pids[0] = pid;
		android.os.Debug.MemoryInfo[] memoryInfoArray = activityManager
				.getProcessMemoryInfo(pids);
		return String.valueOf(memoryInfoArray[0].getTotalPss() / 1024);
	}

	// private Drawable getAppIcon(String packageName) {
	// final PackageManager pm = context.getPackageManager();
	// ApplicationInfo ai;
	// try {
	// ai = pm.getApplicationInfo(packageName, 0);
	// } catch (final NameNotFoundException e) {
	// ai = null;
	// }
	// final Drawable appIcon = (ai != null ? pm.getApplicationIcon(ai) : null);
	// return appIcon;
	// }
	private String getAppName(String packageName) {
		final PackageManager pm = context.getPackageManager();
		ApplicationInfo ai;
		try {
			ai = pm.getApplicationInfo(packageName, 0);
		} catch (final NameNotFoundException e) {
			ai = null;
		}
		final String applicationName = (String) (ai != null ? pm
				.getApplicationLabel(ai) : "");
		return applicationName;

	}

	private boolean isExist(String packageName,
			List<KTApplicationInfo> arrayAppList) {
		for (KTApplicationInfo runningAppDTO : arrayAppList) {
			if (runningAppDTO.getProcessName().equals(packageName))
				return true;
		}
		return false;
	}

}
