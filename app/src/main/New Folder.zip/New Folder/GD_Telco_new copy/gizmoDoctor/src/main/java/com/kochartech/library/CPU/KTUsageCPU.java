package com.kochartech.library.CPU;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager.Process;

/**
 * This class has been used to calculate CPU Usage.
 * 
 * @author aman.arora
 */
public class KTUsageCPU extends KTUsage {

	private String tag = "CpuUsage";
	private Hashtable<String, Integer> hashTable = new Hashtable<String, Integer>();
	private ArrayList<String> headerName = null;
	private Hashtable<Integer, ApplicationInfo> pidMap_ApplicationInfo = new Hashtable<Integer, ApplicationInfo>();
	private int countNumApps;
	private int numOfAppsRequire = 0;
	private int total = 0;

	/**
	 * Default Constructor
	 * 
	 * @param context
	 *            - Application Context
	 */
	public KTUsageCPU(Context context) {
		super(context);
	}

	/**
	 * This Method returns list of KTApplicationInfo which contains info like
	 * Application Name, Icon, ProcessName , ProcessID, CPU Usage(In Percentage)
	 * 
	 * @param numOfAppsRequire
	 *            - Number of Applications to be displayed
	 * @return List of KTApplicationInfo
	 */
	public List<KTApplicationInfo> getPerAppUsage(int numOfAppsRequire) {
		this.numOfAppsRequire = numOfAppsRequire > 25 ? 25 : numOfAppsRequire;
		return refresh(numOfAppsRequire);
		// return runningAppUsageInfo;
	}

	/**
	 * This Method refreshes list of KTApplicationInfo which contains info like
	 * Application Name, Icon, ProcessName , ProcessID, CPU Usage(In
	 * Percentage).
	 * 
	 * @return List of KTApplicationInfo
	 */
	public List<KTApplicationInfo> refresh(int numOfAppsRequire) {
		initPIDMap();
		resetPerAppUsage();
		return calculatePerAppUsage(numOfAppsRequire);
	}

	/**
	 * This Method returns CPU Usage(in percentage) of the corresponding
	 * ProcessName.
	 * 
	 * @param processName
	 * @return CpuPercentage
	 */
	public String getUsage(String processName) {
		for (KTApplicationInfo ktAppInfo : runningAppUsageInfo) {
			if (ktAppInfo.getProcessName().equals(processName)) {
				return ktAppInfo.getUsage();
			}
		}
		return String.valueOf("0%");
	}

	/**
	 * This Method returns Total CPU usage of Device.
	 * 
	 * @return totalCpuUsage
	 */
	public int getTotalCPUUsage() {
		// resetTotalCPUsage();
		// calculatePerAppUsage(true);
		if (total > 100)
			total = 95;
		return total;
	}

	/**
	 * This Method returns free CPU
	 * 
	 * @return freeCpuUsage
	 */
	public int getFreeCPUUsage() {
		return (100 - total);
	}

	private void initPIDMap() {
		pidMap_ApplicationInfo.clear();

		List<Process> list = ProcessManager.getRunningApps();
		for (Process process : list) {
			try {
				int pid = process.pid;
				String processName = process.getPackageName();
				// try to fetch application info from process name
				ApplicationInfo applicationInfo = getApplicationInfo(processName);
				if (applicationInfo == null) {
					/*
					 * fail to fetch the application info from the process name
					 * then try with pkgname
					 */
					// String[] packages = runningAppProcess.pkgList;
					// applicationInfo = getApplicationInfo(packages[0]);
					applicationInfo = getApplicationInfo(processName);
				}
				// application info found
				if (applicationInfo != null) {
					pidMap_ApplicationInfo.put(pid, applicationInfo);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// List<RunningAppProcessInfo> runningAppProcessList = activityManager
		// .getRunningAppProcesses();
		// for (RunningAppProcessInfo runningAppProcess : runningAppProcessList)
		// {
		// int pid = runningAppProcess.pid;
		// String processName = runningAppProcess.processName;
		// // try to fetch application info from process name
		// ApplicationInfo applicationInfo = getApplicationInfo(processName);
		// if (applicationInfo == null) {
		// /*
		// * fail to fetch the application info from the process name then
		// * try with pkgname
		// */
		// String[] packages = runningAppProcess.pkgList;
		// applicationInfo = getApplicationInfo(packages[0]);
		// }
		// // application info found
		// if (applicationInfo != null) {
		// pidMap_ApplicationInfo.put(pid, applicationInfo);
		// }
		// }
		LogWrite.d(tag, "HashMap Size :" + pidMap_ApplicationInfo.size());
	}

	@SuppressLint("DefaultLocale")
	private List<KTApplicationInfo> calculatePerAppUsage(int numberOfApps) {
		int count = 0;
		List<KTApplicationInfo> runningAppUsageInfo = new ArrayList<KTApplicationInfo>();
		List<KTApplicationInfo> kocharAppList = new ArrayList<KTApplicationInfo>();
		try {
			String commandName = "top -d 1 -n 1"; // "top " + "-m " +
													// numberOfApps +
													// " -d 1 -n 1";
			java.lang.Process process = Runtime.getRuntime().exec(commandName);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					process.getInputStream()));
			String line = null;
			process.waitFor();

			while ((line = reader.readLine()) != null) {
				try {

					line = line.trim().toLowerCase();
					if (line.length() == 0) {
						// LogWrite.d(tag, "Length of Line is 0");
						continue;
					} else if (line.startsWith("user")) {
						// LogWrite.d(tag, "Length starts with User");
						// if(isToCalculateTotal) {
						if (count == 0) {
							LogWrite.e(tag, "Line :" + line);
							total = calculateTotalUsage(line);
							LogWrite.d(tag, "TotalUsage : " + total);
							count++;
						} else {
							// LogWrite.d(tag, "Working fine");
							continue;
						}
						// break;
						// }
						// LogWrite.d(tag, "Total  : ----> " + total);
					} else if (line.startsWith("pid")) {
						// LogWrite.d(tag, "Length starts with PID");
						headerName = stringToArrayList(line);
						for (int i = 0; i < headerName.size(); i++) {
							// LogWrite.i("Aman", "HeaderName : "
							// + headerName.get(i).toLowerCase());
							hashTable.put(headerName.get(i).toLowerCase(), i);
						}
					} else {
						// LogWrite.d(tag, "Else Block Enters");
						// LogWrite.e("Aman", line);
						// if (countNumApps == numOfAppsRequire)
						// break;
						// LogWrite.d(tag, "Work");
						ArrayList<String> elements = stringToArrayList(line);

						int pid = Integer.valueOf(elements.get(hashTable
								.get("pid")));
						// LogWrite.d(tag, "pid :" + pid);
						String processName = elements.get(elements.size() - 1);
						// LogWrite.d(tag,
						// "ProcessName :" + processName + "  AppName : "
						// + getAppLabel(context, processName));
						if (pidMap_ApplicationInfo.containsKey(pid)) {
							// LogWrite.i(tag,
							// "------------------------------------1");
							if (processName.toLowerCase().indexOf("kochar") == -1) {
								// LogWrite.d(tag, "App Found");
								ApplicationInfo applicationInfo = pidMap_ApplicationInfo
										.get(pid);
								KTApplicationInfo ktApplicationInfo = new KTApplicationInfo();
								ktApplicationInfo.setPid(pid);
								ktApplicationInfo.setProcessName(processName);
								ktApplicationInfo
										.setIcon(getAppIcon(applicationInfo));
								ktApplicationInfo
										.setAppName(getAppName(applicationInfo));
								ktApplicationInfo.setUsage(elements
										.get(hashTable.get("cpu%")));
								runningAppUsageInfo.add(ktApplicationInfo);
								// LogWrite.d(
								// tag,
								// "CPU % : "
								// + elements.get(hashTable
								// .get("cpu%")));
								countNumApps++;
							} else {
								ApplicationInfo applicationInfo = pidMap_ApplicationInfo
										.get(pid);
								KTApplicationInfo kocharApplicationInfo = new KTApplicationInfo();
								kocharApplicationInfo.setPid(pid);
								kocharApplicationInfo
										.setProcessName(processName);
								kocharApplicationInfo
										.setIcon(getAppIcon(applicationInfo));
								kocharApplicationInfo
										.setAppName(getAppName(applicationInfo));
								kocharApplicationInfo.setUsage(elements
										.get(hashTable.get("cpu%")));
								LogWrite.d(tag, "ProcessId : " + pid);
								LogWrite.d(tag, "ProcessName : " + processName);
								LogWrite.d(tag, "AppName : "
										+ getAppName(applicationInfo));
								// LogWrite.d(
								// tag,
								// "CPU % : "
								// + elements.get(hashTable
								// .get("cpu%")));
								kocharAppList.add(kocharApplicationInfo);
							}
						}

					}
				} catch (Exception e) {
					LogWrite.e(tag, "ExceptionDTO... " + e.toString());
				}
			}
		} catch (Exception e) {
			LogWrite.e(tag, "calculatePerAppUsageException... " + e.toString());
		} finally {
			if (kocharAppList.size() > 0) {
				KTApplicationInfo gizmoDoctorInfo = null;
				for (KTApplicationInfo ktApplicationInfo : kocharAppList) {
					if (ktApplicationInfo.getAppName().toLowerCase()
							.equals("gizmodoctor"))
						gizmoDoctorInfo = ktApplicationInfo;
					else
						runningAppUsageInfo.add(ktApplicationInfo);
					countNumApps++;
				}
				if (gizmoDoctorInfo != null)
					runningAppUsageInfo.add(gizmoDoctorInfo);
			}
		}
		// LogWrite.d(tag,
		// "runningAppUsageInfo size= " + runningAppUsageInfo.size());
		return runningAppUsageInfo;
	}

	private String getAppLabel(Context context, String processName) {
		PackageManager packageManager = context.getPackageManager();
		ApplicationInfo applicationInfo = null;
		try {
			applicationInfo = packageManager.getApplicationInfo(processName, 0);
		} catch (final NameNotFoundException e) {
		}
		return (String) (applicationInfo != null ? packageManager
				.getApplicationLabel(applicationInfo) : "Unknown");
	}

	private int calculateTotalUsage(String line) {
		int usage = 0;
		try {
			String[] commaSplitedArrayOfLine = line.split(",");
			for (String token : commaSplitedArrayOfLine) {
				token = token.toLowerCase().trim();
				if (token.startsWith("user") || token.startsWith("system")
						|| token.startsWith("iow") || token.startsWith("irq")) {
					String[] spaceSplitedArrayOfToken = token.split(" ");
					int lengthOfArray = spaceSplitedArrayOfToken.length;
					String cpuUsageToken = spaceSplitedArrayOfToken[lengthOfArray - 1]
							.trim();
					int indexOfPercentage = cpuUsageToken.indexOf("%");
					usage += Integer.parseInt(cpuUsageToken.substring(0,
							indexOfPercentage));
				}
			}
		} catch (NumberFormatException e) {
			LogWrite.e(tag, "NumberFormatException.... " + e.toString());
		}
		LogWrite.d(tag, "Usage ===> " + usage);
		return usage;
	}

	private ArrayList<String> stringToArrayList(String line) {
		ArrayList<String> arrayList = new ArrayList<String>();
		String[] lineSplit = line.split(" ");
		for (int i = 0; i < lineSplit.length; i++) {
			// LogWrite.e("Aman", lineSplit[i]);
			try {
				lineSplit[i] = StringEscapeUtils.escapeJava(lineSplit[i]);
				if (lineSplit[i].contains("\\u"))
					lineSplit[i] = "0";
			} catch (Exception e) {
				e.printStackTrace();
			}

			String token = lineSplit[i].trim();

			if (token.length() > 0) {
				token = token.toLowerCase();
				// LogWrite.w("Aman", token);
				arrayList.add(token);
			}
		}
		return arrayList;
	}

	private void resetTotalCPUsage() {
		total = 0;
	}

	private void resetPerAppUsage() {

		runningAppUsageInfo.clear();
		countNumApps = 0;
		hashTable.clear();
	}

	// private String getAppName(String packageName) {
	// final PackageManager pm = context.getPackageManager();
	// ApplicationInfo ai;
	// try {
	// ai = pm.getApplicationInfo(packageName, 0);
	// } catch (final NameNotFoundException e) {
	// ai = null;
	// }
	// final String applicationName = (String) (ai != null ? pm
	// .getApplicationLabel(ai) : "");
	// return applicationName;
	//
	// }
	//
	// private boolean isExist(String packageName,
	// List<KTApplicationInfo> arrayAppList) {
	// for (KTApplicationInfo runningAppDTO : arrayAppList) {
	// if (runningAppDTO.getProcessName().equals(packageName))
	// return true;
	// }
	// return false;
	// }
}
