package com.kochartech.devicemax.dto;

import android.util.Log;

import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by gauravjeet on 18/8/17.
 */
//used for sending location_json
public class AckCommand extends Thread {
    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");
    private static final String TAG = "AckCommand";
    private String ack_json;

    public AckCommand(AckDTO ackDTO) {
        Gson gson = new Gson();
        ack_json = gson.toJson(ackDTO);
        Log.e(TAG, "Sending the ACK JSON:" + ack_json);
    }

    @Override
    public void run() {
        super.run();
        try {
            String response_from_server = post(AppConstant.ACK_URL, this.ack_json);
            Log.e(TAG, "ResponseDTO of ack:" + response_from_server);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    String post(String url, String json) throws IOException {
        final OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        return response.body().string();
    }
}
