package com.kochartech.devicemax.Utility;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.kochartech.devicemax.Activities.LogWrite;

import org.apache.http.client.ClientProtocolException;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@SuppressWarnings("deprecation")
public class Response {
    private String TAG = Response.class.getSimpleName();
    private String server_url = "";
    private Context context;

    // String message = ""[{"AppNameMonitor":"WhatsApp",
    // "BatteryLevel":"67.0",
    // "BatteryTemp":"30.0",
    // "BatteryUsage":"0",
    // "BluetoothTime":"0",
    // "CPUUsage":"0",
    // "ChargingState":"Charging",
    // "DeviceHealth":"Good",
    // "GpsTime":"6",
    // "HotspotTime":"12",
    // "IMEI":"865072028158973",
    // "ProcessName":"com.whatsapp",
    // "RAMUsage":"1",
    // "TimeStamp":"2015-05-16 14:48:58",
    // "WifiTime":"6"}]";
    public boolean send(Context context, String server_url, String message) {
        this.server_url = server_url;
        this.context = context;
        if (isConnected()) {
            return doPost(context, message);
        }
        return false;
    }

    public boolean send(Context context, String server_url, byte[] messageBytes) {
        this.server_url = server_url;
        this.context = context;
        if (isConnected()) {
            return doPost(context, messageBytes);
        }
        return false;
    }

    public String sendFileToServer(String path, String targetUrl) {
        String response = "error";
        LogWrite.e(TAG, path);
        LogWrite.e(TAG, targetUrl);
        HttpURLConnection connection = null;
        DataOutputStream outputStream = null;
        // DataInputStream inputStream = null;

        // String pathToOurFile = filename;
        String urlServer = targetUrl;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        DateFormat df = new SimpleDateFormat("yyyy_MM_dd_HH:mm:ss");

        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024;
        try {
            FileInputStream fileInputStream = new FileInputStream(
                    new File(path));

            URL url = new URL(urlServer);
            connection = (HttpURLConnection) url.openConnection();

            // Allow Inputs & Outputs
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setUseCaches(false);
            connection.setChunkedStreamingMode(1024);
            // Enable POST method
            connection.setRequestMethod("POST");

            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type",
                    "multipart/form-data;boundary=" + boundary);

            outputStream = new DataOutputStream(connection.getOutputStream());
            outputStream.writeBytes(twoHyphens + boundary + lineEnd);

            String connstr = null;
            connstr = "Content-Disposition: form-data; name=\"uploadedfile\";filename=\""
                    + path + "\"" + lineEnd;
            LogWrite.i(TAG, connstr);

            outputStream.writeBytes(connstr);
            outputStream.writeBytes(lineEnd);

            bytesAvailable = fileInputStream.available();
            bufferSize = Math.min(bytesAvailable, maxBufferSize);
            buffer = new byte[bufferSize];

            // Read file
            bytesRead = fileInputStream.read(buffer, 0, bufferSize);
            LogWrite.w(TAG, bytesAvailable + " :: " + bytesRead);
            try {
                while (bytesRead > 0) {
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    byte byt[] = new byte[bufferSize];
                    fileInputStream.read(byt);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                    outputStream.write(buffer, 0, bufferSize);
                    LogWrite.d(TAG, "Bytes Read : " + bytesRead);
                    // try {
                    // outputStream.write(buffer, 0, bufferSize);
                    // } catch (OutOfMemoryError e) {
                    // LogWrite.e(TAG, "OutOfMemoryError : " + e.toString());
                    // response = "outofmemoryerror";
                    // return response;
                    // }
                    // bytesAvailable = fileInputStream.available();
                    // bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    // bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                }
            } catch (Exception e) {
                e.printStackTrace();
                LogWrite.e(TAG, "Error ????? " + e.toString());
                response = "error";
                return response;
            }
            outputStream.writeBytes(lineEnd);
            outputStream.writeBytes(twoHyphens + boundary + twoHyphens
                    + lineEnd);

            // Responses from the server (code and message)
            int serverResponseCode = connection.getResponseCode();
            String serverResponseMessage = connection.getResponseMessage();
            LogWrite.i(TAG, "ResponseCode : " + serverResponseCode);
            LogWrite.i(TAG, "ResponseMessage : " + serverResponseMessage);

            if (serverResponseCode == 200) {
                response = "true";
            }

            String CDate = null;
            Date serverTime = new Date(connection.getDate());
            try {
                CDate = df.format(serverTime);
            } catch (Exception e) {
                e.printStackTrace();
                LogWrite.e(TAG, "DateException : " + e.getMessage());
            }
            LogWrite.i(TAG, CDate + "");

            // filename = CDate
            // + filename.substring(filename.lastIndexOf("."),
            // filename.length());
            // Log.i("File Name in Server : ", filename);

            fileInputStream.close();
            outputStream.flush();
            outputStream.close();
            outputStream = null;
        } catch (Exception ex) {
            // ExceptionDTO handling
            response = "error";
            LogWrite.e(TAG, "Error...." + ex.getMessage() + "");
            ex.printStackTrace();
        }
        return response;
    }

    // private boolean post(String message) {
    // try {
    // // 1. create HttpClient
    // HttpClient httpclient = new DefaultHttpClient();
    // // 2. make POST request to the given URL
    // HttpPost httpPost = new HttpPost(MONITOR_SERVICE_URL);
    //
    // StringEntity se = new StringEntity(message);
    //
    // httpPost.setEntity(se);
    // httpPost.setHeader("Accept", "application/json");
    // httpPost.setHeader("Content-type", "application/json");
    //
    // HttpResponse httpResponse = httpclient.execute(httpPost);
    //
    // int responseCode = httpResponse.getStatusLine().getStatusCode();
    //
    // if (responseCode == 200) {
    // LogWrite.d(TAG, "Post Successfully!!!!!!!");
    // return true;
    // } else {
    // LogWrite.e(TAG, "Unable to post");
    // return false;
    // }
    //
    // } catch (ExceptionDTO e) {
    // LogWrite.e(TAG, "PostJSONException :---> " + e.toString());
    // }
    // return false;
    // }

    @SuppressLint("DefaultLocale")
    private boolean doPost(Context context, String message) {
        // String dataFromServer="";
        HttpURLConnection urlConnection = null;
        // String responseString="";
        LogWrite.d(TAG, "Server Url ->" + server_url);
        LogWrite.d(TAG, "ResponseDTO->" + message);
        try {
            // String url = context.getString(R.string.RegisterUrl);
            URL _url = new URL(server_url);
            urlConnection = (HttpURLConnection) _url.openConnection();
            urlConnection.setReadTimeout(1 * 60 * 1000);
            urlConnection.setConnectTimeout(1 * 60 * 1000);
            urlConnection.setRequestMethod("POST");
            urlConnection
                    .setRequestProperty("Content-Type", "application/json");
            // urlConnection.setRequestProperty("Content-Length", message
            // .toString().length() + "");
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            LogWrite.d(TAG, "Message Length ->" + message.toString().length());
            DataOutputStream dos = new DataOutputStream(
                    urlConnection.getOutputStream());
            byte[] bs = message.getBytes();
            LogWrite.d(TAG, "Sending JSON String ->" + new String(bs));
            // LogData.writeToFile(new String(bs));
            dos.write(bs);
            dos.flush();
            dos.close();
            LogWrite.e(TAG, "ResponseCode ->" + urlConnection.getResponseCode());
            LogWrite.d(TAG,
                    "ResponseMessage ->" + urlConnection.getResponseMessage());
            if (urlConnection.getResponseMessage().toLowerCase().equals("ok")) {

                InputStream is = urlConnection.getInputStream();
                int ch;
                StringBuffer b = new StringBuffer();
                while ((ch = is.read()) != -1) {
                    b.append((char) ch);
                }
                // responseString = b.toString();
                return true;

            } // data sent successfully
            dos.close();
        } catch (IOException ioe) {
            LogWrite.e(TAG, "IOException : " + ioe.toString());
            return false;
        }
        return false;
    }

    @SuppressLint("DefaultLocale")
    private boolean doPost(Context context, byte[] message) {
        // LogWrite.d(TAG, "upload====" + upLoadServerUri);
        String responseStringIMAGE = "";
        DataOutputStream dos;
        try {

            HttpURLConnection urlConnection = null;
            URL url = new URL(server_url);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type",
                    "application/octet-stream");
            urlConnection.setRequestProperty("Content-Length", message.length
                    + "");
            // urlConnection.setRequestProperty("Connection", "Keep-Alive");
            urlConnection.setChunkedStreamingMode(1024);
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            // urlConnection.connect();

            dos = new DataOutputStream(urlConnection.getOutputStream());
            dos.write(message);
            LogWrite.d(TAG,
                    "ResponceCode  : " + urlConnection.getResponseCode());
            LogWrite.d(TAG,
                    "ResponceMessage  : " + urlConnection.getResponseMessage());
            if (urlConnection.getResponseMessage().toLowerCase().equals("ok")) {

                // deleteFile(path);
                InputStream is = urlConnection.getInputStream();
                int ch;
                StringBuffer b = new StringBuffer();
                // //LogWrite.d(TAG, "before while");
                while ((ch = is.read()) != -1) {
                    // //LogWrite.d(TAG, "ch===" + ch);
                    b.append((char) ch);
                }

                responseStringIMAGE = b.toString();
                LogWrite.d(TAG, "ResponseStringIMAGE : " + responseStringIMAGE);
                return true;
            }
            dos.flush();
            dos.close();
            // urlConnection.disconnect();
        } catch (SocketException e) {
        } catch (ClientProtocolException e) {
        } catch (IOException e) {
        }
        return false;
    }

    // private boolean post1(String message) {
    // try {
    // // 1. create HttpClient
    // HttpClient httpClient = new DefaultHttpClient();
    // // 2. make POST request to the given URL
    // HttpPost httppost = new HttpPost(MONITOR_SERVICE_URL);
    //
    // StringEntity se = new StringEntity(message, HTTP.UTF_8);
    //
    // se.setContentType("text/xml");
    // httppost.setEntity(se);
    //
    // HttpResponse httpResponse = httpClient.execute(httppost);
    //
    // int responseCode = httpResponse.getStatusLine().getStatusCode();
    //
    // if (responseCode == 200) {
    // LogWrite.d(TAG, "Post Successfully!!!!!!!");
    // return true;
    // } else {
    // LogWrite.e(TAG, "Unable to post");
    // return false;
    // }
    // } catch (ExceptionDTO e) {
    // LogWrite.e(TAG, "PostXMLException :---> " + e.toString());
    // }
    // return false;
    // }

    private boolean isConnected() {
        ConnectivityManager connMgr = (ConnectivityManager) context
                .getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }
}
