package com.kochartech.gizmodoctor.Fragment;
//package com.kochartech.Fragment;
//
//import java.util.ArrayList;
//
//import android.app.Activity;
//import android.os.Bundle;
//import android.support.v4.app.Fragment;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.AdapterView;
//import android.widget.AdapterView.OnItemClickListener;
//import android.widget.ListView;
//import android.widget.Toast;
//
//import com.kochartech.Adapter.MemoryDetailAdapter;
//import com.kochartech.POJO.AppInfo;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.library.Application.KTInformation;
//import com.kochartech.library.Application.KTInstalled;
//
//public class MemoryDetailFragment extends Fragment implements OnItemClickListener
//{
//	private Activity activityContext;
//	private KTInstalled ktInstalled;
//	private ListView listViewMeoryDetail;
//	private ArrayList<KTInformation> ktInformationList ;
//	private MemoryDetailAdapter listViewAdapter;
//	private View rootView;
//	@Override
//	public View onCreateView(LayoutInflater inflater, ViewGroup container,
//			Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		
//		activityContext = getActivity();
//		
//		rootView = inflater.inflate(R.layout.fragment_memorydetail, container , false); 	
//		
//		listViewMeoryDetail = (ListView) rootView.findViewById(R.id.listView_MemoryDetail);
//		listViewMeoryDetail.setOnItemClickListener(this);
//		
//		ktInstalled = new KTInstalled(activityContext);
//		ktInformationList = ktInstalled.getInstalledApps();
//		
//		listViewAdapter = new MemoryDetailAdapter(activityContext, ktInformationList);
//		
//		listViewMeoryDetail.setAdapter(listViewAdapter);
//		
//		
//		
//		return rootView;
//	}
//	@Override
//	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
//		
//	}
//}
