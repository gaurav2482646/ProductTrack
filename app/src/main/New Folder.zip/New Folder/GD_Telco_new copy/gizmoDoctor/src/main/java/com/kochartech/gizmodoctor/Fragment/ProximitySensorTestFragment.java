package com.kochartech.gizmodoctor.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;

@SuppressLint("DefaultLocale")
public class ProximitySensorTestFragment extends Fragment implements
		SensorEventListener, OnClickListener, MyFragment {

	private final static String TAG = ProximitySensorTestFragment.class
			.getSimpleName();
	private Context context;
	private View rootView;
	private TextView textView;
	private SensorManager mSensorManager;
	private Sensor mSensor;
	private boolean flag = false;

	private boolean isFromCommand = false;
	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
	private OnCommandListener onCommandListener;
	private boolean isClickWork = false;

	private boolean checkProximityFlag = false;
	private CircularProgressBar timerProgress;

	private boolean success = false;
	private String FAILURE_MESSAGE = "Press OK if proximity sensor not working";
	private Button okButton;
	private OnAutoHardwareTestListener onAutoHardwareTestListener;

	public ProximitySensorTestFragment(OnCommandListener onCommandListener) {
		this.onCommandListener = onCommandListener;
	}

	public void setOnAutoHardwareTestListener(
			OnAutoHardwareTestListener onAutoHardwareTestListener) {
		this.onAutoHardwareTestListener = onAutoHardwareTestListener;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		getActivity().getWindow()
				.setFlags(
						0xFFFFFFFF,
						LayoutParams.FLAG_FULLSCREEN
								| LayoutParams.FLAG_KEEP_SCREEN_ON);

		checkProximityFlag = false;
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		Bundle bundle = getArguments();
		if (bundle != null) {
			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
			}

		}
		mSensorManager = (SensorManager) context
				.getSystemService(Context.SENSOR_SERVICE);
		mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
		registerSensor();
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {
		context = getActivity().getApplicationContext();
		rootView = inflater.inflate(R.layout.layout_textview, container, false);
		textView = (TextView) rootView.findViewById(R.id.textView);
		textView.setText(R.string.place_hand_near_speaker);

		okButton = (Button) rootView.findViewById(R.id.ok_button);
		okButton.setOnClickListener(this);

		timerProgress = (CircularProgressBar) rootView
				.findViewById(R.id.circularprogressbar2);
		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {

			@Override
			public void onAnimationStart() {
			}

			@Override
			public void onAnimationProgress(int progress) {
				timerProgress.setTitle(progress + "");
				timerProgress.setSubTitle("");
			}

			@Override
			public void onAnimationFinish() {
				if (!success) {
					textView.setText(FAILURE_MESSAGE);
					textView.setTextAppearance(context, R.style.textStyleRed);
					okButton.setVisibility(View.VISIBLE);
					timerProgress.setSubTitle("");
					timerProgress.setVisibility(View.GONE);
					if (HardwareTestFragment.isAutoStartClicked) {
						onAutoHardwareTestListener.onHardwareTestFinish(2,
								"Proximity Sensor", false);
						// FragmentListener fragmentListener =
						// (FragmentListener) getActivity();
						// fragmentListener.onItemClicked(FragmentListener.actionRemove,
						// ProximitySensorTestFragment.this);
						getActivity().getSupportFragmentManager()
								.beginTransaction()
								.remove(ProximitySensorTestFragment.this)
								.commit();
						getActivity().getFragmentManager().popBackStack();
						// getActivity().onBackPressed();
					}

				}
			}
		});
	}

	@Override
	public void onSensorChanged(SensorEvent event) {

		LogWrite.d(TAG, "Event : " + event.values[0]);

		if (Build.BRAND.toLowerCase().equals("micromax")
				|| Build.BRAND.toLowerCase().equals("xiaomi")) {
			if (event.values[0] == 0 || event.values[0] == 1) {
				// if (checkProximityFlag) {
				flag = true;
				try {
					Vibrator vibrator = (Vibrator) context
							.getSystemService(Context.VIBRATOR_SERVICE);
					vibrator.vibrate(500);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				timerProgress.setVisibility(View.GONE);
				textView.setText(R.string.proximitysensor_working_fine);
				textView.setTextAppearance(getActivity(),
						R.style.textStyleGreen);

				if (HardwareTestFragment.isAutoStartClicked) {
					onAutoHardwareTestListener.onHardwareTestFinish(2,
							"Proximity Sensor", true);
					// FragmentListener fragmentListener = (FragmentListener)
					// getActivity();
					// fragmentListener.onItemClicked(FragmentListener.actionRemove,
					// this);
					getActivity().getSupportFragmentManager()
							.beginTransaction()
							.remove(ProximitySensorTestFragment.this).commit();
//					getActivity().getFragmentManager().popBackStack();
					// getActivity().onBackPressed();
				}

				if (isFromCommand) {
					onCommandListener.onCommand(true);
					FragmentListener fragmentListener = (FragmentListener) getActivity();
					fragmentListener.onItemClicked(
							FragmentListener.actionRemove, this);
				}
				success = true;
				isClickWork = true;
				// } else {
				// checkProximityFlag = true;
				// }
			}
		} else {
			if (event.values[0] == 0 || event.values[0] == 3) {
				if (checkProximityFlag) {
					flag = true;
					try {
						Vibrator vibrator = (Vibrator) context
								.getSystemService(Context.VIBRATOR_SERVICE);
						vibrator.vibrate(500);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					timerProgress.setVisibility(View.GONE);
					textView.setText(R.string.proximitysensor_working_fine);
					textView.setTextAppearance(getActivity(),
							R.style.textStyleGreen);
					if (HardwareTestFragment.isAutoStartClicked) {
						onAutoHardwareTestListener.onHardwareTestFinish(2,
								"Proximity Sensor", true);
						// FragmentListener fragmentListener =
						// (FragmentListener) getActivity();
						// fragmentListener.onItemClicked(FragmentListener.actionRemove,
						// this);
						getActivity().getSupportFragmentManager()
								.beginTransaction()
								.remove(ProximitySensorTestFragment.this)
								.commit();
//						getFragmentManager().popBackStack();
						// getActivity().onBackPressed();
					}

					if (isFromCommand) {
						onCommandListener.onCommand(true);
						FragmentListener fragmentListener = (FragmentListener) getActivity();
						fragmentListener.onItemClicked(
								FragmentListener.actionRemove, this);
					}
					success = true;
					isClickWork = true;
				} else {
					checkProximityFlag = true;
				}
			}
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub

	}

	public void registerSensor() {
		if (mSensorManager != null && mSensor != null)
			mSensorManager.registerListener(this, mSensor,
					SensorManager.SENSOR_DELAY_NORMAL);
	}

	public void unRegisterSensor() {
		if (mSensorManager != null && mSensor != null)
			mSensorManager.unregisterListener(this, mSensor);
		// mSensorManager.
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		LogWrite.d(TAG, "onDestroy is working...");
		super.onDestroy();
		unRegisterSensor();
		// if (onCommandListener != null) {
		// onCommandListener.onCommand(isClickWork);
		// }
	}

	@Override
	public void onClick(View v) {
		Vibrator vibrator = (Vibrator) context
				.getSystemService(Context.VIBRATOR_SERVICE);
		vibrator.vibrate(500);
		textView.setText("ProximitySensor test fails.");
		if (HardwareTestFragment.isAutoStartClicked) {
			onAutoHardwareTestListener.onHardwareTestFinish(2,
					"Proximity Sensor", false);
			// FragmentListener fragmentListener = (FragmentListener)
			// getActivity();
			// fragmentListener.onItemClicked(FragmentListener.actionRemove,
			// this);
			getActivity().getSupportFragmentManager().beginTransaction()
					.remove(ProximitySensorTestFragment.this).commit();
			getActivity().getFragmentManager().popBackStack();
			// getActivity().onBackPressed();
		}
		if (isFromCommand) {
			onCommandListener.onCommand(false);
			FragmentListener fragmentListener = (FragmentListener) getActivity();
			fragmentListener.onItemClicked(FragmentListener.actionRemove, this);
		}
		okButton.setVisibility(View.GONE);
	}

	@Override
	public String getTitle() {
		return "Proximity Sensor";
	}

}
