package com.kochartech.gizmodoctor.HelperClass;

public class Config {

	private static AppTye applicationType = AppTye.WITHOUT_REGISTRATION;

	public static AppTye getApplicationType() {
		return applicationType;
	}

	public enum AppTye {
		FOREGROUND_REGISTER, BACKGROUND_REGISTER, WITHOUT_REGISTRATION
	};

	// private static String serverUrl =
	// "http://192.161.0.207/gh_crm_service/GHCRMService.svc/ghcrmclient/";
	// private static String serverUrl =
	// "http://202.164.36.66/gizmosupportservice/GHCRMService.svc/ghcrmclient/";
	private static String serverUrl = "http://202.164.38.206:14/gizmosupportservice/GHCRMService.svc/ghcrmclient/";
	private static String methodValidateKey_foregroundRegister = "ValidateKey";
	private static String methodValidateKey_backgroundRegister = "ValidateKeyTrial";
	private static String methodGetApplicationKey = "GetApplicationKey";

	public static String getUrl_ValidateKey() {
		String serverUrl = Config.serverUrl;
		if (applicationType == AppTye.BACKGROUND_REGISTER)
			serverUrl += methodValidateKey_backgroundRegister;
		else if (applicationType == AppTye.FOREGROUND_REGISTER)
			serverUrl += methodValidateKey_foregroundRegister;

		return serverUrl;
	}

	public static String getUrl_ApplicationKey() {
		String serverUrl = Config.serverUrl;
		if (applicationType == AppTye.FOREGROUND_REGISTER)
			serverUrl += methodGetApplicationKey;

		return serverUrl;
	}
}
