package com.kochartech.gizmodoctor.HardwareModel;

import java.util.List;

import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.os.Build;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.Toast;

import com.kochartech.devicemax.Activities.LogWrite;

@SuppressWarnings("deprecation")
public class CameraPreview extends SurfaceView implements
		SurfaceHolder.Callback {
	private String TAG = CameraPreview.class.getSimpleName();
	private SurfaceHolder mSurfaceHolder;

	private Camera mCamera;

	private boolean flipFlag = false;
	private Context context;

	// private boolean angleFlag = false;

	// Constructor that obtains context and camera
	public CameraPreview(Context context, Camera camera, boolean flipFlag) {
		super(context);
		this.context = context;
		this.flipFlag = flipFlag;
		this.mCamera = camera;
		this.mSurfaceHolder = this.getHolder();
		this.mSurfaceHolder.addCallback(this);
		this.mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	}

	@Override
	public void surfaceCreated(SurfaceHolder surfaceHolder) {
		try {
			LogWrite.d(TAG, "surfaceCreated method enters............"
					+ flipFlag);
			Parameters parameters = mCamera.getParameters();
			List<Camera.Size> previewSizes = parameters
					.getSupportedPreviewSizes();
			Camera.Size previewSize = previewSizes.get(4); // 480h x 720w

			parameters.setPreviewSize(previewSize.width, previewSize.height);
			parameters.setFlashMode(Parameters.FLASH_MODE_AUTO);
			parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
			mCamera.setParameters(parameters);

			Display display = ((WindowManager) context
					.getSystemService(Context.WINDOW_SERVICE))
					.getDefaultDisplay();
			// Toast.makeText(context,
			// "DeviceRotation : " + display.getRotation(),
			// Toast.LENGTH_SHORT).show();
			// if (display.getRotation() == Surface.ROTATION_0) {
			// mCamera.setDisplayOrientation(90);
			// } else if (display.getRotation() == Surface.ROTATION_270) {
			// mCamera.setDisplayOrientation(180);
			// }

			// You need to choose the most appropriate previewSize for your app
			// .... select one of previewSizes here
			/* parameters.setPreviewSize(previewSize.width, previewSize.height); */

			if (display.getRotation() == Surface.ROTATION_0) {
				if (Build.BRAND.equals("google")
						&& Build.MODEL.equals("Nexus 5X"))
					mCamera.setDisplayOrientation(270);
				else
					mCamera.setDisplayOrientation(90);
			}

			if (display.getRotation() == Surface.ROTATION_180) {
				mCamera.setDisplayOrientation(270);
			}
			if (display.getRotation() == Surface.ROTATION_270) {
				mCamera.setDisplayOrientation(180);
			}
			mCamera.startPreview();
		} catch (Exception e) {
			e.printStackTrace();
			LogWrite.e(TAG, "surfaceCreated ExceptionDTO : " + e.toString());
		}

		// try {
		// Parameters params = mCamera.getParameters();
		// if (this.getResources().getConfiguration().orientation !=
		// Configuration.ORIENTATION_LANDSCAPE) {
		// params.set("orientation", "portrait");
		// if (Build.VERSION.SDK_INT >= 24) {
		// if (flipFlag)
		// mCamera.setDisplayOrientation(90);
		// else
		// mCamera.setDisplayOrientation(270);
		//
		// } else {
		// mCamera.setDisplayOrientation(90);
		// }
		// }
		//
		// mCamera.setPreviewDisplay(surfaceHolder);
		// mCamera.startPreview();
		// } catch (ExceptionDTO e) {
		//
		// }
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
		LogWrite.d(TAG, "surfaceDestroyed method enters............");
		try {
			mCamera.stopPreview();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// mCamera.release();
	}

	@Override
	public void surfaceChanged(SurfaceHolder surfaceHolder, int format,
			int width, int height) {
		LogWrite.d(TAG, "surfaceChanged method enters............");
		// start preview with new settings
		try {
			mCamera.stopPreview();
			mCamera.setPreviewDisplay(surfaceHolder);
			mCamera.startPreview();
		} catch (Exception e) {
			// intentionally left blank for a test
		}
	}
}
