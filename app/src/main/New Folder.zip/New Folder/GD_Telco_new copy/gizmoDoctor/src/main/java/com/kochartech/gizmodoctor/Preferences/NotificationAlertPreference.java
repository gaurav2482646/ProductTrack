package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class NotificationAlertPreference {

	// private String TAG = NotificationAlertPreference.class.getSimpleName();

	private final String PREFERENCE_NAME = "gizmodoctor";
	private final int PREFERENCE_MODE = 0;

	private String ALERT_BATTERY_LEVEL = "alertbatterylevel";
	private String ALERT_BATTERY_TEMPERATURE = "alertbatterytemperature";
	private String ALERT_CPU_TEMPERATURE = "alertcputemperature";
	private String BATTERY_LEVEL_WHILE_CHK = "alert_battery_level_while_chk";
	private String BATTERY_TEMPERATURE_WHILE_CHK = "alert_battery_temperature_while_chk";
	private String CPU_TEMPERATURE_WHILE_CHK = "alert_cpu_temperature_while_chk";
	private final String ALERT_DATACONNECTION_OFF = "alert_dataConnection_isnot_working";
	private final String ALERT_RAM_USAGE = "alert_ram_usage";
	private final String ALERT_CPU_USAGE = "alert_cpu_usage";
	private final String ALERT_SETTINGS_USAGE = "alert_settings_usage";
	public final boolean DEFAULTVALUE = false;
	// public final boolean DEFAULTVALUE_BATTERY_TEMPERATURE = false;
	// public final boolean DEFAULTVALUE_DATACONNECTION_OFF = false;
	//

	// private Context context;
	private SharedPreferences myPreference;
	private Editor editor;

	public NotificationAlertPreference(Context context) {
		// TODO Auto-generated constructor stub
		// this.context = context;
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();
	}

	public boolean getAlert_Battery_Level() {
		return myPreference.getBoolean(ALERT_BATTERY_LEVEL, DEFAULTVALUE);
	}

	public void setAlert_Battery_Level(boolean value) {
		editor.putBoolean(ALERT_BATTERY_LEVEL, value).commit();
	}

	public boolean getAlert_Battery_Temperature() {
		return myPreference.getBoolean(ALERT_BATTERY_TEMPERATURE, DEFAULTVALUE);
	}

	public void setAlert_Battery_Temperature(boolean value) {
		editor.putBoolean(ALERT_BATTERY_TEMPERATURE, value).commit();
	}

	public boolean getAlert_CPU_Temperature() {
		return myPreference.getBoolean(ALERT_CPU_TEMPERATURE, DEFAULTVALUE);
	}

	public void setAlert_CPU_Temperature(boolean value) {
		editor.putBoolean(ALERT_CPU_TEMPERATURE, value).commit();
	}

	public int getBatteryLevel_WHILE_SCAN() {
		return myPreference.getInt(BATTERY_LEVEL_WHILE_CHK, 0);
	}

	public void setBatteryLevel_WHILE_SCAN(int value) {
		editor.putInt(BATTERY_LEVEL_WHILE_CHK, value).commit();
	}

	public int getBatteryTemperature_WHILE_SCAN() {
		return myPreference.getInt(BATTERY_TEMPERATURE_WHILE_CHK, 0);
	}

	public void setBatteryTemperature_WHILE_SCAN(int value) {
		editor.putInt(BATTERY_TEMPERATURE_WHILE_CHK, value).commit();
	}

	public int getCpuTemperature_WHILE_SCAN() {
		return myPreference.getInt(CPU_TEMPERATURE_WHILE_CHK, 0);
	}

	public void setCpuTemperature_WHILE_SCAN(int value) {
		editor.putInt(CPU_TEMPERATURE_WHILE_CHK, value).commit();
	}

	public boolean isToAlertDataConnectionWorking() {
		return myPreference.getBoolean(ALERT_DATACONNECTION_OFF, DEFAULTVALUE);
	}

	public void setDataConnectionAlert(boolean value) {
		editor.putBoolean(ALERT_DATACONNECTION_OFF, value).commit();
	}

	public boolean isToAlertRAMNotification() {
		return myPreference.getBoolean(ALERT_RAM_USAGE, DEFAULTVALUE);
	}

	public void setRAMNotificationAlert(boolean value) {
		editor.putBoolean(ALERT_RAM_USAGE, value).commit();
	}

	public boolean isToAlertCPUNotification() {
		return myPreference.getBoolean(ALERT_CPU_USAGE, DEFAULTVALUE);
	}

	public void setCPUNotificationAlert(boolean value) {
		editor.putBoolean(ALERT_CPU_USAGE, value).commit();
	}

	public boolean isToAlertSettingsNotification() {
		return myPreference.getBoolean(ALERT_SETTINGS_USAGE, DEFAULTVALUE);
	}

	public void setSettingsNotificationAlert(boolean value) {
		editor.putBoolean(ALERT_SETTINGS_USAGE, value).commit();
	}

	public void resetPreferences() {
		setAlert_Battery_Level(false);
		setAlert_Battery_Temperature(false);
		setDataConnectionAlert(false);
		setRAMNotificationAlert(false);
		setCPUNotificationAlert(false);
		setSettingsNotificationAlert(false);
		setAlert_CPU_Temperature(false);
	}

}
