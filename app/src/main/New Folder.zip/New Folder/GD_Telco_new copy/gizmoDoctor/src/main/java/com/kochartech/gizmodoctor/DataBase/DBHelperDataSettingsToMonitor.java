package com.kochartech.gizmodoctor.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.kochartech.devicemax.Activities.LogWrite;

/*
 *  it holds the settings on/off  data, and also check is to currently monitor the settings.
 *  column name:  SettingName,ontime,offtime,isupdate.
 */

public class DBHelperDataSettingsToMonitor {
	private String tag = "DBHelperDataSettingsToMonitor";
	private Context context;
	private static DBHelperDataSettingsToMonitor classInstance = null;
	private MySQLiteOpenHelper mySQLiteOpenHelper;
	private SQLiteDatabase db;

	public static DBHelperDataSettingsToMonitor getInstance(Context context) {
		if (classInstance == null)
			classInstance = new DBHelperDataSettingsToMonitor(context);
		return classInstance;
	}

	private DBHelperDataSettingsToMonitor(Context context) {
		LogWrite.d(tag, "constructor");
		this.context = context;
		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
	}

	private void open() {
		LogWrite.d(tag, "open");
		db = mySQLiteOpenHelper.getWritableDatabase();
	}

	private void close() {
		LogWrite.d(tag, "close");
		db.close();
	}

	public synchronized void insertEntry(String settingName) {
		open();
		String tag = "insert";
		// SimpleDateFormat formatter = new
		// SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// String timeInString = formatter.format(new
		// Date(System.currentTimeMillis()));

		// LogWrite.d(tag,"timeInString: "+timeInString);

		long currentTime = System.currentTimeMillis();
		ContentValues values = new ContentValues();
		values.put(
				MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName,
				settingName);
		values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnoOnTime,
				currentTime);
		values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnOffTime,
				currentTime);
		values.put(
				MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate, 1);
		long id = db.insertOrThrow(
				MySQLiteOpenHelper.Data_SettingsToMonitring_TableName, null,
				values);

		// db.q
		// db.updateWithOnConflict(table, values, whereClause, whereArgs,
		// conflictAlgorithm)
		LogWrite.d(tag, "id :" + id);
		close();
		// printTable();

	}

	// public void insertEntry(String settingName)
	// {
	// ContentValues values = new ContentValues();
	// values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName,
	// settingName);
	// values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnoOnTime,
	// System.currentTimeMillis());
	// values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnOffTime, 0);
	//
	// long id =
	// db.insertOrThrow(MySQLiteOpenHelper.Data_SettingsToMonitring_TableName,
	// null, values);
	//
	// // db.q
	// // db.updateWithOnConflict(table, values, whereClause, whereArgs,
	// conflictAlgorithm)
	// LogWrite.d(tag,"id :"+id);
	//
	// }

	public synchronized void updateSettingEndTime(String settingName) {
		// SimpleDateFormat formatter = new
		// SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		// String timeInString = formatter.format(new
		// Date(System.currentTimeMillis()));

		open();
		long currentTime = System.currentTimeMillis();
		ContentValues values = new ContentValues();
		values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnOffTime,
				currentTime);

		long id = db
				.update(MySQLiteOpenHelper.Data_SettingsToMonitring_TableName,
						values,
						MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName
								+ " =? and "
								+ MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate
								+ " =?", new String[] { settingName, "1" });
		close();
		// LogWrite.d(tag,"id :"+id);
	}

	public synchronized void setSettingMonitorningOff(String settingName) {
		open();
		try {
			ContentValues values = new ContentValues();
			values.put(
					MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate,
					0);
			LogWrite.d(tag, "settingName: " + settingName);
			long id = db
					.update(MySQLiteOpenHelper.Data_SettingsToMonitring_TableName,
							values,
							MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName
									+ " =? and "
									+ MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate
									+ " =?", new String[] { settingName, "1" });

			LogWrite.d(tag, "NNum Row Affected: " + id);
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO..." + e);
		}
		close();
	}

	// public void printTable() {
	// String tag = "printTable";
	// Cursor cursor = db.query(
	// MySQLiteOpenHelper.Data_SettingsToMonitring_TableName, null,
	// null, null, null, null, null);
	// int cursorSize = cursor.getCount();
	// LogWrite.d(tag, "CursorSize: " + cursorSize);
	//
	// if (cursor.getCount() > 0) {
	// if (cursor.moveToFirst()) {
	// do {
	// int indexSettingName = cursor
	// .getColumnIndex(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName);
	// int onTime = cursor
	// .getColumnIndex(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnoOnTime);
	// int offTime = cursor
	// .getColumnIndex(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnOffTime);
	// int isToUpdate = cursor
	// .getColumnIndex(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate);
	//
	// LogWrite.d(tag, cursor.getString(indexSettingName));
	// LogWrite.d(tag, "onTime :" + cursor.getLong(onTime));
	// LogWrite.d(tag, "offTime :" + cursor.getLong(offTime));
	// LogWrite.d(tag, "IsToMonitor :" + cursor.getInt(isToUpdate));
	// } while (cursor.moveToNext());
	// }
	// }
	// }

	public synchronized long getSettingOnTime(String settingName) {
		open();
		long startTime = 0;
		String tag = "getSettingOnTime";
		Cursor cursor = db
				.query(MySQLiteOpenHelper.Data_SettingsToMonitring_TableName,
						new String[] { MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnoOnTime },
						MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate
								+ " =? and "
								+ MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName
								+ " =?", new String[] { "1", settingName },
						null, null, null);
		if (cursor.getCount() > 0) {
			if (cursor.moveToFirst()) {
				startTime = cursor.getLong(0);

				LogWrite.d(tag, "startTime: " + startTime);
			}
		}
		close();
		return startTime;
	}
}

// package com.kochartech.gizmodoctor.DataBase;
//
// import android.content.ContentValues;
// import android.content.Context;
// import android.database.sqlite.SQLiteDatabase;
// import android.util.Log;
//
// public class DBHelperDataSettingsToMonitor {
// private String tag = "DBHelperDataSettingsToMonitor";
// private Context context;
// private static DBHelperDataSettingsToMonitor classInstance = null;
// private MySQLiteOpenHelper mySQLiteOpenHelper;
// private SQLiteDatabase db;
//
// public static DBHelperDataSettingsToMonitor getInstance(Context context) {
// if (classInstance == null)
// classInstance = new DBHelperDataSettingsToMonitor(context);
// return classInstance;
// }
//
// private DBHelperDataSettingsToMonitor(Context context) {
// LogWrite.d(tag, "constructor");
// this.context = context;
// mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
// }
//
// public void open() {
// LogWrite.d(tag, "open");
// db = mySQLiteOpenHelper.getWritableDatabase();
// }
//
// public void close() {
// LogWrite.d(tag, "close");
// db.close();
// }
//
// public void insertEntry(String settingName) {
// ContentValues values = new ContentValues();
// values.put(
// MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName,
// settingName);
// values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnoOnTime,
// System.currentTimeMillis());
// values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnOffTime,
// System.currentTimeMillis());
// values.put(
// MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate, 1);
// long id = db.insertOrThrow(
// MySQLiteOpenHelper.Data_SettingsToMonitring_TableName, null,
// values);
//
// // db.q
// // db.updateWithOnConflict(table, values, whereClause, whereArgs,
// // conflictAlgorithm)
// LogWrite.d(tag, "id :" + id);
//
// }
//
// // public void insertEntry(String settingName)
// // {
// // ContentValues values = new ContentValues();
// // values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName,
// // settingName);
// // values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnoOnTime,
// // System.currentTimeMillis());
// // values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnOffTime, 0);
// //
// // long id =
// // db.insertOrThrow(MySQLiteOpenHelper.Data_SettingsToMonitring_TableName,
// // null, values);
// //
// // // db.q
// // // db.updateWithOnConflict(table, values, whereClause, whereArgs,
// // conflictAlgorithm)
// // LogWrite.d(tag,"id :"+id);
// //
// // }
//
// public void updateSettingEndTime(String settingName) {
// ContentValues values = new ContentValues();
//
// values.put(MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnOffTime,
// System.currentTimeMillis());
//
// long id = db
// .update(MySQLiteOpenHelper.Data_SettingsToMonitring_TableName,values,
// MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnSettingName
// + " =? and "
// + MySQLiteOpenHelper.Data_SettingsToMonitring_ColumnIsToUpdate
// + " =?", new String[] {settingName,"1"});
//
//
//
// // LogWrite.d(tag,"id :"+id);
// }
//
//
// }
