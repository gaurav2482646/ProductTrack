package com.kochartech.devicemax.Receivers;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.AsyncTask.DownloadAsyncTask;
import com.kochartech.devicemax.Utility.ServerResponse;
import com.kochartech.gizmodoctor.R;

public class ServiceReceiver extends BroadcastReceiver 
{
	String tag = "testreceiver";
	private Context context;
	private String SERVERURL;
	private String phoneNumberToSend;
	private static int signalStrength;
	private  static String latitude;
	private  static String longitude;
	@Override
	public void onReceive(Context context, Intent intent) 
	{
		LogWrite.d(tag, "On Receive method call upon");
		this.context = context;
		LoggingAsyncTask asyncTask = new LoggingAsyncTask();
		asyncTask.execute("");
	}
	PhoneStateListener phonestate = new PhoneStateListener() 
	{
		public void onSignalStrengthChanged(int asu) 
		{
			signalStrength = asu;
			int dbm = -113 + (2 * asu);
			dbm = dbm * (-1);
			if (dbm >= 60 && dbm < 70) {
				dbm = 95;
			} else if (dbm >= 70 && dbm < 87) {
				dbm = 85;
			} else if (dbm >= 87) {
				dbm = 60;
			}
			signalStrength = dbm;
		}
	};
	private class LoggingAsyncTask extends AsyncTask<String, String, String>
	{
		String data1 = "fail";
		@Override
		protected void onPreExecute() 
		{
			LogWrite.d(tag, "onPreExecute Method call upon");
			SERVERURL = context.getString(R.string.ServerUrl);
			phoneNumberToSend = getDeviceId(context); //"4444444444";
			LogWrite.d(tag, "SIM Number : " + phoneNumberToSend);
			((android.telephony.TelephonyManager) context.getSystemService(context.TELEPHONY_SERVICE)).listen(phonestate,
					PhoneStateListener.LISTEN_SIGNAL_STRENGTH);
			setLatitudeAndLongitude(context);
		}
		private String getDeviceId(Context context)
		{
			TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			return tm.getDeviceId();
		}
		@Override
		protected String doInBackground(String... params) 
		{
			try 
			{	
				LogWrite.d(tag, "Do in Background method call upon");
				TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
				LogWrite.d(tag,"Start =");
				if(telephonyManager.getDataState() == TelephonyManager.DATA_CONNECTED)
				{
					LogWrite.d(tag, "Start");
					URL url;
					url = new URL(SERVERURL);
					LogWrite.d(tag, "SERVERURL  " + SERVERURL);
					URLConnection conn = url.openConnection();
					HttpURLConnection httpConn = (HttpURLConnection) conn;
				
					httpConn.setConnectTimeout(9*1000);
					httpConn.setReadTimeout(9*1000);
					httpConn.setRequestMethod("POST");
					
					httpConn.setDoInput(true);
					httpConn.setDoOutput(true);
					httpConn.setRequestProperty("Content-Type", "text/plain");
					httpConn.setRequestMethod("POST");
					OutputStreamWriter os = new OutputStreamWriter(httpConn.getOutputStream());
					httpConn.connect();
					os.write("MessageID:" + getRandomNumber()
							+ "\nMessageClass:Event\nMessageType:HTTPToHSet\n"
							+ "Event:HandShaking\nMobile:"
							+ phoneNumberToSend + "\nContent-Length:0\n");
					os.close();
					BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					String data = "";
					while ((data = br.readLine()) != null) 
					{
						LogWrite.d(tag,"While Work");
						data1 += data;
					}
					LogWrite.d(tag,"Finish =");
					sendTextMessage(phoneNumberToSend, "Connecting Success!");
				}
				LogWrite.d(tag,"Start =");
			}
			catch (java.net.SocketException se) 
			{
				LogWrite.d(tag, "SocketException "+se);
			} 
			catch (Exception ex) 
			{
				LogWrite.d(tag, "ExceptionDTO "+ex.toString());
			}
			LogWrite.d(tag, "Finish");
			return "";
		}
//		@Override
//		protected void onProgressUpdate(String... values) 
//		{
//			LogWrite.d(tag, "onProgressUpdate Method call upon");
//			super.onProgressUpdate(values);
//		}
		@Override
		protected void onPostExecute(String result) 
		{
			LogWrite.d(tag, "onPostExecute Method call upon");
//			if (!data1.equalsIgnoreCase("fail")) 
//			{
//				LogWrite.d(tag, "Nothing from server");
//				sendTextMessage(phoneNumberToSend, "Connecting Success!");
//			}
//			super.onPostExecute(result);
		}	
	}
	/**
	 * Generates a Random Number.
	 * 
	 * @return String
	 */
	public String getRandomNumber() 
	{
		String finalRN = "";
		Random rd = new Random(10000);
		int randomNumber = rd.nextInt();
		String rn = Integer.toString(randomNumber);
		if (rn.startsWith("-")) 
		{
			int index = rn.indexOf("-");
			finalRN = rn.substring(index + 1, rn.length());
			LogWrite.d(tag, "getRandomNumber-> " + finalRN);
			return finalRN;
		}
		else 
		{
			return rn;
		}
		// return Integer.toString(randomNumber);
	}
	
	public void sendTextMessage(String address, String message)
	{
//		if(isToSleep)
//		{
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//		}
		String tag="sendtextmessage";
		try
		{
			LogWrite.d(tag,"Message ="+message);
			ServerResponse.set(message);
			
			String messageToAppend, messageToSend = "";
			HttpClient httpclient = new DefaultHttpClient();
			
			HttpPost httppost = new HttpPost(SERVERURL);
//			messageToAppend = "DM:1of1;UID:" + htDMCommand.get("UID") + ";DT:<";
//			messageToSend +=  message + ">;";
			LogWrite.d(tag, "sendresponse--"+"MessageID:"
					+ getRandomNumber()
					+ "MessageClass:EventMessageType:HSetToHTTPEvent:"
					+ "HandShaking"    //ChunkData:" + messageToSend
					+ "Mobile:" + phoneNumberToSend
					+ "Content-Length:0\n");
			httppost.setEntity(new StringEntity("MessageID:"
							+ getRandomNumber()
							+ "\nMessageClass:Event\nMessageType:HSetToHTTP\nEvent:"
							+ "HandShaking"						//\nChunkData:"  + messageToSend
							+ "\nMobile:" + phoneNumberToSend
							+ "\nContent-Length:0\n"));    
			HttpResponse resp = httpclient.execute(httppost);
			HttpEntity ent = resp.getEntity();
			
			LogWrite.d(tag,"StatusCode ="+resp.getStatusLine().getStatusCode());
			
            if(resp.getStatusLine().getStatusCode()==200)
            {
            	startSpeedTest();
            }
            else
            {
            	
            }
		}
		catch(Exception e)
		{
			LogWrite.d(tag, "ExceptionDTO ="+e);
		}
	}
	protected void startSpeedTest() 
	{
//		Intent startTestIntent = new Intent(context, StartTestReceiver.class);
////		Intent stopTestIntent = new Intent(context, StopTestReceiver.class);
//		AlarmManager alarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
//		PendingIntent pendingstartTestIntent = PendingIntent.getBroadcast(context, 232324, startTestIntent, 0);
////		PendingIntent pendingstopTestIntent = PendingIntent.getBroadcast(context, 232324, stopTestIntent, 0);
//
//		alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(), (5*60*1000),pendingstartTestIntent);
		new DownloadAsyncTask(context, phoneNumberToSend, signalStrength, latitude, longitude);
	}
	public void setLatitudeAndLongitude(Context context)
	{			
		LocationManager locationManager = (LocationManager) context.getSystemService(context.LOCATION_SERVICE);
		try
		{
			locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1000, new LocationListener() 
			{
				public void onStatusChanged(String provider, int status, Bundle extras) 
				{
				}
				public void onProviderEnabled(String provider) 
				{
				}
				public void onProviderDisabled(String provider) 
				{
				}
				public void onLocationChanged(Location location) 
				{
					latitude = ""+location.getLatitude();
					longitude = ""+location.getLongitude();
				}
			});	
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,"ExceptionDTO =setLatitudeAndLongitude = "+e);
		}
		LogWrite.d(tag,"2");
		LogWrite.d(tag,"outside of function...");
	}
}
