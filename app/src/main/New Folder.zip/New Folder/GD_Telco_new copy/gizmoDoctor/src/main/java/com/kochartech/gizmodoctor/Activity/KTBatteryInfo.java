//package com.kochartech.gizmodoctor.Activity;
//
//public class KTBatteryInfo 
//{
//	
//}
