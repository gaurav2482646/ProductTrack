package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.os.Bundle;

public class BringApplicationToForeground extends Activity{


	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	
		finish();
	}
}
