package com.kochartech.HttpConn;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import com.kochartech.devicemax.Activities.LogWrite;

// JsonFormat: "application/json"

public class HttpPostConnection {
	private String tag = "HttpPostConnection";
	private HttpURLConnection httpConn = null;
	
	public boolean connect(String serverUrl, String formatOfPostData) {
		try {

			URL logServiceURL = new URL(serverUrl);

			URLConnection conn = logServiceURL.openConnection();
			httpConn = (HttpURLConnection) conn;
			httpConn.setRequestMethod("POST");
			httpConn.setDoInput(true);
			httpConn.setDoOutput(true);
			
			if(formatOfPostData != null)
			httpConn.setRequestProperty("Content-Type", formatOfPostData);
			
			httpConn.connect();
			LogWrite.d(tag, "connection establish sucessfully");
			
			return true;
		} catch (Exception e) {
			LogWrite.d(tag, "connect() ExceptionDTO: " + e);
			return false;
		}
	}	


	public boolean writeToServer(String data) {
		OutputStreamWriter outStreamWriter = null;
		try {

			outStreamWriter = new OutputStreamWriter(httpConn.getOutputStream());
			outStreamWriter.write(data);
			outStreamWriter.flush();
			outStreamWriter.close();

			String responseMessage = httpConn.getResponseMessage();

			LogWrite.d(tag, "ResponseDTO Message: " + responseMessage);
		
			return true;
		} catch (Exception e) {
			LogWrite.d(tag, "writeToServer() ExceptionDTO: " + e);
			return false;
		}
	}

	public String readFromServer() {
		InputStreamReader inStreamReader = null;
		BufferedReader bufferReader = null;
		String line = null;
		StringBuilder responseMsg = new StringBuilder();
		try {
			InputStream ins = httpConn.getInputStream();
			inStreamReader = new InputStreamReader(ins);
			bufferReader = new BufferedReader(inStreamReader);

			while ((line = bufferReader.readLine()) != null) {
				responseMsg.append(line);
			}
			
			LogWrite.d(tag, "data: " + responseMsg.toString());
			return responseMsg.toString();
		} catch (Exception e) {
			LogWrite.d(tag, "readFromServer() ExceptionDTO: " + e);
			return null;
		}
		
		
	}

	public void close() {
		try {
			httpConn.disconnect();
		} catch (Exception e) {
			LogWrite.d(tag, "close() ExceptionDTO: " + e);
		}
	}
}
