//package com.kochartech.devicemax.Utility;
//
//import java.lang.reflect.Method;
//import java.util.Hashtable;
//
//import android.content.Context;
//import android.content.pm.PackageManager;
//import android.content.pm.PackageStats;
//import android.os.RemoteException;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//
//public class AppSizer 
//{
//	private static String tag="AppSizer";
//    static Hashtable<String, Long> appSizeHash = new Hashtable<String, Long>();
//	static public long getSize(final Context context,String packageName)
//	{
////		PackageManager packageManager = context.getPackageManager();
//		appSizeHash.put("appsize",new Long(0));
////		List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
//
//		// Semaphore to handle concurrency
////		final Semaphore codeSizeSemaphore = new Semaphore(1, true);
//
//		// Code size will be here
////		 long codeSize1 ;
////		SharedPreferences sharedPreferences = PreferenceManager
////				.getDefaultSharedPreferences(context);
////		Editor editor = sharedPreferences.edit();
////		editor.putLong("appsize", 0);
////		editor.commit();
////		for (ApplicationInfo appInfo : installedApplications)
////		{
////			 if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 1)
////		     {
////		            //System app
////				 continue;
////		     }
////			 else
////			 {
////			    try
////			    {
////			        codeSizeSemaphore.acquire();
////			    }
////			    catch (InterruptedException e)
////			    {
////			        e.printStackTrace(System.err);
////			    }
////			    
////			    // Collect some other statistics
////			    
////			    // Collect code size
//			    try 
//			    {
//			    	final PackageManager packageManager = context.getPackageManager();
//			        Method getPackageSizeInfo = 
//			            packageManager.getClass().getMethod("getPackageSizeInfo",String.class,IPackageStatsObserver.class);
//			        LogWrite.d(tag,"package Name ="+packageName);
//			        getPackageSizeInfo.invoke(packageManager, packageName,new IPackageStatsObserver.Stub()
//			        {
////			        	long codeSize=0;
//			            public void onGetStatsCompleted(PackageStats pStats, boolean succeedded) 
//			                throws    RemoteException
//			            {
//			            	long codeSize = (pStats.codeSize+pStats.dataSize);
//			                appSizeHash.put("appsize",new Long(codeSize));  
////			                long dataSize = pStats.dataSize;
////			                codeSizeSemaphore.release();
//			            	LogWrite.d(tag,"package Size1 ="+appSizeHash.get("appsize"));
////			                codeSizeSemaphore.release();
//			            }
//			            
//				       
//			        });
//			        
//			    }
//			    catch (ExceptionDTO e)
//			    {
//			    	LogWrite.d(tag,"ExceptionDTO ="+e);
//			    }
////			}
////		}
//			    try
//			    {
//					Thread.sleep(500);
//				}
//			    catch (InterruptedException e)
//			    {
//					// TODO Auto-generated catch block
////					e.printStackTrace();
//				}
////				editor.commit();
//			    LogWrite.d(tag,"package Size2 ="+appSizeHash.get("appsize"));
//				return appSizeHash.get("appsize");
//	}
//}
