package com.kochartech.devicemax.Utility;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Camera;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.StatFs;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.DualSimPackage.TelephonyInfo;
import com.kochartech.gizmodoctor.DataBase.DataSource_DischargeRate;
import com.kochartech.library.Battery.KTBatteryInfo;
import com.kochartech.library.CPU.KTUsageCPU;
import com.kochartech.library.Device.KTInformation;
import com.kochartech.library.Memory.KTUsageRAM;

import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Method;
import java.text.DecimalFormat;


public class GetHandsetInfoRemoteMax {
    public static String handsetno = "N/A";
    /*
     * CatLog tag
     */
    static private String tag = "GetHandsetInfo";
    public String TypeName = "N/A";
    public String Battery = "N/A";
    public String Brand = "N/A";
    public String Build = "N/A";
    public String isRooted = "N/A";
    public boolean Bluetooth = false;
    public String FreePrimary = "N/A";
    public String batteryTemp = "N/A";
    public String FreeSecondary = "N/A";
    public boolean Gps = false;
    public boolean HasUserDenied = false;
    public String Imei = "N/A";
    public int CpuUsage = 0;
    public int RamPercentage = 0;
    public int ScreenBrightness = 0;
    public double BatteryDischarge = 0;
    public boolean tethering = false;
    public boolean hotspot = false;
    public boolean FrontCamera = false;


    public boolean BackCamera = false;
    public float FrontCameraPixel = 0.0f;
    public float BackCameraPixel = 0.0f;
    public String Imsi = "N/A";
    public boolean isDualSim = false;
    public String Model = "N/A";
    public String OsVersion = "N/A";
    public String TotalPrimary = "N/A";
    public String TotalSecondary = "N/A";
    public boolean Wifi = false;
    public String width, height;
    public KTBatteryInfo mKTBatteryInfo;
    private String sd1path = "", sd0path = "";

    public GetHandsetInfoRemoteMax(String mobileNumber) {

        handsetno = mobileNumber;

    }

    public GetHandsetInfoRemoteMax() {

    }

    /**
     * this is used to get serial number of sim
     *
     * @param context
     * @return
     */
    public static String getSimSerialNumber(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return tm.getSimSerialNumber();
    }

    public JSONObject toJSONObject() {
        JSONObject jsonObject = new JSONObject();
        try {
            NetworkInfoDTORemoteMax networkInfoDto = new NetworkInfoDTORemoteMax();
            jsonObject.put("__type", "HandsetInfoReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
            jsonObject.put("BatteryStrength", String.valueOf(getBattery()));
            jsonObject.put("Brand", getBrand());
            jsonObject.put("BatteryTemp", String.valueOf(getBatteryTemperature()));
            jsonObject.put("Tethering", String.valueOf(gettethering()));
            jsonObject.put("Hotspot", getHotspot());

            jsonObject.put("CpuUsage", getCpuUsage());
            jsonObject.put("RamPercentage", getRamPercentage());
            jsonObject.put("ScreenBrightness", getScreenBrightness());
            jsonObject.put("BatteryDischarge", getBatteryDischarge());

            jsonObject.put("FrontCamera",isFrontCamera());
            jsonObject.put("BackCamera", isBackCamera());
            jsonObject.put("FrontCameraPixel", getFrontCameraPixel());
            jsonObject.put("BackCameraPixel", getBackCameraPixel());


            jsonObject.put("FreeMemory", String.valueOf(getFreePrimary()));
            jsonObject.put("Build", String.valueOf(getBuild()));
            jsonObject.put("DualSim", getDualsim());
            jsonObject.put("SDFree", String.valueOf(getFreeSecondary()));
            jsonObject.put("Gps", getGps());
            jsonObject.put("Imei", getImei());
            jsonObject.put("HandsetMobileNumber", handsetno);
            jsonObject.put("IMSI", getImsi());
            jsonObject.put("Model", getModel());
            jsonObject.put("OsVersion", getOsVersion());
            jsonObject.put("TotalMemory", String.valueOf(getTotalPrimary()));
            jsonObject.put("SDTotal", String.valueOf(getTotalSecondary()));
            jsonObject.put("Wifi", getWifi());
            jsonObject.put("Command", "HandsetInfo");
//            jsonObject.put("HasUserDenied", HasUserDenied);
//            jsonObject.put("Width", getWidth());
//            jsonObject.put("Height", getHeight());
            /**
             * Network Information
             *
             */
            jsonObject.put("BearerType", networkInfoDto.getBearerType());
            jsonObject.put("NetworkId", networkInfoDto.getNetworkId());
            jsonObject.put("NetworkName", networkInfoDto.getNetworkName());
            jsonObject.put("SignalStrength", String.valueOf(networkInfoDto.getSignalStrength()));
            jsonObject.put("RoamingStatus", networkInfoDto.getRoamingStatus());
            jsonObject.put("Rooted", executeShellCommand("su"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public boolean gettethering() {
        return tethering;
    }

    public void setTethering(boolean tethering) {
        this.tethering = tethering;
    }

    public boolean getHotspot() {
        return hotspot;
    }

    public void setHotspot(boolean hotspot) {
        this.hotspot = hotspot;
    }

    public String getTypeName() {
        return TypeName;
    }

    public void setTypeName(String typeName) {
        TypeName = typeName;
    }

    public String getBattery() {
        return Battery;
    }

    public void setBattery(String battery) {
        Battery = battery;
    }

    public String getBatteryTemperature() {
        return batteryTemp;
    }

    public void setBatteryTemp(String batteryTemp) {
        this.batteryTemp = batteryTemp;
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String brand) {
        Brand = brand;
    }

    public String getBuild() {
        return Build;
    }

    public void setBuild(String build) {
        Build = build;
    }

    public boolean isHasUserDenied() {
        return HasUserDenied;
    }

    public void setHasUserDenied(boolean hasUserDenied) {
        HasUserDenied = hasUserDenied;
    }

    public int getCpuUsage() {
        return CpuUsage;
    }

    public void setCpuUsage(int cpuUsage) {
        CpuUsage = cpuUsage;
    }

    public int getRamPercentage() {
        return RamPercentage;
    }

    public void setRamPercentage(int ramPercentage) {
        RamPercentage = ramPercentage;
    }

    public int getScreenBrightness() {
        return ScreenBrightness;
    }

    public void setScreenBrightness(int screenBrightness) {
        ScreenBrightness = screenBrightness;
    }

    public double getBatteryDischarge() {
        return BatteryDischarge;
    }

    public void setBatteryDischarge(double batteryDischarge) {
        BatteryDischarge = batteryDischarge;
    }

    public boolean getBluetooth() {
        return Bluetooth;
    }

    public void setBluetooth(boolean bluetooth) {
        Bluetooth = bluetooth;
    }

    public String getFreePrimary() {
        return FreePrimary;
    }

    public void setFreePrimary(String freePrimary) {
        FreePrimary = freePrimary;
    }

    public String getFreeSecondary() {
        return FreeSecondary;
    }

    public void setFreeSecondary(String freeSecondary) {
        FreeSecondary = freeSecondary;
    }

    public boolean getGps() {
        return Gps;
    }

    public void setGps(boolean gps) {
        Gps = gps;
    }

    public String getImei() {
        return Imei;
    }

    public void setImei(String imei) {
        Imei = imei;
    }

    public String getImsi() {
        return Imsi;
    }

    public void setImsi(String imsi) {
        Imsi = imsi;
    }

    public boolean getDualsim() {
        return isDualSim;
    }

    public void setDualSim(boolean isDualSim) {
        this.isDualSim = isDualSim;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }

    public String getOsVersion() {
        return OsVersion;
    }

    public void setOsVersion(String osVersion) {
        OsVersion = osVersion;
    }

    public String getTotalPrimary() {
        return TotalPrimary;
    }

    public void setTotalPrimary(String totalPrimary) {
        TotalPrimary = totalPrimary;
    }

    public String getTotalSecondary() {
        return TotalSecondary;
    }

    public void setTotalSecondary(String totalSecondary) {
        TotalSecondary = totalSecondary;
    }

    public boolean getWifi() {
        return Wifi;
    }

    public void setWifi(boolean wifi) {
        Wifi = wifi;
    }

    public String getWidth() {
        return width;
    }

    private void setWidth(String width) {
        this.width = width;

    }

    public String getHeight() {
        return height;
    }

    private void setHeight(String height) {

        this.height = height;
    }

    public boolean isFrontCamera() {
        return FrontCamera;
    }

    public void setFrontCamera(boolean frontCamera) {
        FrontCamera = frontCamera;
    }

    public boolean isBackCamera() {
        return BackCamera;
    }

    public void setBackCamera(boolean backCamera) {
        BackCamera = backCamera;
    }

    public float getFrontCameraPixel() {
        return FrontCameraPixel;
    }

    public void setFrontCameraPixel(float frontCameraPixel) {
        FrontCameraPixel = frontCameraPixel;
    }

    public float getBackCameraPixel() {
        return BackCameraPixel;
    }

    public void setBackCameraPixel(float backCameraPixel) {
        BackCameraPixel = backCameraPixel;
    }

    /**
     * this method is used to fill all handset information required for
     * startsession command...
     *
     * @param
     */
    public GetHandsetInfoRemoteMax getHandsetInfoDTO(Context context) {

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
//        String displayInfo = preferences.getString(DeviceMaxConstants.WIDTH_HEIGHT.toString(), "0");
//        String widthHeight[] = displayInfo.split("~");
        GetHandsetInfoRemoteMax handsetInfoDTO = new GetHandsetInfoRemoteMax();
        try {
            TelephonyInfo telephonyInfo = TelephonyInfo.getInstance(context);
            KTInformation ktInfo = new KTInformation(context);
            mKTBatteryInfo = KTBatteryInfo.getInstance();
            mKTBatteryInfo.calculate(context);
            handsetInfoDTO.setTotalSecondary(String.valueOf(getExternalStorage(context)[1]));
            handsetInfoDTO.setFreeSecondary(String.valueOf(getExternalStorage(context)[0]));
            handsetInfoDTO.setBattery(String.valueOf(ktInfo.getBatteryLevel()));
            handsetInfoDTO.setBatteryTemp(String.valueOf(mKTBatteryInfo.getTemperature()));
            handsetInfoDTO.setScreenBrightness(getScreenBrightness(context));
            handsetInfoDTO.setRamPercentage(getRamPercentage(context));
            handsetInfoDTO.setBatteryDischarge(getBatteryDischargeRate(context));
            handsetInfoDTO.setCpuUsage(getCpuUsage(context));
            handsetInfoDTO.setTethering(checkUSBTethering(context));
            handsetInfoDTO.setHotspot(checkHotspot(context));
            handsetInfoDTO.setBluetooth(ktInfo.isBluetoothEnabled());
            handsetInfoDTO.setBrand(ktInfo.getDeviceBrand());
            handsetInfoDTO.setBuild(String.valueOf(android.os.Build.VERSION.SDK_INT));
            handsetInfoDTO.setGps(ktInfo.isGPSEnabled());
            handsetInfoDTO.setDualSim(telephonyInfo.isDualSIM() == 1);
            handsetInfoDTO.setImei(ktInfo.getDeviceId());
            handsetInfoDTO.setImsi(getSimSerialNumber(context));
            handsetInfoDTO.setFrontCamera(isFrontCameraAvailable(context));
            handsetInfoDTO.setBackCamera(isRearCameraAvailable(context));
            handsetInfoDTO.setFrontCameraPixel(getFrontCameraResolutionInMp(context));
            handsetInfoDTO.setBackCameraPixel(getBackCameraResolutionInMp(context));
            handsetInfoDTO.setModel(ktInfo.getDeviceModel());
            handsetInfoDTO.setOsVersion(ktInfo.getDeviceOSVersion());
            handsetInfoDTO.setTotalPrimary(String.valueOf(getInternalStorage(context)[1]));
            handsetInfoDTO.setFreePrimary(String.valueOf(getInternalStorage(context)[0]));
            handsetInfoDTO.setWifi(ktInfo.isWifiEnabled());
//            handsetInfoDTO.setWidth(widthHeight[0]);
//            handsetInfoDTO.setHeight(widthHeight[1]);
        } catch (Exception e) {
            Log.e(tag, "exception: " + e.toString());
        }
        return handsetInfoDTO;
    }

    int getCpuUsage(Context context) {
        int cpuUsage = 0;
        try {

            KTUsageCPU ktCPUUsage = new KTUsageCPU(context);
            ktCPUUsage.refresh(5);
            cpuUsage = ktCPUUsage.getTotalCPUUsage();
            return cpuUsage;
        } catch (Exception e1) {
            LogWrite.e(tag,
                    "CPU initializing exception : " + e1.toString());
        }
        return cpuUsage;
    }

    int getRamPercentage(Context context) {
        int ramPercentage = 0;
        try {
            KTUsageRAM ktUsageRAM = new KTUsageRAM(context);
            float usedRamUsage = ktUsageRAM.getMeoryInfo().getUsed();
            int totalRamUsage = (int) ktUsageRAM.getMeoryInfo()
                    .getTotal();
            ramPercentage = (int) ((usedRamUsage * 100) / totalRamUsage);
            return ramPercentage;
        } catch (Exception e1) {
            LogWrite.e(tag,
                    "RAM initializing exception : " + e1.toString());
        }
        return ramPercentage;
    }

    int getScreenBrightness(Context context) {
        int brightness = 0;
        // Calculate the brightness percentage
        try {
            brightness = android.provider.Settings.System.getInt(
                    context.getContentResolver(),
                    android.provider.Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException e) {
            brightness = 0;
        }
        LogWrite.e("Aman", "Brightness : " + brightness);
        int perc = (brightness * 100 / 255);
        return perc;
    }

    double getBatteryDischargeRate(Context context) {
        double dischargeFormatDouble = 0;
        try {
            DataSource_DischargeRate dischargeRate = DataSource_DischargeRate
                    .getInstance(context);
            float discharge = dischargeRate.getDischargeRate();
            DecimalFormat twoDForm = new DecimalFormat("#.##");
            dischargeFormatDouble = Double.valueOf(twoDForm
                    .format(discharge));
            return dischargeFormatDouble;
            // dischargeFormat = "" + dischargeFormatDouble;

            // DecimalFormat df = new DecimalFormat();
            // df.setMinimumFractionDigits(2);
            // dischargeFormat = df.format(discharge);
        } catch (Exception e1) {
            // dischargeFormat = "0.00";
            dischargeFormatDouble = 0;
            e1.printStackTrace();
        }
        return dischargeFormatDouble;
    }

    public boolean isRearCameraAvailable(Context context) {
        int backCameraId = -1;
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                backCameraId = 1;
                break;
            }
        }
        return backCameraId == 1;
    }

    public boolean isFrontCameraAvailable(Context context) {
        int frontCameraId = -1;
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                frontCameraId = 1;
                break;
            }
        }
        return frontCameraId == 1;
    }

    public float getBackCameraResolutionInMp(Context context) {
        int noOfCameras = Camera.getNumberOfCameras();
        float maxResolution = -1;
        long pixelCount = -1;
        for (int i = 0; i < noOfCameras; i++) {
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            Camera.getCameraInfo(i, cameraInfo);

            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                Camera camera = Camera.open(i);
                ;
                Camera.Parameters cameraParams = camera.getParameters();
                for (int j = 0; j < cameraParams.getSupportedPictureSizes().size(); j++) {
                    long pixelCountTemp = cameraParams.getSupportedPictureSizes().get(j).width * cameraParams.getSupportedPictureSizes().get(j).height; // Just changed i to j in this loop
                    if (pixelCountTemp > pixelCount) {
                        pixelCount = pixelCountTemp;
                        maxResolution = ((float) pixelCountTemp) / (1024000.0f);
                    }
                }
                camera.release();
            }
        }
        return maxResolution;
    }

    public float getFrontCameraResolutionInMp(Context context) {
        int noOfCameras = Camera.getNumberOfCameras();
        float maxResolution = -1;
        long pixelCount = -1;
        for (int i = 0; i < noOfCameras; i++) {
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            Camera.getCameraInfo(i, cameraInfo);

            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                Camera camera = Camera.open(i);
                ;
                Camera.Parameters cameraParams = camera.getParameters();
                for (int j = 0; j < cameraParams.getSupportedPictureSizes().size(); j++) {
                    long pixelCountTemp = cameraParams.getSupportedPictureSizes().get(j).width * cameraParams.getSupportedPictureSizes().get(j).height; // Just changed i to j in this loop
                    if (pixelCountTemp > pixelCount) {
                        pixelCount = pixelCountTemp;
                        maxResolution = ((float) pixelCountTemp) / (1024000.0f);
                    }
                }
                camera.release();
            }
        }
        return maxResolution;
    }

    private boolean executeShellCommand(String command) {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(command);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            if (process != null) {
                try {
                    process.destroy();

                } catch (Exception e) {
                    Log.e(tag, "executableShellCommand exception: " + e.toString());
                }
            }
        }
    }

    public boolean checkUSBTethering(Context context) {
        String tag = "usbTethering";
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            String[] available = null;
            Method[] wmMethods = cm.getClass().getDeclaredMethods();
            for (Method method : wmMethods) {
                Log.d(tag, method.getName());
                if (method.getName().equals("getTetheredIfaces")) {
                    try {
                        available = (String[]) method.invoke(cm);
                        String kk = "";
                        for (int i = 0; i < available.length; i++) {
                            kk = kk + " " + available[i] + " ";
                        }
                        Log.d(tag, "kk--" + kk);
                        if (available.length > 0) {
                            if (kk.contains("usb"))
                                return true;
                            else
                                return false;
                        } else {
                            return false;
                        }
                    } catch (Exception e) {
                        Log.e(tag, "checkUSBTethering exception: " + e.toString());

                    }
                }
            }
        } catch (Exception e) {
            Log.d(tag, "Exception:>>> " + e.toString());
            e.printStackTrace();
        }
        return false;
    }

    private boolean checkHotspot(Context context) {
        boolean state = false;
        WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        Method[] wmMethods = wifi.getClass().getDeclaredMethods();
        for (Method method : wmMethods) {
            if (method.getName().equals("isWifiApEnabled")) {
                try {
                    state = (Boolean) method.invoke(wifi);
                    if (state == true) {
                        return true;
                    } else {
                        return false;
                    }

                } catch (Exception e) {
                    Log.e(tag, "checkHotspot exception: " + e.toString());
                }
            }
        }
        return false;
    }

    public double[] getExternalStorage(Context context) {
        double[] externalMemories = new double[2];
        String sdCard1 = externalSDCard1();

        Log.d(tag, "SDCard 1 : " + sdCard1);

        if (!sdCard1.equals("")) {
            StatFs externalStorage = new StatFs(sdCard1);

            long bytesAvailable = (long) externalStorage.getFreeBlocks()
                    * (long) externalStorage.getBlockSize();
            long totalBytes = (long) externalStorage.getBlockCount()
                    * (long) externalStorage.getBlockSize();

            externalMemories[0] = bytesAvailable / (1024 * 1024);
//                    unitConversion(bytesAvailable);
            externalMemories[1] = totalBytes / (1024 * 1024);
            //unitConversion(totalBytes);

            Log.d(tag, "External Memory : " + externalMemories[0] + " / " + externalMemories[1]);
        }
        return externalMemories;

    }

    public double[] getInternalStorage(Context context) {
        double[] internalMemories = new double[2];
        String sdCard0 = externalSDCard0();
        Log.d(tag, "SDCard 0 : " + sdCard0);
        if (!sdCard0.equals("")) {
            StatFs internalStorage = new StatFs(sdCard0);
            long bytesAvailable = (long) internalStorage.getFreeBlocks()
                    * (long) internalStorage.getBlockSize();
            long totalBytes = (long) internalStorage.getBlockCount()
                    * (long) internalStorage.getBlockSize();

            internalMemories[0] = bytesAvailable / (1024 * 1024);
            internalMemories[1] = totalBytes / (1024 * 1024);
            Log.d(tag, "Internal Memory : " + internalMemories[0] + " / " + internalMemories[1]);


        }
        return internalMemories;
    }

    public String externalSDCard1() {
        if (new File("/storage/sdcard1/").exists()) {
            sd1path = "/storage/sdcard1/";
            Log.i("Sd Card1 Path", sd1path);
        }
        return sd1path;
    }

    public String externalSDCard0() {
        if (new File("/storage/sdcard0/").exists()) {
            sd0path = "/storage/sdcard0/";
            Log.i("Sd Card0 Path", sd0path);
        }
        return sd0path;
    }
}