package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.kochar.MDM.Command.Manager.MDM_CommandHandler;
import com.kochartech.gizmodoctor.R;
//import com.kochar.AsyncTask.ApplicationUpdatehandler;

public class ApplicationUpdate extends Activity
{
	String tag = "ApplicationUpdate";
	Button yes,no;
	Context context;
	String url="";
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
	    LogWrite.d(tag,"ApplicationUpdate onCreate Work");
		context = this;
		url= getIntent().getExtras().getString("url");
		setContentView(R.layout.activity_applicationupdate);
	    
		((Button) findViewById(R.id.updateno)).setOnClickListener(new OnClickListener()
		{
			  
			public void onClick(View v)
			{
				LogWrite.d(tag,"AppUpdate =No");
				finish();
			}
		});
		
		((Button) findViewById(R.id.updateyes)).setOnClickListener(new OnClickListener()
		{			  
			public void onClick(View v)
			{	
//				ApplicationUpdatehandler.stopAlarm(context);
				new InnerAsync().execute("");
				finish();
			}
		});
	}
	class InnerAsync extends AsyncTask<String,String,String>
    {
    	MDM_CommandHandler handler;
    	int count=0;
    	boolean result = false;
    	InnerAsync()
    	{
    		handler = new MDM_CommandHandler(context,true);	
    	}    	
		protected String doInBackground(String... params) 
		{
			LogWrite.d(tag,"Asyn Start");
			LogWrite.d(tag,"url = "+url);
			try
			{				
				do
				{
					LogWrite.d(tag,"While = "+count);
					count++; 
					result = handler.getAppUpdates(url);
					LogWrite.d(tag,"result = "+result);
				}
				while(result==false && count<3);
				LogWrite.d(tag,"Finish");				
			}
			catch (Exception e) 
			{
				LogWrite.d(tag,"ExceptionDTO...."+e);
			}
			return null;
		}    	
    }
}
