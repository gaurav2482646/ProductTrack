//package com.kochartech.gizmodoctor.Activity;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.util.Log;
//
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.Fragment.GUIPowerSavingProfile;
//import com.kochartech.gizmodoctor.Fragment.GUIPowerSavingSetting;
//
//public class TestActivity extends Activity{
//
//	private String TAG = TestActivity.class.getSimpleName();
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//		 setContentView(R.layout.test_fragment_activity);
//		
//		try {
//			android.app.FragmentManager fm = getFragmentManager();
//			GUIPowerSavingSetting  obj = new GUIPowerSavingSetting();
//			Bundle bundle = new Bundle();
//			bundle.putBoolean("isViewDisable", true);
//			obj.setArguments(bundle);
//			fm.beginTransaction().add(R.id.fragment_container11, obj).commit();
//		} catch (ExceptionDTO e) {
//		Log.d(TAG,"TestActivity: "+e);
//		}
//		
//	}
//}
