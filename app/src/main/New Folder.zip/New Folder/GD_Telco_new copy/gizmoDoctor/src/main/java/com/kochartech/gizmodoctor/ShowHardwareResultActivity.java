package com.kochartech.gizmodoctor;

import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

import com.kochartech.gizmodoctor.CustomView.HardwareResultCustomGridAdapter;
import com.kochartech.gizmodoctor.POJO.SoftKey;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.WindowManager.LayoutParams;
import android.widget.GridView;
import android.widget.TextView;

public class ShowHardwareResultActivity extends ActionBarActivity {
	// private static final String TAG = ShowHardwareResultActivity.class
	// .getSimpleName();
	private Context context;
	private GridView gridView;

	private ArrayList<SoftKey> arrayList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.getWindow()
				.setFlags(
						0xFFFFFFFF,
						LayoutParams.FLAG_FULLSCREEN
								| LayoutParams.FLAG_KEEP_SCREEN_ON);

		context = this;
		setContentView(R.layout.activity_show_hardware_result);
		getSupportActionBar().setTitle("Hardware Results");
		arrayList = new ArrayList<SoftKey>();
		TextView textView = (TextView) findViewById(R.id.textHardwareResult);
		String result = getIntent().getStringExtra("result_array");
		try {
			JSONObject jsonObject = new JSONObject(result);
			Iterator<String> iteratorKeys = jsonObject.keys();
			while (iteratorKeys.hasNext()) {
				String key = iteratorKeys.next();
				boolean value = jsonObject.getBoolean(key);
				textView.append(key + "\t\t : \t\t" + value + "\n\n ");
				SoftKey softKey = new SoftKey();
				softKey.setName(key);
				softKey.setDescription(value ? "Working" : "Not Working");
				arrayList.add(softKey);
				// setLeftRightText(textView, key, value + "");
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		gridView = (GridView) findViewById(R.id.gridview);
		gridView.setAdapter(new HardwareResultCustomGridAdapter(context,
				arrayList));

	}

	// @Override
	// public boolean onCreateOptionsMenu(Menu menu) {
	// // Inflate the menu; this adds items to the action bar if it is present.
	// getMenuInflater().inflate(R.menu.show_hardware_result, menu);
	// return true;
	// }
	//
	// @Override
	// public boolean onOptionsItemSelected(MenuItem item) {
	// // Handle action bar item clicks here. The action bar will
	// // automatically handle clicks on the Home/Up button, so long
	// // as you specify a parent activity in AndroidManifest.xml.
	// int id = item.getItemId();
	// if (id == R.id.action_settings) {
	// return true;
	// }
	// return super.onOptionsItemSelected(item);
	// }
}
