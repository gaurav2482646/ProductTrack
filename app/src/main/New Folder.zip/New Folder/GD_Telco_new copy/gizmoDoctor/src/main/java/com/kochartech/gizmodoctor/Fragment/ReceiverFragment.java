package com.kochartech.gizmodoctor.Fragment;

import android.support.v4.app.Fragment;

public class ReceiverFragment extends Fragment{

	
}
