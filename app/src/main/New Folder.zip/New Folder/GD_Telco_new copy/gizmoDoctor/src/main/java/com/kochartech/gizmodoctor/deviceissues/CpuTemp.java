package com.kochartech.gizmodoctor.deviceissues;

import java.io.File;
import java.io.FileInputStream;

import android.content.Context;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;

public class CpuTemp {
	private String TAG = CpuTemp.class.getSimpleName();
	private File tempFile;

	public CpuTemp(Context context) {
		tempFile = getTempFile(context, "AUTO");
	}

	public float getCpuTemp() {
		try {
			LogWrite.i(TAG, "------------------------1");
			FileInputStream fis = new FileInputStream(tempFile);
			LogWrite.i(TAG, "------------------------2");
			StringBuffer sbTemp = new StringBuffer("");
			LogWrite.i(TAG, "------------------------3");
			// read temperature
			byte[] buffer = new byte[1024];
			LogWrite.i(TAG, "------------------------A");
			while (fis.read(buffer) != -1) {
				LogWrite.i(TAG, "------------------------4");
				sbTemp.append(new String(buffer));
			}
			fis.close();
			LogWrite.i(TAG, "------------------------5");
			// parse temp
			String sTemp = sbTemp.toString().replaceAll("[^0-9.]+", "");
			LogWrite.i(TAG, "------------------------6");
			float temp = Float.valueOf(sTemp);
			LogWrite.i(TAG, "------------------------7");
			Log.e(TAG, "TEMP :::::::::::::::: " + temp);
			return temp;
		} catch (Exception e) {
			Log.e(TAG, "ExceptionDTO : " + e.toString());
		}
		return 0;
	}

	static String[] cputemp_urls = {
			"/sys/devices/system/cpu/cpu0/cpufreq/cpu_temp",
			"/sys/devices/system/cpu/cpu0/cpufreq/FakeShmoo_cpu_temp",
			"/sys/class/thermal/thermal_zone0/temp",
			"/sys/class/i2c-adapter/i2c-4/4-004c/temperature",
			"/sys/devices/platform/tegra-i2c.3/i2c-4/4-004c/temperature",
			"/sys/devices/platform/omap/omap_temp_sensor.0/temperature",
			"/sys/devices/platform/tegra_tmon/temp1_input",
			"/sys/kernel/debug/tegra_thermal/temp_tj",
			"/sys/devices/platform/s5p-tmu/temperature",
			"/sys/class/thermal/thermal_zone1/temp",
			"/sys/class/hwmon/hwmon0/device/temp1_input",
			"/sys/devices/virtual/thermal/thermal_zone1/temp",
			"/sys/devices/platform/s5p-tmu/curr_temp",
			"/sys/devices/virtual/thermal/thermal_zone0/temp",
			"/sys/class/thermal/thermal_zone3/temp",
			"/sys/class/thermal/thermal_zone4/temp" };

	// private static String[] tempFiles = {
	// "/sys/devices/platform/omap/omap_temp_sensor.0/temperature",
	// "/sys/kernel/debug/tegra_thermal/temp_tj",
	// "/sys/devices/system/cpu/cpu0/cpufreq/cpu_temp",
	// "/sys/class/thermal/thermal_zone0/temp",
	// "/sys/class/thermal/thermal_zone1/temp",
	// "/sys/devices/platform/s5p-tmu/curr_temp",
	// "/sys/devices/virtual/thermal/thermal_zone0/temp",
	// "/sys/devices/virtual/thermal/thermal_zone1/temp",
	// "/sys/devices/system/cpu/cpufreq/cput_attributes/cur_temp",
	// "/sys/devices/platform/s5p-tmu/temperature", };

	public File getTempFile(Context context, String fileName) {
		File ret = null;
		if (fileName != null) {
			ret = new File(fileName);
			if (!ret.exists() || !ret.canRead())
				ret = null;
		}
		if (ret == null || fileName.equals("AUTO")) {
			for (String tempFileName : cputemp_urls) {
				ret = new File(tempFileName);
				if (!ret.exists() || !ret.canRead()) {
					ret = null;
					continue;
				} else
					LogWrite.e(TAG, "FileName : " + tempFileName);
				break;
			}
		}

		if (ret == null) {
			Log.e(TAG, "Couldn't find any temp files!");
		}
		return ret;
	}

}
