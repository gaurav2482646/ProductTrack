package com.kochartech.MyLibs;

import java.util.HashSet;
import java.util.Set;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

public class MyBluetoothManager {

//	private Context context;
	public MyBluetoothManager() {
//		this.context = context;	
	}
	
	public boolean isBluetoothEnable() {
		BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
			return (bluetoothAdapter != null) ? bluetoothAdapter.isEnabled() : false;
	}
	
	public boolean  hasPairedDevices() {
		Set<BluetoothDevice>  pairedBluetoothDevicesSet = getPairedDevice();
		return pairedBluetoothDevicesSet.size()>0 ? true : false;
	}
	
	public Set<BluetoothDevice> getPairedDevice() {
		Set<BluetoothDevice>  pairedBluetoothDevicesSet = new HashSet<BluetoothDevice>();
		if(isBluetoothEnable()) {
			BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
			pairedBluetoothDevicesSet =  bluetoothAdapter.getBondedDevices();
		}
		return pairedBluetoothDevicesSet;
		
		
	}
	
	public void setBluetoothState(boolean state) {
		BluetoothAdapter mBluetoothAdapter = BluetoothAdapter
				.getDefaultAdapter();
		if (state)
			mBluetoothAdapter.enable();
		else
			mBluetoothAdapter.disable();	
	}
}
