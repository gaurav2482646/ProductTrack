package com.kochartech.gizmodoctor.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.Vibrator;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
import com.kochartech.gizmodoctor.HardwareModel.SoundMeter;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;

public class MicTestActivity extends ActionBarActivity implements OnClickListener {
	private String TAG = MicTestActivity.class.getSimpleName();

	private boolean isFromCommand = false;

	private Context context;

	private TextView messageTextView;

	private Button okButton;

	private ImageView fanImageView;

	private CircularProgressBar timerProgress;

	private boolean success = false;
	private String FAILURE_MESSAGE = "Press OK if Mic test not working";

	private WakeLock mWakeLock;

	private SoundMeter mSensor;

	private static OnCommandListener onCommandListener;
	private static OnAutoHardwareTestListener onAutoHardwareTestListener;

	private boolean soundCheck = false;

	private CheckMicAsync async;

	private static boolean isInstance = false;

	public static void startActivity(Context context, String keyToCheck,
			boolean isFromCommand, OnCommandListener onCommandListener,
			OnAutoHardwareTestListener onAutoHardwareTestListener) {
		if (!isInstance) {
			// Build extras with passed in parameters
			Bundle extras = new Bundle();
			extras.putString("HardwareTest", keyToCheck);
			extras.putBoolean("IsFromCommand", isFromCommand);
			MicTestActivity.onCommandListener = onCommandListener;
			MicTestActivity.onAutoHardwareTestListener = onAutoHardwareTestListener;
			// Create and start intent for this activity
			Intent intent = new Intent(context, MicTestActivity.class);
			intent.putExtras(extras);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.getWindow()
				.setFlags(
						0xFFFFFFFF,
						LayoutParams.FLAG_FULLSCREEN
								| LayoutParams.FLAG_KEEP_SCREEN_ON);
		this.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		setContentView(R.layout.fragment_mic);
		LogWrite.d(TAG, "OnCreate Method Enters..");
		try {
			this.getSupportActionBar().setTitle( "Microphone");
		}catch (Exception e) {
			Log.e(TAG, "ActionBarOnCreate: ExceptionDTO " + e.toString() );
		}
		isFromCommand = getIntent().getExtras().getBoolean("IsFromCommand");
		context = MicTestActivity.this;
		messageTextView = (TextView) findViewById(R.id.textView);
		messageTextView.setText(R.string.micro_phone_screen);
		fanImageView = (ImageView) findViewById(R.id.fan_image);
		fanImageView.setVisibility(View.VISIBLE);
		okButton = (Button) findViewById(R.id.ok_button);
		okButton.setOnClickListener(this);
		timerProgress = (CircularProgressBar) findViewById(R.id.circularprogressbar2);
		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {

			@Override
			public void onAnimationStart() {
			}

			@Override
			public void onAnimationProgress(int progress) {
				timerProgress.setTitle(progress + "");
				timerProgress.setSubTitle("");
			}

			@Override
			public void onAnimationFinish() {
				if (!success) {
					messageTextView.setText(FAILURE_MESSAGE);
					messageTextView.setTextAppearance(context,
							R.style.textStyleRed);
					okButton.setVisibility(View.VISIBLE);
					timerProgress.setSubTitle("");
					timerProgress.setVisibility(View.GONE);
					try {
						soundCheck = false;
						mSensor.stop();
					} catch (Exception e) {
						e.printStackTrace();
					}
					if (HardwareTestFragment.isAutoStartClicked) {
						if (!soundCheck) {
							// if (success) {
							onAutoHardwareTestListener.onHardwareTestFinish(7,
									"Microphone", false);
							MicTestActivity.this.finish();
							// }
						}
					}

				}
			}
		});
		async = new CheckMicAsync();
		// Used to record voice
		mSensor = new SoundMeter();

		PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK,
				"NoiseAlert");
		isInstance = true;

	}

	@Override
	public void onResume() {
		super.onResume();
		LogWrite.d(TAG, "OnResume Method Enters..");
		try {
			soundCheck = true;
			mSensor.start();
			async.execute("");
		} catch (Exception e) {
			LogWrite.e(TAG, "OnResumeMicException : " + e.toString());
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		LogWrite.d(TAG, "OnPause Method Enters..");
		// try {
		// soundCheck = false;
		// mSensor.stop();
		// } catch (ExceptionDTO e) {
		// LogWrite.e(TAG, "MsensorException : " + e.toString());
		// }

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		LogWrite.d(TAG, "OnDestroy Method Enters..");
		try {
			soundCheck = false;
			mSensor.stop();
		} catch (Exception e) {
			LogWrite.e(TAG, "MsensorException : " + e.toString());
		}
		isInstance = false;
	}

	@Override
	public void onClick(View v) {
		Vibrator vibrator = (Vibrator) context
				.getSystemService(Context.VIBRATOR_SERVICE);
		vibrator.vibrate(500);
		messageTextView.setText("Mic test fails.");

		if (HardwareTestFragment.isAutoStartClicked) {
			soundCheck = false;
			onAutoHardwareTestListener.onHardwareTestFinish(7, "Microphone",
					false);
			MicTestActivity.this.finish();
		}

		if (isFromCommand) {
			soundCheck = false;
			onCommandListener.onCommand(false);
			MicTestActivity.this.finish();
		}
		okButton.setVisibility(View.GONE);
	}

	private class CheckMicAsync extends AsyncTask<String, String, String> {

		@Override
		protected synchronized String doInBackground(String... params) {
			while (soundCheck) {
				LogWrite.d(TAG, "Thread is working");
				int amplitude = (int) mSensor.getAmplitudeEMA();
				LogWrite.d(TAG, "Amplitude: " + amplitude);
				if (amplitude > 2) {
					LogWrite.d(TAG,
							"Mic is working : " + mSensor.getAmplitudeEMA());
					publishProgress("a");
					sleep(1000);
					publishProgress("b");
				}
				sleep(2000);
				// appAlreadyWorkingFlag = true;
			}
			return "";
		}

		@Override
		protected void onProgressUpdate(String... values) {
			String value = values[0];
			if (value.equals("a")) {
				Animation sampleFadeAnimation = AnimationUtils.loadAnimation(
						context, R.anim.anim_rotate);
				sampleFadeAnimation.setRepeatCount(1);
				fanImageView.startAnimation(sampleFadeAnimation);
			} else if (value.equals("b")) {
				try {

					messageTextView
							.setText(R.string.micro_phone_is_working_fine);
					messageTextView.setTextAppearance(context,
							R.style.textStyleGreen);
					success = true;
					timerProgress.setVisibility(View.GONE);

					if (HardwareTestFragment.isAutoStartClicked) {
						soundCheck = false;
						success = true;
					}

					if (isFromCommand) {
						soundCheck = false;
						success = true;
						// MicTestActivity.this.finish();
						// FragmentListener fragmentListener =
						// (FragmentListener) getActivity();
						// fragmentListener.onItemClicked(
						// FragmentListener.actionRemove,
						// MicTestFragment.this);

					}
					// isClickWork = true;
					// setToSendFlag();
				} catch (Exception e) {

				}
			}

			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(String result) {
			if (isFromCommand) {
				if (!soundCheck) {
					if (success) {
						onCommandListener.onCommand(true);
						MicTestActivity.this.finish();
					}
				}
			}

			if (HardwareTestFragment.isAutoStartClicked) {
				if (!soundCheck) {
					if (success) {
						onAutoHardwareTestListener.onHardwareTestFinish(7,
								"Microphone", true);
						MicTestActivity.this.finish();
					}
				}
			}

			super.onPostExecute(result);
		}

		private void sleep(long time) {
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
