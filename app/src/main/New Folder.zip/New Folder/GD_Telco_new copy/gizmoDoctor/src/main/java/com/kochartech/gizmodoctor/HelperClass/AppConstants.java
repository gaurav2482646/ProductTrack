package com.kochartech.gizmodoctor.HelperClass;

public class AppConstants {
	private final String ApplicationKeyCode = "GD";
	public String getApplicationkeycode() {
		return ApplicationKeyCode;
	}	
}
