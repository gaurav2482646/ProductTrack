package com.kochartech.devicemax.Activities;
//package com.kochar.it.MDMSV1;
//
//import java.io.DataOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.net.HttpURLConnection;
//import java.net.SocketException;
//import java.net.URL;
//import org.apache.http.client.ClientProtocolException;
//
//import android.content.Context;
//import android.content.SharedPreferences;
//import android.util.Log;
//
//import com.kochar.DefinedPermissions.Defined_Code_Permissions;
//import com.kochar.it.MDMS.JSON.MyJSONObject;
//
///**
// * This signleton class is created to post data to server.
// * 
// * @author gaurav.gupta
// */
//
//public class HttpOperations {
//
//	private static final String tag = "HttpOperationsTest";
//	final static String TAG = "HttpOperations";
//	String className = "";
//	static SharedPreferences sharedPreferences = null;
//	static SharedPreferences.Editor editor = null;
//	static String lastUploadDate; 
//	private static HttpOperations instance = null;
//	boolean responseSentFlag = false;
//	public static String responseString ="";
//	// default private constructor so that object can't be created from outside
//	// the class
//	private HttpOperations() {
//
//	}
//
//	public static HttpOperations getInstance()
//	{
//		if (instance == null)
//			instance = new HttpOperations();
//
//		return instance;
//	}
//
//	public static boolean doPost(String value, String className, Context context)
//			throws ClientProtocolException, IOException {
//
//		 if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(TAG," in do post ");
//		 
//		HttpURLConnection urlConnection = null;
//		URL _url = null;
//		
//		try
//		{
//			if(className.equalsIgnoreCase("Notification"))
//			{
//				
//				_url = new URL(WebServiceURL.NOTIFICATION_REQUEST.toString());
//				if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag, "inside notification url is: "+_url);
//			}
//			else if(className.equalsIgnoreCase("UploadStatistics")) 
//			{
//				if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag,"url is "+ WebServiceURL.SENDING_STATISTICS_REQUEST.toString());
//				_url = new URL(WebServiceURL.SENDING_STATISTICS_REQUEST.toString());
//			}
//			else if(className.equalsIgnoreCase("RegisterDeviceCode"))
//			{
//				if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag,"url is "+ WebServiceURL.REGISTER_DEVICE_CODE.toString());
//				_url = new URL(WebServiceURL.REGISTER_DEVICE_CODE.toString());
//
//			}
//			else
//			{
//				if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag,"url is "+ WebServiceURL.SEND_RESPONSE.toString());
//				_url = new URL(WebServiceURL.SEND_RESPONSE.toString());
//			}
//			
//			//URL _url = new URL(WebServiceURL.SEND_RESPONSE.toString());
//			urlConnection = (HttpURLConnection) _url.openConnection();
//			urlConnection.setConnectTimeout(2*1000);
//			urlConnection.setReadTimeout(2*1000);
//			urlConnection.setRequestMethod("POST");
//			urlConnection.setRequestProperty("Content-Type", "application/json");
////			urlConnection.setRequestProperty("Content-Length", value.length()+"" );
//			urlConnection.setDoInput(true);
//			urlConnection.setDoOutput(true);
//			DataOutputStream dos = new DataOutputStream(urlConnection.getOutputStream());
//			byte[] bs = value.toString().getBytes();
//			if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(TAG, "Sending JSON String ji->" + new String(bs));
//
//			
//			dos.write(bs);
//			dos.flush();
//			dos.close();
//			
//				/*if(className.equalsIgnoreCase("DeviceInfo"))
//				{
////					Logs.write("Sending DeviceInfo JSON: "+value);
//
//					//					Logs.write(" DeviceInfo Sent ");
//				}
//				if(className.equalsIgnoreCase("SendLocation"))
//				{
////					Logs.write("Sending SendLocation JSON: "+value);
//					
////					Logs.write("Location Sent ");
//					
//				}*/
////				Logs.write("\nResponse sent->  "+urlConnection.getResponseMessage());
////			urlConnection.getInputStream();
//			if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(TAG, "Response ->" + urlConnection.getResponseMessage());
//			
//			if (urlConnection.getResponseMessage().toLowerCase().equals("ok")) 
//			{
////				Logs.write("Sent successfully");
//				InputStream is = urlConnection.getInputStream();
//				long ch;
//				StringBuffer b = new StringBuffer();
//				while ((ch = is.read()) != -1)
//				{
//					b.append((char) ch);
//				}
//				responseString = b.toString();
//				if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(TAG, "responseString="+responseString);
//				
//				bs = null;
//				b = null;
//				_url = null;
//				urlConnection = null;
//				
//				/*
//				 * to get current date and time
//				 */
////				getDateTime(context);
//				
//				return true;
//
//			} // data sent successfully
////			dos.close();
//
//		} 
//		catch (SocketException e)
//		{
////			Logs.write("Error: "+e.getMessage());
//			if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(TAG, e.toString());
//			_url = null;
//			return false;
//
//		} catch (ExceptionDTO e)
//		{
////			Logs.write("Error: "+e.getMessage());
//			_url = null;
//			if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(TAG, "unable to post data ");
//			Log.e(TAG, "-->" + e);
//			return false;
//		}
//
//		return false;
//	} // do post
//
///*	private static void getDateTime(Context context) 
//	{
//		StringBuilder installedDateTime = new StringBuilder(); 
//		Calendar c = Calendar.getInstance();
//		installedDateTime         
//	            .append(c.get(Calendar.DAY_OF_MONTH)+"-")
//	            .append(c.get(Calendar.MONTH) + 1).append("-")
//	            .append(c.get(Calendar.YEAR)+"  ")
//	            .append(c.get(Calendar.HOUR_OF_DAY)+":")
//	            .append(c.get(Calendar.MINUTE)+":")
//	            .append(c.get(Calendar.SECOND)).toString();
//		
//		//  to set the value of date and time in shared preference for used in MyDevice.java 
//		 
//		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
//		editor = sharedPreferences.edit();
//		editor.putString("LastUploadDateTime",installedDateTime.toString());
//		editor.commit();
//		
//	}*/
//
//
//	/**
//	 * retry count to send start session result to server via http... 
//	 */
//	static int retryCount = 0;
//	public static String doPost(String URL, MyJSONObject value)	throws ClientProtocolException, IOException 
//	{
//		String responseString = "";
//		HttpURLConnection urlConnection = null;
//		retryCount++;
//		try 
//		{
//			URL url = new URL(URL);
//			urlConnection = (HttpURLConnection) url.openConnection();
//			urlConnection.setRequestMethod("POST");
//			urlConnection.setRequestProperty("Content-Type", "application/json");
//			urlConnection.setRequestProperty("Content-Length", value.toString().length()+ "");
//			urlConnection.setDoInput(true);
//			urlConnection.setDoOutput(true);
//			DataOutputStream dos = new DataOutputStream(urlConnection.getOutputStream());
//			byte[] bs = value.toString().getBytes();
//			if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag, "Sending JSON String ->" + new String(bs));
//			dos.write(bs);
//			dos.flush();
//			dos.close();
//			if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag, "Responce ->" + urlConnection.getResponseMessage());
//			if (urlConnection.getResponseMessage().toLowerCase().equals("ok")) 
//			{
//				InputStream is = urlConnection.getInputStream();
//				int ch;
//				StringBuffer b = new StringBuffer();
//				while ((ch = is.read()) != -1) 
//				{
//					b.append((char) ch);
//				}
//				responseString = b.toString();
//				return  responseString;
//			} 
//			else 
//			{
//				if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag,  urlConnection.getResponseMessage());
//			}
//			dos.close();
//		} 
//		catch (SocketException e) 
//		{
//			if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag,  e.toString());
//			if (retryCount != 4)
//				doPost(URL, value);
//			else 
//			{
//				if( Defined_Code_Permissions.DEBUG_LOG)   Log.d(tag,  "3 retry Fail");
//			}
//		} 
//		catch (ExceptionDTO e)
//		{
//			
//			Log.e(tag, "-->" + e);
//		}
//		return "";
//	}
//	
//} // end classs
//
