package com.kochartech.gizmodoctor.POJO;



public class AppInfo 
{
	private String appName;
	private String packageName;
	private int    icon;
	
	public AppInfo(String appName)
	{
		this.appName = appName;
	}
	public AppInfo(String appName, String packageName, int icon)
	{
		this.appName = appName;
		this.packageName = packageName;
		this.icon = icon;
	}
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public int getIcon() {
		return icon;
	}
	public void setIcon(int icon) {
		this.icon = icon;
	}
}
