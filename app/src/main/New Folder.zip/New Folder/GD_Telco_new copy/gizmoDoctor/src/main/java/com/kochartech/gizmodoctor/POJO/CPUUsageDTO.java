package com.kochartech.gizmodoctor.POJO;

import java.util.ArrayList;

public class CPUUsageDTO
{
	private int id;
	private ArrayList<Integer> usage;
	
	public CPUUsageDTO(int id, ArrayList<Integer> usage)
	{
		this.id = id;
		this.usage = usage;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ArrayList<Integer> getUsage() {
		return usage;
	}

	public void setUsage(ArrayList<Integer> usage) {
		this.usage = usage;
	}
	
	
}
