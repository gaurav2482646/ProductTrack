package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.kochartech.gizmodoctor.HelperClass.KTEnum;

public class AppSettingsPreference {
	private final String PREFERENCE_NAME = "gizmodoctor";
	private final int PREFERENCE_MODE = 0;
	private String KEY_TEMPERATURE_UNIT = "temperature_unit";
	public SharedPreferences myPreference;
	public Editor editor;

	public AppSettingsPreference(Context context) {
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();
	}

	public void setTemperatureUnitToShow(
			KTEnum.TEMPERATURE_UNIT enumTemperatureUnit) {
		editor.putInt(KEY_TEMPERATURE_UNIT, enumTemperatureUnit.getValue())
				.commit();
	}

	public int getTemperatureUnitToShow() {
		return myPreference.getInt(KEY_TEMPERATURE_UNIT,
				KTEnum.TEMPERATURE_UNIT.CELSIUS.getValue());
	}
}
