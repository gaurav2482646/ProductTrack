package com.kochartech.gizmodoctor.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
import com.kochartech.gizmodoctor.homehelper.HomeKeyWatcher;
import com.kochartech.gizmodoctor.homehelper.OnHomePressedListener;
import com.kochartech.gizmodoctor.homehelper.OnPowerPressedListener;
import com.kochartech.gizmodoctor.homehelper.PowerButtonListener;

public class KeysTestFragment extends ActionBarActivity implements OnClickListener {
	private String TAG = KeysTestFragment.class.getSimpleName();
	// private FrameLayout mainView;

	private Context context;
	// private View rootView;
	// private TextView textView;

	private boolean isFromCommand = false;
	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
	private static OnCommandListener onCommandListener;
	// private boolean isClickWork = false;

	private TextView messageTextView;
	private CircularProgressBar timerProgress;
	private Button okButton;
	private String keyToCheck = "";
	private String FAILURE_MESSAGE = "Desired key fails, Press ok to confirm?";
	// public KeysTestFragment(String keyToCheck,
	// OnCommandListener onCommandListener) {
	// this.keyToCheck = keyToCheck;
	// this.onCommandListener = onCommandListener;
	// }

	private boolean checkPower = false;
	private boolean checkHome = false;
	private boolean checkMenu = false;
	private boolean checkBack = false;
	private boolean checkVolumeUp = false;
	private boolean checkVolumeDown = false;

	private boolean success = false;
	private HomeKeyWatcher mHomeWatcher = null;
	private PowerButtonListener powerButtonListener;

	private boolean homepress = false;
	private boolean powerpress = false;
	// private boolean batteryflag = false;

	private boolean isAppForeground = false;

	public static void startActivity(Context context, String keyToCheck,
			boolean isFromCommand, OnCommandListener onCommandListener) {
		// Build extras with passed in parameters
		Bundle extras = new Bundle();
		extras.putString("SoftKeyTest", keyToCheck);
		extras.putBoolean("IsFromCommand", isFromCommand);
		KeysTestFragment.onCommandListener = onCommandListener;
		// Create and start intent for this activity
		Intent intent = new Intent(context, KeysTestFragment.class);
		intent.putExtras(extras);
		context.startActivity(intent);
	}

	private boolean isTimerFinishFlag = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		this.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		setContentView(R.layout.fragment_soft_key);
		keyToCheck = getIntent().getExtras().get("SoftKeyTest").toString();
		getSupportActionBar().setTitle(keyToCheck + " Test");
		isFromCommand = getIntent().getExtras().getBoolean("IsFromCommand");
		context = KeysTestFragment.this;
		messageTextView = (TextView) findViewById(R.id.soft_key_message);
		okButton = (Button) findViewById(R.id.ok_button);
		okButton.setOnClickListener(this);
		timerProgress = (CircularProgressBar) findViewById(R.id.circularprogressbar2);
		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {
			@Override
			public void onAnimationStart() {

			}

			@Override
			public void onAnimationProgress(int progress) {
				timerProgress.setTitle(progress + "");
				timerProgress.setSubTitle("");
			}

			@Override
			public void onAnimationFinish() {
				if (!success) {
					messageTextView.setText(FAILURE_MESSAGE);
					messageTextView.setTextAppearance(context,
							R.style.textStyleRed);
					okButton.setVisibility(View.VISIBLE);
					timerProgress.setSubTitle("");
					timerProgress.setVisibility(View.GONE);
					isTimerFinishFlag = true;
				}
			}
		});

	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		LogWrite.d(TAG, "Focus changed !");
		if (!hasFocus) {
			LogWrite.d(TAG, "Lost focus !");
			Intent closeDialog = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
			sendBroadcast(closeDialog);
		}
		super.onWindowFocusChanged(hasFocus);
	}

	@Override
	protected void onResume() {
		if (!isTimerFinishFlag) {
			isAppForeground = true;
			LogWrite.i(TAG, "onResume enters : " + isAppForeground);
			if (!powerpress)
				checkKey(keyToCheck);
			if (checkHome) {
				mHomeWatcher = new HomeKeyWatcher(this, true);
				mHomeWatcher
						.setOnHomePressedListener(new OnHomePressedListener() {
							@Override
							public void onHomePressed() {
								LogWrite.d(TAG, "Home Key Press..........");
								homepress = true;
							}

							@Override
							public void onHomeLongPressed() {
								LogWrite.d(TAG, "Home Key Long Press..........");
								homepress = true;
							}
						});
				mHomeWatcher.startWatch();
			}
			if (!powerpress) {
				if (checkPower) {
					powerButtonListener = new PowerButtonListener(context);
					powerButtonListener.register(new OnPowerPressedListener() {
						@Override
						public void onPowerKeyPressed(boolean batteryFlag) {
							LogWrite.i(TAG, "Power Button Clicked!");
							// batteryflag = batteryFlag;
							if (!isTimerFinishFlag) {
								if (batteryFlag) {
									Vibrator vibrator = (Vibrator) context
											.getSystemService(Context.VIBRATOR_SERVICE);
									vibrator.vibrate(500);
									timerProgress.setVisibility(View.GONE);
									messageTextView
											.setText(R.string.power_key_working_fine);
									messageTextView.setTextAppearance(context,
											R.style.textStyleGreen);
									if (isFromCommand) {
										onCommandListener.onCommand(true);
										KeysTestFragment.this.finish();
									}
								} else {
									Vibrator vibrator = (Vibrator) context
											.getSystemService(Context.VIBRATOR_SERVICE);
									vibrator.vibrate(500);
									timerProgress.setVisibility(View.GONE);
									messageTextView
											.setText("Power key test can't be initiated because battery is below 5%");
									messageTextView.setTextAppearance(context,
											R.style.textStyleRed);
									if (isFromCommand) {
										onCommandListener.onCommand(true);
										KeysTestFragment.this.finish();
									}
								}
								powerpress = true;
								success = true;
							}
						}
					});

				}
			}

			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (homepress) {
				Vibrator vibrator = (Vibrator) context
						.getSystemService(Context.VIBRATOR_SERVICE);
				vibrator.vibrate(500);
				timerProgress.setVisibility(View.GONE);
				success = true;
				messageTextView.setText(R.string.home_key_working_fine);
				messageTextView.setTextAppearance(this, R.style.textStyleGreen);
				if (isFromCommand) {
					onCommandListener.onCommand(true);
					KeysTestFragment.this.finish();
				}
			}
		}

		super.onResume();
	}

	@Override
	protected void onPause() {
		isAppForeground = false;
		LogWrite.i(TAG, "onPause enters : " + isAppForeground);
		super.onPause();
		if (mHomeWatcher != null) {
			try {
				mHomeWatcher.stopWatch();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// try {
		// Thread.sleep(300);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
	}

	@Override
	protected void onDestroy() {
		isAppForeground = false;
		LogWrite.i(TAG, "onDestroy enters : " + isAppForeground);
		super.onDestroy();
		if (mHomeWatcher != null) {
			try {
				mHomeWatcher.stopWatch();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		isTimerFinishFlag = false;

		if (powerButtonListener != null)
			powerButtonListener.unregister();
	}

	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		int key_code = event.getKeyCode();
		if (!isTimerFinishFlag) {
			if (checkPower) {
				if (key_code == KeyEvent.KEYCODE_POWER) {
					LogWrite.i(TAG, "Power Button Clicked!");
					Vibrator vibrator = (Vibrator) context
							.getSystemService(Context.VIBRATOR_SERVICE);
					vibrator.vibrate(500);
					timerProgress.setVisibility(View.GONE);
					messageTextView.setText(R.string.power_key_working_fine);
					messageTextView.setTextAppearance(this,
							R.style.textStyleGreen);
					if (isFromCommand) {
						onCommandListener.onCommand(true);
						KeysTestFragment.this.finish();
					}
					success = true;
					return true;
				} else if (key_code == KeyEvent.KEYCODE_BACK) {
					if (isFromCommand) {
						onCommandListener.onCommand(false);
						KeysTestFragment.this.finish();
					} else {
						KeysTestFragment.this.finish();
					}
					return true;
				}
			} else if (checkMenu) {
				if (key_code == KeyEvent.KEYCODE_MENU) {
					LogWrite.i(TAG, "Menu Button Clicked!");
					Vibrator vibrator = (Vibrator) context
							.getSystemService(Context.VIBRATOR_SERVICE);
					vibrator.vibrate(500);
					timerProgress.setVisibility(View.GONE);
					messageTextView.setText(R.string.menu_key_working_fine);
					messageTextView.setTextAppearance(this,
							R.style.textStyleGreen);
					if (isFromCommand) {
						onCommandListener.onCommand(true);
						KeysTestFragment.this.finish();
					} else {
						KeysTestFragment.this.finish();
					}
					success = true;
					return true;
				} else if (key_code == KeyEvent.KEYCODE_BACK) {
					if (isFromCommand) {
						onCommandListener.onCommand(false);
						KeysTestFragment.this.finish();
					} else {
						KeysTestFragment.this.finish();
					}
					return true;
				}
			} else if (checkVolumeUp) {
				if (key_code == KeyEvent.KEYCODE_VOLUME_UP) {
					LogWrite.i(TAG, "Volume Up Button Clicked!");
					Vibrator vibrator = (Vibrator) context
							.getSystemService(Context.VIBRATOR_SERVICE);
					vibrator.vibrate(500);
					timerProgress.setVisibility(View.GONE);
					messageTextView.setText(R.string.volumeup_key_working_fine);
					messageTextView.setTextAppearance(this,
							R.style.textStyleGreen);
					if (isFromCommand) {
						onCommandListener.onCommand(true);
						KeysTestFragment.this.finish();
					} else {
						KeysTestFragment.this.finish();
					}
					success = true;
					return true;
				} else if (key_code == KeyEvent.KEYCODE_BACK) {
					if (isFromCommand) {
						onCommandListener.onCommand(false);
						KeysTestFragment.this.finish();
					} else {
						KeysTestFragment.this.finish();
					}
					return true;
				}
			} else if (checkVolumeDown) {
				if (key_code == KeyEvent.KEYCODE_VOLUME_DOWN) {
					LogWrite.i(TAG, "Volume Down Button Clicked!");
					Vibrator vibrator = (Vibrator) context
							.getSystemService(Context.VIBRATOR_SERVICE);
					vibrator.vibrate(500);
					timerProgress.setVisibility(View.GONE);
					messageTextView
							.setText(R.string.volumedown_key_working_fine);
					messageTextView.setTextAppearance(this,
							R.style.textStyleGreen);
					if (isFromCommand) {
						onCommandListener.onCommand(true);
						KeysTestFragment.this.finish();
					}
					success = true;
					return true;
				} else if (key_code == KeyEvent.KEYCODE_BACK) {
					if (isFromCommand) {
						onCommandListener.onCommand(false);
						KeysTestFragment.this.finish();
					} else {
						KeysTestFragment.this.finish();
					}
					return true;
				}
			} else if (checkBack) {
				if (key_code == KeyEvent.KEYCODE_BACK) {
					LogWrite.i(TAG, "Back Key Clicked!");
					Vibrator vibrator = (Vibrator) context
							.getSystemService(Context.VIBRATOR_SERVICE);
					vibrator.vibrate(500);
					timerProgress.setVisibility(View.GONE);
					messageTextView.setText(R.string.back_key_working_fine);
					messageTextView.setTextAppearance(this,
							R.style.textStyleGreen);
					if (isFromCommand) {
						onCommandListener.onCommand(true);
						KeysTestFragment.this.finish();
					}
					success = true;
					checkBack = false;
					return false;
				}
			} else if (powerpress || homepress) {
				if (key_code == KeyEvent.KEYCODE_BACK) {
					if (isFromCommand) {
						onCommandListener.onCommand(false);
						KeysTestFragment.this.finish();
					} else {
						KeysTestFragment.this.finish();
					}
					return true;
				}
			}
		} else {
			if (key_code == KeyEvent.KEYCODE_BACK) {
				if (isFromCommand) {
					onCommandListener.onCommand(false);
					KeysTestFragment.this.finish();
				} else {
					KeysTestFragment.this.finish();
				}
				return true;
			}
		}
		return super.dispatchKeyEvent(event);
	}

	// <item>PowerKey</item>
	// <item>HomeKey</item>
	// <item>MenuKey</item>
	// <item>VolumeUpKey</item>
	// <item>VolumeDownKey</item>

	private void checkKey(String keyToCheck) {
		String[] softKeyTitles = context.getResources().getStringArray(
				R.array.soft_key_titles);
		if (keyToCheck.equals(softKeyTitles[0])) {
			// Power key to check
			checkPower = true;
			messageTextView.setText(R.string.power_key_screen);
		} else if (keyToCheck.equals(softKeyTitles[1])) {
			// Home key to check
			checkHome = true;
			messageTextView.setText(R.string.home_key_screen);
		} else if (keyToCheck.equals(softKeyTitles[2])) {
			// Menu key to check
			checkMenu = true;
			messageTextView.setText(R.string.menu_key_screen);
		} else if (keyToCheck.equals(softKeyTitles[3])) {
			// Menu key to check
			checkBack = true;
			messageTextView.setText(R.string.back_key_screen);
		} else if (keyToCheck.equals(softKeyTitles[4])) {
			// Volume up to check
			checkVolumeUp = true;
			messageTextView.setText(R.string.volumeup_key_screen);
		} else if (keyToCheck.equals(softKeyTitles[5])) {
			// Volume down to check
			checkVolumeDown = true;
			messageTextView.setText(R.string.volumedown_key_screen);
		}
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.ok_button) {
			Vibrator vibrator = (Vibrator) context
					.getSystemService(Context.VIBRATOR_SERVICE);
			vibrator.vibrate(500);
			messageTextView.setText(failureMessage());
			if (isFromCommand) {
				onCommandListener.onCommand(false);
				KeysTestFragment.this.finish();
			}
			okButton.setVisibility(View.GONE);
		}
	}

	private String failureMessage() {
		String message = "";
		if (checkPower)
			message = "PowerKey test fails.";
		else if (checkHome)
			message = "HomeKey test fails.";
		else if (checkMenu)
			message = "MenuKey test fails.";
		else if (checkBack)
			message = "BackKey test fails.";
		else if (checkVolumeUp)
			message = "VolumeupKey test fails.";
		else if (checkVolumeDown)
			message = "VolumedownKey test fails.";
		return message;
	}
}
