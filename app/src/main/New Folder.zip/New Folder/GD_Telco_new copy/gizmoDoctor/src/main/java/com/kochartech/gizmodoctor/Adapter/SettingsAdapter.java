package com.kochartech.gizmodoctor.Adapter;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;

public class SettingsAdapter extends CursorAdapter
{
	
	LayoutInflater inflater;
	public SettingsAdapter(Context context, Cursor c) {
		super(context, c);
		// TODO Auto-generated constructor stub
		inflater = LayoutInflater.from(context);
	}

	@Override
	public void bindView(View arg0, Context context, Cursor cursor) {
		// TODO Auto-generated method stub
		TextView tv1 = (TextView)arg0.findViewById(R.id.featurename);
		CheckBox tv2 = (CheckBox)arg0.findViewById(R.id.checkbox);
		
		
		tv1.setText(cursor.getString(1));
		tv2.setChecked(cursor.getInt(2)==1);
		
	}

	@Override
	public View newView(Context arg0, Cursor arg1, ViewGroup arg2) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.rowlayout_settingfragment, arg2, false);
	}
	
	@Override
	public void changeCursor(Cursor cursor) {
		// TODO Auto-generated method stub
		super.changeCursor(cursor);
	}
	
	
}
