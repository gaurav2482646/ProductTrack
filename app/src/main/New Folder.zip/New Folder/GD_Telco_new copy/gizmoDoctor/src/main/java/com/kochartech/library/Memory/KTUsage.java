package com.kochartech.library.Memory;

import java.util.ArrayList;
import java.util.List;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;

 public abstract class KTUsage {
	public Context context;
	public List<KTApplicationInfo> runningAppUsageInfo = new ArrayList<KTApplicationInfo>();
	public PackageManager pkgManager;
	public ActivityManager activityManager;

	protected KTUsage(Context context) {
		this.context = context;
		pkgManager = context.getPackageManager();
		activityManager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
	}

	protected ApplicationInfo getApplicationInfo(String processName) {
		ApplicationInfo applInfo = null;
		try {
			applInfo = pkgManager.getApplicationInfo(processName,
					PackageManager.GET_META_DATA);
		} catch (NameNotFoundException e) {
		}
		return applInfo;
	}

	protected String getAppName(ApplicationInfo appInfo) {
		return pkgManager.getApplicationLabel(appInfo).toString();
	}

	protected Drawable getAppIcon(ApplicationInfo appInfo) {
		return pkgManager.getApplicationIcon(appInfo);
	}

}
