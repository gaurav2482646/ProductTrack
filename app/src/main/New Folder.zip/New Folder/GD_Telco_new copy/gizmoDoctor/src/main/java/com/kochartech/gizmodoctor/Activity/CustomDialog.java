//package com.kochartech.gizmodoctor.Activity;
//package com.kochar.singtel.device_settings;
//
//import android.app.AlertDialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.text.InputFilter;
//import android.text.InputType;
//import android.widget.EditText;
//import android.widget.Toast;
//
//public class CustomDialog 
//{
//	public static void show(final Context context,String title,String message,
//			final NetworkSettingsManager networkSettingsManager, final String preferenceKey,final String preferenceCurrentValue)
//	{
//		final AlertDialog.Builder alert = new AlertDialog.Builder(context);
//		
//		alert.setTitle(title);
//		alert.setMessage(message);
//
//	
//		
//		// Set an EditText view to get user input 
//		final EditText input = new EditText(context);
//		input.setInputType(InputType.TYPE_CLASS_NUMBER);
//		InputFilter[] filterArray = new InputFilter[1];
//		filterArray[0] = new InputFilter.LengthFilter(3);
//		input.setFilters(filterArray);
//		
//		input.setText(preferenceCurrentValue);
//		alert.setView(input);
////		input.setSelection(input.getText().length());
//		alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//		public void onClick(DialogInterface dialog, int whichButton) {
//		  String value = input.getText().toString();
//		  
//		  int valueInInt = 0;
//		
//			try {
//				valueInInt = Integer.valueOf(value);
//				 if(valueInInt>=0 && valueInInt<=100)
//				  {
//					 networkSettingsManager.setSignalLimit_Preference(value);
//				  }
//				  else
//				  {
//					  Toast.makeText(context.getApplicationContext(),"! please enter the valid Limit",Toast.LENGTH_LONG).show();
//				  }
//			} catch (NumberFormatException e) {
//				Toast.makeText(context.getApplicationContext(),"! please enter the valid Limit",Toast.LENGTH_LONG).show();
//				
//			}
//		
//		  
//		 
//		    
//		  }
//		});
//
//		  alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//		  public void onClick(DialogInterface dialog, int whichButton) {
//		  }
//		});
//
//		alert.show();
//	}
////	public static void show1(Context context,String title,String message,
////			final Editor editor,final String preferenceKey,final String preferenceCurrentValue)
////	{
////		try
////		{
////AlertDialog.Builder alert = new AlertDialog.Builder(context);
////		
////		alert.setTitle(title);
////		alert.setMessage(message);
////		
////		LayoutInflater inflater = (LayoutInflater)context.getLa
////		View v = inflater.inflate(R.layout.radiobutton, );
////		alert.setView(v);
////		alert.show();
////		}
////		catch(ExceptionDTO e)
////		{
////			//Log.d("Ashish", "ExceptionDTO...."+e);
////		}
////	}
//}
