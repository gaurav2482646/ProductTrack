package com.kochartech.gizmodoctor.gpshelper;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import com.kochartech.devicemax.Activities.LogWrite;

public class LocationTracker implements LocationListener {
	private String tag = "GPSTracker";
	private final Context mContext;
	// flag for GPS status
	boolean isGPSEnabled = false;
	// flag for network status
	boolean isNetworkEnabled = false;
	// flag for GPS status
	boolean canGetLocation = false;
	Location location; // location

	public double latitude = 0.0; // latitude
	public double longitude = 0.0; // longitude
	public int no_of_satellites = 0;
	public String speed = "0.0 m/s";
	public String altitude = "0.0 m";
	public float bearing = 0;
	public float accuracy = 0;

	// The minimum distance to change Updates in meters
	private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10; // 10 meters
	// The minimum time between updates in milliseconds
	private static final long MIN_TIME_BW_UPDATES = 1000 * 60 * 1; // 1 minute
	// Declaring a Location Manager
	protected LocationManager locationManager;
	// Declaring Cellid and lac address
	int cellID, lac;

	// private static boolean gpsFlag = false;

	public LocationTracker(Context context) {
		this.mContext = context;
		location = getLocation();
	}

	private Location getLocation() {
		try {
			locationManager = (LocationManager) mContext
					.getSystemService(Context.LOCATION_SERVICE);
			// getting GPS status
			isGPSEnabled = locationManager
					.isProviderEnabled(LocationManager.GPS_PROVIDER);
			// getting network status
			isNetworkEnabled = locationManager
					.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
			if (!isGPSEnabled && !isNetworkEnabled) {
				// LogWrite.d(tag, "No Network");
				// new Thread() {
				// @Override
				// public void run() {
				// getLocationFromCellid();
				// }
				// }.start();

			} else {
				this.canGetLocation = true;
				// First get location from Network Provider
				// if (isNetworkEnabled) {
				// locationManager.requestLocationUpdates(
				// LocationManager.NETWORK_PROVIDER,
				// MIN_TIME_BW_UPDATES,
				// MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
				// LogWrite.d(tag, "Network Enabled");
				// if (locationManager != null) {
				// location = locationManager
				// .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
				// if (location != null) {
				// latitude = location.getLatitude() + "";
				// longitude = location.getLongitude() + "";
				// LogWrite.d(tag, "Latitude : " + latitude);
				// LogWrite.d(tag, "Longitude : " + longitude);
				// }
				// }
				// }
				// if GPS Enabled get lat/long using GPS Services
				if (isGPSEnabled) {
					locationManager.requestLocationUpdates(
							LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES,
							MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
					LogWrite.d(tag, "GPS Enabled");
					if (locationManager != null) {
						location = locationManager
								.getLastKnownLocation(LocationManager.GPS_PROVIDER);
						if (location != null) {
							no_of_satellites = location.getExtras().getInt(
									"satellites");
							speed = location.getSpeed() + " m/s";
							altitude = location.getAltitude() + " m";
							bearing = location.getBearing();
							accuracy = location.getAccuracy();
							latitude = location.getLatitude();
							longitude = location.getLongitude();
							LogWrite.d(tag, "Latitude : " + latitude);
							LogWrite.d(tag, "Longitude : " + longitude);
						}
					} else {
						LogWrite.d(tag, "Location Manager is null");
					}
				}
			}
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO(getlocation)----> " + e.toString());
			// new AsyncTask<String, String, String>() {
			// @Override
			// protected String doInBackground(String... params) {
			// getLocationFromCellid();
			// return null;
			// }
			// }.execute("");
		}
		return location;
	}

	@Override
	public void onLocationChanged(Location location) {

		LogWrite.d(tag, "onLocationChanged()");
		latitude = location.getLatitude();
		longitude = location.getLongitude();
		no_of_satellites = location.getExtras().getInt("satellites");
		speed = location.getSpeed() + " m/s";
		altitude = location.getAltitude() + " m";
		bearing = location.getBearing();
		accuracy = location.getAccuracy();
		LogWrite.d(tag, "Latitude : " + latitude);
		LogWrite.d(tag, "Longitude : " + longitude);
		LogWrite.d(tag, "____");
	}

	@Override
	public void onProviderDisabled(String provider) {
		LogWrite.d(tag, "____1");
	}

	@Override
	public void onProviderEnabled(String provider) {
		LogWrite.d(tag, "____2");
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		LogWrite.d(tag, "____3");
	}

	// private void getLocationFromCellid() {
	// LogWrite.d(tag, "getLocationFromCellid Method Enters");
	// TelephonyManager tm = (TelephonyManager) mContext
	// .getSystemService(Context.TELEPHONY_SERVICE);
	// GsmCellLocation location = (GsmCellLocation) tm.getCellLocation();
	// cellID = location.getCid();
	// LogWrite.d(tag, "CellID : " + cellID);
	// lac = location.getLac();
	// LogWrite.d(tag, "Lac : " + lac);
	// String string = getGoogleCellID(lac, cellID);
	// LogWrite.d(tag, "String  : " + string);
	// String[] latlLong = string.split("~");
	// latitude = latlLong[0];
	// longitude = latlLong[1];
	// }

	public String getLocationInString(String latitude, String longitude)
			throws Exception {
		String userlocation = "";
		String readUserFeed = readUserLocationFeed(latitude.trim() + ","
				+ longitude.trim());
		try {
			JSONObject Strjson = new JSONObject(readUserFeed);
			JSONArray jsonArray = new JSONArray(Strjson.getString("results"));
			userlocation = jsonArray.getJSONObject(1)
					.getString("formatted_address").toString();
		} catch (Exception e) {
			throw new Exception(e.toString());
		}
		LogWrite.w("User Location ", userlocation);
		return userlocation;
	}

	public String getCityName(String latitude, String longitude) {
		String cityName = "";
		String readUserFeed = readUserLocationFeed(latitude.trim() + ","
				+ longitude.trim());
		try {
			JSONObject Strjson = new JSONObject(readUserFeed);
			JSONArray jsonArray = new JSONArray(Strjson.getString("results"));
			JSONArray addressComponent = jsonArray.getJSONObject(0)
					.getJSONArray("address_components");
			LogWrite.d(tag, "Address Component : --------> " + addressComponent);
			for (int i = 0; i < addressComponent.length(); i++) {
				JSONObject jsonObject = addressComponent.getJSONObject(i);
				LogWrite.d(tag, "JSONObject : " + jsonObject.toString());
				String city = jsonObject.getString("long_name").toString();
				LogWrite.d(tag, "LongName : " + cityName);
				JSONArray jsonArray2 = (JSONArray) jsonObject.get("types");
				String typeName = jsonArray2.getString(0);
				if (typeName.equals("administrative_area_level_2")) {
					cityName = city;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		LogWrite.w("CityName :  ", cityName);
		return cityName;
	}

	private String readUserLocationFeed(String address) {
		String TAG = "readUserLocationFeed";
		StringBuilder builder = new StringBuilder();

		HttpClient client = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(
				"http://maps.google.com/maps/api/geocode/json?latlng="
						+ address + "&sensor=false");
		try {
			HttpResponse response = client.execute(httpGet);
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			if (statusCode == 200) {
				HttpEntity entity = response.getEntity();
				InputStream content = entity.getContent();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(content));
				String line;
				while ((line = reader.readLine()) != null) {
					builder.append(line);
				}
			} else {
				LogWrite.d(TAG, "Failed to download file");
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return builder.toString();
	}

	private String getGoogleCellID(int lac, int cid) {
		LogWrite.d(tag, "getGoogleCellID Method Enters");
		int shortcid = cid & 0xffff;
		LogWrite.d(tag, "Lac : " + lac);
		LogWrite.d(tag, "CID: " + cid);
		double lat = 0, longi = 0;
		try {
			String surl = "http://www.google.com/glm/mmap";
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(surl);
			LogWrite.d(tag, "----------------------------1");
			httppost.setEntity(new MyCellIDRequestEntity(shortcid, lac));
			LogWrite.d(tag, "----------------------------2");
			HttpResponse response = httpclient.execute(httppost);
			LogWrite.d(tag, "----------------------------3");
			HttpEntity entity = response.getEntity();
			LogWrite.d(tag, "----------------------------4");
			DataInputStream dis = new DataInputStream(entity.getContent());
			LogWrite.d(tag, "----------------------------5");
			// Read some prior data
			dis.readShort();
			LogWrite.d(tag, "----------------------------6");
			dis.readByte();
			LogWrite.d(tag, "----------------------------7");
			// Read the error-code
			int errorCode = dis.readInt();
			LogWrite.d(tag, "Error Code : " + errorCode);
			if (errorCode == 0) {
				lat = (double) dis.readInt() / 1000000D;
				longi = (double) dis.readInt() / 1000000D;
				LogWrite.d(tag, lat + "");
				LogWrite.d(tag, longi + "");
			}
			return lat + "~" + longi;
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO CellID Method ----> " + e.toString());
			return "0.0" + "~" + "0.0";
		}
	}

	private class MyCellIDRequestEntity implements HttpEntity {

		protected int myCellID;
		protected int myLAC;

		public MyCellIDRequestEntity(int aCellID, int aLAC) {
			this.myCellID = aCellID;
			this.myLAC = aLAC;
		}

		public Header getContentType() {
			return new BasicHeader("Content-Type", "application/binary");
		}

		public void consumeContent() throws IOException {
		}

		public InputStream getContent() throws IOException,
				IllegalStateException {
			return null;
		}

		public Header getContentEncoding() {
			return null;
		}

		public boolean isChunked() {
			return false;
		}

		public boolean isStreaming() {
			return false;
		}

		/**
		 * Pretend to be a French Sony_Ericsson-K750 that wants to receive its
		 * lat/long-values =) The data written is highly proprietary !!!
		 */
		public void writeTo(OutputStream outputStream) throws IOException {
			DataOutputStream os = new DataOutputStream(outputStream);
			os.writeShort(21);
			os.writeLong(0);
			os.writeUTF("fr");
			os.writeUTF("Sony_Ericsson-K750");
			os.writeUTF("1.3.1");
			os.writeUTF("Web");
			os.writeByte(27);

			os.writeInt(0);
			os.writeInt(0);
			os.writeInt(3);
			os.writeUTF("");
			os.writeInt(myCellID); // CELL-ID
			os.writeInt(myLAC); // LAC
			os.writeInt(0);
			os.writeInt(0);
			os.writeInt(0);
			os.writeInt(0);
			os.flush();
		}

		@Override
		public long getContentLength() {
			return -1;
		}

		@Override
		public boolean isRepeatable() {
			return true;
		}

	}

}
