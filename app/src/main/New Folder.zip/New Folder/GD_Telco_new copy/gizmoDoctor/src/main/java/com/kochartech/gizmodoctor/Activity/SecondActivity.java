package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.os.Bundle;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;

public class SecondActivity extends Activity
{
	private String tag = "SecondActivity";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		LogWrite.d(tag,"Start");
	}
}
