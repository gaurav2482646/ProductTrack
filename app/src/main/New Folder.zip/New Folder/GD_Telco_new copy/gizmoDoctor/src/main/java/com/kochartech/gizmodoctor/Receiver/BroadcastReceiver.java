package com.kochartech.gizmodoctor.Receiver;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.UpdateUi.UiRequireUpdate;

public class BroadcastReceiver extends android.content.BroadcastReceiver
{
	private String tag = "BroadcastReceiver1";
	private UiRequireUpdate fragment;
	public BroadcastReceiver(Fragment fragment) {
		// TODO Auto-generated constructor stub
	
		this.fragment = (UiRequireUpdate) fragment;
	}
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
	
		LogWrite.d(tag,""+fragment.getClass().toString());
		fragment.runInBackGround();
//		fragment.updateUI();
	
		
	}

}
