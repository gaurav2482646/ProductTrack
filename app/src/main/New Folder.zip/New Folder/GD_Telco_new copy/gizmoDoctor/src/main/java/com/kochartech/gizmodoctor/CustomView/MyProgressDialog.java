package com.kochartech.gizmodoctor.CustomView;

import android.app.Activity;
import android.app.ProgressDialog;

import com.kochartech.gizmodoctor.R;

public class MyProgressDialog {

	// private Activity activityContext;
	private ProgressDialog progressDialog;

	public MyProgressDialog(Activity activityContext) {
		// this.activityContext = activityContext;
		progressDialog = new ProgressDialog(activityContext, R.style.MyTheme);
	}

	public void show() {
		if (progressDialog != null) {
			progressDialog.show();
			progressDialog.setContentView(R.layout.myprogressdialog_layout);
			progressDialog.setCanceledOnTouchOutside(false);
			progressDialog.setCancelable(false);
		}
	}

	public boolean isShowing() {
		return progressDialog != null ? progressDialog.isShowing() : false;
	}

	public void dismiss() {
		if (progressDialog != null)
			progressDialog.dismiss();
	}
}
