package com.kochartech.devicemax.Activities;

public class ServerResponse {
	private static String message = "";

	public static void set(String message) {
		ServerResponse.message = message;
	}

	public static String get() {
		return ServerResponse.message;
	}

}
