package com.kochartech.gizmodoctor.deviceissues;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;

@SuppressWarnings("deprecation")
@SuppressLint({ "InflateParams", "ViewHolder" })
public class CleanAppAdapter extends ArrayAdapter<RunningAppDTO> {
	// private String TAG = CleanAppAdapter.class.getSimpleName();
	private Context context;
	private ArrayList<RunningAppDTO> appList;
	public static ArrayList<RunningAppDTO> newAppList;

	public CleanAppAdapter(Context context, int textViewResourceId,
			ArrayList<RunningAppDTO> appList) {
		super(context, textViewResourceId, appList);
		this.context = context;
		this.appList = appList;
		newAppList = appList;

		// this.appList.addAll(appList);
	}

	private class ViewHolder {
		LinearLayout appLayout;
		ImageView icon;
		TextView appName;
		TextView appInfo;
		CheckBox selected;
	}

	@Override
	public View getView(final int position, View view, ViewGroup parent) {
		View convertView = null;
		ViewHolder holder = null;
		LogWrite.d("ConvertView", String.valueOf(position));

		if (view == null) {
			convertView = new View(context);
		} else {
			convertView = (View) view;
		}

		LayoutInflater vi = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		convertView = vi.inflate(R.layout.clean_app_view, null);

		holder = new ViewHolder();
		holder.appLayout = (LinearLayout) convertView
				.findViewById(R.id.app_layout);
		holder.icon = (ImageView) convertView.findViewById(R.id.icon);
		holder.appName = (TextView) convertView.findViewById(R.id.appname);
		holder.appInfo = (TextView) convertView.findViewById(R.id.appinfo);
		holder.selected = (CheckBox) convertView
				.findViewById(R.id.selected_checkbox);
		convertView.setTag(holder);

		RunningAppDTO appDTO = appList.get(position);
		holder.icon.setBackgroundDrawable(appDTO.getIcon());
		holder.appName.setText(appDTO.getAppName());
		holder.appInfo.setText(appDTO.getPackageName());
		holder.selected.setChecked(appDTO.isSelected());
		holder.selected.setTag(appDTO);
		holder.appLayout.setTag(appDTO);

		holder.selected.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				CheckBox cb = (CheckBox) v;
				RunningAppDTO appDTO = (RunningAppDTO) cb.getTag();
				// Toast.makeText(
				// context,
				// "Clicked on Checkbox: " + appDTO.getAppName() + " is "
				// + cb.isChecked(), Toast.LENGTH_LONG).show();
				appDTO.setSelected(cb.isChecked());
				newAppList.set(position, appDTO);

			}
		});

		holder.appLayout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				LinearLayout layout = (LinearLayout) v;
				RunningAppDTO appDTO = (RunningAppDTO) layout.getTag();
				openManageAppSettings(appDTO.getPackageName());
				// performAction(context, appDTO.getPackageName());
			}
		});

		return convertView;
	}

	private void openManageAppSettings(String packageName) {
		try {
			// Open the specific App Info page:
			Intent intent = new Intent(
					android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
			intent.setData(Uri.parse("package:" + packageName));
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		} catch (ActivityNotFoundException e) {
			// Open the generic Apps page:
			Intent intent = new Intent(
					android.provider.Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		}
	}
}
