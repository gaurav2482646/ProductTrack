package com.kochartech.gizmodoctor.HelperClass;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import android.content.Context;

import com.kochartech.devicemax.Activities.LogWrite;

public class HttpPostConnection {
	private String tag = "KTServletRequest";
	private HttpURLConnection httpConn;
//	private Context context;

//	private String serverUrl = "http://202.164.36.66:1002/GHCRMService.svc/ghcrmclient/ValidateKey/GHD390807303";

//	private String serverUrl = "http://202.164.36.66:1002/GHCRMService.svc?op=CheckSerialKey";
//	private String serverUrl = "http://192.161.0.207/gh_crm_service/GHCRMService.svc/ghcrmclient/";
//	public static String serverUrl = "http://202.164.36.66/gizmosupportservice/GHCRMService.svc/ghcrmclient/";
									  
//	public static final String methodValidateSerialKey     = "ValidateKey";
//	public static final String methodValidateActivationKey = "ValidateAppKey";
//	public static final String methodGetApplicationKey     = "GetApplicationKey";
//	private String currentUrl = null;
	
	private String serverUrl;
	public HttpPostConnection(Context context, String serverUrl) {
//		this.context = context;
		this.serverUrl = serverUrl;
		
	}

	public void connect() {
		try {

			URL logServiceURL = new URL(serverUrl);

			URLConnection conn = logServiceURL.openConnection();
			httpConn = (HttpURLConnection) conn;
			httpConn.setRequestMethod("POST");
			httpConn.setDoInput(true);
			httpConn.setDoOutput(true);
			httpConn.setRequestProperty("Content-Type", "application/json");
			httpConn.connect();

			LogWrite.d(tag, "connection establish sucessfully");
		} catch (Exception e) {
			LogWrite.d(tag, "init: ExceptionDTO: " + e);
		}
	}

	public void writeToServer(String dataString) {
		OutputStreamWriter outStreamWriter = null;
		try {

			outStreamWriter = new OutputStreamWriter(httpConn.getOutputStream());
			outStreamWriter.write(dataString);
			outStreamWriter.flush();
			outStreamWriter.close();

			String responseMessage = httpConn.getResponseMessage();

			LogWrite.d(tag, "ResponseDTO Message: " + responseMessage);

		} catch (Exception e) {
			LogWrite.d(tag, "sendData: ExceptionDTO: " + e);
		}
	}
	
	public String readFromServer() {
		InputStreamReader inStreamReader = null;
		BufferedReader    bufferReader = null;
		String 			  line = null;
		StringBuilder stringBuilder = new StringBuilder(); 
		try {
			InputStream ins = httpConn.getInputStream();
			inStreamReader = new InputStreamReader(ins);
			bufferReader = new BufferedReader(inStreamReader);
			
			while((line = bufferReader.readLine()) != null) {
				LogWrite.d(tag,line);
				stringBuilder.append(line);
			}					
			
		} catch (Exception e) {
			LogWrite.d(tag, "getData: ExceptionDTO: " + e);
		}
		LogWrite.d(tag, "data: "+stringBuilder.toString());
		return stringBuilder.toString();
	}
	

	public void close() {
		try {
			httpConn.disconnect();
		} catch (Exception e) {
			LogWrite.d(tag, "sendRequest: ExceptionDTO: " + e);
		}
	}
}
