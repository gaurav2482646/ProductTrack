package com.kochartech.devicemax.AsyncTask;
//package com.kochar.testappjar;
//
//import java.lang.reflect.Method;
//import java.util.List;
//
//import com.kochar.MDM.Command.Manager.MDM_CommandHandler;
//
//import android.app.Activity;
//import android.content.pm.ApplicationInfo;
//import android.content.pm.IPackageStatsObserver;
//import android.content.pm.PackageManager;
//import android.content.pm.PackageStats;
//import android.os.Bundle;
//import android.os.RemoteException;
//import android.util.Log;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.Button;
//
//public class MainActivity extends Activity 
//{
//	private String TAG = "MainActivity";
//	protected void onCreate(Bundle savedInstanceState) 
//	{
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_main);
//		Button button = (Button) findViewById(R.id.button1);
//		button.setOnClickListener(new OnClickListener() 
//		{	
//			@Override
//			public void onClick(View v) 
//			{
//				final PackageManager packageManager = getPackageManager();
//				List<ApplicationInfo> installedApplications = FetchPackageName(packageManager);
//				for (final ApplicationInfo appInfo : installedApplications)
//				{
//					Method getPackageSizeInfo;
//					try 
//					{
//						getPackageSizeInfo = packageManager.getClass().getMethod("getPackageSizeInfo", String.class, IPackageStatsObserver.class);
//						getPackageSizeInfo.invoke(packageManager, appInfo.packageName, new IPackageStatsObserver.Stub() 
//						{
//							
//
//							public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) throws RemoteException 
//							{
//								Log.d(TAG, "Package name : " + appInfo.packageName);	
//								Log.d(TAG, "Name: " + appInfo.loadLabel(packageManager));
//								Log.d(TAG, "codeSize: " + pStats.codeSize);
//								Log.d(TAG, "dataSize: " + pStats.dataSize);
//								MDM_CommandHandler handler = new MDM_CommandHandler(getApplicationContext());
//								String appVersion 	= handler.getAppNameVersion(appInfo.packageName, null);
//								String codeVersion = handler.getAppCodeVersion(appInfo.packageName, null);
//								Log.d(TAG, "appVersion: " + appVersion);
//								Log.d(TAG, "codeVersion: " + codeVersion);
////								handler.getAppUpdates("url");
//							}
//						});
//					} 
//					catch (ExceptionDTO e)
//					{
//						e.printStackTrace();
//					}
//				}
//			}
//		});
//		
//	}
//	private static List<ApplicationInfo> FetchPackageName(PackageManager packageManager)
//	{
//		List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
//		return installedApplications;
//	}
//}
