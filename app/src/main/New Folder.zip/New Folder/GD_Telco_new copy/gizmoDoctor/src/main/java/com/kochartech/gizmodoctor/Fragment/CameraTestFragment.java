package com.kochartech.gizmodoctor.Fragment;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.media.ExifInterface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Utility.CameraDTO;
import com.kochartech.devicemax.Utility.Response;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.HardwareModel.CameraPreview;
import com.kochartech.gizmodoctor.HardwareModel.CircleButton;
import com.kochartech.gizmodoctor.HardwareModel.FlashState;
import com.kochartech.gizmodoctor.HardwareModel.ImageCaptureListener;
import com.kochartech.gizmodoctor.HardwareModel.KTCamera;
import com.kochartech.gizmodoctor.HelperClass.HardwareUtility;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;
import com.kochartech.gizmodoctor.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

@SuppressWarnings("deprecation")
public class CameraTestFragment extends Fragment implements OnClickListener,
        ImageCaptureListener, MyFragment {
    public static final String KEY_ISFROMCOMMAND = "isfromcommand";
    private String TAG = CameraTestFragment.class.getSimpleName();
    private Activity activity;
    private boolean isFromCommand = false;
    private View rootView;
    private FrameLayout frameLayout;
    private CircleButton flipButton, flashButton, informButton, captureButton;
    private RelativeLayout cameraLayout;
    private LinearLayout resultLayout;
    private ImageView saveImageView;
    private TextView resultTextView;

    private CameraPreview cameraPreview;

    private KTCamera cameraInstance;
    private Camera mCamera;

    private CameraDTO cameraDTO;
    private boolean flipFlag = false;
    private FlashState flashState;

    private String serverUrl;
    private byte[] imageArray;

    private MyProgressDialog progressDialog;
    private OnAutoHardwareTestListener onAutoHardwareTestListener;

    public CameraTestFragment(CameraDTO cameraDTO) {
        this.cameraDTO = cameraDTO;
    }

    public void setOnAutoHardwareTestListener(
            OnAutoHardwareTestListener onAutoHardwareTestListener) {
        this.onAutoHardwareTestListener = onAutoHardwareTestListener;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.e(TAG, "onCreateView......................1");
        Log.e(TAG, "onCreateView......................2");
        Log.e(TAG, "onCreateView......................3");
        Log.e(TAG, "onCreateView......................4");

        serverUrl = getActivity().getString(R.string.CameraUrl).trim();
        initData();
        initUi(inflater, container);

        if (!cameraInstance.hasCamera()) {
            cameraLayout.setVisibility(View.GONE);
            resultLayout.setVisibility(View.VISIBLE);
            resultTextView.setText("No Camera Found!");
            if (isFromCommand) {

            }
        } else {
            if (!cameraInstance.hasFrontCamera()) {
                flipButton.setVisibility(View.GONE);
            }
        }

        try {

            if (!cameraInstance.hasFlash(mCamera)) {
                flashButton.setClickable(false);
                flashButton.setEnabled(false);
                flashButton.setImageResource(R.drawable.flash_off);
                cameraDTO.setFlashStatus(false);
            } else {
                if (flashState.isEnable()) {
                    LogWrite.i(TAG, "FlashState is ON");
                    flashButton.setImageResource(R.drawable.flash_on);
                } else {
                    LogWrite.i(TAG, "FlashState is OFF");
                    flashButton.setImageResource(R.drawable.flash_off);
                }
                cameraDTO.setFlashStatus(true);
            }
        } catch (Exception e) {
            Log.e(TAG, "FLASH------EXCEPTION : " + e.toString());
        }
        if (isFromCommand) {
            flipButton.setVisibility(View.GONE);
            flashButton.setVisibility(View.GONE);
            cameraDTO.setAutoFocusStatus(cameraInstance.hasAutoFocus(mCamera));
            cameraDTO.setAutoFlashStatus(cameraInstance.hasAutoFlash(mCamera));
            cameraDTO.setImageSize(cameraInstance.getImageSize(mCamera));
            cameraDTO.setImagePixcels(cameraInstance.getImagePixel(mCamera));
        }

        if (HardwareTestFragment.isAutoStartClicked) {
            flipButton.setVisibility(View.GONE);
            flashButton.setVisibility(View.GONE);
            // cameraDTO.setAutoFocusStatus(cameraInstance.hasAutoFocus(mCamera));
            // cameraDTO.setAutoFlashStatus(cameraInstance.hasAutoFlash(mCamera));
            // cameraDTO.setImageSize(cameraInstance.getImageSize(mCamera));
            // cameraDTO.setImagePixcels(cameraInstance.getImagePixel(mCamera));
        }

        return rootView;
    }

    private void initUi(LayoutInflater inflater, ViewGroup container) {
        rootView = inflater.inflate(R.layout.fragment_camera, container, false);
        // Getting ui id's
        flashState = new FlashState(activity);
        saveImageView = (ImageView) rootView.findViewById(R.id.image_show);
        resultTextView = (TextView) rootView.findViewById(R.id.result_text);
        flipButton = (CircleButton) rootView.findViewById(R.id.rotation_button);
        flashButton = (CircleButton) rootView.findViewById(R.id.flash_button);
        informButton = (CircleButton) rootView.findViewById(R.id.inform_button);
        captureButton = (CircleButton) rootView
                .findViewById(R.id.capture_button);
        cameraPreview = new CameraPreview(activity, mCamera, flipFlag);
        cameraLayout = (RelativeLayout) rootView.findViewById(R.id.camera_view);
        resultLayout = (LinearLayout) rootView.findViewById(R.id.result_view);
        frameLayout = (FrameLayout) rootView.findViewById(R.id.camera_preview);
        frameLayout.addView(cameraPreview);
        // registering click listener
        flipButton.setOnClickListener(this);
        flashButton.setOnClickListener(this);
        informButton.setOnClickListener(this);
        captureButton.setOnClickListener(this);
        cameraInstance.setOnImageCapture(this);
        try {
            cameraInstance
                    .showFlashButton(mCamera.getParameters(), flashButton);
        } catch (Exception e) {
            Log.e(TAG, "showFlashButtonException : " + e.toString());
        }

        if (HardwareTestFragment.isAutoStartClicked)
            captureButton.performClick();
    }

    private void initData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
                isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
            }
        }
        activity = getActivity();
        cameraInstance = new KTCamera(activity);
        if (isFromCommand) {
            if (cameraDTO.getType().equals(
                    HardwareUtility.KEY_BACK_CAMERA_HARDWARE)) {
                mCamera = cameraInstance.getBackCameraInstance();
                flipFlag = false;
            } else if (cameraDTO.getType().equals(
                    HardwareUtility.KEY_FRONT_CAMERA_HARDWARE)) {
                mCamera = cameraInstance.getFrontCameraInstance();
                flipFlag = true;
            }
        } else if (HardwareTestFragment.isAutoStartClicked) {
            if (cameraDTO.getType().equals(
                    HardwareUtility.KEY_BACK_CAMERA_HARDWARE)) {
                mCamera = cameraInstance.getBackCameraInstance();
                flipFlag = false;
            } else if (cameraDTO.getType().equals(
                    HardwareUtility.KEY_FRONT_CAMERA_HARDWARE)) {
                mCamera = cameraInstance.getFrontCameraInstance();
                flipFlag = true;
            }
        } else {
            mCamera = cameraInstance.getBackCameraInstance();
        }
        progressDialog = new MyProgressDialog(getActivity());

    }


    // @Override
    // public void onResume() {
    // flipFlag = flipFlag ? false : true;
    // mCamera = cameraInstance.flipcamera(mCamera, cameraPreview,
    // flipFlag);
    // // if (Build.VERSION.SDK_INT >= 24 && Build.VERSION.SDK_INT < 25) {
    // // if (flipFlag)
    // // mCamera.setDisplayOrientation(90);
    // // else
    // // mCamera.setDisplayOrientation(270);
    // //
    // // }
    // if (flipFlag) {
    // cameraInstance.showFlashButton(mCamera.getParameters(),
    // flashButton);
    // } else {
    // cameraInstance.showFlashButton(mCamera.getParameters(),
    // flashButton);
    // }
    // super.onResume();
    // }

    @Override
    public void onClick(View v) {
        performAction(v.getId());
    }

    private void performAction(int id) {
        switch (id) {
            case R.id.rotation_button:
                flipFlag = flipFlag ? false : true;
                mCamera = cameraInstance.flipcamera(mCamera, cameraPreview,
                        flipFlag);
                // if (Build.VERSION.SDK_INT >= 24 && Build.VERSION.SDK_INT < 25) {
                // if (flipFlag)
                // mCamera.setDisplayOrientation(90);
                // else
                // mCamera.setDisplayOrientation(270);
                //
                // }
                if (flipFlag) {
                    cameraInstance.showFlashButton(mCamera.getParameters(),
                            flashButton);
                } else {
                    cameraInstance.showFlashButton(mCamera.getParameters(),
                            flashButton);
                }
                break;
            case R.id.flash_button:
                if (!flashState.isEnable()) {
                    flashState.setEnable(true);
                    flashButton.setImageResource(R.drawable.flash_on);
                } else {
                    flashState.setEnable(false);
                    flashButton.setImageResource(R.drawable.flash_off);
                }
                break;
            case R.id.inform_button:
                Toast.makeText(activity, "Inform Button Clicked!",
                        Toast.LENGTH_SHORT).show();
                break;
            case R.id.capture_button:
                new AsyncTask<String, String, String>() {

                    @Override
                    protected String doInBackground(String... params) {
                        if (HardwareTestFragment.isAutoStartClicked) {
                            try {
                                Thread.sleep(2000);
                            } catch (Exception e) {

                            }
                        }
                        return "";
                    }

                    protected void onPostExecute(String result) {
                        if (!progressDialog.isShowing())
                            progressDialog.show();
                        try {
                            cameraInstance.refreshCamera(mCamera, cameraPreview);
                            cameraInstance.takePicture(mCamera,
                                    activity.getString(R.string.app_name), true,
                                    flashState.isEnable(), flipFlag);

                        } catch (Exception e) {
                            LogWrite.e(TAG,
                                    "cameraInstanceException : " + e.toString());
                        }
                        cameraLayout.setVisibility(View.GONE);
                        resultLayout.setVisibility(View.VISIBLE);
                    }
                }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "");

                break;
            default:
                break;
        }
    }

    @Override
    public void onImageCapture(File file, String reason) {
        try {
            if (reason.equals("success")) {
                if (file != null) {
                    LogWrite.d(TAG, "File Path ::: " + file.getAbsolutePath());
                    Bitmap myBitmap = showBitmapFromFile(file.getAbsolutePath());
                    // Display display = ((WindowManager) activity
                    // .getSystemService(Context.WINDOW_SERVICE))
                    // .getDefaultDisplay();
                    // Toast.makeText(context,
                    // "DeviceRotation : " + display.getRotation(),
                    // Toast.LENGTH_SHORT).show();
                    // if (display.getRotation() == Surface.ROTATION_0) {
                    // myBitmap = RotateBitmap(myBitmap, 90);
                    // }
                    //
                    // if (display.getRotation() == Surface.ROTATION_180) {
                    // myBitmap = RotateBitmap(myBitmap, 270);
                    // }
                    // if (display.getRotation() == Surface.ROTATION_270) {
                    // myBitmap = RotateBitmap(myBitmap, 180);
                    // }

                    // if (!flipFlag) {
                    // if (Build.VERSION.SDK_INT >= 24)
                    // myBitmap = RotateBitmap(myBitmap, 270);
                    // else
                    // myBitmap = RotateBitmap(myBitmap, 90);
                    // } else
                    // myBitmap = RotateBitmap(myBitmap, 270);
                    if (isFromCommand) {
                        try {
                            SendResponse response = new SendResponse(activity,
                                    serverUrl, cameraDTO, myBitmap);
                            response.execute("");
                        } catch (Exception e) {
                            LogWrite.e(TAG,
                                    "ImageByteException : " + e.toString());
                        }
                    } else {
                        Vibrator vibrator = (Vibrator) activity
                                .getSystemService(Context.VIBRATOR_SERVICE);
                        vibrator.vibrate(500);
                        resultTextView.setTextAppearance(getActivity(),
                                R.style.textStyleGreen);
                        resultTextView.setText(R.string.camera_is_working_fine);
                        Drawable ob = new BitmapDrawable(getResources(),
                                myBitmap);
                        saveImageView.setBackgroundDrawable(ob);
                        if (HardwareTestFragment.isAutoStartClicked) {
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
                            if (cameraDTO.getType().equals(
                                    HardwareUtility.KEY_BACK_CAMERA_HARDWARE)) {
                                onAutoHardwareTestListener
                                        .onHardwareTestFinish(10,
                                                "Back Camera", true);
                                getActivity().getSupportFragmentManager()
                                        .beginTransaction()
                                        .remove(CameraTestFragment.this)
                                        .commit();
                                getActivity().getFragmentManager()
                                        .popBackStack();
                            } else {
                                Log.d(TAG,
                                        "--------------------------FRONT SUCCESS");
                                onAutoHardwareTestListener
                                        .onHardwareTestFinish(12,
                                                "Front Camera", true);
                                getActivity().getSupportFragmentManager()
                                        .beginTransaction()
                                        .remove(CameraTestFragment.this)
                                        .commit();
                                getActivity().getFragmentManager()
                                        .popBackStack();
                            }

                        }
                    }
                }
            } else {
                LogWrite.e(TAG, "CameraTestFails!");
                Vibrator vibrator = (Vibrator) activity
                        .getSystemService(Context.VIBRATOR_SERVICE);
                vibrator.vibrate(500);
                resultTextView.setTextAppearance(getActivity(),
                        R.style.textStyleRed);
                resultTextView.setText(getActivity().getString(
                        R.string.camera_is_fail)
                        + " " + reason);
                if (HardwareTestFragment.isAutoStartClicked) {
                    if (progressDialog.isShowing())
                        progressDialog.dismiss();
                    if (cameraDTO.getType().equals(
                            HardwareUtility.KEY_BACK_CAMERA_HARDWARE)) {
                        onAutoHardwareTestListener.onHardwareTestFinish(10,
                                "Back Camera", false);
                        getActivity().getSupportFragmentManager()
                                .beginTransaction()
                                .remove(CameraTestFragment.this).commit();
                        getActivity().getFragmentManager().popBackStack();
                    } else {
                        Log.d(TAG, "--------------------------FRONT FAILED");
                        onAutoHardwareTestListener.onHardwareTestFinish(12,
                                "Front Camera", false);
                        getActivity().getSupportFragmentManager()
                                .beginTransaction()
                                .remove(CameraTestFragment.this).commit();
                        getActivity().getFragmentManager().popBackStack();
                    }

                }

            }
            if (progressDialog.isShowing())
                progressDialog.dismiss();
        } catch (Exception e) {
            LogWrite.e(TAG, "OnImageCaptureException : " + e.toString());
        }
    }

    @Override
    public void onDestroy() {
        cameraInstance.releaseCamera(mCamera);
        super.onDestroy();
    }

    private Bitmap RotateBitmap(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        if (flipFlag)
            matrix.preScale(-1.0f, 1.0f);
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(),
                source.getHeight(), matrix, true);
    }

    private Bitmap decodeFile(String path) {
        Bitmap b = null;
        File f = new File(path);
        // Decode image size
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(f);
            BitmapFactory.decodeStream(fis, null, o);
            fis.close();

            int IMAGE_MAX_SIZE = 1024; // maximum dimension limit
            int scale = 1;
            if (o.outHeight > IMAGE_MAX_SIZE || o.outWidth > IMAGE_MAX_SIZE) {
                scale = (int) Math.pow(
                        2,
                        (int) Math.round(Math.log(IMAGE_MAX_SIZE
                                / (double) Math.max(o.outHeight, o.outWidth))
                                / Math.log(0.5)));
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;

            fis = new FileInputStream(f);
            b = BitmapFactory.decodeStream(fis, null, o2);
            fis.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return b;
    }

    private Bitmap showBitmapFromFile(String file_path) {
        try {
            File imgFile = new File(file_path);
            if (imgFile.exists()) {
                Bitmap pic_Bitmap = decodeFile(file_path);
                ExifInterface exif = new ExifInterface(file_path);
                int exifOrientation = exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL);

                int rotate = 0;

                switch (exifOrientation) {
                    case ExifInterface.ORIENTATION_UNDEFINED:
                        if (Build.BRAND.equals("google")
                                && Build.MODEL.equals("Nexus 5X"))
                            rotate = 270;
                        else
                            rotate = 90;
                        break;

                    case ExifInterface.ORIENTATION_NORMAL:
                        rotate = 90;
                        break;

                    case ExifInterface.ORIENTATION_ROTATE_180:
                        rotate = 270;
                        break;

                    case ExifInterface.ORIENTATION_ROTATE_270:
                        rotate = 180;
                        break;
                }

                if (rotate != 0) {
                    pic_Bitmap = RotateBitmap(pic_Bitmap, rotate);
                    // int w = pic_Bitmap.getWidth();
                    // int h = pic_Bitmap.getHeight();
                    //
                    // // Setting pre rotate
                    // Matrix mtx = new Matrix();
                    // mtx.preRotate(rotate);
                    //
                    // // Rotating Bitmap & convert to ARGB_8888, required by
                    // tess
                    // pic_Bitmap = Bitmap.createBitmap(pic_Bitmap, 0, 0, w, h,
                    // mtx, false);
                    // pic_Bitmap = pic_Bitmap.copy(Bitmap.Config.ARGB_8888,
                    // true);
                }
                return pic_Bitmap;
            }
        } catch (Exception e) {
            LogWrite.e(TAG, "ExceptionDTO showBitmapFromFile");
            return null;
        }
        return null;
    }

    @Override
    public String getTitle() {
        return "Camera";
    }

    private class SendResponse extends AsyncTask<String, String, String> {
        private Context context;
        private String serverUrl;
        private CameraDTO cameraDTO;
        private Bitmap bitmap;
        private boolean responseStatus;

        public SendResponse(Context context, String serverUrl,
                            CameraDTO cameraDTO, Bitmap bitmap) {
            this.context = context;
            this.serverUrl = serverUrl;
            this.cameraDTO = cameraDTO;
            this.bitmap = bitmap;
        }

        @Override
        protected void onPreExecute() {
            LogWrite.i(TAG, "onPreExecute method enters!!");
            LogWrite.d(TAG, cameraDTO.toJson().toString());
        }

        @Override
        protected String doInBackground(String... params) {
            LogWrite.d(TAG, "doInBackground method enters!!");
            bitmap = Bitmap.createScaledBitmap(bitmap, 180, 350, true);

            bitmap = Bitmap.createScaledBitmap(bitmap, 180, 350, true);

            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 60, stream);
            imageArray = stream.toByteArray();
            long sessionId = cameraDTO.getSessionId();
            long messageId = cameraDTO.getMessageId();
            String cameraSelected = cameraDTO.getType();
            int flashStatus = cameraDTO.isFlashStatus() ? 1 : 0;
            int autoFlashStatus = cameraDTO.isAutoFlashStatus() ? 1 : 0;
            int autoFocusStatus = cameraDTO.isAutoFocusStatus() ? 1 : 0;
            String mode = cameraDTO.getMode();
            String pixcels = cameraDTO.getImagePixcels() + "MP";
            String size = cameraDTO.getImageSize();
            LogWrite.d(TAG, sessionId + " :::: " + messageId);

            byte[] byteArrayMessage = (sessionId + "~" + messageId + "~"
                    + cameraSelected + "~" + flashStatus + "~"
                    + autoFlashStatus + "~" + autoFocusStatus + "~" + mode
                    + "~" + pixcels + "~" + size + "\n").getBytes();

            byte[] byteArrayImage = imageArray;

            int total = byteArrayMessage.length + byteArrayImage.length;

            byte[] newByteArray = new byte[total];

            // System.arraycopy(byteArrayMessage, 0, newByteArray, 0,
            // byteArrayMessage.length);
            // System.arraycopy(byteArrayImage, 0, newByteArray,
            // byteArrayMessage.length, byteArrayImage.length);

            for (int i = 0; i < byteArrayMessage.length; i++) {
                newByteArray[i] = byteArrayMessage[i];
            }
            for (int i = byteArrayMessage.length, j = 0; i < byteArrayImage.length; i++, j++) {
                newByteArray[i] = byteArrayImage[j];
            }
            Response response = new Response();
            responseStatus = response.send(context, serverUrl, newByteArray);
            String responseString = responseStatus ? "Success!" : "Fail!";
            LogWrite.e(TAG, "Response " + responseString);
            return "";
        }

        @Override
        protected void onPostExecute(String result) {
            LogWrite.i(TAG, "onPostExecute method enters!!");
            if (responseStatus) {
                Vibrator vibrator = (Vibrator) activity
                        .getSystemService(Context.VIBRATOR_SERVICE);
                vibrator.vibrate(500);
                resultTextView.setTextAppearance(getActivity(),
                        R.style.textStyleGreen);
                resultTextView.setText(R.string.camera_is_working_fine);
                resultTextView.setText(R.string.camera_is_working_fine);
                Drawable ob = new BitmapDrawable(getResources(), bitmap);
                saveImageView.setBackgroundDrawable(ob);
            } else {
                Vibrator vibrator = (Vibrator) activity
                        .getSystemService(Context.VIBRATOR_SERVICE);
                vibrator.vibrate(500);
                resultTextView.setTextAppearance(getActivity(),
                        R.style.textStyleRed);
                resultTextView.setText(R.string.camera_is_working_fine);
                resultTextView.setText(R.string.camera_is_fail);
                Drawable ob = new BitmapDrawable(getResources(), bitmap);
                saveImageView.setBackgroundDrawable(ob);
            }
            FragmentListener fragmentListener = (FragmentListener) getActivity();
            fragmentListener.onItemClicked(FragmentListener.actionRemove,
                    CameraTestFragment.this);
            if (progressDialog.isShowing())
                progressDialog.dismiss();
        }
    }


}
