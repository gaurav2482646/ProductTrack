package com.kochartech.devicemax.Utility;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.http.entity.AbstractHttpEntity;

public class LocationHelperClass extends AbstractHttpEntity{

	protected int myCellID;
    protected int myLAC;

    public LocationHelperClass(int aCellID, int aLAC) {
            this.myCellID = aCellID;
            this.myLAC = aLAC;
    }
	  
	public InputStream getContent() throws IOException, IllegalStateException {
		// TODO Auto-generated method stub
		return null;
	}

	  
	public long getContentLength() {
		// TODO Auto-generated method stub
		return -1;
	}

	  
	public boolean isRepeatable() {
		// TODO Auto-generated method stub
		return true;
	}

	  
	public boolean isStreaming() {
		// TODO Auto-generated method stub
		return false;
	}

	  
	public void writeTo(OutputStream outputStream) throws IOException {
		 DataOutputStream os = new DataOutputStream(outputStream);
         os.writeShort(21);
         os.writeLong(0);
         os.writeUTF("fr");
         os.writeUTF("Sony_Ericsson-K750");
         os.writeUTF("1.3.1");
         os.writeUTF("Web");
         os.writeByte(27);

         os.writeInt(0); os.writeInt(0); os.writeInt(3);
         os.writeUTF("");
         os.writeInt(myCellID); // CELL-ID
         os.writeInt(myLAC); // LAC
         os.writeInt(0); os.writeInt(0);
         os.writeInt(0); os.writeInt(0);
         os.flush();
		
	}

}
