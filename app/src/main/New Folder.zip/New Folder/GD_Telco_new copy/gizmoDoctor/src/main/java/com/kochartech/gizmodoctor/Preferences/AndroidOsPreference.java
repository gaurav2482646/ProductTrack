package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class AndroidOsPreference {
	private final String PREFERENCE_NAME = "gizmodoctor";
	private final int PREFERENCE_MODE = 0;

	private final String KEY_OS_VERSION = "last_os_version";

	private SharedPreferences myPreference;
	private Editor editor;

	public AndroidOsPreference(Context context) {
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();
	}

	public String getLastOsVerison() {
		return myPreference.getString(KEY_OS_VERSION, "");
	}

	public void setOsVersion(String value) {
		editor.putString(KEY_OS_VERSION, value).commit();
	}

	public void reset() {
		editor.clear().commit();
	}

}
