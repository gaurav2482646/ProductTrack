package com.kochartech.devicemax.dto;

/**
 * Created by gauravjeetsingh on 20/3/18.
 */
// This is a part of the command received from the portal
public class ResponseDTO
{
    private String Params;

    private String CommandKey;

    private String MAC;

    public ResponseDTO(String params, String commandKey, String MAC, String messageCommandId) {
        Params = params;
        CommandKey = commandKey;
        this.MAC = MAC;
        MessageCommandId = messageCommandId;
    }

    private String MessageCommandId;

    public String getParams ()
    {
        return Params;
    }

    public void setParams (String Params)
    {
        this.Params = Params;
    }

    public String getCommandKey ()
    {
        return CommandKey;
    }

    public void setCommandKey (String CommandKey)
    {
        this.CommandKey = CommandKey;
    }

    public String getMAC ()
    {
        return MAC;
    }

    public void setMAC (String MAC)
    {
        this.MAC = MAC;
    }

    public String getMessageCommandId ()
    {
        return MessageCommandId;
    }

    public void setMessageCommandId (String MessageCommandId)
    {
        this.MessageCommandId = MessageCommandId;
    }

    @Override
    public String toString()
    {
        return "ResponseDTO [Params = "+Params+", CommandKey = "+CommandKey+", MAC = "+MAC+", MessageCommandId = "+MessageCommandId+"]";
    }
}