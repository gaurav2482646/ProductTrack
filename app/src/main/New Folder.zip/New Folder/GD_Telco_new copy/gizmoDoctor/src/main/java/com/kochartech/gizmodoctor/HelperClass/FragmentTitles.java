package com.kochartech.gizmodoctor.HelperClass;

public class FragmentTitles {
	public static final String GPS_TEST = "GPS Test";
	public static final String HARDWARE_TEST = "Hardware Test";
	public static final String SOFTWARE_KEY_TEST = "Software Key Test";
	public static final String SETTINGS = "Settings";
	public static final String POWERSAVING_SETTINGS = "Power Saving Settings";
	public static final String CUSTOMSAVING_SETTINGS = "Custom Power Saving Settings";
	public static final String NOTIFICATION = "Notifications";
	
}
