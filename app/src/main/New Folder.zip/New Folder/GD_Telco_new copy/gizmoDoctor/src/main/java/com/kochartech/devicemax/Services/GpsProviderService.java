package com.kochartech.devicemax.Services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;

@SuppressWarnings("deprecation")
public class GpsProviderService extends Service {
	String tag = "GpsProviderService";

	@Override
	public void onCreate() {
		LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
			try {
				LogWrite.d(tag, "Network Provider");
				locationManager.requestLocationUpdates(
						LocationManager.NETWORK_PROVIDER, 1000, 10,
						new LocationListener() {
							public void onStatusChanged(String provider,
									int status, Bundle extras) {

							}

							public void onProviderEnabled(String provider) {

							}

							public void onProviderDisabled(String provider) {

							}

							public void onLocationChanged(Location location) {
								String locationCoordinates = "";
								double latitude;
								double longitude;
								try {

									latitude = location.getLatitude();
									longitude = location.getLongitude();
									LogWrite.d(tag, "onLocationChanged Work");
									// Toast.makeText(getApplicationContext(),
									// "Latitude is " + latitude +
									// "\nLongitude is "+ longitude,
									// Toast.LENGTH_SHORT).show();
									// String currentLocation =
									// getUserLocation(""+ latitude,
									// ""+longitude);
									// LogWrite.d(tag, "Current Location is " +
									// currentLocation);
									// Toast.makeText(getApplicationContext(),
									// "Current Location is " + currentLocation,
									// Toast.LENGTH_SHORT).show();
									// String latitudeLongiTude=0+"~"+0;
									// latitudeLongiTude =
									// location.getLatitude()+"~"+location.getLongitude();
									// LogWrite.d(tag,"latitudeLongiTude = "+latitudeLongiTude);
								} catch (Exception e) {
									LogWrite.d(tag, "Location ExceptionDTO ---> "
											+ e.toString());
								}
							}
						});
			} catch (Exception e) {
				LogWrite.d(tag,
						"NETWORK_PROVIDER ExceptionDTO ---> " + e.toString());
			}
		}
		super.onCreate();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		return Service.START_STICKY;
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	/**
	 * Retrieves User Location Address by manipulating Latitude & longitude.
	 * 
	 * @param lat
	 * @param lon
	 * @return String
	 */
	public static String getUserLocation(String lat, String lon) {
		String userlocation = null;
		String readUserFeed = readUserLocationFeed(lat.trim() + ","
				+ lon.trim());
		try {
			JSONObject Strjson = new JSONObject(readUserFeed);
			JSONArray jsonArray = new JSONArray(Strjson.getString("results"));
			userlocation = jsonArray.getJSONObject(1)
					.getString("formatted_address").toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Log.i("User Location ", userlocation);
		return userlocation;
	}

	public static String readUserLocationFeed(String address) {
		String TAG = "readUserLocationFeed";
		StringBuilder builder = new StringBuilder();
		HttpClient client = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(
				"http://maps.google.com/maps/api/geocode/json?latlng="
						+ address + "&sensor=false");
		try {

			HttpResponse response = client.execute(httpGet);
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			if (statusCode == 200) {
				HttpEntity entity = response.getEntity();
				InputStream content = entity.getContent();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(content));
				String line;
				while ((line = reader.readLine()) != null) {
					builder.append(line);
				}
			} else {
				LogWrite.d(TAG, "Failed to download file");
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return builder.toString();
	}
}
