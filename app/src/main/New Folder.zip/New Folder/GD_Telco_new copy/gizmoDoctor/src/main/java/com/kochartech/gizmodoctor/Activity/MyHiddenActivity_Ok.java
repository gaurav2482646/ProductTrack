package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;

public class MyHiddenActivity_Ok extends Activity {
	// private String tag = "MyHiddenActivity_Ok";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		try {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.myhiddenactivity_ok);
			// getIntent().hasExtra("usermsg")?getIntent().getExtras().getString("usermsg")
			String messageToDisplay = getIntent().getExtras().getString(
					"usermsg");
			((TextView) findViewById(R.id.myhiddenactiviyok_textview_usermessage))
					.setText(messageToDisplay);

		} catch (Exception e) {
		}
	}

	public void onClick(View view) {
		finish();
	}
}
