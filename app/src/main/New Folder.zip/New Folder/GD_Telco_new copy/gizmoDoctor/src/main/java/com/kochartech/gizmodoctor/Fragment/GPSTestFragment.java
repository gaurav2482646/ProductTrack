package com.kochartech.gizmodoctor.Fragment;

import java.math.BigDecimal;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Adapter.MobileInfoAdapter;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.HelperClass.FragmentTitles;
import com.kochartech.gizmodoctor.gpshelper.LocationTracker;
import com.kochartech.library.Device.KTDeviceInfo;

public class GPSTestFragment extends Fragment implements MyFragment {
	private String TAG = GPSTestFragment.class.getSimpleName();
	private View rootView;
	private Context context;
	private ListView deviceInfoListView;
	private String[] infoTypeStringAraay = { "Latitude", "Longitude",
			"Altitude", "Speed", "Bearing", "Accuracy", "Satellite",
			"Current Location" };
	private String[] infoValueStringArray = { "NA", "NA", "NA", "NA", "NA",
			"NA", "NA", "NA" };
	private MobileInfoAdapter deviceInfoAdapter;

	private LocationTracker tracker;
	private KTDeviceInfo deviceInfo;

	private static MyProgressDialog myprogressDialog;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		deviceInfo = new KTDeviceInfo(context);
		deviceInfoAdapter = new MobileInfoAdapter(context, infoTypeStringAraay,
				infoValueStringArray, true);
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_gps, container, false);
		deviceInfoListView = (ListView) rootView
				.findViewById(R.id.deviceInfolistView);
		deviceInfoListView.setAdapter(deviceInfoAdapter);
		CheckGPSAsync async = new CheckGPSAsync();
		async.execute("");

		myprogressDialog = new MyProgressDialog(getActivity());
		LogWrite.i(TAG, "Progress Dialog showing....");
		myprogressDialog.show();
	}

	@Override
	public String getTitle() {
		return FragmentTitles.GPS_TEST;
	}

	// public String speed = "0.0 m/s";
	// public String altitude = "0.0 m";
	// public float bearing = 0;
	// public float accuracy = 0;
	private class CheckGPSAsync extends AsyncTask<String, String, String> {
		private boolean gpsEnable = false;
		private double latitude;
		private double longitude;
		private int no_of_satellites;
		private String speed;
		private String altitude;
		private float bearing;
		private float accuracy;
		private String current_location;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();
		}

		@Override
		protected synchronized String doInBackground(String... params) {
			while (!gpsEnable) {
				gpsEnable = deviceInfo.isGPSEnabled();
				if (!gpsEnable)
					publishProgress("disable");
				sleep(5000);

			}
			if (gpsEnable) {
				publishProgress("enable");
				sleep(15000);
				latitude = tracker.latitude;
				longitude = tracker.longitude;
				no_of_satellites = tracker.no_of_satellites;
				speed = tracker.speed;
				altitude = tracker.altitude;
				bearing = tracker.bearing;
				accuracy = tracker.accuracy;
				LogWrite.d(TAG, "Latitude : " + latitude);
				LogWrite.d(TAG, "Longitude : " + longitude);
				LogWrite.d(TAG, "NumberofSatellites : " + no_of_satellites);
				LogWrite.d(TAG, "Speed : " + speed);
				LogWrite.d(TAG, "Altitude : " + altitude);
				LogWrite.d(TAG, "Bearing : " + bearing);
				current_location = "UNKNOWN";
				try {
					current_location = tracker.getLocationInString(""
							+ latitude, "" + longitude);
				} catch (Exception e) {
					e.printStackTrace();
				}
				LogWrite.d(TAG, "CurrentLocation : " + current_location);
			}
			return "";
		}

		@Override
		protected void onProgressUpdate(String... values) {
			if (values[0].equals("disable")) {
				Intent locationIntent = new Intent(
						Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				locationIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
						| Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(locationIntent);
			} else if (values[0].equals("enable")) {
				tracker = new LocationTracker(context);
			}
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(String result) {
			try {
				infoValueStringArray[0] = "" + round(latitude, 2);
			} catch (Exception e) {
				infoValueStringArray[0] = "NA";
			}
			try {
				infoValueStringArray[1] = "" + round(longitude, 2);
			} catch (Exception e) {
				infoValueStringArray[1] = "NA";
			}
			try {
				String[] altitudeArray = altitude.split(" ");
				double altitudeDouble = Double.parseDouble(altitudeArray[0]);
				infoValueStringArray[2] = "" + round(altitudeDouble, 2) + " "
						+ altitudeArray[1];
			} catch (NumberFormatException e) {
				infoValueStringArray[2] = "NA";
			}
			try {
				String[] speedArray = speed.split(" ");
				double speedDouble = Double.parseDouble(speedArray[0]);
				infoValueStringArray[3] = "" + round(speedDouble, 2) + " "
						+ speedArray[1];
			} catch (NumberFormatException e) {
				infoValueStringArray[3] = "NA";
			}
			try {
				infoValueStringArray[4] = "" + round(bearing, 2);
			} catch (Exception e) {
				infoValueStringArray[4] = "NA";
			}
			try {
				infoValueStringArray[5] = "" + accuracy;
			} catch (Exception e) {
				infoValueStringArray[5] = "NA";
			}
			try {
				infoValueStringArray[6] = "" + no_of_satellites;
			} catch (Exception e) {
				infoValueStringArray[6] = "NA";
			}
			try {
				infoValueStringArray[7] = current_location;
			} catch (Exception e) {
				infoValueStringArray[7] = "UNKNOWN";
			}
			deviceInfoAdapter.notifyDataSetChanged();
			myprogressDialog.dismiss();
			super.onPostExecute(result);
		}
	}

	/**
	 * Round to certain number of decimals
	 * 
	 * @param d
	 * @param decimalPlace
	 * @return
	 */
	public static float round(double d, int decimalPlace) {
		BigDecimal bd = new BigDecimal(Double.toString(d));
		bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
		return bd.floatValue();
	}

	private void sleep(long seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
