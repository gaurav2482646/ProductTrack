//package com.kochartech.gizmodoctor.HelperClass;
//
//import java.io.File;
//import java.text.DecimalFormat;
//import java.util.ArrayList;
//
//import android.content.Context;
//import android.os.Environment;
//import android.os.StatFs;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//
//public class InternalMemory {
//	private static String tag = "InternalMemory";
//
//	// public static boolean isOk(DeviceSettingManager deviceSettingsManager,
//	// boolean scanInternal) {
//	// boolean flag = false;
//	// //LogWrite.d(tag,"getExternalStorage = "+
//	// Environment.getExternalStorageDirectory());
//	// String interStoragePath = null;
//	// if (scanInternal)
//	// interStoragePath = getInternalStoragePath();
//	// else
//	// interStoragePath = getExternalStoragePath();
//	// Logger.d(tag, "Internal Storage Path = " + interStoragePath);
//	// int internal_percent = 0;
//	// if (interStoragePath != null) {
//	// StatFs internalStorageFs = new StatFs(interStoragePath);
//	// long bytesAvailable = (long) internalStorageFs.getFreeBlocks()
//	// * (long) internalStorageFs.getBlockSize();
//	// long totalMemory = (long) internalStorageFs.getBlockCount()
//	// * (long) internalStorageFs.getBlockSize();
//	// long freeMemory = bytesAvailable / 1048576;
//	// long mbTotal = totalMemory / 1048576;
//	// Logger.d(tag, "mbTotal = " + mbTotal);
//	// Logger.d(tag, "freeMemory = " + freeMemory);
//	// if (mbTotal > 0) {
//	// internal_percent = (int) ((freeMemory * 100) / mbTotal);
//	// //LogWrite.d(tag, "internal_percent = " + internal_percent);
//	// if (scanInternal)
//	// flag = internal_percent > deviceSettingsManager
//	// .getInternalStorage_Limit_Preferences();
//	// else
//	// flag = internal_percent > deviceSettingsManager
//	// .getExternalStorage_Limit_Preferences();
//	//
//	// //LogWrite.d(tag, "Response = " + flag);
//	// }
//	// } else {
//	// /*
//	// * Method unable to find the specified path for the specified
//	// * storage. I consider storage is not present. so result is true.
//	// * means it does not exceed specified limit .
//	// */
//	// flag = true;
//	// }
//	// return flag;
//	// }
//
//	private static String getInternalStoragePath() {
//
//		String tag = "getInternalStoragePath";
//		String responsePath = null;
//
//		ArrayList<File> selected_ExternalStorages = new ArrayList<File>();
//		File externalStorage = Environment.getExternalStorageDirectory();
//
//		File rootOf_externalStorage = externalStorage.getParentFile();
//		File[] listOf_externalStorages = rootOf_externalStorage.listFiles();
//
//		// LogWrite.d(tag, "External Storage = " +
//		// listOf_externalStorages.length);
//		/*
//		 * 
//		 * we select the storages that has writable permission.
//		 */
//		for (File storage : listOf_externalStorages) {
//
//			// LogWrite.d(tag, "storage = " + storage.getPath());
//			// LogWrite.d(tag, "storage can write= " + storage.canWrite());
//			if (storage.canWrite()) {
//				selected_ExternalStorages.add(storage);
//				// Logger.d(tag, "Selected Path= " + storage.getPath());
//			}
//		}
//
//		/*
//		 * 
//		 * from selected_ExternalStorages select phones inbuild storage.
//		 */
//
//		int countExternalStorage = selected_ExternalStorages.size();
//		// LogWrite.d(tag, "countExternalStorage =" + countExternalStorage);
//
//		boolean isExternalStorageRemovable = false;
//		if (android.os.Build.VERSION.SDK_INT >= 9) {
//			isExternalStorageRemovable = Environment
//					.isExternalStorageRemovable();
//			// LogWrite.d(tag, "isExternalStorageRemovable =" +
//			// isExternalStorageRemovable);
//		}
//		// //LogWrite.d(tag,"isExternalStorageEmulated ="+Environment.isExternalStorageEmulated());
//		// if(countExternalStorage == 0)
//		// {
//		// // return "";
//		// }
//		if (countExternalStorage == 1) {
//			// if(isExternalStorageRemovable)
//			// return "";
//			// else
//			// return selected_ExternalStorages.get(0).getPath();
//
//			if (!isExternalStorageRemovable)
//				responsePath = Environment.getExternalStorageDirectory()
//						.getPath();
//
//		} else if (selected_ExternalStorages.size() == 2) {
//
//			if (isExternalStorageRemovable) {
//				String sdCardPath = Environment.getExternalStorageDirectory()
//						.getPath();
//				for (File storage : selected_ExternalStorages) {
//					if (!storage.getPath().equalsIgnoreCase(sdCardPath)) {
//						responsePath = storage.getPath();
//					}
//				}
//			} else {
//				/*
//				 * Means External Storage is Not removeable.
//				 */
//				responsePath = Environment.getExternalStorageDirectory()
//						.getPath();
//			}
//		}
//		// LogWrite.d(tag, "responsePath = " + responsePath);
//		return responsePath;
//	}
//
//	public static String getExternalStoragePath() {
//		String tag = "getExternalStoragePath";
//		String responsePath = null;
//
//		ArrayList<File> selected_ExternalStorages = new ArrayList<File>();
//		File externalStorage = Environment.getExternalStorageDirectory();
//		File rootOf_externalStorage = externalStorage.getParentFile();
//		File[] listOf_externalStorages = rootOf_externalStorage.listFiles();
//
//		/*
//		 * 
//		 * we select the storages that has writable permission.
//		 */
//		for (File storage : listOf_externalStorages) {
//			if (storage.canWrite()) {
//				selected_ExternalStorages.add(storage);
//			}
//		}
//
//		/*
//		 * 
//		 * from selected_ExternalStorages select phones inbuild storage.
//		 */
//
//		int countExternalStorage = selected_ExternalStorages.size();
//		// LogWrite.d(tag, "countExternalStorage =" + countExternalStorage);
//
//		boolean isExternalStorageRemovable = false;
//		if (android.os.Build.VERSION.SDK_INT >= 9) {
//			isExternalStorageRemovable = Environment
//					.isExternalStorageRemovable();
//			// LogWrite.d(tag, "isExternalStorageRemovable ="+
//			// isExternalStorageRemovable);
//		}
//
//		// if(countExternalStorage == 0)
//		// {
//		// // return "";
//		// }
//		if (countExternalStorage == 1) {
//			// if(isExternalStorageRemovable)
//			// return "";
//			// else
//			// return selected_ExternalStorages.get(0).getPath();
//
//			if (isExternalStorageRemovable)
//				responsePath = Environment.getExternalStorageDirectory()
//						.getPath();
//
//		} else if (selected_ExternalStorages.size() == 2) {
//
//			if (!isExternalStorageRemovable) {
//				String sdCardPath = Environment.getExternalStorageDirectory()
//						.getPath();
//				for (File storage : selected_ExternalStorages) {
//					if (!storage.getPath().equalsIgnoreCase(sdCardPath)) {
//						responsePath = storage.getPath();
//					}
//				}
//			} else {
//				responsePath = Environment.getExternalStorageDirectory()
//						.getPath();
//			}
//		}
//		// LogWrite.d(tag, "responsePath = " + responsePath);
//		return responsePath;
//	}
//
//	public static String getTotalStorageCapacity(Context context) {
//		float totalCapacity = 0;
//		float internalCapacity = 0;
//		float externalCapacity = 0;
//		float totalInternal = 0, totalexternal = 0, freeInternal = 0, freeExternal = 0;
//
//		String interStoragePath = getInternalStoragePath();
//		LogWrite.d(tag, "interStoragePath =" + interStoragePath);
//		String externalStoragePath = getExternalStoragePath();
//		LogWrite.d(tag, "externalStoragePath =" + externalStoragePath);
//
//		if (interStoragePath != null) {
//			StatFs internalStorageFs = new StatFs(interStoragePath);
//
//			freeInternal = (long) internalStorageFs.getFreeBlocks()
//					* (long) internalStorageFs.getBlockSize();
//			totalInternal = (long) internalStorageFs.getBlockCount()
//					* (long) internalStorageFs.getBlockSize();
//
//			internalCapacity = totalInternal / 1048576;
//
//			LogWrite.d(tag, "internalCapacity = " + internalCapacity);
//
//		}
//		if (externalStoragePath != null) {
//			StatFs internalStorageFs = new StatFs(externalStoragePath);
//			freeExternal = (long) internalStorageFs.getFreeBlocks()
//					* (long) internalStorageFs.getBlockSize();
//			totalexternal = (long) internalStorageFs.getBlockCount()
//					* (long) internalStorageFs.getBlockSize();
//
//			externalCapacity = totalexternal / 1048576;
//
//			// Logger.d(tag,"externalCapacity = "+externalCapacity);
//			LogWrite.d(tag, "externalCapacity =" + externalCapacity);
//		}
//
//		if (totalInternal == totalexternal & freeInternal == freeExternal) {
//			totalCapacity = (float) internalCapacity;
//		} else {
//			totalCapacity = (float) internalCapacity + externalCapacity;
//		}
//
//		// Logger.d(tag,"totalCapacity = "+totalCapacity);
//		totalCapacity = totalCapacity / 1024;
//		// Logger.d(tag,"totalCapacity = "+totalCapacity);
//		return new DecimalFormat("##.##").format(totalCapacity);
//	}
//}
