package com.kochartech.devicemax.Activities;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

public class MyLocationListener implements LocationListener
{
	private static String tag = "MyLocationListener";
	private static MyLocationListener classInstance ;
	private static LocationManager locationManager;
	private MyLocationListener() {}
	public static MyLocationListener getInstance(Context context) {
		if(classInstance==null)
		{
			classInstance = new MyLocationListener();
			locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);			
		}
		return classInstance;
	}
	
	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		final Location tempLocation = location;
		new Thread(new Runnable() {			
			public void run() {
				// TODO Auto-generated method stub
				LogWrite.d(tag,"onLocationChanged Work");
				String latitudeLongiTude=0+"~"+0;
				latitudeLongiTude = tempLocation.getLatitude()+"~"+tempLocation.getLongitude();
				LogWrite.d(tag,"latitudeLongiTude = "+latitudeLongiTude);
				
				MDMMainActivity.GetIns().sendLocationFromMyLocationListener(latitudeLongiTude);
			}
		}).start();
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}
	public static void getLocation()
	{
		LogWrite.d("Loc--","1");	
		try
		{
			locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 10, classInstance);
		}
		catch(Exception e)
		{
			LogWrite.d("Loc--","ExceptionDTO-"+e);
		}
		LogWrite.d("Loc--","2");
	}

}
