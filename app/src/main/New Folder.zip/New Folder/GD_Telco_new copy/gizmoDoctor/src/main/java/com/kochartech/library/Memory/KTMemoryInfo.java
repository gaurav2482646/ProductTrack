package com.kochartech.library.Memory;

public class KTMemoryInfo {
	private float total, free, used;

	/**
	 * This Method returns Total RAM Usage of device.
	 * 
	 * @return TotalRAMUsage
	 */
	public float getTotal() {
		return total;
	}

	/**
	 * This method set Total RAM Usage.
	 * 
	 * @param total
	 */
	public void setTotal(float total) {
		this.total = total;
	}

	/**
	 * This Method returns Free RAM Usage of Device.
	 * 
	 * @return FreeRAMUsage
	 */
	public float getFree() {
		return free;
	}

	/**
	 * This Method set Free RAM Usage.
	 * 
	 * @param free
	 */
	public void setFree(float free) {
		this.free = free;
	}

	/**
	 * This Method returns Used RAM Usage of Device.
	 * 
	 * @return UsedRAMUsage
	 */
	public float getUsed() {
		return used;
	}

	/**
	 * This Method set Used RAM Usage.
	 * 
	 * @param used
	 */
	public void setUsed(float used) {
		this.used = used;
	}

	/**
	 * This Method returns Used RAM usage in Percentage.
	 * 
	 * @return UsedRAMPercentage
	 */
	public int getUsedInPercentage() {
		return (int) ((used / total) * 100);
	}
}