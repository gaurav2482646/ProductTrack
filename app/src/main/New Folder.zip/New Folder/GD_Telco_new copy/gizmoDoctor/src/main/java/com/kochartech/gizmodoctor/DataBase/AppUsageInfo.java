package com.kochartech.gizmodoctor.DataBase;

import java.util.ArrayList;

import com.kochartech.gizmodoctor.POJO.AppUsageDTO;

public class AppUsageInfo {
	private int appId;
	private ArrayList<AppUsageDTO> appUsage = new ArrayList<AppUsageDTO>();

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public ArrayList<AppUsageDTO> getAppUsage() {
		return appUsage;
	}

	public void setAppUsage(ArrayList<AppUsageDTO> appUsage) {
		this.appUsage = appUsage;
	}
}
