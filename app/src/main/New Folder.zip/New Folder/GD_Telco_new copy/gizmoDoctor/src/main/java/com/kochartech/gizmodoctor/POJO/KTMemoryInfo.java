//package com.kochartech.gizmodoctor.POJO;
//
//public class KTMemoryInfo 
//{
//	private float total,free,used,freeInPercentage;
//
//	
//	public float getTotal() {
//		return total;
//	}
//
//	public void setTotal(float total) {
//		this.total = total;
//	}
//
//	public float getFree() {
//		return free;
//	}
//
//	public void setFree(float free) {
//		this.free = free;
//	}
//
//	public float getUsed() {
//		return used;
//	}
//
//	public void setUsed(float used) {
//		this.used = used;
//	}
//
//	public int getUsedInPercentage() {
//		return (int)((free/total)*100);
//	}	
//}	