package com.kochartech.gizmodoctor.Fragment;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.os.Vibrator;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.CustomView.SoundLevelView;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
import com.kochartech.gizmodoctor.HardwareModel.SoundMeter;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;

public class SoundTestActivity extends ActionBarActivity implements OnClickListener {
	private String TAG = SoundTestActivity.class.getSimpleName();

	private boolean isFromCommand = false;

	private Context context;

	private TextView messageTextView;

	private Button okButton, playButton;

	private CircularProgressBar timerProgress;

	private boolean success = false;
	private String FAILURE_MESSAGE = "Press OK if speaker test not working";

	private static OnCommandListener onCommandListener;
	private static OnAutoHardwareTestListener onAutoHardwareTestListener;

	// Sound test parameters
	/* constants */

	private MediaPlayer player = null;

	private static final int POLL_INTERVAL = 300;

	/** running state **/
	private boolean mRunning = false;

	/** config state **/
	private int mThreshold;

	private PowerManager.WakeLock mWakeLock;

	private Handler mHandler = new Handler();

	private SoundLevelView mDisplay;

	/* sound data source */
	private SoundMeter mSensor;

	private int count = 0;
	/****************** Define runnable thread again and again detect noise *********/

	private boolean mPollTaskStatus = true;

	private Runnable mSleepTask = new Runnable() {
		public void run() {
			Log.i(TAG, "runnable mSleepTask");
			start();
		}
	};

	// Create runnable thread to Monitor Voice
	private Runnable mPollTask = new Runnable() {
		public void run() {

			double amp = 0;
			try {
				amp = mSensor.getAmplitude();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			LogWrite.i(TAG, "runnable mPollTask");
			LogWrite.i(TAG, "AMP : " + amp);
			updateDisplay("Monitoring Voice...", amp);

			if ((amp > mThreshold)) {
				count++;
				if (count >= 10) {
					mPollTaskStatus = false;
					callForHelp();
				}
				// Log.i("Noise", "==== onCreate ===");
			}
			if (mPollTaskStatus) {
				// Runnable(mPollTask) will again execute after POLL_INTERVAL
				mHandler.postDelayed(mPollTask, POLL_INTERVAL);
			}
		}
	};

	public static void startActivity(Context context, String keyToCheck,
			boolean isFromCommand, OnCommandListener onCommandListener,
			OnAutoHardwareTestListener onAutoHardwareTestListener) {
		// Build extras with passed in parameters
		Bundle extras = new Bundle();
		extras.putString("HardwareTest", keyToCheck);
		extras.putBoolean("IsFromCommand", isFromCommand);
		SoundTestActivity.onCommandListener = onCommandListener;
		SoundTestActivity.onAutoHardwareTestListener = onAutoHardwareTestListener;
		// Create and start intent for this activity
		Intent intent = new Intent(context, SoundTestActivity.class);
		intent.putExtras(extras);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		setContentView(R.layout.activity_speaker_test);
		getSupportActionBar().setTitle("Speaker");
		isFromCommand = getIntent().getExtras().getBoolean("IsFromCommand");
		context = SoundTestActivity.this;
		messageTextView = (TextView) findViewById(R.id.textView);
		messageTextView.setText(R.string.speaker_screen);
		okButton = (Button) findViewById(R.id.ok_button);
		playButton = (Button) findViewById(R.id.button_play);
		okButton.setOnClickListener(this);
		playButton.setOnClickListener(this);
		timerProgress = (CircularProgressBar) findViewById(R.id.circularprogressbar2);
		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {

			@Override
			public void onAnimationStart() {
			}

			@Override
			public void onAnimationProgress(int progress) {
				timerProgress.setTitle(progress + "");
				timerProgress.setSubTitle("");
			}

			@Override
			public void onAnimationFinish() {
				if (!success) {
					messageTextView.setText(FAILURE_MESSAGE);
					messageTextView.setTextAppearance(context,
							R.style.textStyleRed);
					okButton.setVisibility(View.VISIBLE);
					timerProgress.setSubTitle("");
					timerProgress.setVisibility(View.GONE);
					playButton.setVisibility(View.GONE);
					mDisplay.setVisibility(View.GONE);
				}
			}
		});

		// Used to record voice
		mSensor = new SoundMeter();
		mDisplay = (SoundLevelView) findViewById(R.id.volume);

		PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK,
				"NoiseAlert");
		
		if(HardwareTestFragment.isAutoStartClicked) {
			playButton.performClick();
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		LogWrite.d(TAG, "OnResume Method Enters..");
		initializeApplicationConstants();
		mDisplay.setLevel(0, mThreshold);
	}

	@Override
	public void onStop() {
		super.onStop();
		stop();

	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (null != player) {
			player.release();
		}
		stop();
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.ok_button) {
			Vibrator vibrator = (Vibrator) context
					.getSystemService(Context.VIBRATOR_SERVICE);
			vibrator.vibrate(500);
			messageTextView.setText("Speaker test fails.");
			if(HardwareTestFragment.isAutoStartClicked) {
				onAutoHardwareTestListener.onHardwareTestFinish(9, "Sound Test", false);
				SoundTestActivity.this.finish();
			}
			
			if (isFromCommand) {
				onCommandListener.onCommand(false);
				SoundTestActivity.this.finish();
			}
			okButton.setVisibility(View.GONE);
		} else if (v.getId() == R.id.button_play) {
			playMusic(context);
			playButton.setVisibility(View.GONE);
		}
	}

	private void start() {
		// Log.i("Noise", "==== start ===");

		mSensor.start();
		if (!mWakeLock.isHeld()) {
			mWakeLock.acquire();
		}

		// Noise monitoring start
		// Runnable(mPollTask) will execute after POLL_INTERVAL
		mHandler.postDelayed(mPollTask, POLL_INTERVAL);
	}

	private void stop() {
		Log.i("Noise", "==== Stop Noise Monitoring===");
		if (mWakeLock.isHeld()) {
			mWakeLock.release();
		}
		mHandler.removeCallbacks(mPollTask);
		mHandler.removeCallbacks(mSleepTask);
		try {
			mSensor.stop();
		} catch (Exception e) {
			e.printStackTrace();
		}
		mDisplay.setLevel(0, 0);
		updateDisplay("stopped...", 0.0);
		mHandler = new Handler();
		mRunning = false;

	}

	private void initializeApplicationConstants() {
		// Set Noise Threshold
		mThreshold = 1;

	}

	private void updateDisplay(String status, double signalEMA) {

		//
		mDisplay.setLevel((int) signalEMA, mThreshold);
	}

	private void callForHelp() {
		player.stop();
		player.release();
		stop();
		LogWrite.i(TAG, "Sound Test Success!");
		Vibrator vibrator = (Vibrator) context
				.getSystemService(Context.VIBRATOR_SERVICE);
		vibrator.vibrate(500);
		timerProgress.setVisibility(View.GONE);
		mDisplay.setVisibility(View.GONE);
		messageTextView.setText(R.string.speaker_is_working_fine);
		messageTextView.setTextAppearance(this, R.style.textStyleGreen);
		if (isFromCommand) {
			onCommandListener.onCommand(true);
			SoundTestActivity.this.finish();
		}
		
		if(HardwareTestFragment.isAutoStartClicked) {
			onAutoHardwareTestListener.onHardwareTestFinish(9, "Sound Test", true);
			SoundTestActivity.this.finish();
		}
		success = true;

	}

	private void playMusic(Context context) {
		if (player != null)
			player.release();

		player = MediaPlayer.create(this, R.raw.siren);
		player.setVolume(1f, 1f);
		player.setLooping(false);
		try {
			AudioManager audioManager = (AudioManager) context
					.getSystemService(Context.AUDIO_SERVICE);
			audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 20, 0);
			player.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// if (player.isPlaying()) {
		if (!mRunning) {
			mRunning = true;
			start();
		}
		// }
	}

}
