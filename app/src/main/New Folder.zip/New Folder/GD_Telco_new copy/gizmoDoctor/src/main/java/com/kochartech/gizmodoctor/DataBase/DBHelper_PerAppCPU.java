//package com.kochartech.gizmodoctor.DataBase;
//
//import java.util.List;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//import com.kochartech.gizmodoctor.HelperClass.PkgManagerHelper;
//
//import android.content.ContentValues;
//import android.content.Context;
//import android.content.pm.PackageManager;
//import android.content.pm.ResolveInfo;
//import android.database.Cursor;
//import android.database.SQLException;
//import android.database.sqlite.SQLiteDatabase;
//import android.util.Log;
//
//public class DBHelper_PerAppCPU {
//	private String tag = "CPUUsagePerAppDBHelper";
//	private Context context;
//	private static DBHelper_PerAppCPU classInstance = null;
//	private MySQLiteOpenHelper mySQLiteOpenHelper;
//	private SQLiteDatabase db;
//
//	public static DBHelper_PerAppCPU getInstance(Context context) {
//		if (classInstance == null)
//			classInstance = new DBHelper_PerAppCPU(context);
//		return classInstance;
//	}
//
//	private DBHelper_PerAppCPU(Context context) {
//		LogWrite.d(tag, "constructor");
//		this.context = context;
//		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
//	}
//
//	public void open() {
//		LogWrite.d(tag, "open");
//		db = mySQLiteOpenHelper.getWritableDatabase();
//	}
//
//	public void close() {
//		LogWrite.d(tag, "close");
//		db.close();
//	}
//
//	public Cursor getAllColumns() {
//		Cursor cursor = db.query(MySQLiteOpenHelper.CPUUsagePerApp_TableName,
//				null, null, null, null, null, null);
//		if (cursor.getCount() > 0) {
//			
//			LogWrite.d(tag, "Cursor Size :" + cursor.getCount());
//			if (cursor.moveToFirst()) {
//				do {
//					String appName = cursor
//							.getString((cursor
//									.getColumnIndex(MySQLiteOpenHelper.CPUUsagePerApp_ColumnAppName)));
//					float usage = cursor
//							.getFloat(cursor
//									.getColumnIndex(MySQLiteOpenHelper.CPUUsagePerApp_ColumnUsage));
//
//					LogWrite.d(tag, "getAllColumns () : appName :" + appName);
//					LogWrite.d(tag, "getAllColumns () : usage :" + usage);
//
//				} while (cursor.moveToNext());
//			}
//		}
//		return cursor;
//	}
//	
//	public void updateRow(String appName, float cpuUsage)
//	{
//		LogWrite.d(tag,"updateRow () : appName :"+appName);
//		LogWrite.d(tag,"updateRow () : cpuUsage :"+cpuUsage);
//		
//		ContentValues values = new ContentValues();		
//		values.put(MySQLiteOpenHelper.CPUUsagePerApp_ColumnUsage, cpuUsage);
//		
//		int id = db.update(MySQLiteOpenHelper.CPUUsagePerApp_TableName, values,
//				MySQLiteOpenHelper.CPUUsagePerApp_ColumnAppName + "=?",
//				new String[] {appName});
//		
//		LogWrite.d(tag,"updateRow () : affected Rows :"+id);
//		
//	}
//
//	public void init(SQLiteDatabase db) {
//		PkgManagerHelper pkgMangerHelper = new PkgManagerHelper(context);
//		PackageManager pkgManager = pkgMangerHelper.getPackageManager();
//		List<ResolveInfo> resolveInfoList = pkgMangerHelper.getLauncherApps();
//		for (ResolveInfo resolveInfo : resolveInfoList) {
//			String appName = resolveInfo.activityInfo.applicationInfo
//					.loadLabel(pkgManager).toString();
//
//			ContentValues values = new ContentValues();
//			values.put(MySQLiteOpenHelper.CPUUsagePerApp_ColumnAppName, appName);
//			values.put(MySQLiteOpenHelper.CPUUsagePerApp_ColumnUsage, 0);
//			long id = -1;
//			try {
//				id = db.insertOrThrow(
//						MySQLiteOpenHelper.CPUUsagePerApp_TableName, null,
//						values);
//				LogWrite.d(tag, "init() insert Id: " + id);
//			} catch (SQLException e) {
//				LogWrite.d(tag, "ExceptionDTO...: " + e);
//			}
//		}
//	}
//}
//
////package com.kochartech.gizmodoctor.DataBase;
////
////import java.util.List;
////
////import com.kochartech.devicemax.Activities.LogWrite;
////import com.kochartech.gizmodoctor.HelperClass.PkgManagerHelper;
////
////import android.content.ContentValues;
////import android.content.Context;
////import android.content.pm.PackageManager;
////import android.content.pm.ResolveInfo;
////import android.database.Cursor;
////import android.database.SQLException;
////import android.database.sqlite.SQLiteDatabase;
////import android.util.Log;
////
////public class DBHelper_PerAppCPU {
////	private String tag = "CPUUsagePerAppDBHelper";
////	private Context context;
////	private static DBHelper_PerAppCPU classInstance = null;
////	private MySQLiteOpenHelper mySQLiteOpenHelper;
////	private SQLiteDatabase db;
////
////	public static DBHelper_PerAppCPU getInstance(Context context) {
////		if (classInstance == null)
////			classInstance = new DBHelper_PerAppCPU(context);
////		return classInstance;
////	}
////
////	private DBHelper_PerAppCPU(Context context) {
////		LogWrite.d(tag, "constructor");
////		this.context = context;
////		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
////	}
////
////	public void open() {
////		LogWrite.d(tag, "open");
////		db = mySQLiteOpenHelper.getWritableDatabase();
////	}
////
////	public void close() {
////		LogWrite.d(tag, "close");
////		db.close();
////	}
////
////	public Cursor getAllColumns() {
////		Cursor cursor = db.query(MySQLiteOpenHelper.CPUUsagePerApp_TableName,
////				null, null, null, null, null, null);
////		if (cursor.getCount() > 0) {
////			
////			LogWrite.d(tag, "Cursor Size :" + cursor.getCount());
////			if (cursor.moveToFirst()) {
////				do {
////					String appName = cursor
////							.getString((cursor
////									.getColumnIndex(MySQLiteOpenHelper.CPUUsagePerApp_ColumnAppName)));
////					float usage = cursor
////							.getFloat(cursor
////									.getColumnIndex(MySQLiteOpenHelper.CPUUsagePerApp_ColumnUsage));
////
////					LogWrite.d(tag, "getAllColumns () : appName :" + appName);
////					LogWrite.d(tag, "getAllColumns () : usage :" + usage);
////
////				} while (cursor.moveToNext());
////			}
////		}
////		return cursor;
////	}
////	
////	public void updateRow(String appName, float cpuUsage)
////	{
////		LogWrite.d(tag,"updateRow () : appName :"+appName);
////		LogWrite.d(tag,"updateRow () : cpuUsage :"+cpuUsage);
////		
////		ContentValues values = new ContentValues();		
////		values.put(MySQLiteOpenHelper.CPUUsagePerApp_ColumnUsage, cpuUsage);
////		
////		int id = db.update(MySQLiteOpenHelper.CPUUsagePerApp_TableName, values,
////				MySQLiteOpenHelper.CPUUsagePerApp_ColumnAppName + "=?",
////				new String[] {appName});
////		
////		LogWrite.d(tag,"updateRow () : affected Rows :"+id);
////		
////	}
////
////	public void init(SQLiteDatabase db) {
////		PkgManagerHelper pkgMangerHelper = new PkgManagerHelper(context);
////		PackageManager pkgManager = pkgMangerHelper.getPackageManager();
////		List<ResolveInfo> resolveInfoList = pkgMangerHelper.getLauncherApps();
////		for (ResolveInfo resolveInfo : resolveInfoList) {
////			String appName = resolveInfo.activityInfo.applicationInfo
////					.loadLabel(pkgManager).toString();
////
////			ContentValues values = new ContentValues();
////			values.put(MySQLiteOpenHelper.CPUUsagePerApp_ColumnAppName, appName);
////			values.put(MySQLiteOpenHelper.CPUUsagePerApp_ColumnUsage, 0);
////			long id = -1;
////			try {
////				id = db.insertOrThrow(
////						MySQLiteOpenHelper.CPUUsagePerApp_TableName, null,
////						values);
////				LogWrite.d(tag, "init() insert Id: " + id);
////			} catch (SQLException e) {
////				LogWrite.d(tag, "ExceptionDTO...: " + e);
////			}
////		}
////	}
////}
