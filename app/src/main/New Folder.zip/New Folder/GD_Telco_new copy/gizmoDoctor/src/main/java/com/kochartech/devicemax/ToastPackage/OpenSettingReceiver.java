package com.kochartech.devicemax.ToastPackage;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.kochartech.devicemax.Activities.LogWrite;

public class OpenSettingReceiver extends BroadcastReceiver 
{
	String tag = "OpenSettingReceiver";
	@Override
	public void onReceive(Context context, Intent intent) 
	{
		String message = (String) intent.getExtras().get("Message");
		LogWrite.d(tag, "Message ----> " + message);
		SettingsToast settingsToast = SettingsToast.openSingleInstance();
		settingsToast.show(context , message, SettingsToast.ARROW_UP, SettingsToast.GRAVITY_CENTER);
	}
}
