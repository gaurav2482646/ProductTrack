//package com.kochartech.gizmodoctor.Activity;
//
//import java.util.List;
//
//import android.app.Activity;
//import android.app.ActivityManager;
//import android.app.ActivityManager.RunningAppProcessInfo;
//import android.content.Context;
//import android.content.pm.ApplicationInfo;
//import android.content.pm.PackageManager;
//import android.content.pm.PackageManager.NameNotFoundException;
//import android.os.Bundle;
//import android.util.Log;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.library.CPU.KTApplicationInfo;
//import com.kochartech.library.CPU.KTUsageCPU;
//
//public class TestComponentActivity extends Activity
//{
//	private String tag = "TestComponentActivity";
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//	    setContentView(R.layout.activity_home);
//	    
//	    
//	    
////	    new KTUsage().calculate(this, "");
//	    
////	    printRunningAppProcessInfo();
//	    
////	    printRunningAppProcessInfo();
//	    List<KTApplicationInfo> KtApplicationList = new KTUsageCPU(this).getPerAppUsage(36);
//		LogWrite.d(tag, "size :"+KtApplicationList.size());
//	    for(KTApplicationInfo ktApplication : KtApplicationList)
//	    {
//	    	LogWrite.d(tag, "AppName :"+ktApplication.getAppName());
//	    	LogWrite.d(tag, "PackageName :"+ktApplication.getProcessName());
//	    	LogWrite.d(tag, "Pid :"+ktApplication.getPid());
//	    	LogWrite.d(tag, "CPU Usage :"+ktApplication.getUsage());	    	
//	    }
////	    printRunningAppProcessInfo();
//	}
//	
//	private void printRunningAppProcessInfo()
//	{
//		log("Running App Process Info");
//		
//		PackageManager pkgManager = getPackageManager();
//		ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);  
//		List<RunningAppProcessInfo> runningAppProcesses = activityManager.getRunningAppProcesses();  
//		for (RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses)  
//		{  
//			log("pid :"+runningAppProcessInfo.pid);	
//			log("processName :"+runningAppProcessInfo.processName);
//			try 
//			{
//				ApplicationInfo appIfo = pkgManager.getApplicationInfo(runningAppProcessInfo.processName, PackageManager.GET_META_DATA);
//				log("appName From Process :"+pkgManager.getApplicationLabel(appIfo));
//			}
//			catch (NameNotFoundException e)
//			{
//				log("ExceptionDTO..."+e);
//			}
//			
//			String[] pkgNames = runningAppProcessInfo.pkgList;
//			for(int i=0; i<pkgNames.length; i++)
//			{
//				log("pkg ("+i+") :"+pkgNames[i]);
//				try 
//				{
//					ApplicationInfo appIfo = pkgManager.getApplicationInfo(pkgNames[i], 0);
//					log("appName ("+i+") :"+pkgManager.getApplicationLabel(appIfo));
//				}
//				catch (NameNotFoundException e)
//				{
//					log("ExceptionDTO..."+e);
//				}
//			}	
//			log("---------------------------");
//		}  
//
//	}
//	private void log(String msg)
//	{
//		LogWrite.d(tag , msg);
//	}
//	private void getAppInfo(String packageName)
//	{
//		PackageManager pkgManger = getPackageManager();
//		try 
//		{
//			ApplicationInfo appIfo = pkgManger.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
//		}
//		catch (NameNotFoundException e) 
//		{
//			log("Not");
//		}
//		
//	}
//}	
