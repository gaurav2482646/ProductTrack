package com.kochartech.gizmodoctor.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;

public class TouchTestFragment extends Fragment implements OnLongClickListener,
		OnClickListener, MyFragment {

	private Context context;
	private View rootView;
	private TextView textView;
	public static final int FRAGMENT_TYPE_SIMPLE_TOUCH = 0;
	public static final int FRAGMENT_TYPE_LONG_TOUCH = 1;
	private int currentFragmentType;

	private boolean isFromCommand = false;
	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
	private OnCommandListener onCommandListener;
	private boolean isClickWork = false;
	private CircularProgressBar timerProgress;

	private String FAILURE_MESSAGE = "Touch test fails.";
	private boolean success;
	private Button okButton;

	private boolean backPressed = false;

	private boolean isTimerFinishFlag = false;

	private OnAutoHardwareTestListener onAutoHardwareTestListener;

	public TouchTestFragment(int currentFragmentType,
			OnCommandListener onCommandListener) {
		this.currentFragmentType = currentFragmentType;
		this.onCommandListener = onCommandListener;
	}

	public TouchTestFragment(){

	}
	public void setOnAutoHardwareTestListener(
			OnAutoHardwareTestListener onAutoHardwareTestListener) {
		this.onAutoHardwareTestListener = onAutoHardwareTestListener;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		initDataSet();
		initUi(inflater, container);

		return rootView;
	}

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		Bundle bundle = getArguments();
		if (bundle != null) {
			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
			}

		}
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_touchtest, container,
				false);
		textView = (TextView) rootView.findViewById(R.id.textView);

		okButton = (Button) rootView.findViewById(R.id.ok_button);
		okButton.setOnClickListener(this);
		timerProgress = (CircularProgressBar) rootView
				.findViewById(R.id.circularprogressbar2);
		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {

			@Override
			public void onAnimationStart() {
			}

			@Override
			public void onAnimationProgress(int progress) {
				timerProgress.setTitle(progress + "");
				timerProgress.setSubTitle("");
			}

			@Override
			public void onAnimationFinish() {
				if (!success) {
					isTimerFinishFlag = true;
					textView.setText(FAILURE_MESSAGE);
					textView.setTextAppearance(context, R.style.textStyleRed);
					timerProgress.setSubTitle("");
					timerProgress.setVisibility(View.GONE);
					if (currentFragmentType == FRAGMENT_TYPE_SIMPLE_TOUCH) {
						if (!backPressed) {
							if (HardwareTestFragment.isAutoStartClicked) {
								onAutoHardwareTestListener
										.onHardwareTestFinish(4,
												"Touch Sensor", false);
								getActivity().getSupportFragmentManager()
										.beginTransaction()
										.remove(TouchTestFragment.this)
										.commit();
								getActivity().getFragmentManager()
										.popBackStack();
								// FragmentListener fragmentListener =
								// (FragmentListener) getActivity();
								// fragmentListener.onItemClicked(
								// FragmentListener.actionRemove,
								// TouchTestFragment.this);
								// getActivity().onBackPressed();
							}

							if (isFromCommand) {
								onCommandListener.onCommand(false);
								FragmentListener fragmentListener = (FragmentListener) getActivity();
								fragmentListener.onItemClicked(
										FragmentListener.actionRemove,
										TouchTestFragment.this);
							}
						}
					} else if (currentFragmentType == FRAGMENT_TYPE_LONG_TOUCH) {
						okButton.setVisibility(View.VISIBLE);
						if (!backPressed) {
							if (HardwareTestFragment.isAutoStartClicked) {
								onAutoHardwareTestListener
										.onHardwareTestFinish(5,
												"Long Press Sensor", false);
								getActivity().getSupportFragmentManager()
										.beginTransaction()
										.remove(TouchTestFragment.this)
										.commit();
								getActivity().getFragmentManager()
										.popBackStack();
								// FragmentListener fragmentListener =
								// (FragmentListener) getActivity();
								// fragmentListener.onItemClicked(
								// FragmentListener.actionRemove,
								// TouchTestFragment.this);
								// getActivity().onBackPressed();
							}

							if (isFromCommand) {
								onCommandListener.onCommand(false);
								FragmentListener fragmentListener = (FragmentListener) getActivity();
								fragmentListener.onItemClicked(
										FragmentListener.actionRemove,
										TouchTestFragment.this);
							}
						}
					}
				}
			}
		});

		if (currentFragmentType == FRAGMENT_TYPE_SIMPLE_TOUCH) {
			FAILURE_MESSAGE = "Touch test fails.";
			textView.setText(R.string.touch_screen);
			registerOnClick(rootView);
		} else if (currentFragmentType == FRAGMENT_TYPE_LONG_TOUCH) {
			FAILURE_MESSAGE = "Press OK if long press not working";
			textView.setText(R.string.long_press_screen);
			registerLongOnClick(rootView);
		}
	}

	@Override
	public void onDetach() {
		LogWrite.d("Aman", "on Detach......................");
		backPressed = true;
		super.onDetach();
	}

	public void registerOnClick(View v) {
		v.setOnClickListener(this);
	}

	public void registerLongOnClick(View v) {
		v.setOnLongClickListener(this);
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.ok_button) {
			Vibrator vibrator = (Vibrator) context
					.getSystemService(Context.VIBRATOR_SERVICE);
			vibrator.vibrate(500);
			textView.setText("Long press test fails.");
			if (HardwareTestFragment.isAutoStartClicked) {
				onAutoHardwareTestListener.onHardwareTestFinish(5,
						"Long Press Sensor", false);
				// FragmentListener fragmentListener = (FragmentListener)
				// getActivity();
				// fragmentListener.onItemClicked(FragmentListener.actionRemove,
				// TouchTestFragment.this);
				getActivity().getSupportFragmentManager().beginTransaction()
						.remove(TouchTestFragment.this).commit();
				getActivity().getFragmentManager().popBackStack();
			}

			if (isFromCommand) {
				onCommandListener.onCommand(false);
				FragmentListener fragmentListener = (FragmentListener) getActivity();
				fragmentListener.onItemClicked(FragmentListener.actionRemove,
						this);
			}
			okButton.setVisibility(View.GONE);
		} else {
			handleClick();
		}
	}

	@Override
	public boolean onLongClick(View v) {
		handleClick();
		return true;
	}

	private void handleClick() {
		if (!isTimerFinishFlag) {
			try {
				Vibrator vibrator = (Vibrator) context
						.getSystemService(Context.VIBRATOR_SERVICE);
				vibrator.vibrate(500);
			} catch (Exception e) {
			}

			if (currentFragmentType == FRAGMENT_TYPE_SIMPLE_TOUCH) {
				success = true;
				textView.setText(R.string.touch_is_working_fine);
				if (HardwareTestFragment.isAutoStartClicked) {
					onAutoHardwareTestListener.onHardwareTestFinish(4,
							"Touch Sensor", true);
					// FragmentListener fragmentListener = (FragmentListener)
					// getActivity();
					// fragmentListener.onItemClicked(
					// FragmentListener.actionRemove,
					// TouchTestFragment.this);
					getActivity().getSupportFragmentManager()
							.beginTransaction().remove(TouchTestFragment.this)
							.commit();
					getActivity().getFragmentManager().popBackStack();

				}

			} else if (currentFragmentType == FRAGMENT_TYPE_LONG_TOUCH) {
				success = true;
				textView.setText(R.string.long_press_is_working_fine);
				if (HardwareTestFragment.isAutoStartClicked) {
					onAutoHardwareTestListener.onHardwareTestFinish(5,
							"Long Press Sensor", true);
					getActivity().getSupportFragmentManager()
							.beginTransaction().remove(TouchTestFragment.this)
							.commit();
					getActivity().getFragmentManager().popBackStack();
					// FragmentListener fragmentListener = (FragmentListener)
					// getActivity();
					// fragmentListener.onItemClicked(
					// FragmentListener.actionRemove,
					// TouchTestFragment.this);
				}
			}
			try {
				timerProgress.setVisibility(View.GONE);
				textView.setTextAppearance(context, R.style.textStyleGreen);
			} catch (Exception e) {

			}
			if (isFromCommand) {
				if (onCommandListener != null) {
					onCommandListener.onCommand(true);
				}
				FragmentListener fragmentListener = (FragmentListener) getActivity();
				fragmentListener.onItemClicked(FragmentListener.actionRemove,
						this);
			}

			isClickWork = true;
		}

	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		// if (onCommandListener != null) {
		// onCommandListener.onCommand(isClickWork);
		// }

	}

	@Override
	public String getTitle() {
		return "Touch Sensor";
	}

}
