package com.kochartech.gizmodoctor.DataBase;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.kochartech.devicemax.Activities.LogWrite;

public class DataSource_AppsInfo {
	private String tag = "DataSource_Apps";
	private Context context;
	private static DataSource_AppsInfo classInstance = null;
	private MySQLiteOpenHelper mySQLiteOpenHelper;
	private SQLiteDatabase db;

	public static int Remove_App = 0;
	public static int Add_App = 0;

	public static DataSource_AppsInfo getInstance(Context context) {
		if (classInstance == null)
			classInstance = new DataSource_AppsInfo(context);
		return classInstance;
	}

	private DataSource_AppsInfo(Context context) {
		LogWrite.d(tag, "constructor");
		this.context = context;
		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
	}

	private void open() {
		LogWrite.d(tag, "open");
		db = mySQLiteOpenHelper.getWritableDatabase();
	}

	private void close() {
		LogWrite.d(tag, "close");
		db.close();
	}

	public synchronized List<AppInfo> queryAllRecord() {
		// open the database
		open();

		List<AppInfo> appsInfoList = new ArrayList<AppInfo>();

		Cursor cursor = db.query(MySQLiteOpenHelper.APPS_TABLE, null, null,
				null, null, null, null);

		if (cursor.getCount() > 0) {
			if (cursor.moveToFirst()) {
				int index_RowId = cursor
						.getColumnIndex(MySQLiteOpenHelper.APPS_ColumnID);
				int index_Name = cursor
						.getColumnIndex(MySQLiteOpenHelper.APPS_ColumnName);
				int index_PkgName = cursor
						.getColumnIndex(MySQLiteOpenHelper.APPS_ColumnPkgName);

				do {
					int rowId = cursor.getInt(index_RowId);
					String name = cursor.getString(index_Name);
					String pkgName = cursor.getString(index_PkgName);
					AppInfo appInfo = new AppInfo(rowId, name, pkgName);
					appsInfoList.add(appInfo);
				} while (cursor.moveToNext());
			}
		}

		// close the database
		close();
		return appsInfoList;
	}

	public synchronized AppInfo queryAppInfo(String appName) {
		// open the database
		open();
		// getAllColumns();
		AppInfo appInfo = null;
		try {

			Cursor cursor = db.query(MySQLiteOpenHelper.APPS_TABLE, null,
					MySQLiteOpenHelper.APPS_ColumnName + " =? ",
					new String[] { appName }, null, null, null);
			if (cursor != null) {
				if (cursor.getCount() > 0) {
					if (cursor.moveToFirst()) {

						int index_RowId = cursor
								.getColumnIndex(MySQLiteOpenHelper.APPS_ColumnID);
						int index_Name = cursor
								.getColumnIndex(MySQLiteOpenHelper.APPS_ColumnName);
						int index_PkgName = cursor
								.getColumnIndex(MySQLiteOpenHelper.APPS_ColumnPkgName);

						do {
							int rowId = cursor.getInt(index_RowId);
							String name = cursor.getString(index_Name);
							String pkgName = cursor.getString(index_PkgName);

							appInfo = new AppInfo(rowId, name, pkgName);

						} while (cursor.moveToNext());

					}
				}
			}
		} catch (Exception e) {
			LogWrite.d("Hanji", "queryAppInfo: ExceptionDTO= " + e);
		}

		// close the database
		close();

		return appInfo;
	}

	// public synchronized Cursor getAllColumns() {
	// open();
	// Cursor cursor = db.query(MySQLiteOpenHelper.CPUUsageTotal_TableName,
	// null, null, null, null, null, null);
	//
	// LogWrite.d(tag, "Cursor Size :" + cursor.getCount());
	// if (cursor.getCount() > 0) {
	// if (cursor.moveToFirst()) {
	// do {
	// float cpuUsage = cursor
	// .getFloat((cursor
	// .getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnUsage)));
	// int numOfDiagnose = cursor
	// .getInt(cursor
	// .getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnNumOfDiagnose));
	// int columnId = cursor
	// .getInt(cursor
	// .getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnID));
	//
	// LogWrite.d(tag, "getAllColumns () : columnId :" + columnId);
	// LogWrite.d(tag, "getAllColumns () : cpuUsage :" + cpuUsage);
	// LogWrite.d(tag, "getAllColumns () : numOfDiagnose :"
	// + numOfDiagnose);
	//
	// } while (cursor.moveToNext());
	// }
	// }
	// close();
	// return cursor;
	// }

	public synchronized void addApp(String appName, String packageName) {
		open();
		/*
		 * Inserting value to Table
		 */
		ContentValues values = new ContentValues();
		values.put(MySQLiteOpenHelper.APPS_ColumnName, appName);
		values.put(MySQLiteOpenHelper.APPS_ColumnPkgName, packageName);

		long id = db.insert(MySQLiteOpenHelper.APPS_TABLE, null, values);

		LogWrite.d(tag, "addApp(): RowId: " + id);

		close();
	}

	public synchronized void deleteApp(String packageName) {
		open();
		/*
		 * Inserting value to Table
		 */
		int numRowsAffected = db.delete(MySQLiteOpenHelper.APPS_TABLE,
				MySQLiteOpenHelper.APPS_ColumnPkgName + " =?",
				new String[] { packageName });

		LogWrite.d(tag, "deleteApp(): numRowsAffected: " + numRowsAffected);

		close();
	}

	public synchronized void removeApp() {

	}

	public synchronized void init(SQLiteDatabase db) {
		try {
			PackageManager pm = context.getPackageManager();
			List<ApplicationInfo> list = pm
					.getInstalledApplications(PackageManager.GET_META_DATA);
			for (ApplicationInfo resolveInfo : list) {
				ContentValues values = new ContentValues();
				values.put(MySQLiteOpenHelper.APPS_ColumnName, pm
						.getApplicationLabel(resolveInfo).toString());
				values.put(MySQLiteOpenHelper.APPS_ColumnPkgName,
						resolveInfo.packageName);
				long id = db
						.insert(MySQLiteOpenHelper.APPS_TABLE, null, values);

				LogWrite.d(tag, "id: " + id);
			}
		} catch (Exception e) {

		}
	}
}
