package com.kochartech.gizmodoctor.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.kochartech.devicemax.Activities.LogWrite;

public class DataSource_DischargeRate {

	private String fileName = DataSource_DischargeRate.class.getSimpleName()
			+ ".txt";
	// private String fileName
	private String TAG = DataSource_DischargeRate.class.getSimpleName();
	// private Context context;
	private static DataSource_DischargeRate classInstance = null;
	private MySQLiteOpenHelper mySQLiteOpenHelper;
	private SQLiteDatabase db;

	private final String TableName = MySQLiteOpenHelper.DischargeRate_TableName;
	private final String Column_Id = MySQLiteOpenHelper.DischargeRate_ColumnID;
	private final String Column_Level = MySQLiteOpenHelper.DischargeRate_ColumnDecreaseLevel;
	private final String Column_Time = MySQLiteOpenHelper.DischargeRate_ColumnTimeInterval;

	public static DataSource_DischargeRate getInstance(Context context) {
		if (classInstance == null)
			classInstance = new DataSource_DischargeRate(context);
		return classInstance;
	}

	private DataSource_DischargeRate(Context context) {
		LogWrite.d(TAG, "constructor");
		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
	}

	private synchronized void open() {
		LogWrite.d(TAG, "open");
		db = mySQLiteOpenHelper.getWritableDatabase();
	}

	private synchronized void close() {
		LogWrite.d(TAG, "close");
		db.close();
	}

	public synchronized void insertLevel(int decreaseLevel, long timeInterval) {
		// open database
		open();

		Cursor cursor = db.query(TableName, null, null, null, null, null, null);
		int cursorSize = cursor.getCount();
		if (cursorSize >= maxNumOfRow) // delete the first row
		{
			if (cursor.moveToFirst()) {
				int indexColumnID = cursor.getColumnIndex(Column_Id);
				int firstROWId = cursor.getInt(indexColumnID);
				deleteROW(firstROWId);
			}
		}
		insertRecord(decreaseLevel, timeInterval);

		printTable();
		// getDischargeRate();

		// close database
		close();
	}

	private synchronized void insertRecord(int decreaseLevel, long timeInterval) {
		ContentValues values = new ContentValues();
		values.put(Column_Level, decreaseLevel);
		values.put(Column_Time, timeInterval);
		try {
			long id = db.insertOrThrow(TableName, null, values);
			LogWrite.d(TAG, "InsertRecord: Record Inserted Successflly : " + id);
			WriteToFile.write(fileName,
					"InsertRecord: Record Inserted Successflly");
		} catch (SQLException e) {
			LogWrite.d(TAG, "InsertRecord: ExceptionDTO= " + e);
			WriteToFile.write(fileName, "InsertRecord: ExceptionDTO= " + e);
		}

	}

	private synchronized void deleteFirstRecord() {
		Cursor cursor = db.query(TableName, null, null, null, null, null, null);
		int cursorSize = cursor.getCount();
		if (cursorSize > 0) {
			if (cursor.moveToFirst()) {
				int indexColumnID = cursor.getColumnIndex(Column_Id);
				int firstROWId = cursor.getInt(indexColumnID);
				db.delete(TableName, Column_Id + " =?",
						new String[] { String.valueOf(firstROWId) });
			}
		}
	}

	private synchronized void deleteROW(int rowId) {
		db.delete(TableName, Column_Id + " =?",
				new String[] { String.valueOf(rowId) });
	}

	public synchronized float getDischargeRate() {
		// open data base
		open();

		WriteToFile.write(fileName, "getDischargeRate Start---");
		float consumption = 0;
		try {
			int count = 0;
			int level = 0;
			long time = 0;
			Cursor cursor = db.query(TableName, null, null, null, null, null,
					null);
			WriteToFile.write(fileName, "cursor Size: " + cursor.getCount());
			if (cursor.getCount() > 0) {
				LogWrite.d(TAG, "cursor size Greater > 0");
				if (cursor.moveToFirst()) {
					int indexColumnLevel = cursor.getColumnIndex(Column_Level);
					int indexColumnTime = cursor.getColumnIndex(Column_Time);

					do {
						count++;
						level += cursor.getInt(indexColumnLevel);
						time += cursor.getInt(indexColumnTime);
					} while (cursor.moveToNext());
				}
			}
			consumption = 0;
			WriteToFile.write(fileName, "getDischargeRate: count= " + count);
			WriteToFile.write(fileName, "getDischargeRate: level= " + level);
			WriteToFile.write(fileName, "getDischargeRate: time= " + time);
			if (count > 0) {
				float avgLevel = level / count;
				float avgTime = ((time / count) / 1000) / 60;
				WriteToFile.write(fileName, "getDischargeRate: avgLevel= "
						+ avgLevel);
				WriteToFile.write(fileName, "getDischargeRate: avgTime= "
						+ avgTime);
				WriteToFile.write(fileName, "getDischargeRate: avgTime= "
						+ avgTime / 60);
				consumption = (avgLevel / avgTime);
				WriteToFile.write(fileName, "getDischargeRate: consumption= "
						+ consumption);
			}
		} catch (Exception e) {
			WriteToFile.write(fileName, "getDischargeRate: ExceptionDTO= " + e);
			LogWrite.e(TAG, "getDischargeRate: ExceptionDTO= " + e);
		}

		WriteToFile.write(fileName, "getDischargeRate Finsih---");

		// close data base
		close();
		return consumption;
	}

	public synchronized void printTable() {
		WriteToFile.write(fileName, "printTable Start---");
		String tag = "printTable";
		Cursor cursor = db.query(TableName, null, null, null, null, null, null);
		int cursorSize = cursor.getCount();
		LogWrite.d(tag, "CursorSize: " + cursorSize);
		WriteToFile.write(fileName, "CursorSize: " + cursorSize);
		if (cursor.getCount() > 0) {
			if (cursor.moveToFirst()) {
				int indexColumn1 = cursor.getColumnIndex(Column_Id);
				int indexColumn2 = cursor.getColumnIndex(Column_Level);
				int indexColumn3 = cursor.getColumnIndex(Column_Time);
				do {

					WriteToFile.write(fileName,
							"id: " + cursor.getInt(indexColumn1));
					WriteToFile.write(fileName,
							"level: " + cursor.getInt(indexColumn2));
					WriteToFile.write(fileName,
							"time: " + cursor.getLong(indexColumn3));

				} while (cursor.moveToNext());
			}
		}

		WriteToFile.write(fileName, "printTable Finish----");
	}

	int indexColumnID, indexColumnLevel, indexColumnTime;

	private final int maxNumOfRow = 5;

}
