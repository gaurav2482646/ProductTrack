package com.kochartech.devicemax.dm;

public class Trace extends DmCommand
{

	public Trace()
	{
	}

	public Trace(String installAppCommand)
	{

		String dataKey = "", dataValue = "";
		int cmdCount = 1;
		boolean flag = true;

		char[] dataCharArray = installAppCommand.toCharArray();
		int dataCharArrayLength = dataCharArray.length;

		for (int j = 0; j < dataCharArrayLength; j++)
		{

			if (dataCharArray[j] == ':')
			{
				while (flag)
				{
					if (dataKey.equals("CMDINF-" + cmdCount))
					{
						j++;
						j++;
						while (dataCharArray[j] != '>')
						{
							dataValue += dataCharArray[j];
							j++;
						}
						System.out.println("latest  " + dataValue);
						// parsePRCmd(dataValue);
						findTCCount(dataValue);
						System.out.println("char " + dataCharArray[j]);
						dataKey = "";
						dataValue = "";
						flag = false;
					} else
					{
						cmdCount++;
					}
				} // end while

				// so that < gets removed

			}

			else
			{
				dataKey += dataCharArray[j];
				// System.out.println(dataKey);
			}
		}

	}

	void findTCCount(String str)
	{
		System.out.println("Removed " + str);
		String dataKey = "";
//		String dataValue = "";
//		String cmdInfo1 = "CMDINF-1";
		String ap = "TC";
		char[] dataCharArray = str.toCharArray();
		int dataCharArrayLength = dataCharArray.length;

		for (int j = 0; j < dataCharArrayLength; j++)
		{

			if (dataCharArray[j] == ':')
			{
				if (dataKey.substring(0, dataKey.length() - 2).equals(ap))
				{
					// so that < gets removed
					// j++;j++;
					hashTable.put("TCCount", dataKey.substring(3));
					String toSendParseCmd = str.substring(j + 2, str.length());
					System.out.println("tosend parser" + toSendParseCmd);
					parseTCCmdD(toSendParseCmd);
				}
			} else
			{
				dataKey += dataCharArray[j];
			}
		}

	}

	void parseTCCmdD(String parsePRCmd)
	{

//		char charArrayPR[] = parsePRCmd.toCharArray();

		String[] keyValuesPairs = parsePRCmd.split(";");
		for (String keyValue : keyValuesPairs)
		{
			String keyValueSeprated[] = keyValue.split(":");
			hashTable.put("TC" + keyValueSeprated[0], keyValueSeprated[1]);
		}
		System.out.println(hashTable.toString());
		// System.out.println(hashTable.toString());
	}

}
