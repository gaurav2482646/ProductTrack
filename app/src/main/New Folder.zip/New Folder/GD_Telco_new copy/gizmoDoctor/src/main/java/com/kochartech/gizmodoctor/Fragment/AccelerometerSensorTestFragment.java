//package com.kochartech.gizmodoctor.Fragment;
//
//import android.content.Context;
//import android.hardware.Sensor;
//import android.hardware.SensorEvent;
//import android.hardware.SensorEventListener;
//import android.hardware.SensorManager;
//import android.os.Bundle;
//import android.os.Vibrator;
//import android.support.v4.app.Fragment;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.Activity.FragmentListener;
//import com.kochartech.gizmodoctor.Activity.OnCommandListener;
//
//public class AccelerometerSensorTestFragment extends Fragment implements
//		SensorEventListener {
//	// private String TAG =
//	// AccelerometerSensorTestFragment.class.getSimpleName();
//	
//	private Context context;
//	private View rootView;
//	private TextView textView;
//	private long lastUpdate;
//	private float last_x, last_y, last_z;
//	private SensorManager mSensorManager;
//	private Sensor mSensor;
//	
//	private boolean isFromCommand = false;
//	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
//	private OnCommandListener onCommandListener;
//	private boolean isClickWork = false;
//
//	public AccelerometerSensorTestFragment(OnCommandListener onCommandListener) {
//		this.onCommandListener = onCommandListener;
//	}
//
//	@Override
//	public View onCreateView(LayoutInflater inflater, ViewGroup container,
//			Bundle savedInstanceState) {
//		initDataSet();
//		initUi(inflater, container);
//		return rootView;
//	}
//
//	public void initDataSet() {
//		Bundle bundle = getArguments();
//		if (bundle != null) {
//			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
//				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
//			}
//		}
//		context = getActivity().getApplicationContext();
//		mSensorManager = (SensorManager) context
//				.getSystemService(Context.SENSOR_SERVICE);
//		mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
//		registerSensor();
//	}
//
//	public void initUi(LayoutInflater inflater, ViewGroup container) {
//		context = getActivity().getApplicationContext();
//		rootView = inflater.inflate(R.layout.layout_textview, container, false);
//		textView = (TextView) rootView.findViewById(R.id.textView);
//		textView.setText(R.string.shake_your_device);
//	}
//
//	@Override
//	public void onSensorChanged(SensorEvent sensorEvent) {
//		// TODO Auto-generated method stub
//		float x = sensorEvent.values[0];
//		float y = sensorEvent.values[1];
//		float z = sensorEvent.values[2];
//
//		long curTime = System.currentTimeMillis();
//		if ((curTime - lastUpdate) > 100) {
//			long diffTime = (curTime - lastUpdate);
//			lastUpdate = curTime;
//
//			float speed = Math.abs(x + y + z - last_x - last_y - last_z)
//					/ diffTime * 10000;
//
//			if (speed > 1500) {
//				try {
//					Vibrator vibrator = (Vibrator) context
//							.getSystemService(Context.VIBRATOR_SERVICE);
//					vibrator.vibrate(500);
//					textView.setText(R.string.accelerometer_working_fine);
//					textView.setTextAppearance(getActivity(),
//							R.style.textStyleGreen);
//
//					if (isFromCommand) {
//						FragmentListener fragmentListener = (FragmentListener) getActivity();
//						fragmentListener.onItemClicked(
//								FragmentListener.actionRemove, this);
//					}
//					isClickWork = true;
//				} catch (ExceptionDTO e) {
//
//				}
//
//			}
//			last_x = x;
//			last_y = y;
//			last_z = z;
//		}
//	}
//
//	@Override
//	public void onAccuracyChanged(Sensor sensor, int accuracy) {
//		// TODO Auto-generated method stub
//
//	}
//
//	public void registerSensor() {
//		if (mSensorManager != null && mSensor != null)
//			mSensorManager.registerListener(this, mSensor,
//					SensorManager.SENSOR_DELAY_NORMAL);
//	}
//
//	public void unRegisterSensor() {
//		if (mSensorManager != null && mSensor != null)
//			mSensorManager.unregisterListener(this, mSensor);
//	}
//
//	@Override
//	public void onDestroy() {
//		super.onDestroy();
//		unRegisterSensor();
//		if (onCommandListener != null) {
//			onCommandListener.onCommand(isClickWork);
//		}
//	}
//}
