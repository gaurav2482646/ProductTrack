package com.kochartech.gizmodoctor.HelperClass;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.GUICleanActivity;
import com.kochartech.gizmodoctor.Activity.GUINotification;

/**
 * Helps in notifying user by sending notifications.
 * 
 * @author aman.arora
 * 
 */

@SuppressWarnings("deprecation")
public class NotificationHelper {

	// private String TAG = NotificationHelper.class.getSimpleName();
	private static Context mContext;
	// private final int ID_CANCELABLE_NOTIFICATION = 1;
	// private final int ID_NOT_TOCLEAR_NOTIFICATION = 2;

	private Notification mNotification;
	private NotificationManager mNotificationManager;
	private PendingIntent mContentIntent;
	private CharSequence mContentTitle;

	public static int ID_DEVICE_HOT = 101;
	public static int ID_CPU_HOT = 102;
	public static int ID_DEVICE_SLOW = 103;
	public static int ID_SETTINGS = 104;
	public static int ID_BATTERY_LOW = 105;
	public static int ID_INTERNET = 106;
	public static int ID_CPU = 107;
	public static int ID_RAM = 108;

	private NotificationHelper(Context context) {
		mContext = context;
	}

	private static NotificationHelper notificationHelper = null;

	public static NotificationHelper getInstance(Context context) {
		mContext = context;
		if (notificationHelper == null)
			notificationHelper = new NotificationHelper(context);
		return notificationHelper;
	}

	public void createNotification(String message, int reqCode, boolean flag) {
		// get the notification manager
		mNotificationManager = (NotificationManager) mContext
				.getSystemService(Context.NOTIFICATION_SERVICE);

		// create the notification
		int icon = R.drawable.appicon;
		CharSequence tickerText = "Gizmo Doctor";
		long when = System.currentTimeMillis();
		// CharSequence tickerText = mContext.getString(R.string.header_text);
		// // Initial
		// text
		// that
		// appears
		// in
		// the
		// status
		// bar
		// long when = System.currentTimeMillis();
		mNotification = new Notification(icon, tickerText, when);

		// create the content which is shown in the notification pulldown
		mContentTitle = "!GizmoDoctor Alert"; // Full
												// title of
												// the
												// notification
												// in the
												// pull down
		CharSequence contentText = message; // Text of the notification in
											// the pull down

		// you have to set a PendingIntent on a notification to tell the system
		// what you want it to do when the notification is selected
		// I don't want to use this here so I'm just creating a blank one
		Intent notificationIntent = new Intent(mContext, GUINotification.class);
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		notificationIntent.putExtra("Msg", message);
		mContentIntent = PendingIntent.getActivity(mContext, reqCode,
				notificationIntent, PendingIntent.FLAG_ONE_SHOT);

		// add the additional content and intent to the notification
		mNotification.setLatestEventInfo(mContext, mContentTitle, contentText,
				mContentIntent);

		// make this notification appear in the 'Ongoing events' section
		mNotification.flags = Notification.FLAG_ONGOING_EVENT;
		mNotification.flags = Notification.FLAG_AUTO_CANCEL;

		// show the notification
		mNotificationManager.notify(reqCode, mNotification);
	}

	public void createNotificationDialog(String message, int reqCode,
			boolean flag) {
		// get the notification manager
		mNotificationManager = (NotificationManager) mContext
				.getSystemService(Context.NOTIFICATION_SERVICE);

		// create the notification
		int icon = R.drawable.appicon;
		CharSequence tickerText = "Gizmo Doctor";
		long when = System.currentTimeMillis();
		// CharSequence tickerText = mContext.getString(R.string.header_text);
		// // Initial
		// text
		// that
		// appears
		// in
		// the
		// status
		// bar
		// long when = System.currentTimeMillis();
		mNotification = new Notification(icon, tickerText, when);

		// create the content which is shown in the notification pulldown
		mContentTitle = "!GizmoDoctor Alert"; // Full
												// title of
												// the
												// notification
												// in the
												// pull down
		CharSequence contentText = message; // Text of the notification in
											// the pull down

		// you have to set a PendingIntent on a notification to tell the system
		// what you want it to do when the notification is selected
		// I don't want to use this here so I'm just creating a blank one
		Intent notificationIntent = new Intent(mContext, GUICleanActivity.class);
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		notificationIntent.putExtra("Msg", message);
		mContentIntent = PendingIntent.getActivity(mContext, reqCode,
				notificationIntent, PendingIntent.FLAG_ONE_SHOT);

		// add the additional content and intent to the notification
		mNotification.setLatestEventInfo(mContext, mContentTitle, contentText,
				mContentIntent);

		// make this notification appear in the 'Ongoing events' section
		mNotification.flags = Notification.FLAG_ONGOING_EVENT;
		mNotification.flags = Notification.FLAG_AUTO_CANCEL;

		// show the notification
		mNotificationManager.notify(reqCode, mNotification);
	}

	// /**
	// * Put the notification into the status bar
	// */
	// @SuppressWarnings("deprecation")
	// public void createNotification(String message, int reqCode, boolean
	// isCancelable) {
	// // get the notification manager
	// mNotificationManager = (NotificationManager) mContext
	// .getSystemService(Context.NOTIFICATION_SERVICE);
	//
	// // create the notification
	// int notificationId = 0 ;
	// int icon = R.drawable.appicon;
	// CharSequence tickerText = "Gizmo Doctor";
	// long when = System.currentTimeMillis();
	//
	// mNotification = new Notification(icon, tickerText, when);
	//
	// // create the content which is shown in the notification pulldown
	// mContentTitle = "!GizmoDoctor Alert"; // Full
	// // title of
	// // the
	// // notification
	// // in the
	// // pull down
	// CharSequence contentText = message; // Text of the notification in
	// // the pull down
	//
	// // mNotification.flags = Notification.FLAG_ONGOING_EVENT;
	// if(isCancelable) {
	//
	// LogWrite.d(TAG, "isCancelable");
	//
	// Intent notificationIntent = new Intent(mContext, GUINotification.class);
	// notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	// notificationIntent.putExtra("Msg", message);
	// mContentIntent = PendingIntent.getActivity(mContext, reqCode,
	// notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	// mNotification.flags = Notification.FLAG_ONGOING_EVENT;
	// mNotification.flags = Notification.FLAG_AUTO_CANCEL;
	// notificationId = ID_CANCELABLE_NOTIFICATION;
	// }
	// else {
	// // LogWrite.d(TAG, "isCancelable");
	// Intent notificationIntent = new Intent(mContext,
	// PowerSavingNotificationActivity.class);
	// notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	// notificationIntent.putExtra("Msg", message);
	//
	// mContentIntent = PendingIntent.getActivity(mContext, reqCode,
	// notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
	// mNotification.flags = Notification.FLAG_NO_CLEAR;
	// notificationId = ID_NOT_TOCLEAR_NOTIFICATION;
	// }
	//
	// mNotification.setLatestEventInfo(mContext, mContentTitle, contentText,
	// mContentIntent);
	//
	// // show the notification
	// mNotificationManager.notify(notificationId, mNotification);
	// }

	// public void createNotification
	@SuppressLint("NewApi")
	public void createNotification1(String lineOne, String lineTwo, int reqCode) {

		mNotificationManager = (NotificationManager) mContext
				.getSystemService(Context.NOTIFICATION_SERVICE);
		int icon = R.drawable.appicon;
		Builder builder = new Notification.Builder(mContext)
				.setContentTitle("!GizmoDoctor Alert").setContentText(lineOne)
				.setSmallIcon(icon);
		Notification notification = new Notification.InboxStyle(builder)
				.addLine(lineOne).addLine(lineTwo).build();
		mNotificationManager.notify(reqCode, notification);
	}

	/**
	 * Receives progress updates from the background task and updates the status
	 * bar notification appropriately
	 * 
	 * @param percentageComplete
	 */
	public void progressUpdate(String statusmsg, int reqCode) {
		// build up the new status message
		// //LogWrite.d(">>>>>>>>","Inside progress Update>>>>>" +
		// percentageComplete);
		CharSequence contentText = statusmsg;

		// publish it to the status bar
		mNotification.setLatestEventInfo(mContext, mContentTitle, contentText,
				mContentIntent);
		mNotificationManager.notify(reqCode, mNotification);
	}

	/**
	 * called when the DownloadAsynctask is canceled
	 * 
	 * 
	 */
	public void cancelUpdate(int reqCode) {
		// build up the new status message
		// //LogWrite.d(">>>>>>>>","Inside progress Update>>>>>" +
		// percentageComplete);

		// publish it to the status bar
		mNotification.setLatestEventInfo(mContext, "Diagnose failed.",
				"Cancelling", mContentIntent);
		mNotificationManager.cancel(reqCode);
	}

	public void cancelNotification(int reqCode) {
		mNotificationManager = (NotificationManager) mContext
				.getSystemService(Context.NOTIFICATION_SERVICE);
		mNotificationManager.cancel(reqCode);
	}

	/**
	 * called when the background task is complete, this removes the
	 * notification from the status bar. We could also use this to add a new
	 * task complete notification
	 */
	public void completed(int reqCode) {
		// remove the notification from the status bar
		mNotificationManager.cancel(reqCode);
	}
}