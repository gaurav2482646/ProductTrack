package com.kochartech.gizmodoctor.UpdateUi;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;

import com.kochartech.devicemax.Activities.LogWrite;

public class BroadcastService extends Service {
	private static final String tag = BroadcastService.class.getSimpleName();
	public static final String BROADCAST_ACTION = "com.kochartech.gizmodoctor.UpdateUI";
	public static final String REQUESTCODE_KEY = "request_code";
	public static final int REQUESTCODE_VALUE = 1120;

	private final Handler handler = new Handler();
	private final long INITIAL_TIME = 2;
	private final long DELAY_TIME = 4;
	private Intent intent;

	private boolean isServiceRunning = false;

	@Override
	public void onCreate() {
		super.onCreate();
		LogWrite.w(tag, "On Create Method Enters......");
		intent = new Intent(BROADCAST_ACTION);
		intent.putExtra(REQUESTCODE_KEY, REQUESTCODE_VALUE);
	}

	@Override
	public void onStart(Intent intent, int startId) {
		LogWrite.w(tag, "On Start Method Enters......");
		isServiceRunning = true;
		handler.removeCallbacks(sendUpdatesToUI);
		LogWrite.d(tag, "Works every initial  time " + DELAY_TIME + " sec");
		handler.postDelayed(sendUpdatesToUI, INITIAL_TIME * 1000);
	}

	private Runnable sendUpdatesToUI = new Runnable() {
		public void run() {
			sendBroadcast(intent);
			LogWrite.d(tag, "Works every delay time " + INITIAL_TIME + " sec");
			if (isServiceRunning)
				handler.postDelayed(this,  DELAY_TIME * 1000);
		}
	};

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onDestroy() {
		LogWrite.w(tag, "On Destroy Method Enters......");
		isServiceRunning = false;
		handler.removeCallbacks(sendUpdatesToUI);
		super.onDestroy();
	}
}
