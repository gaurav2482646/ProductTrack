package com.kochartech.gizmodoctor.Fragment;

public class DeviceGetsHotFragment 
{

}
