package com.kochartech.gizmodoctor.HardwareModel;

import android.content.Context;
import android.os.Vibrator;

import com.kochartech.devicemax.Activities.LogWrite;

public class Vibration {
	private String TAG = Vibration.class.getSimpleName();
	private Vibrator vibrator;

	public Vibration(Context context) {
		vibrator = (Vibrator) context
				.getSystemService(Context.VIBRATOR_SERVICE);
	}

	/**
	 * This method is used to check vibration.
	 */
	public boolean vibrate() {
		LogWrite.d(TAG, "Vibrate Method Enters.....");
		try {
			if (vibrator.hasVibrator()) {
				vibrator.vibrate(3000);
				return true;
			}
		} catch (Exception e) {
			LogWrite.e(TAG, "VibrateException :---> " + e.toString());
		}
		return false;
	}

}
