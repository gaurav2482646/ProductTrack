package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Adapter.CPUDetailAdapter;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.HelperClass.LineGraph;
import com.kochartech.gizmodoctor.HelperClass.SettingsToast;
import com.kochartech.gizmodoctor.UpdateUi.UiRequireUpdate;
import com.kochartech.library.CPU.KTApplicationInfo;
import com.kochartech.library.CPU.KTUsageCPU;

@SuppressWarnings("deprecation")
public class GUICPU extends Fragment implements UiRequireUpdate,
		OnItemClickListener, MyFragment {
	private String tag = "GUICPU";
	private Context context;
	private View rootView;
	private ListView listView_CpuDetail;
	// private ActivityManager activityManager ;
	private List<KTApplicationInfo> runningAppProcesses = new ArrayList<KTApplicationInfo>();
	private KTUsageCPU ktCpuUsage;
	private CPUDetailAdapter cpuDetailAapter;

	private LineGraph lineGraphView;
	private LinearLayout mLayout;
	// private UiUpdateAsync uiUpdateAsync;
	private TextView cpuPercentageTextView;
	private int cpuUsage;
	private MyProgressDialog myProgressDialog;

	// private boolean isToUpadteUi = false;

	public String getTitle() {
		return "CPU Diagnosis";
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// getActivity().setTitle("CPU Diagnosis");
		LogWrite.d(tag, "onCreateView ");
		context = getActivity().getApplicationContext();

		rootView = inflater.inflate(R.layout.fragment_cpudetail, container,
				false);
		listView_CpuDetail = (ListView) rootView
				.findViewById(R.id.cpuDetail_ListView);
		cpuPercentageTextView = (TextView) rootView
				.findViewById(R.id.cpuPercentage);
		mLayout = (LinearLayout) rootView.findViewById(R.id.graph);

		lineGraphView = new LineGraph(getActivity());
		ktCpuUsage = new KTUsageCPU(context);

		mLayout.addView(lineGraphView.getView(), new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT,
				LinearLayout.LayoutParams.FILL_PARENT, 1));

		// try {
		// LayoutAnimationController controller =
		// new LayoutAnimationController(set, 0.5f);
		// listView_CpuDetail.setLayoutAnimation(controller);
		// } catch (NotFoundException e) {
		// LogWrite.d("Ashu","ExceptionDTO..."+e);
		// }

		/*
		 * Animation Used by the ListView
		 */
		// AnimationSet set = new AnimationSet(true);
		//
		// Animation animation = new AlphaAnimation(0.0f, 1.0f);
		// animation.setDuration(500);
		// set.addAnimation(animation);
		//
		// animation = new TranslateAnimation(
		// Animation.RELATIVE_TO_SELF, 0.0f,Animation.RELATIVE_TO_SELF, 0.0f,
		// Animation.RELATIVE_TO_SELF, 1.0f,Animation.RELATIVE_TO_SELF, 0.0f
		// );
		// animation.setDuration(100);
		// set.addAnimation(animation);
		//
		// LayoutAnimationController controller =
		// new LayoutAnimationController(set, 0.5f);
		//
		// listView_CpuDetail.setLayoutAnimation(controller);

		cpuDetailAapter = new CPUDetailAdapter(context, runningAppProcesses);

		listView_CpuDetail.setAdapter(cpuDetailAapter);
		listView_CpuDetail.setOnItemClickListener(this);

		if (savedInstanceState == null) {

			myProgressDialog = new MyProgressDialog(getActivity());
			myProgressDialog.show();
		} else {
			isToShowProgressDialog = true;
		}

		// broadcasrReceiver = new BroadcastReceiver(this);
		// intentBroadcastService = new Intent(context, BroadcastService.class);
		// uiUpdateAsync = UiUpdateAsync.getInstance();

		// isToUpadteUi = true;
		// new Async().execute("");
		// runInBackGround();
		return rootView;
	}

	// class Async extends AsyncTask<String, String, String>
	// {
	//
	// @Override
	// protected String doInBackground(String... params) {
	// // TODO Auto-generated method stub
	// runInBackGround();
	//
	// publishProgress("");
	// return null;
	// }
	//
	// @Override
	// protected void onProgressUpdate(String... values) {
	// // TODO Auto-generated method stub
	// updateUI();
	// }
	// }

	boolean isToShowProgressDialog = false;

	@Override
	public void runInBackGround() {
		// TODO Auto-generated method stub
		LogWrite.d(tag, "Run in Background: ");
		if (isToShowProgressDialog) {
			isToShowProgressDialog = false;
			getActivity().runOnUiThread(new Runnable() {
				@Override
				public void run() {
					myProgressDialog = new MyProgressDialog(getActivity());
					myProgressDialog.show();
				}
			});
		}
		ArrayList<KTApplicationInfo> runningAppProcesses1 = (ArrayList<KTApplicationInfo>) ktCpuUsage
				.refresh(25);
		LogWrite.d(tag, "rumApps: " + runningAppProcesses1.size());
		runningAppProcesses.clear();
		for (int i = 0; i < runningAppProcesses1.size(); i++) {
			if (!isAppExist(runningAppProcesses, runningAppProcesses1.get(i)
					.getAppName())) {
				LogWrite.d(tag, "packageName: "
						+ runningAppProcesses1.get(i).getProcessName());
				runningAppProcesses.add(runningAppProcesses1.get(i));
			}
		}
		// runningAppProcesses.addAll(runningAppProcesses1);
		cpuUsage = ktCpuUsage.getTotalCPUUsage();
		LogWrite.d(tag, "Run in Background: Finsish");

	}

	private boolean isAppExist(List<KTApplicationInfo> runningAppProcesses,
			String appName) {
		for (KTApplicationInfo ktApplicationInfo : runningAppProcesses) {
			if (ktApplicationInfo.getAppName().equals(appName))
				return true;
		}
		return false;
	}

	@Override
	public void updateUI() {
		// TODO Auto-generated method stub

		LogWrite.d(tag, "Update Ui ");

		if (myProgressDialog != null)
			if (myProgressDialog.isShowing())
				myProgressDialog.dismiss();

		cpuDetailAapter.notifyDataSetChanged();

		cpuPercentageTextView.setText("" + cpuUsage + " %");
		lineGraphView.refresh(cpuUsage);

		LogWrite.d(tag, "Update Ui  Finish");

	}

	// @Override
	// public void onDetach() {
	// // TODO Auto-generated method stub
	// super.onDetach();
	//
	// DiagnoseFragment diagnoseFragment = (DiagnoseFragment)
	// getActivity().getSupportFragmentManager().getFragments().get(0);
	// if(diagnoseFragment != null)
	// diagnoseFragment.onResume();
	//
	// }

	@Override
	public void onDestroy() {
		super.onDestroy();
		// uiUpdateAsync.stop();
		setToastVisibilty(false);

		LogWrite.d(tag, "onDestroy Work :");
	}

	@Override
	public void onResume() {
		super.onResume();
		// uiUpdateAsync = uiUpdateAsync.start(this);
		setToastVisibilty(false);

		// context.startService(intentBroadcastService);
		// Intent intent = context.registerReceiver(broadcasrReceiver, new
		// IntentFilter(BroadcastService.BROADCAST_ACTION));

		// LogWrite.d("Temp1", "onResume Work :"+intent);
	}

	@Override
	public void onPause() {
		super.onPause();
		// uiUpdateAsync.stop();
		setToastVisibilty(true);

		// try {
		//
		// context.stopService(intentBroadcastService);
		// context.unregisterReceiver(broadcasrReceiver);
		//
		//
		// } catch (ExceptionDTO e) {
		// LogWrite.d("Temp1",""+e);
		// }

		LogWrite.d(tag, "onPause Work :");
	}

	private void setToastVisibilty(boolean flag) {
		if (settingToast != null) {
			settingToast.setToastVisibility(flag);
		}
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub

		KTApplicationInfo ktApplicationInfo = runningAppProcesses.get(arg2);
		if (!context.getPackageName()
				.equals(ktApplicationInfo.getProcessName())) {
			Bundle bundle = new Bundle();
			bundle.putString(GUIUsageStats.KEY_APPNAME,
					ktApplicationInfo.getAppName());
			bundle.putString(GUIUsageStats.KEY_PKGNAME,
					ktApplicationInfo.getProcessName());

			Fragment fragment = new GUIUsageStats();
			fragment.setArguments(bundle);

			// FragmentTransaction fragmentTransaction = getActivity()
			// .getSupportFragmentManager().beginTransaction();
			// fragmentTransaction.addToBackStack("1");
			// fragmentTransaction.add(R.id.frame_container,
			// fragment).commit();

			FragmentListener fragmentListener = (FragmentListener) getActivity();
			fragmentListener
					.onItemClicked(FragmentListener.actionAdd, fragment);

			// runningAppProcesses.get(arg2).getProcessName();
			// // TODO Auto-generated method stub
			// Intent intent = new Intent(
			// android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
			// intent.setData(Uri.parse("package:"
			// + runningAppProcesses.get(arg2).getProcessName()));
			// startActivity(intent);
			//
			// settingToast = new SettingsToast(getActivity());
			// settingToast.show(0);
		}
	}

	// private Intent intentBroadcastService;
	private SettingsToast settingToast;
	// private BroadcastReceiver broadcasrReceiver;

	// @Override
	// public boolean isToUpdateUi() {
	// // TODO Auto-generated method stub
	// return isToUpadteUi;
	// }
}
