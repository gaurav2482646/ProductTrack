package com.kochartech.gizmodoctor.HelperClass;

import android.app.Activity;

public class CustomDialog {
	
	private Activity activityContext; 
	public CustomDialog(Activity activityContext) {
		this.activityContext = activityContext ;
	}
	
	
}
