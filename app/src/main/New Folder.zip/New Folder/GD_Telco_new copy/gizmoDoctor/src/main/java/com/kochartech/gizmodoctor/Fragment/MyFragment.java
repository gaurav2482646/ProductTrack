package com.kochartech.gizmodoctor.Fragment;

public interface MyFragment {	
	 public String getTitle();
}
