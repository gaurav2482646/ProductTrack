package com.kochartech.gizmodoctor.deviceissues;

import android.graphics.drawable.Drawable;

public class RunningAppDTO {

	private String packageName;
	private String appName;
	private int systemApp;
	private Drawable icon;
	private boolean selected;

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public int getSystemApp() {
		return systemApp;
	}

	public void setSystemApp(int systemApp) {
		this.systemApp = systemApp;
	}

	public Drawable getIcon() {
		return icon;
	}

	public void setIcon(Drawable icon) {
		this.icon = icon;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

}
