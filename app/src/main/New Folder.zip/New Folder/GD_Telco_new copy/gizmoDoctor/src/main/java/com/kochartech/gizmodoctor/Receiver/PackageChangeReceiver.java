package com.kochartech.gizmodoctor.Receiver;

import java.text.SimpleDateFormat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.DataBase.DataSource_AppsInfo;

/*
 *  link, how to get package info when a new package added and removed 
 *  http://stackoverflow.com/questions/14455851/determine-the-intent-filter-for-a-receiver-from-the-package-info
 */

public class PackageChangeReceiver extends BroadcastReceiver {
	private String tag = "PackageChangeReceiver";
	public static boolean Add_App = true;
	public static boolean Remove_App = false;

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub

		if (intent.getAction().equals(Intent.ACTION_PACKAGE_ADDED)) {
			LogWrite.d(tag, "Package Added.");
			managePackage(context, intent, Add_App);

		} else if (intent.getAction().equals(Intent.ACTION_PACKAGE_REMOVED)) {
			LogWrite.d(tag, "Package Removed.");
			managePackage(context, intent, Remove_App);
		}

	}

	private void managePackage(Context context, Intent intent, boolean flag) {
		/*
		 * flag = true to add flag = false to remove
		 */

		PackageManager pm = null;
		PackageInfo packageInfo = null;
		String appName = null;
		String appType = "I";
		DataSource_AppsInfo dsAppsInfo = null;

		Uri uri = intent.getData();
		String packageName = uri != null ? uri.getSchemeSpecificPart() : null;
		if (packageName != null) {
			pm = context.getPackageManager();
			try {
				dsAppsInfo = DataSource_AppsInfo.getInstance(context);
				// If Flag is true then it means to add app
				if (flag) {
					packageInfo = pm.getPackageInfo(packageName, 0);

					appType = isSystemPackage(packageInfo) ? "I" : "E";
					// if (isSystemPackage(packageInfo)) {
					// appType = "I";
					// } else {
					// appType = "E";
					// }
					long time = packageInfo.lastUpdateTime;
					String update_time = getDate(time);
					if (packageInfo != null) {
						appName = pm.getApplicationLabel(
								packageInfo.applicationInfo).toString();
						dsAppsInfo.addApp(appName, packageName);
					}
				} else {
					dsAppsInfo.deleteApp(packageName);
				}
			} catch (Exception e) {
				LogWrite.e(tag,
						"PackageInfo not find exception: " + e.toString());
			}
		}
	}

	private boolean isSystemPackage(PackageInfo packageInfo) {
		return ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
	}

	private String getDate(long time) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		return format.format(time);
	}

}
