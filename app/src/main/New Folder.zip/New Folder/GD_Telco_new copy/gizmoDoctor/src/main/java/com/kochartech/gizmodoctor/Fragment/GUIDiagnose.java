package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Adapter.DiagnoseAdapter;
import com.kochartech.gizmodoctor.CustomView.CircleView;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.HelperClass.SettingStateMonitor;
import com.kochartech.gizmodoctor.HelperClass.Utility;
import com.kochartech.gizmodoctor.POJO.SettingStateDTO;
import com.kochartech.gizmodoctor.Preferences.AppSettingsPreference;
import com.kochartech.gizmodoctor.UpdateUi.UiRequireUpdate;
import com.kochartech.library.Battery.KTBatteryInfo;
import com.kochartech.library.CPU.KTUsageCPU;
import com.kochartech.library.Memory.KTMemoryInfo;
import com.kochartech.library.Memory.KTUsageRAM;
@SuppressWarnings("deprecation")
public class GUIDiagnose extends Fragment implements UiRequireUpdate,
		OnClickListener, MyFragment {
	private final static String tag = GUIDiagnose.class.getSimpleName();

	private Context context;
	private View rootView;
	private static MyProgressDialog myprogressDialog;
	private Drawable thumb;
	// Parameters used to display Device settings on time like Wifi, Bluetooth,
	// GPS, Hotspot
	private ListView settings_ListView;
	private DiagnoseAdapter diagnoseAdapter;
	private SettingStateMonitor settingStateMonitor;
	// End Device settings
	// Parameters used to display CPU and RAM Usage
	private CircleView ramInfo, cpuInfo;
	private TextView valueFreeRAM, valueUsedRAM, valueFreeCPU, valueUsedCPU;
	private int cpufree, cpuUsed;
	private KTUsageRAM ktUsageRAM;
	private KTUsageCPU ktCPUUsage;
	private KTMemoryInfo ktMemory;
	// End CPU and RAM Usage
	// Parameters used to display Battery Status
	private SeekBar seekBar;
	private LinearLayout batteryTextView;
	private TextView temperatureTextView;
	private ImageView descriptionToBatteryTemp;
	private float batteryTmp;
	private KTBatteryInfo information;
	private int temperatureUnit;

	public static boolean firstTimeFlag = false;

	// End Battery
	// private String tempWithUnit;
	// private Intent intentBroadcastService;

	public String getTitle() {
		return "Diagnose";
	}

	ArrayList<SettingStateDTO> arrayListSettingStateDTO = new ArrayList<SettingStateDTO>();

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		LogWrite.i(tag, "onCreate View");
		firstTimeFlag = true;
		// Initializing values to data
		initDataSet();
		// Initializing UI
		initUi(inflater, container);
		LogWrite.i(tag, "savedInstanceState: " + savedInstanceState);
		if (savedInstanceState == null) {
			LogWrite.i(tag, "savedInstanceState is null");
			myprogressDialog = new MyProgressDialog(getActivity());
			LogWrite.i(tag, "Progress Dialog showing....");
			myprogressDialog.show();
		} else {
			LogWrite.i(tag, "savedInstanceState is not null");
			isToShowProgressDialog = true;
		}

		return rootView;
	}

	/**
	 * Initializing Values to parameters
	 */
	public void initDataSet() {
		try {
			LogWrite.d(tag, "Inid Data Set : Start");
			context = getActivity().getApplicationContext();
			settingStateMonitor = new SettingStateMonitor(context);
			ktCPUUsage = new KTUsageCPU(context);
			ktUsageRAM = new KTUsageRAM(context);
			arrayListSettingStateDTO = settingStateMonitor.getSettingState();
			LogWrite.d(tag, "arrayListSettingStateDTO..."
					+ arrayListSettingStateDTO.size());
			diagnoseAdapter = new DiagnoseAdapter(context,
					arrayListSettingStateDTO);
			information = KTBatteryInfo.getInstance();

			AppSettingsPreference appSetting = new AppSettingsPreference(
					context);
			temperatureUnit = appSetting.getTemperatureUnitToShow();
			LogWrite.i(tag, "TemperatureUnit : " + temperatureUnit);
			batteryTmp = getBatteryTemp();
			LogWrite.i(tag, "BatteryTemperature : " + batteryTmp);
			// intentBroadcastService = new Intent(context,
			// BroadcastService.class);
		} catch (Exception e) {
			LogWrite.e(tag, "Diagnose initdataset ExceptionDTO : " + e.toString());
		}
		LogWrite.d(tag, "Inid Data Set : Finish");
	}

	/**
	 * Initializing UI Components
	 * 
	 * @param inflater
	 * @param container
	 */
	
	public void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_diagnose2, container,
				false);
		settings_ListView = (ListView) rootView
				.findViewById(R.id.listView_Settings);
		settings_ListView.setAdapter(diagnoseAdapter);
		temperatureTextView = (TextView) rootView
				.findViewById(R.id.temperatureTextView);
		descriptionToBatteryTemp = (ImageView) rootView
				.findViewById(R.id.descriptionToBatteryTemp);

		seekBar = (SeekBar) rootView.findViewById(R.id.seekBar1);
		thumb = getResources().getDrawable(R.drawable.thumb_green);
		seekBar.setThumb(thumb);

		ViewTreeObserver vto = seekBar.getViewTreeObserver();
		vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
			public boolean onPreDraw() {
				Resources res = getResources();
				Drawable thumb = res.getDrawable(R.drawable.thumb_green);
				double h = seekBar.getMeasuredHeight() * 0.85; // 8 * 1.5 = 12
				double w = h;
				Bitmap bmpOrg = ((BitmapDrawable)thumb).getBitmap();
				Bitmap bmpScaled = Bitmap.createScaledBitmap(bmpOrg,(int) w,(int) h, true);
				Drawable newThumb = new BitmapDrawable(res, bmpScaled);
				newThumb.setBounds(0, 0, newThumb.getIntrinsicWidth(), newThumb.getIntrinsicHeight());
				seekBar.setThumb(newThumb);

				seekBar.getViewTreeObserver().removeOnPreDrawListener(this);

				return true;
			}
		});

		seekBar.setEnabled(false);

		batteryTextView = (LinearLayout) rootView
				.findViewById(R.id.displayBatteryView);
		batteryTextView.setOnClickListener(this);

		ramInfo = (CircleView) rootView.findViewById(R.id.ramInfo);
		ramInfo.setText("RAM");
		ramInfo.setOnClickListener(this);

		((TextView) initTextView(R.id.ramInfo_Used, R.id.descTitle))
				.setText("Used");
		valueUsedRAM = ((TextView) initTextView(R.id.ramInfo_Used,
				R.id.descValue));
		((TextView) initTextView(R.id.ramInfo_Free, R.id.descTitle))
				.setText("Free");
		valueFreeRAM = ((TextView) initTextView(R.id.ramInfo_Free,
				R.id.descValue));

		cpuInfo = (CircleView) rootView.findViewById(R.id.cpuInfo);
		cpuInfo.setText("CPU");
		cpuInfo.setOnClickListener(this);

		((TextView) initTextView(R.id.cpuInfo_Used, R.id.descTitle))
				.setText("Used");
		valueUsedCPU = ((TextView) initTextView(R.id.cpuInfo_Used,
				R.id.descValue));

		((TextView) initTextView(R.id.cpuInfo_Free, R.id.descTitle))
				.setText("Free");
		valueFreeCPU = ((TextView) initTextView(R.id.cpuInfo_Free,
				R.id.descValue));

		AnimationSet set = new AnimationSet(true);

		Animation animation = new AlphaAnimation(0.0f, 1.0f);
		animation.setDuration(500);
		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
				Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF,
				-1.0f, Animation.RELATIVE_TO_SELF, 0.0f);
		animation.setDuration(1000);
		set.addAnimation(animation);

		LayoutAnimationController controller = new LayoutAnimationController(
				set, 0.5f);

		settings_ListView.setLayoutAnimation(controller);

	}

	/**
	 * This method returns battery temperature from KTLibrary.
	 * 
	 * @return battery_temperature
	 */
	public float getBatteryTemp() {
		information.calculate(context);
		return information.getTemperature();
	}

	// private String displayTempToStringWithUnit() {
	//
	// AppSettingsPreference appSetting = new AppSettingsPreference(context);
	// int tempUnitsToShow = appSetting.getTemperatureUnitToShow();
	// if(KTEnum.TEMPERATURE_UNIT.CELSIUS.getValue() == tempUnitsToShow ) {
	// return batteryTmp+" "+Utility.CELCIUS_UNICODE;
	// }
	// else {
	// return
	// Utility.convertCelsiusToFahrenheit(batteryTmp)+" "+Utility.FARENHEIT_UNICODE;
	// }
	// }

	/**
	 * This method is used to get battery temperature and updating ui i.e
	 * SeekBar.
	 */
	public void updateBatteryTempUi() {
		temperatureTextView.setText(Utility.tempWithUnits(batteryTmp,
				temperatureUnit));

		if (((int) batteryTmp) >= 40) {
			descriptionToBatteryTemp
					.setBackgroundResource(R.drawable.temp_error);
			Animation animation = AnimationUtils.loadAnimation(context,
					R.anim.fade_out);
			descriptionToBatteryTemp.startAnimation(animation);
			thumb = getResources().getDrawable(R.drawable.thumb_red);
			seekBar.setThumb(thumb);
			ViewTreeObserver vto = seekBar.getViewTreeObserver();
			vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
				public boolean onPreDraw() {
					Resources res = getResources();
					Drawable thumb = res.getDrawable(R.drawable.thumb_red);
					double h = seekBar.getMeasuredHeight() * 0.85; // 8 * 1.5 = 12
					double w = h;
					Bitmap bmpOrg = ((BitmapDrawable)thumb).getBitmap();
					Bitmap bmpScaled = Bitmap.createScaledBitmap(bmpOrg,(int) w,(int) h, true);
					Drawable newThumb = new BitmapDrawable(res, bmpScaled);
					newThumb.setBounds(0, 0, newThumb.getIntrinsicWidth(), newThumb.getIntrinsicHeight());
					seekBar.setThumb(newThumb);

					seekBar.getViewTreeObserver().removeOnPreDrawListener(this);

					return true;
				}
			});
		} else {
			descriptionToBatteryTemp.setBackgroundResource(R.drawable.temp_ok);
			descriptionToBatteryTemp.clearAnimation();
			thumb = getResources().getDrawable(R.drawable.thumb_green);
			seekBar.setThumb(thumb);
			ViewTreeObserver vto = seekBar.getViewTreeObserver();
			vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
				public boolean onPreDraw() {
					Resources res = getResources();
					Drawable thumb = res.getDrawable(R.drawable.thumb_green);
					double h = seekBar.getMeasuredHeight() * 0.85; // 8 * 1.5 = 12
					double w = h;
					Bitmap bmpOrg = ((BitmapDrawable)thumb).getBitmap();
					Bitmap bmpScaled = Bitmap.createScaledBitmap(bmpOrg,(int) w,(int) h, true);
					Drawable newThumb = new BitmapDrawable(res, bmpScaled);
					newThumb.setBounds(0, 0, newThumb.getIntrinsicWidth(), newThumb.getIntrinsicHeight());
					seekBar.setThumb(newThumb);

					seekBar.getViewTreeObserver().removeOnPreDrawListener(this);

					return true;
				}
			});

		}
		seekBar.setProgress(((int) batteryTmp));
	}

	boolean isToShowProgressDialog = false;

	// class Async extends AsyncTask<String, String, String> {
	//
	// @Override
	// protected String doInBackground(String... params) {
	// runInBackGround();
	// publishProgress("");
	// return null;
	// }
	//
	// @Override
	// protected void onProgressUpdate(String... values) {
	// updateUI();
	// }
	// }

	@Override
	public void onClick(View v) {
		FragmentListener fragmentListener = (FragmentListener) getActivity();
		if (v.getId() == R.id.ramInfo) {
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					new GUIRAM());
		} else if (v.getId() == R.id.cpuInfo) {
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					new GUICPU());
		} else if (v.getId() == R.id.displayBatteryView) {
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					new GUIBattery());
		}
	}

	private View initTextView(int parentViewId, int childViewId) {
		View view = rootView.findViewById(parentViewId);
		View findChildView = view.findViewById(childViewId);
		return findChildView;
	}

	/**
	 * This method shows progress dialog status i.e visible or not.
	 * 
	 * @return status
	 */
	public static boolean isDialogShow() {
		return myprogressDialog.isShowing();
	}

	// private String usedMemory, FreeMemory;

	private void refresViewsValue() {
		try {
			LogWrite.d(tag, "--------------1");
			valueUsedRAM.setText(getString(ktMemory.getUsed(), " Mb"));
			LogWrite.d(tag, "--------------2");
			valueFreeRAM.setText(getString(ktMemory.getFree(), " Mb"));
			LogWrite.d(tag, "--------------3");
			valueFreeCPU.setText(String.valueOf(cpufree) + " %");
			LogWrite.d(tag, "--------------4");
			valueUsedCPU.setText(String.valueOf(cpuUsed) + " %");
			LogWrite.d(tag, "--------------5");
			cpuInfo.setProgress(cpuUsed);
			LogWrite.d(tag, "--------------6");
			ramInfo.setProgress(ktMemory.getUsedInPercentage());
			LogWrite.d(tag, "--------------7");
			diagnoseAdapter.notifyDataSetChanged();
			LogWrite.d(tag, "--------------8");
			/*
			 * Update Battery UI
			 */
			updateBatteryTempUi();
			LogWrite.d(tag, "--------------9");

		} catch (Exception e) {
			LogWrite.e(tag, "RefresViewsValue ExceptionDTO : " + e.toString());
		}
	}

	public String getString(int value, String postFix) {
		return value + postFix;
	}

	public String getString(float value, String postFix) {
		return value + postFix;
	}

	// private String settingNameTT, lastOnTime;

	@Override
	public void runInBackGround() {
		if (isToShowProgressDialog) {
			isToShowProgressDialog = false;
			getActivity().runOnUiThread(new Runnable() {
				@Override
				public void run() {
					myprogressDialog = new MyProgressDialog(getActivity());
					myprogressDialog.show();
				}
			});
		}
		LogWrite.d(tag, "Run in Background: Start ");
		initVariables();
		ArrayList<SettingStateDTO> dto = settingStateMonitor.getSettingState();
		arrayListSettingStateDTO.clear();
		arrayListSettingStateDTO.addAll(dto);
		LogWrite.d(tag, "Run in Background: Finish");

		for (SettingStateDTO settingStateDTO : dto) {
			LogWrite.d(tag, settingStateDTO.getSettingName() + " : "
					+ settingStateDTO.getOnTime());
		}

	}

	private void initVariables() {
		try {
			ktCPUUsage.refresh(5);
			cpuUsed = ktCPUUsage.getTotalCPUUsage();
			cpufree = ktCPUUsage.getFreeCPUUsage();
			ktMemory = ktUsageRAM.getMeoryInfo();
			batteryTmp = getBatteryTemp();
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO : " + e.toString());
		}
	}

	@Override
	public void updateUI() {
		try {
			LogWrite.d(tag, "Update Ui ");
			if (myprogressDialog != null)
				if (myprogressDialog.isShowing())
					myprogressDialog.dismiss();
			refresViewsValue();
			LogWrite.d(tag, "Update Ui Finish");
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO..." + e.toString());
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		LogWrite.d(tag, "onDestroy :");
		firstTimeFlag = false;
	}

	@Override
	public void onStop() {
		super.onStop();
		LogWrite.d(tag, "onStop :");
	}

	@Override
	public void onResume() {
		super.onResume();
		LogWrite.d(tag, "onResume :");
	}

	@Override
	public void onPause() {
		super.onPause();
		LogWrite.d(tag, "onPause :");
	}
}
