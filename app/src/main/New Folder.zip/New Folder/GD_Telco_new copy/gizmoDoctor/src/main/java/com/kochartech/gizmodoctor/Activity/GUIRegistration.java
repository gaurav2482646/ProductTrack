package com.kochartech.gizmodoctor.Activity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.CustomView.MyAlertDialog;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.HelperClass.AppConstants;
import com.kochartech.gizmodoctor.HelperClass.AppInfo;
import com.kochartech.gizmodoctor.HelperClass.BackgroundTaskManager;
import com.kochartech.gizmodoctor.HelperClass.Config;
import com.kochartech.gizmodoctor.HelperClass.ConnectionDetector;
import com.kochartech.gizmodoctor.HelperClass.DeviceInformation;
import com.kochartech.gizmodoctor.HelperClass.HttpPostConnection;
import com.kochartech.gizmodoctor.Preferences.ActivationKeyPreference;
import com.kochartech.gizmodoctor.R;

import org.json.JSONException;
import org.json.JSONObject;

public class GUIRegistration extends ActionBarActivity {

    private final String Action_ActivationKeyRegistration = "ActivationKeyRegistration";
    private final String Action_ForgetActivationKey = "ForgetActivationKey";
    private String tag = "GUIRegistration";
    private Context context;
    private DeviceInformation deviceInfo;
    private String imei, brand, model, appType = "Buy", appVersion;
    private EditText userNameEditTxt, emailEditTxt, mobileEditTxt,
            activationKeyEditTxt;
    private GUIRegistration guiRegistration;
    // private Intent intentGUIActivation;
    private MyProgressDialog myProgressDialog;
    private ConnectionDetector connDetector;
    private AppConstants appConstants;
    private ActivationKeyPreference activationKeyPreference;

    public static long convertDaysToMilliseconds(int numOfDays) {
        return numOfDays * 24 * 60 * 60 * 1000L;
    }

    /*
     * it return true if integer value receive from the server
     */
    public static boolean isNumOfDaysReceived(String serverMessage) {
        try {
            Integer.parseInt(serverMessage);
            return true;
        } catch (NumberFormatException e) {
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initVariables();
        initUi();
    }

    public void initVariables() {
        context = this;
        guiRegistration = this;
        activationKeyPreference = new ActivationKeyPreference(context);
        appConstants = new AppConstants();
        connDetector = new ConnectionDetector(context);

        // intentGUIActivation = new Intent(context, GUIActivation.class);
        deviceInfo = new DeviceInformation(context);

        imei = deviceInfo.getIMEI();
        brand = deviceInfo.getBrand();
        model = deviceInfo.getModel();
        appVersion = AppInfo.getApplicationVersionName(context);

        LogWrite.d(tag, "initVariables finish");

        // My
    }

    public void initUi() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_registration);
        userNameEditTxt = (EditText) findViewById(R.id.userNameEditTxt);
        emailEditTxt = (EditText) findViewById(R.id.emailEditTxt);
        mobileEditTxt = (EditText) findViewById(R.id.mobileEditTxt);
        activationKeyEditTxt = (EditText) findViewById(R.id.activationKeyEditTxt);

        myProgressDialog = new MyProgressDialog(this);

        LogWrite.d(tag, "initUi finsih");
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        // Window window = getWindow();
        // window.setFormat(PixelFormat.RGBA_8888);
    }

    /*
     * handle click event
     */
    public void onClick(View view) {

        if (connDetector.isInternetAvailable()) {
            if (view.getId() == R.id.submitBt) {
                registerUser();
            } else if (view.getId() == R.id.iHaveActivationKeyTxtView) {
                forgetActivationKey();
            }
        } else {
            MyAlertDialog.showAlertDialog(context,
                    R.string.InternetConnectionTxt,
                    R.string.InternetNotAvailableTxt);
        }

    }

    public void registerUser() {
        String userName = userNameEditTxt.getText().toString().trim();
        String email = emailEditTxt.getText().toString().trim();
        String mobile = mobileEditTxt.getText().toString().trim();
        String actiationKey = activationKeyEditTxt.getText().toString().trim();

        // validate text Field values
        if (userName.length() == 0) {
            Toast.makeText(context, "Please enter user name",
                    Toast.LENGTH_SHORT).show();
            userNameEditTxt.requestFocus();
        } else if (email.length() == 0) {
            Toast.makeText(context, "Please enter email address",
                    Toast.LENGTH_SHORT).show();
            emailEditTxt.requestFocus();
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email)
                .matches()) {
            Toast.makeText(context, "Please enter valid email address",
                    Toast.LENGTH_SHORT).show();
            emailEditTxt.requestFocus();
        } else if (mobile.length() == 0) {
            Toast.makeText(context, "Please enter mobile number",
                    Toast.LENGTH_SHORT).show();
            mobileEditTxt.requestFocus();
        } else if (mobile.length() < 10) {
            Toast.makeText(context, "Please enter valid mobile number",
                    Toast.LENGTH_SHORT).show();
            mobileEditTxt.requestFocus();
        } else if (actiationKey.length() == 0) {
            Toast.makeText(context, "Please enter Activation key",
                    Toast.LENGTH_SHORT).show();
            activationKeyEditTxt.requestFocus();
        } else if (!actiationKey.toLowerCase().startsWith(
                appConstants.getApplicationkeycode().toLowerCase())) {
            Toast.makeText(context, "Please enter valid Activation key",
                    Toast.LENGTH_SHORT).show();
            activationKeyEditTxt.requestFocus();
        } else {

			/*
             * validations are fine and sending request to server.
			 */

            JSONObject jsonRegisterInfo = new JSONObject();
            try {

                jsonRegisterInfo.put("ActivationKey", actiationKey);
                jsonRegisterInfo.put("AppType", "Buy");
                jsonRegisterInfo.put("Brand", brand);
                jsonRegisterInfo.put("CustomerName", userName);
                jsonRegisterInfo.put("Email", email);
                jsonRegisterInfo.put("IMEI", imei);
                jsonRegisterInfo.put("KeyCode",
                        appConstants.getApplicationkeycode());
                jsonRegisterInfo.put("Mobile", mobile);
                jsonRegisterInfo.put("Model", model);
                jsonRegisterInfo.put("Version", appVersion);

            } catch (JSONException e) {
                LogWrite.d(tag, "Json ExceptionDTO..." + e);
            }

            String message = jsonRegisterInfo.toString();
            LogWrite.d(tag, "Register User Json: " + message);

            new BackgroundOperation(Action_ActivationKeyRegistration)
                    .execute(message);

        }
    }

    public void forgetActivationKey() {
        JSONObject json = new JSONObject();
        try {
            json.put("imei", imei);
            json.put("keycode", appConstants.getApplicationkeycode());

        } catch (Exception e) {
        }
        String message = json.toString();
        new BackgroundOperation(Action_ForgetActivationKey).execute(message);
    }

    public String getStringMessage(String serverMessage) {
        if (serverMessage.equalsIgnoreCase("-A")
                || serverMessage.equalsIgnoreCase("-B"))
            return "Invalid Activation key.";
        else
            return "Fail to Register";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogWrite.d(tag, "OnDestroy Work");
    }

    // public void getJson
    class BackgroundOperation extends AsyncTask<String, String, String> {
        private String serverResponse;
        private String actionToPerform;

        public BackgroundOperation(String actionToPerform) {
            this.actionToPerform = actionToPerform;

        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            if (myProgressDialog != null) {
                if (!myProgressDialog.isShowing())
                    myProgressDialog.show();
            }
        }

        @Override
        protected String doInBackground(String... params) {
            tag = "BackgroundOperation";
            // TODO Auto-generated method stub
            String message = params[0];
            HttpPostConnection httpConnection = null;
            String serverUrl = null;
            if (actionToPerform
                    .equalsIgnoreCase(Action_ActivationKeyRegistration))
                serverUrl = Config.getUrl_ValidateKey();
            else if (actionToPerform
                    .equalsIgnoreCase(Action_ForgetActivationKey))
                serverUrl = Config.getUrl_ApplicationKey();

            LogWrite.d(tag, "method: " + serverUrl);
            LogWrite.d(tag, "Message To sever: " + message);

            httpConnection = new HttpPostConnection(context, serverUrl);
            httpConnection.connect();
            httpConnection.writeToServer(message);
            String serverResponse = httpConnection.readFromServer();

            if (serverResponse != null)
                publishProgress(serverResponse);

            return null;
        }

        @Override
        protected void onProgressUpdate(String... serverResponse) {
            // TODO Auto-generated method stub
            super.onProgressUpdate(serverResponse);
            String serverResponseMessage = serverResponse[0].replace("\"", "")
                    .trim();
            LogWrite.d(tag, "serverResponseMessage: " + serverResponseMessage);
            if (actionToPerform
                    .equalsIgnoreCase(Action_ActivationKeyRegistration)) {
                LogWrite.d(tag, "Action_ActivationKeyRegistration");
                boolean isActivationKeyValid = false;
                if (isNumOfDaysReceived(serverResponseMessage)) {
                    int numOfDays = Integer.valueOf(serverResponseMessage);
                    if (numOfDays > 0) {
                        // Num of Days greater than 0 it means Activation key is
                        // Valid.

                        isActivationKeyValid = true;
                        LogWrite.d(tag, "NumOfDays: " + numOfDays);
                        long numOfDaysInMilliSeconds = convertDaysToMilliseconds(numOfDays);
                        LogWrite.d(tag, "NumOfDays in Milliseconds: "
                                + numOfDaysInMilliSeconds);

                        activationKeyPreference
                                .setIsActivationKeyRegister(true);
                        activationKeyPreference
                                .setLeftTime(numOfDaysInMilliSeconds);
                        activationKeyPreference.setLastScanTime(System
                                .currentTimeMillis());

                        BackgroundTaskManager.startTask(context);

                        startActivity(new Intent(context,
                                NavDrawerActivity.class));

                        guiRegistration.finish();
                    } else {
                        isActivationKeyValid = true;
                        Toast.makeText(context, "Activation key has expired.",
                                Toast.LENGTH_LONG).show();
                    }
                }

                if (!isActivationKeyValid) {
                    String serverMsgMeaning = getStringMessage(serverResponseMessage);
                    Toast.makeText(context, serverMsgMeaning, Toast.LENGTH_LONG)
                            .show();
                }
            } else if (actionToPerform
                    .equalsIgnoreCase(Action_ForgetActivationKey)) {
                LogWrite.d(tag, "Action_ForgetActivationKey");
                if (serverResponseMessage.equalsIgnoreCase("-1")) {
                    Toast.makeText(context, "Device is not registered.",
                            Toast.LENGTH_LONG).show();
                } else if (serverResponseMessage.contains("@")) {
                    Intent intent = new Intent(context,
                            MyHiddenActivity_Ok.class);
                    intent.putExtra("usermsg", "Activation key send to: "
                            + serverResponseMessage);
                    startActivity(intent);
                }
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            if (myProgressDialog != null) {
                if (myProgressDialog.isShowing())
                    myProgressDialog.dismiss();
            }
        }

    }
}
