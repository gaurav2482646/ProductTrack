package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;

public class APNCorrectDialog extends Activity 
{
	TextView messageTextView;
	Button openSettingButton;
	String apn;
	private APNCorrectDialog apnCorrectDialog = null;
	private APNCorrectDialog getInstance()
	{
		if(apnCorrectDialog == null)
		{
			apnCorrectDialog = new APNCorrectDialog();
		}
		return apnCorrectDialog;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_layout);
		messageTextView = (TextView) findViewById(R.id.message);
		openSettingButton = (Button) findViewById(R.id.okBtn);
		
		apn = getIntent().getExtras().getString("APN");
		
		messageTextView.setText("Click Button to correct APN Settings. APN for your provider is '" + apn +"'");
		openSettingButton.setOnClickListener(new OnClickListener() 
		{	
			@Override
			public void onClick(View v) 
			{
				startActivity(new Intent(Settings.ACTION_APN_SETTINGS).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
				finish();
			}
		});
		
	}
}
