package com.kochartech.devicemax.dm;

import com.kochartech.devicemax.Activities.LogWrite;

public class ParseCommands extends DmCommand
{

	public ParseCommands(String parseCommandsString)
	{
		String dataKey = "", dataValue = "";
		int cmdCount = 0;
//		boolean flag = true;
		char[] dataCharArray = parseCommandsString.toCharArray();
		int dataCharArrayLength = dataCharArray.length;

		for (int j = 0; j < dataCharArrayLength; j++)
		{
			if (dataCharArray[j] == ':')
			{
				cmdCount++;
				if (dataKey.equals("CMD-" + cmdCount))
				{
					j++;
					while (dataCharArray[j] != ';')
					{
						dataValue += dataCharArray[j];
						j++;
					}
					hashTable.put(dataKey, dataValue);
					String currentCommand = "";
					j++;
					if (dataValue.equals("STRTSESS"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						j = j + 1;
						dataKey = "";
						dataValue = "";

					} else if (dataValue.equals("WIPE"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						j = j + 1;
						dataKey = "";
						dataValue = "";

					} else if (dataValue.equals("LOCK"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						j = j + 1;
						dataKey = "";
						dataValue = "";

					} else if (dataValue.equals("UNLOCK"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						j = j + 1;
						dataKey = "";
						dataValue = "";

					} else if (dataValue.equals("ENABLEDISABLEAPPS"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new EnableServices(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("FLGSTG"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new EnableServices(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("OPNSTG"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new OpenSettings(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("CRTPRF"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new CreateProfile(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("EDTPRF"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new EditProfile(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					}

					else if (dataValue.equals("DELPRF"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new DeleteProfile(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("DELALLPRF"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						j = j + 1;
						dataKey = "";
						dataValue = "";

					} else if (dataValue.equals("GETAPPS"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;";
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("ADDBKM"))
					{
						System.out.println("Add Book mark");
					} else if (dataValue.equals("CLRCACHE"))
					{
						System.out.println("Clear cache");
					} else if (dataValue.equals("LOCK"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";

						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("PING"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new Ping(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("TRCRT"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new Trace(currentCommand);
						j = j + 3;
						dataKey = "";
						dataValue = "";
					} else if (dataValue.equals("WIPE"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";

						j = j + 3;
						dataKey = "";
						dataValue = "";
					}

					else if (dataValue.equals("INSAPPS"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new InstallApp(currentCommand);
						j = j + 1;
						dataKey = "";
						dataValue = "";

					} else if (dataValue.equals("UNIAPPS"))
					{
						hashTable.put(dataKey, dataValue);
						while (dataCharArray[j] != '>')
						{
							currentCommand += dataCharArray[j];
							j++;
						}
						currentCommand += ">;>;";
						new UnInstallApp(currentCommand);
						j = j + 1;
						dataKey = "";
						dataValue = "";
					}
					else if (dataValue.equals("LCKHSET"))					
                    {
                        hashTable.put(dataKey, dataValue);
                        while (dataCharArray[j] != '>')
                        {
                            currentCommand += dataCharArray[j];
                            j++;
                        }
                        currentCommand += ">;>;";
                        j = j + 1;
                        cmdinfLOCKBreaker(currentCommand);
                        dataKey = "";
                        dataValue = "";
                    }
					else if (dataValue.equals("WIPHSET"))				
                    {
                        hashTable.put(dataKey, dataValue);
                        while (dataCharArray[j] != '>')
                        {
                            currentCommand += dataCharArray[j];
                            j++;
                        }
                        currentCommand += ">;>;";
                        j = j + 1;
                        cmdinfLOCKBreaker(currentCommand);
                        dataKey = "";
                        dataValue = "";
                    }
					if (dataValue.equals("FLAGAPPS"))					
                    {
                        hashTable.put(dataKey, dataValue);
                        while (dataCharArray[j] != '>')
                        {
                            currentCommand += dataCharArray[j];
                            j++;
                        }
                        currentCommand += ">;>;";
                        j = j + 1;
                        cmdFLGAPPS(currentCommand);
                        dataKey = "";
                        dataValue = "";
                    }
					if (dataValue.equals("GETCORDS"))					
                    {
                        hashTable.put(dataKey, dataValue);
                        while (dataCharArray[j] != '>')
                        {
                            currentCommand += dataCharArray[j];
                            j++;
                        }
                        currentCommand += ">;>;";
                        j = j + 1;
                        LogWrite.d("*****************************",currentCommand);
//                        cmdFLGAPPS(currentCommand);
                        dataKey = "";
                        dataValue = "";
                    }
					if (dataValue.equals("SPDTST"))					
                    {
						  hashTable.put(dataKey, dataValue);
	                        while (dataCharArray[j] != '>')
	                        {
	                            currentCommand += dataCharArray[j];
	                            j++;
	                        }
	                        currentCommand += ">;>;";
	                        j = j + 1;
	                        cmdFLGAPPS(currentCommand);
	                        dataKey = "";
	                        dataValue = "";
					}

				} // end if CMD-cmdCount eg
			} else
			{
				dataKey += dataCharArray[j];
			}
		}
	}
	public void cmdinfLOCKBreaker(String string)
    {
        String Str = string.substring(string.lastIndexOf("<")+1,string.indexOf(";"));
        hashTable.put(Str.split(":")[0], Str.split(":")[1]);
    }
	
    public void cmdFLGAPPS(String string)
    {
        String Str = string.substring(string.lastIndexOf("<")+1,string.indexOf(">"));
        String[] strings = Str.split(";");
        for (int i = 0; i < strings.length; i++) 
        {
            hashTable.put(strings[i].split(":")[0], strings[i].split(":")[1]);            
        }
    }

}