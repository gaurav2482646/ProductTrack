package com.kochartech.devicemax.Utility;

//import com.kochartech.gizmodoctor.Activity.NavDrawerActivity;

//TOUCH = "B";
// LONGPRESS = "C";
// ACCELEROMETER = "D";
// PROXIMITY = "E";
// FLASHLIGHT = "F";
// WIFI = "G";
// GPS ="H";
// CAMERA = "I";
// BLUETOOTH = "J";
//public class HardwareTest {
//
//	public static String KEY_HARDWARE = "HARDWARETEST";
//	public static String KEY_TOUCH_HARDWARE = "TOUCH";
//	public static String KEY_VIBRATION_HARDWARE = "VIBRATION";
//	public static String KEY_FLASH_LIGHT_HARDWARE = "FLASHLIGHT";
//	public static String KEY_PROXIMITY_HARDWARE = "PROXIMITY";
//	public static String KEY_ACCELEROMETER_HARDWARE = "ACCELEROMETER";
//	public static String KEY_LONG_PRESS_HARDWARE = "LONGPRESS";
//	public static String KEY_WIFI_HARDWARE = "WIFI";
//	public static String KEY_GPS_HARDWARE = "GPS";
//	public static String KEY_BLUETOOTH_HARDWARE = "BLUETOOTH";
//	public static String KEY_CAMERA_HARDWARE = "CAMERA";
//
//	private static String hardware_test = "";
//
//	public static void test(Context context, String hardware) {
//		hardware_test = hardware;
//		Intent intent = new Intent(context, NavDrawerActivity.class);
//		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//		intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//		intent.putExtra(KEY_HARDWARE, hardware_test);
//		context.startActivity(intent);
//	}
//
//	// public HardwareTest(Context context) {
//	//
//	// }
// }
