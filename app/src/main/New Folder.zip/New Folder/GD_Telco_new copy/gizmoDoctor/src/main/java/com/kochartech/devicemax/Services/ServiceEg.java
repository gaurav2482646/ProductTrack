package com.kochartech.devicemax.Services;
///*
// * Nishant
// */
//package com.kochar.MDMS.Services;
//
//import java.io.File;
//import java.util.Timer;
//import java.util.TimerTask;
//
//import android.app.ActivityManager;
//import android.app.ActivityManager.RunningTaskInfo;
//import android.app.Application;
//import android.app.Service;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Environment;
//import android.os.Handler;
//import android.os.IBinder;
//import android.os.Message;
//import com.kochar.MDMS.Activities.*;
//
//import com.kochar.MDMS.Activities.DisplayPasswordScreen;
//import com.kochar.MDMS.Utility.MyDataBaseHandlerClass;
//
///*
// * Check TopMost App/Activity if ScreenLockFlag is true then password would be prompted  
// */
//public class ServiceEg extends Service 
//{  
//	String s1 = "";
//	private Timer timer = new Timer();
//	static String activePackage = "";
//	StringBuilder log1;
//	MyDataBaseHandlerClass myDataBase=null;
//	
//	
//	File root=null;
//	File file = null;
////	
//	public static boolean ScreenLockFlag=false;
//	String tag = "ServiceEg";
//	boolean f = false;
//
//	@Override
//	public void onCreate() 
//	{
//		super.onCreate();
//		startservice();
//		myDataBase = new MyDataBaseHandlerClass(getApplicationContext(),"operators.db",null,1);
//		myDataBase.getWritableDatabase();
//		root = Environment.getExternalStorageDirectory();
//        file = new File(root, "test.txt");
//	}
//    
//	public static void setActivePackage(String activePackageName)
//	{
//		ServiceEg.activePackage = activePackageName;
//	}
//	
//	@Override
//	public IBinder onBind(Intent arg0) 
//	{
//		return null;
//	}
//
//	private void startservice() 
//	{
//		toastHandler.sendEmptyMessage(0);
//	}
//
//	private final Handler toastHandler = new Handler() 
//	{
//		@Override
//		public void handleMessage(Message msg) 
//		{
//			timer.scheduleAtFixedRate(new TimerTask() 
//			{
//				
//				@Override
//				public void run() 
//				{
//					/*
//					 * we can't do events on ui directly inside main
//					 * thread,events like printing a toast message ,so we can do
//					 * this by using Handler so to print a toast message i use a
//					 * Handler object
//					 */
//					 
//					ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
//					RunningTaskInfo taskInfo = am.getRunningTasks(1).get(0);
//					String packageName = taskInfo.topActivity.getPackageName();
//					
////					LogWrite.d(tag,"TopActivity package Name ="+ packageName);
////					if(!ScreenLockFlag)
////					{
////						LogWrite.d(tag,"ScreenLockFlag ="+ ScreenLockFlag);
////						if(!packageName.trim().equalsIgnoreCase("com.kochar.MDMS.Activities"))
////						{
////							LogWrite.d(tag,"if ="+1) ;
//////							writeToFile(packageName.trim());
////							try
////							{
//////								if(Settings.System.getInt(getContentResolver(), Settings.System.AUTO_TIME, 0)==0)
//////									Settings.System.putInt(getContentResolver(),Settings.System.AUTO_TIME, 1);  
//////								Time now = new Time();
//////						        now.setToNow();
//////						        int hour = now.hour;
////						        String[] c =null;
//////						        if(9<hour&&hour<19)
//////								{
////						        	c = myDataBase.GetApplicationsFromDataBaseInBlockedTime();	
////						        	LogWrite.d(tag,"c ="+c.toString()) ;
//////								}
//////						        else 
//////						        {
//////						        	c = myDataBase.GetApplicationsFromDataBaseInUnBlockedTime();
//////								}
//////						        LogWrite.d(tag,"----------------->"+ c.length+ "   "+hour);
//////						        	if(!activePackage.equalsIgnoreCase(packageName.trim()))
//////						        		activePackage="";
////								for (int i = 0; i < c.length; i++) 
////								{
////									LogWrite.d(tag,"c["+i+"]"+c[i]) ;
////									LogWrite.d(tag,"TopActivity package Name ="+ packageName);
////									if(packageName.trim().contains(""+c[i]))
////									{
////										LogWrite.d(tag,"if ="+2);
////										if(!activePackage.equalsIgnoreCase(""+packageName.trim()))
////										{
//////											activePackage = packageName.trim();
//////											writeToFile(packageName.trim());
////									/*****************************************************************************************************************/
//////											Calendar cii=Calendar.getInstance();
//////										      String CiiDateTime =  cii.get(Calendar.HOUR_OF_DAY) + ":" +
//////											   cii.get(Calendar.MINUTE);
//////										       LogWrite.d(" Current Time string",CiiDateTime);
//////										   SimpleDateFormat dateFormat1 = new SimpleDateFormat("HH:mm");  
//////										   Date crntTime;
//////										   Date parseStartTime,parseEndTime;
//////										   try {
//////											crntTime=(Date) dateFormat1.parse(CiiDateTime);
//////											LogWrite.d("time after parse",crntTime+"<<>>");
//////											
//////											String startTimeToParse="10:00";
//////											String endTimeToParse="14:50";
//////											parseStartTime=(Date) dateFormat1.parse(startTimeToParse);
//////											parseEndTime=(Date) dateFormat1.parse(endTimeToParse);
//////											LogWrite.d("parsed start time is",parseStartTime+"<<>>");
//////											LogWrite.d("parsed end time is",parseEndTime+"<<>>");
//////											if(crntTime.after(parseStartTime))
//////											{
//////												LogWrite.d(tag, "current time is after start time ");
//////											}
//////											if((crntTime.after(parseStartTime)) &&(crntTime.before(parseEndTime)))
//////											{
//////												LogWrite.d(tag, "current time is after start time n before end time");
//////												LogWrite.d("unlock App id",""+taskInfo.id);
//////												LogWrite.d("unlock App id",""+taskInfo.id);
//////												LogWrite.d("unlock App id",""+taskInfo.id);
//////												LogWrite.d("unlock App id",""+taskInfo.id);
//////												LogWrite.d("unlock App id",""+taskInfo.id);
////												
////												ApplicationUnblockInfo.setAppId(taskInfo.id);
////												
////											    Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
////												intent.putExtra("activepackage",activePackage);
////												intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
////												ServiceEg.this.startActivity(intent);
//////											}
//////											if(crntTime.before(parseEndTime))
//////											{
//////												LogWrite.d(tag, "current time is before end time ");
//////											}
//////											
//////										} catch (ParseException e) {
//////											// TODO Auto-generated catch block
//////											e.printStackTrace();
//////										}//end catch
////								/******************************************************************************************************************/
//////											Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
//////											intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
//////											ServiceEg.this.startActivity(intent);
////							   				
////										}
////										break;
////									}
////								}								
////								if(taskInfo.topActivity.getClassName().equals("com.android.settings.DeviceAdminSettings"))
////								{
////									if(!activePackage.equalsIgnoreCase(""+packageName.trim()))
////									{
////										activePackage = packageName.trim().trim();
//////										writeToFile(packageName.trim());
////										Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
////										intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
////										ServiceEg.this.startActivity(intent);
////									}
////								}
////								if(packageName.trim().equalsIgnoreCase("com.android.launcher")||
////										packageName.trim().equalsIgnoreCase("com.sec.android.app.twlauncher")||
////										packageName.trim().equalsIgnoreCase("com.huaqin.launcherex"))
////										
////								{
////									activePackage = packageName.trim();
////									try
////									{
////										DisplayPasswordScreen.getInstance().finish();
////									}
////									catch (ExceptionDTO e)
////									{
//////										LogWrite.e(tag,e.toString());s
////									}
////								}
////							}
////							catch (ExceptionDTO e)
////							{
////								e.printStackTrace();
////							}
////						}
////					}
//					if(ScreenLockFlag)
//					{
////						LogWrite.d(tag,"ScreenLockFlag ="+ true);
////						LogWrite.d(tag,"Package Name ="+packageName.trim());
//						if(!packageName.trim().equalsIgnoreCase("com.kochar.MDMS.Activities"))
//						{
//							LogWrite.d(tag,"Enter in If");
//						//	
//					/*************************************************************************************************************************/
////							Calendar cii=Calendar.getInstance();
////						      String CiiDateTime =  cii.get(Calendar.HOUR_OF_DAY) + ":" +
////							   cii.get(Calendar.MINUTE);
////						       LogWrite.d(" Current Time string",CiiDateTime);
////						   SimpleDateFormat dateFormat1 = new SimpleDateFormat("HH:mm");  
////						   Date crntTime;
////						   Date parseStartTime,parseEndTime;
////						   try {
////							crntTime=(Date) dateFormat1.parse(CiiDateTime);
////							LogWrite.d("time after parse",crntTime+"<<>>");
////							
////							String startTimeToParse="10:00";
////							String endTimeToParse="14:50";
////							parseStartTime=(Date) dateFormat1.parse(startTimeToParse);
////							parseEndTime=(Date) dateFormat1.parse(endTimeToParse);
////							LogWrite.d("parsed start time is",parseStartTime+"<<>>");
////							LogWrite.d("parsed end time is",parseEndTime+"<<>>");
////							if(crntTime.after(parseStartTime))
////							{
////								LogWrite.d(tag, "current time is after start time ");
////							}
////							if((crntTime.after(parseStartTime)) &&(crntTime.before(parseEndTime)))
////							{
////								LogWrite.d(tag, "current time is after start time n before end time");
////
////								Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
////								intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
////								ServiceEg.this.startActivity(intent);
////							}
////							if(crntTime.before(parseEndTime))
////							{
////								LogWrite.d(tag, "current time is before end time ");
////							}
////							
////						} catch (ParseException e) {
////							// TODO Auto-generated catch block
////							e.printStackTrace();
////						}
//						
//				/******************************************************************************************************************************/
//							
//					//		writeToFile(packageName.trim());
//							Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
//							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK|
//									Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS|
//									Intent.FLAG_ACTIVITY_NO_HISTORY);
//							ServiceEg.this.startActivity(intent);
//							
//						
//						}
//				
//						
//					}
//					
//				}// end run
//				
//			}, 0, 500);// end t
//			
//				
//			
//		}
//	}; // End Handler
//
//	@Override
//	public void onDestroy() 
//	{
////		Toast.makeText(this, "My Service Stopped", Toast.LENGTH_LONG).show();
//	}
//
//	@Override
//	public void onStart(Intent intent, int startid) 
//	{
//		
//	}
//	@Override
//	public int onStartCommand(Intent intent, int flags, int startId) {
//		// TODO Auto-generated method stub
//		//return super.onStartCommand(intent, flags, startId);
//		startservice();
//		return Service.START_STICKY;
//	}
//	
////	void writeToFile(String str)
////	{
////		if (root.canWrite())
////		{
////            try 
////            {
////            	FileWriter filewriter = new FileWriter(file,true);
////                BufferedWriter out = new BufferedWriter(filewriter);
////				out.write(str+"\n");
////				out.close();
////			}
////            catch (IOException e) 
////            {
////            	LogWrite.e(tag, "MSMS_Log-> IOException->"+e.toString());
////            }
////		}
////	}
//}
//
///*
// *   Vikrant
// */
////package com.kochar.MDMS.Services;
////
////import java.io.File;
////import java.util.Timer;
////import java.util.TimerTask;
////
////import android.app.ActivityManager;
////import android.app.ActivityManager.RunningTaskInfo;
////import android.app.Service;
////import android.content.Context;
////import android.content.Intent;
////import android.os.Environment;
////import android.os.Handler;
////import android.os.IBinder;
////import android.os.Message;
////
////import com.kochar.MDMS.Activities.DisplayPasswordScreen;
////import com.kochar.MDMS.Utility.MyDataBaseHandlerClass;
////
/////*
//// * Check TopMost App/Activity if ScreenLockFlag is true then password would be prompted  
//// */
////public class ServiceEg extends Service 
////{  
////	String s1 = "";
////	private Timer timer = new Timer();
////	String activePackage = "";
////	StringBuilder LogWrite;
////	MyDataBaseHandlerClass myDataBase=null;
////	
////	
////	File root=null;
////	File file = null;
//////	
////	public static boolean ScreenLockFlag=false;
////	String tag = "ServiceEg";
////	boolean f = false;
////
////	@Override
////	public void onCreate() 
////	{
////		super.onCreate();
////		startservice();
////		myDataBase = new MyDataBaseHandlerClass(getApplicationContext(),"operators.db",null,1);
////		myDataBase.getWritableDatabase();
////		root = Environment.getExternalStorageDirectory();
////        file = new File(root, "test.txt");
////	}
////
////	@Override
////	public IBinder onBind(Intent arg0) 
////	{
////		return null;
////	}
////
////	private void startservice() 
////	{
////		toastHandler.sendEmptyMessage(0);
////	}
////
////	private final Handler toastHandler = new Handler() 
////	{
////		@Override
////		public void handleMessage(Message msg) 
////		{
////			timer.scheduleAtFixedRate(new TimerTask() 
////			{
////				
////				@Override
////				public void run() 
////				{
////					/*
////					 * we can't do events on ui directly inside main
////					 * thread,events like printing a toast message ,so we can do
////					 * this by using Handler so to print a toast message i use a
////					 * Handler object
////					 */
////					 
////					ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
////					RunningTaskInfo taskInfo = am.getRunningTasks(1).get(0);
////					String packageName = taskInfo.topActivity.getPackageName();
//////					LogWrite.d(tag,"-----------------"+ packageName);
////					if(!ScreenLockFlag)
////					{
////						if(!packageName.trim().equalsIgnoreCase("com.kochar.MDMS.Activities"))
////						{
//////							writeToFile(packageName.trim());
////							try
////							{
//////								if(Settings.System.getInt(getContentResolver(), Settings.System.AUTO_TIME, 0)==0)
//////									Settings.System.putInt(getContentResolver(),Settings.System.AUTO_TIME, 1);  
//////								Time now = new Time();
//////						        now.setToNow();
//////						        int hour = now.hour;
////						        String[] c =null;
//////						        if(9<hour&&hour<19)
//////								{
////						        	c = myDataBase.GetApplicationsFromDataBaseInBlockedTime();								
//////								}
//////						        else 
//////						        {
//////						        	c = myDataBase.GetApplicationsFromDataBaseInUnBlockedTime();
//////								}
//////						        LogWrite.d(tag,"----------------->"+ c.length+ "   "+hour);
////								for (int i = 0; i < c.length; i++) 
////								{
////									if(packageName.trim().contains(""+c[i]))
////									{
////										if(!activePackage.equalsIgnoreCase(""+packageName.trim()))
////										{
////											activePackage = packageName.trim();
//////											writeToFile(packageName.trim());
////									/*****************************************************************************************************************/
//////											Calendar cii=Calendar.getInstance();
//////										      String CiiDateTime =  cii.get(Calendar.HOUR_OF_DAY) + ":" +
//////											   cii.get(Calendar.MINUTE);
//////										       LogWrite.d(" Current Time string",CiiDateTime);
//////										   SimpleDateFormat dateFormat1 = new SimpleDateFormat("HH:mm");  
//////										   Date crntTime;
//////										   Date parseStartTime,parseEndTime;
//////										   try {
//////											crntTime=(Date) dateFormat1.parse(CiiDateTime);
//////											LogWrite.d("time after parse",crntTime+"<<>>");
//////											
//////											String startTimeToParse="10:00";
//////											String endTimeToParse="14:50";
//////											parseStartTime=(Date) dateFormat1.parse(startTimeToParse);
//////											parseEndTime=(Date) dateFormat1.parse(endTimeToParse);
//////											LogWrite.d("parsed start time is",parseStartTime+"<<>>");
//////											LogWrite.d("parsed end time is",parseEndTime+"<<>>");
//////											if(crntTime.after(parseStartTime))
//////											{
//////												LogWrite.d(tag, "current time is after start time ");
//////											}
//////											if((crntTime.after(parseStartTime)) &&(crntTime.before(parseEndTime)))
//////											{
//////												LogWrite.d(tag, "current time is after start time n before end time");
////
////												Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
////												intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
////												ServiceEg.this.startActivity(intent);
//////											}
//////											if(crntTime.before(parseEndTime))
//////											{
//////												LogWrite.d(tag, "current time is before end time ");
//////											}
//////											
//////										} catch (ParseException e) {
//////											// TODO Auto-generated catch block
//////											e.printStackTrace();
//////										}//end catch
////								/******************************************************************************************************************/
//////											Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
//////											intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
//////											ServiceEg.this.startActivity(intent);
////							   				
////										}
////										break;
////									}
////								}
////								
////								if(taskInfo.topActivity.getClassName().equals("com.android.settings.DeviceAdminSettings"))
////								{
////									if(!activePackage.equalsIgnoreCase(""+packageName.trim()))
////									{
////										activePackage = packageName.trim().trim();
//////										writeToFile(packageName.trim());
////										Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
////										intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
////										ServiceEg.this.startActivity(intent);
////										
////									}
////								}
////								if(packageName.trim().equalsIgnoreCase("com.android.launcher")||
////										packageName.trim().equalsIgnoreCase("com.sec.android.app.twlauncher"))
////								{
////									activePackage = packageName.trim();
////									try
////									{
////										DisplayPasswordScreen.getInstance().finish();
////									}
////									catch (ExceptionDTO e)
////									{
//////										LogWrite.e(tag,e.toString());s
////									}
////								}
////							}
////							catch (ExceptionDTO e)
////							{
////								e.printStackTrace();
////							}
////						}
////					}
////					else
////					{
////						if(!packageName.trim().equalsIgnoreCase("com.kochar.MDMS.Activities"))
////						{
////							
////						//	
////					/*************************************************************************************************************************/
//////							Calendar cii=Calendar.getInstance();
//////						      String CiiDateTime =  cii.get(Calendar.HOUR_OF_DAY) + ":" +
//////							   cii.get(Calendar.MINUTE);
//////						       LogWrite.d(" Current Time string",CiiDateTime);
//////						   SimpleDateFormat dateFormat1 = new SimpleDateFormat("HH:mm");  
//////						   Date crntTime;
//////						   Date parseStartTime,parseEndTime;
//////						   try {
//////							crntTime=(Date) dateFormat1.parse(CiiDateTime);
//////							LogWrite.d("time after parse",crntTime+"<<>>");
//////							
//////							String startTimeToParse="10:00";
//////							String endTimeToParse="14:50";
//////							parseStartTime=(Date) dateFormat1.parse(startTimeToParse);
//////							parseEndTime=(Date) dateFormat1.parse(endTimeToParse);
//////							LogWrite.d("parsed start time is",parseStartTime+"<<>>");
//////							LogWrite.d("parsed end time is",parseEndTime+"<<>>");
//////							if(crntTime.after(parseStartTime))
//////							{
//////								LogWrite.d(tag, "current time is after start time ");
//////							}
//////							if((crntTime.after(parseStartTime)) &&(crntTime.before(parseEndTime)))
//////							{
//////								LogWrite.d(tag, "current time is after start time n before end time");
//////
//////								Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
//////								intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
//////								ServiceEg.this.startActivity(intent);
//////							}
//////							if(crntTime.before(parseEndTime))
//////							{
//////								LogWrite.d(tag, "current time is before end time ");
//////							}
//////							
//////						} catch (ParseException e) {
//////							// TODO Auto-generated catch block
//////							e.printStackTrace();
//////						}
////						
////				/******************************************************************************************************************************/
////							
////					//		writeToFile(packageName.trim());
////							Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
////							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
////							ServiceEg.this.startActivity(intent);
////							
////						
////						}
////				
////						
////					}
////					
////				}// end run
////				
////			}, 0, 500);// end t
////			
////				
////			
////		}
////	}; // End Handler
////
////	@Override
////	public void onDestroy() 
////	{
//////		Toast.makeText(this, "My Service Stopped", Toast.LENGTH_LONG).show();
////	}
////
////	@Override
////	public void onStart(Intent intent, int startid) 
////	{
////		
////	}
////	@Override
////	public int onStartCommand(Intent intent, int flags, int startId) {
////		// TODO Auto-generated method stub
////		//return super.onStartCommand(intent, flags, startId);
////		startservice();
////		return Service.START_STICKY;
////	}
////	
//////	void writeToFile(String str)
//////	{
//////		if (root.canWrite())
//////		{
//////            try 
//////            {
//////            	FileWriter filewriter = new FileWriter(file,true);
//////                BufferedWriter out = new BufferedWriter(filewriter);
//////				out.write(str+"\n");
//////				out.close();
//////			}
//////            catch (IOException e) 
//////            {
//////            	LogWrite.e(tag, "MSMS_Log-> IOException->"+e.toString());
//////            }
//////		}
//////	}
////}
