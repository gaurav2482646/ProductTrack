package com.kochartech.devicemax.Utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;

import com.kochartech.devicemax.Activities.LogWrite;

public class DownloadApp
{
	String TAG = ">>>  DownloadApp  <<<";
	String fileURL="";
	String fileName="";
	Activity activity = null;

	public DownloadApp(Activity activity)
	{
		// TODO Auto-generated constructor stub
		this.activity = activity;

		LogWrite.d(TAG, "constor called ");
	}

	public void downloadAndInstall(String apkurl)
	{
		LogWrite.d(TAG, "in Download method");
		fileURL = apkurl;
		Thread t = new Thread(new Runnable()
		{
			public void run()
			{
				try
				{
					fileName = fileURL.substring(fileURL.lastIndexOf("/") + 1);
					LogWrite.d(TAG, "Download Starts");
					// Toast.makeText(SelfHelp.CCP, "Download starts...", Toast.LENGTH_LONG).show();
					URL url = new URL(fileURL);
					HttpURLConnection c =
							(HttpURLConnection) url.openConnection();
					c.setRequestMethod("GET");
					c.setDoOutput(true);
					c.connect();
					String PATH =
							Environment.getExternalStorageDirectory() + "/";
					File file = new File(PATH);
					file.mkdirs();
					File outputFile = new File(file, fileName);
					FileOutputStream fos = new FileOutputStream(outputFile);
					InputStream is = c.getInputStream();
					byte[] buffer = new byte[1024];
					int len1 = 0;
					while ((len1 = is.read(buffer)) != -1)
					{
						fos.write(buffer, 0, len1);
					}
					fos.close();
					is.close();
					LogWrite.d(TAG, "Download Complete");
// Toast.makeText(, "Download completed...", Toast.LENGTH_SHORT).show();
					Intent intent = new Intent(Intent.ACTION_VIEW);
					intent.setDataAndType(Uri.fromFile(new File(Environment.getExternalStorageDirectory()
							+ "/" + fileName)), "application/vnd.android.package-archive");
					activity.startActivity(intent);
				} catch (IOException e)
				{
					LogWrite.d(TAG, e.toString());
// Toast.makeText(SelfHelp.CCP, "Download error!", Toast.LENGTH_LONG).show();
				}
			}
		});
		t.start();
	}
}
