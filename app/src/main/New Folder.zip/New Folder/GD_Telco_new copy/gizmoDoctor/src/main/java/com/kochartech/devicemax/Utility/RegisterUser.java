//package com.kochartech.devicemax.Utility;
//
//import android.app.Activity;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.os.Bundle;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Toast;
//
//import com.kochartech.devicemax.Activities.LockScreenActivity;
//import com.kochartech.gizmodoctor.R;
//
//
//public class RegisterUser extends Activity
//{
//	Button btnSavePassword = null;
//	EditText enterPassword, reEnterPassword = null;
//	Context context = null;
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState)
//	{
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.username_password_layout);
//		context = getApplicationContext();
//		
//		enterPassword = (EditText) findViewById(R.id.editTextEnterPassword);
//		reEnterPassword = (EditText) findViewById(R.id.editTextReEnterPassword);
//		btnSavePassword = (Button) findViewById(R.id.buttonSavePassword);
//
//		btnSavePassword.setOnClickListener(new OnClickListener()
//		{
//			public void onClick(View v)
//			{
//				if (enterPassword.length() > 0 && reEnterPassword.length() > 0)
//				{
//					String password = enterPassword.getText().toString();
//					String rePassword = reEnterPassword.getText().toString();
//					if (password.equals(rePassword))
//					{
//						// shared preferences
//						SharedPreferences preferences =
//								getSharedPreferences("registerUser", Context.MODE_PRIVATE);
//						Editor editor = preferences.edit();
//						editor.putString("userPassword", password);
//						editor.commit();
//
//						Intent intentToCallLockScreen =
//								new Intent(context, LockScreenActivity.class);
//						startActivity(intentToCallLockScreen);
//						finish();
//
//					} // end if password.equals(rePassword)
//					else
//					{
//						Toast.makeText(context, "Password doesn't match", 2000).show();
//					}
//				} else
//				{
//					Toast.makeText(context, "Password not valid", 2000).show();
//				}
//
//			}
//		});
//
//	}
//
//}
