//package com.kochartech.gizmodoctor.DataBase;
//
//import java.util.logging.Logger;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//
//import android.content.ContentValues;
//import android.content.Context;
//import android.database.Cursor;
//import android.database.sqlite.SQLiteDatabase;
//import android.util.Log;
//
//public class DBHelper_TotalCPU {
//	private String tag = "CPUUsageTotalDBHelper";
//	private Context context;
//	private static DBHelper_TotalCPU classInstance = null;
//	private MySQLiteOpenHelper mySQLiteOpenHelper;
//	private SQLiteDatabase db;
//	private static final int TotalCPUUsageColumnID = 1;
//
//	public static DBHelper_TotalCPU getInstance(Context context) {
//		if (classInstance == null)
//			classInstance = new DBHelper_TotalCPU(context);
//		return classInstance;
//	}
//
//	private DBHelper_TotalCPU(Context context) {
//		LogWrite.d(tag, "constructor");
//		this.context = context;
//		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
//	}
//
//	public void open() {
//		LogWrite.d(tag, "open");
//		db = mySQLiteOpenHelper.getWritableDatabase();
//	}
//
//	public void close() {
//		LogWrite.d(tag, "close");
//		db.close();
//	}
//
//	public Cursor getAllColumns() {
//		Cursor cursor = db.query(MySQLiteOpenHelper.CPUUsageTotal_TableName,
//				null, null, null, null, null, null);
//
//		LogWrite.d(tag, "Cursor Size :" + cursor.getCount());
//		if (cursor.getCount()>0) 
//		{
//			if (cursor.moveToFirst()) {
//				do {
//					float cpuUsage = cursor
//							.getFloat((cursor
//									.getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnUsage)));
//					int numOfDiagnose = cursor
//							.getInt(cursor
//									.getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnNumOfDiagnose));
//					int columnId = cursor
//							.getInt(cursor
//									.getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnID));
//
//					LogWrite.d(tag, "getAllColumns () : columnId :" + columnId);
//					LogWrite.d(tag, "getAllColumns () : cpuUsage :" + cpuUsage);
//					LogWrite.d(tag, "getAllColumns () : numOfDiagnose :"
//							+ numOfDiagnose);
//
//				} while (cursor.moveToNext());
//			}
//		}
//		return cursor;
//	}
//
//	public void update(float cpuUsage, int numOfDiagnose) {
//		ContentValues values = new ContentValues();
//
//		LogWrite.d(tag,"update () : cpuUsage :"+cpuUsage);
//		LogWrite.d(tag,"update () : numOfDiagnose :"+numOfDiagnose);
//		
//		values.put(MySQLiteOpenHelper.CPUUsageTotal_ColumnUsage, cpuUsage);
//		values.put(MySQLiteOpenHelper.CPUUsageTotal_ColumnNumOfDiagnose,
//				numOfDiagnose);
//		long id = db.update(MySQLiteOpenHelper.CPUUsageTotal_TableName, values,
//				MySQLiteOpenHelper.CPUUsageTotal_ColumnID + "=?",
//				new String[] { String.valueOf(TotalCPUUsageColumnID) });
//		
//		LogWrite.d(tag, "update () : update Query id: "+id);
//		
//
//	}
//
//	public void init(SQLiteDatabase db) {
//		LogWrite.d(tag, "init Work: ");
//		ContentValues values = new ContentValues();
//		values.put(MySQLiteOpenHelper.CPUUsageTotal_ColumnID,
//				TotalCPUUsageColumnID);
//		values.put(MySQLiteOpenHelper.CPUUsageTotal_ColumnUsage, 0);
//		values.put(MySQLiteOpenHelper.CPUUsageTotal_ColumnNumOfDiagnose, 0);
//		long id = db.insertOrThrow(MySQLiteOpenHelper.CPUUsageTotal_TableName,
//				null, values);
//
//		LogWrite.d(tag, "id: " + id);
//	}
//
//}
