//package com.kochartech.gizmodoctor.Activity;
//
//import java.util.List;
//
//import android.content.Context;
//import android.util.Log;
//
//import com.kochartech.gizmodoctor.DataBase.AppInfo;
//import com.kochartech.gizmodoctor.DataBase.DataSource_AppsInfo;
//import com.kochartech.gizmodoctor.DataBase.DataSource_CPUUsage;
//import com.kochartech.gizmodoctor.DataBase.DataSource_RAMUsage;
//
//public class PrintTable
//{
//	private String tag = "PrintTable";
//	public void printCPUUsageTable(Context context)
//	{
//		DataSource_CPUUsage dsCPUUsage = DataSource_CPUUsage.getInstance(context);
////		dsCPUUsage.open();
//		DataSource_AppsInfo dsApps  = DataSource_AppsInfo.getInstance(context);
//		dsApps.open();
//		
//		
//		List<AppInfo> apps = dsApps.queryAllRecord();
//		
//		for(AppInfo appInfo : apps)
//		{
//			int appId = appInfo.getRowId();
//			String appName = appInfo.getAppName();
//			
//			dsCPUUsage.getRecord(appId);
//			
////			LogWrite.d(tag,appName+":"+appId+"= ")
//		}
//	}
//	
//	
//	public void printRAMUsageTable(Context context)
//	{
//		DataSource_RAMUsage dsRAMUsage = DataSource_RAMUsage.getInstance(context);
////		dsRAMUsage.open();
//		DataSource_AppsInfo dsApps  = DataSource_AppsInfo.getInstance(context);
//		dsApps.open();
//		
//		
//		List<AppInfo> apps = dsApps.queryAllRecord();
//		
//		for(AppInfo appInfo : apps)
//		{
//			int appId = appInfo.getRowId();
//			String appName = appInfo.getAppName();
//			
//			dsRAMUsage.getRecord(appId);
//			
////			LogWrite.d(tag,appName+":"+appId+"= ")
//		}
//	}
//}
