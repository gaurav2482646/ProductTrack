package com.kochartech.devicemax.Utility;

import org.json.JSONObject;

import com.kochartech.devicemax.Activities.LogWrite;

public class CameraDTO {
	private long sessionId;
	private long messageId;
	private byte[] imageBytes;
	private String type;
	private boolean flashStatus;
	private boolean autoFlashStatus;
	private boolean autoFocusStatus;
	private String mode;
	private double imagePixcels;
	private String imageSize;

	public long getSessionId() {
		return sessionId;
	}

	public void setSessionId(long sessionId) {
		this.sessionId = sessionId;
	}

	public long getMessageId() {
		return messageId;
	}

	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}

	public byte[] getImageBytes() {
		return imageBytes;
	}

	public void setImageBytes(byte[] imageBytes) {
		this.imageBytes = imageBytes;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isFlashStatus() {
		return flashStatus;
	}

	public void setFlashStatus(boolean flashStatus) {
		this.flashStatus = flashStatus;
	}

	public boolean isAutoFlashStatus() {
		return autoFlashStatus;
	}

	public void setAutoFlashStatus(boolean autoFlashStatus) {
		this.autoFlashStatus = autoFlashStatus;
	}

	public boolean isAutoFocusStatus() {
		return autoFocusStatus;
	}

	public void setAutoFocusStatus(boolean autoFocusStatus) {
		this.autoFocusStatus = autoFocusStatus;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public double getImagePixcels() {
		return imagePixcels;
	}

	public void setImagePixcels(double imagePixcels) {
		this.imagePixcels = imagePixcels;
	}

	public String getImageSize() {
		return imageSize;
	}

	public void setImageSize(String imageSize) {
		this.imageSize = imageSize;
	}

	/*
	 * { "CameraParameters":{ "CameraAutoFlash":"String content",
	 * "CameraAutoFocus":"String content", "CameraFlash":"String content",
	 * "CameraImage":[81, 109, 70, 122, 90, 83, 65, 50, 78, 67, 66, 84, 100, 72,
	 * 74, 108, 89, 87, 48, 61], "CameraImagePath":"String content",
	 * "CameraImageSize":"String content", "CameraMode":"String content",
	 * "CameraPixels":"String content", "CameraSelected":"String content" },
	 * "MessageId":9223372036854775807, "SessionId":9223372036854775807 }
	 */

	public JSONObject toJson() {
		JSONObject mainJsonObject = null;
		try {
			mainJsonObject = new JSONObject();
			mainJsonObject.put("MessageId", getMessageId());
			mainJsonObject.put("SessionId", getSessionId());
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("CameraSelected", getType());
			jsonObject.put("CameraFlash", "false");
			jsonObject.put("CameraAutoFlash", "false");
			jsonObject.put("CameraAutoFocus", "false");
			jsonObject.put("CameraMode", "" + getMode());
			jsonObject.put("CameraPixels", "" + getImagePixcels());
			jsonObject.put("CameraImageSize", "" + getImageSize());
			jsonObject.put("CameraImage", "" + getImageBytes());
			mainJsonObject.put("CameraParameters", jsonObject);
		} catch (Exception e) {
			LogWrite.e(CameraDTO.class.getSimpleName(),
					"CameraDto toJson Exc  :" + e.toString());
		}
		return mainJsonObject;
	}

}
