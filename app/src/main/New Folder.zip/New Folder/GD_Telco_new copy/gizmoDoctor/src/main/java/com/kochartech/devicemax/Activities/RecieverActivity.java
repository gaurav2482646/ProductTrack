package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;
/**
 * Shows Dialog on toggling Airplane Mode ON/OFF.
 * 
 * 
 * @author nishant.kumar
 *
 */
public class RecieverActivity extends Activity 
{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		String TAG = "RecieverActivity";
		super.onCreate(savedInstanceState);

		TextView tv = new TextView(this);
		AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
		tv.setText("You have enabled airplane mode. Are you sure to enable it?");
		alertbox.setView(tv);
		alertbox.setNegativeButton("No", new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialogInterface, int i) 
			{
//				Settings.System.putInt(getContentResolver(),Settings.System.AIRPLANE_MODE_ON, 0);
//				Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
//				intent.putExtra("state", 0);
//				sendBroadcast(intent);
				finish();
			}
		});
		alertbox.setPositiveButton("Yes",new DialogInterface.OnClickListener() 
		{
			public void onClick(DialogInterface dialog, int which) 
			{
				finish();
			}
		});
		LogWrite.d(TAG, ""+(Settings.System.getInt(getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 0) != 0));
		if(Settings.System.getInt(getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 0) != 0)
			alertbox.show();
	}
}
