package com.kochartech.gizmodoctor.deviceissues;

import android.content.Context;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.text.TextUtils;

import com.kochartech.devicemax.Activities.LogWrite;

public class AccessibilityHelper {
	private String TAG = AccessibilityHelper.class.getSimpleName();
	private Context context;

	// public static OnPackageChangeListener onPackageChangeListener;

	public AccessibilityHelper(Context context) {
		this.context = context;
	}

	public boolean isAccessibilityEnabled() {
		int accessibilityEnabled = 0;
		String ACCESSIBILITY_SERVICE_NAME = "";
		boolean accessibilityFound = false;
		try {
			accessibilityEnabled = Settings.Secure.getInt(
					context.getContentResolver(),
					android.provider.Settings.Secure.ACCESSIBILITY_ENABLED);
			LogWrite.d(TAG, "ACCESSIBILITY: " + accessibilityEnabled);
		} catch (SettingNotFoundException e) {
			LogWrite.d(TAG,
					"Error finding setting, default accessibility to not found: "
							+ e.getMessage());
		}

		TextUtils.SimpleStringSplitter mStringColonSplitter = new TextUtils.SimpleStringSplitter(
				':');

		if (accessibilityEnabled == 1) {
			LogWrite.d(TAG, "***ACCESSIBILIY IS ENABLED***: ");

			String settingValue = Settings.Secure.getString(
					context.getContentResolver(),
					Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
			LogWrite.d(TAG, "Setting: " + settingValue);
			if (settingValue != null) {
				TextUtils.SimpleStringSplitter splitter = mStringColonSplitter;
				splitter.setString(settingValue);
				while (splitter.hasNext()) {
					String accessabilityService = splitter.next();
					LogWrite.d(TAG, "Setting: " + accessabilityService);
					ACCESSIBILITY_SERVICE_NAME = context.getPackageName() + "/"
							+ CleanAccessibilityService.class.getName();
					LogWrite.d(TAG, "ACCESSIBILITY_SERVICE_NAME: "
							+ ACCESSIBILITY_SERVICE_NAME);
					if (accessabilityService
							.equalsIgnoreCase(ACCESSIBILITY_SERVICE_NAME)) {
						LogWrite.d(TAG,
								"We've found the correct setting - accessibility is switched on!");
						return true;
					}
				}
			}

			LogWrite.d(TAG, "***END***");
		} else {
			LogWrite.d(TAG, "***ACCESSIBILIY IS DISABLED***");
		}
		return accessibilityFound;
	}

	// public void setPackageChangeListener(
	// OnPackageChangeListener onPackageChangeListener) {
	// AccessibilityHelper.onPackageChangeListener = onPackageChangeListener;
	// }
	//
	// public static OnPackageChangeListener getPackageChangeListener() {
	// return onPackageChangeListener;
	// }

}
