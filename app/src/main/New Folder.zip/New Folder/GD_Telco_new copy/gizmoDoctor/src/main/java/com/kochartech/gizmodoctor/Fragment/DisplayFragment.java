package com.kochartech.gizmodoctor.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.CustomView.FixerTimer;

public class DisplayFragment extends Fragment implements OnClickListener {
	private String TAG = DisplayFragment.class.getSimpleName();
	private FrameLayout mainView;

	// private Context context;
	private View rootView;
	// private TextView textView;
	private Button start_button;

	private boolean isFromCommand = false;
	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
	public static OnCommandListener onCommandListener;
	private boolean isClickWork = false;

	public DisplayFragment(OnCommandListener onCommandListener) {
		DisplayFragment.onCommandListener = onCommandListener;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		getActivity().getWindow()
				.setFlags(
						0xFFFFFFFF,
						LayoutParams.FLAG_FULLSCREEN
								| LayoutParams.FLAG_KEEP_SCREEN_ON);

		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	private void initDataSet() {
		Bundle bundle = getArguments();
		if (bundle != null) {
			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
			}
		}
	}

	private void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_display_test, container,
				false);
		start_button = (Button) rootView.findViewById(R.id.button_start);
		start_button.setOnClickListener(this);
	}

	@Override
	public void onClick(View view) {
		if (view.getId() == R.id.button_start) {
			Intent launchColor = new Intent(getActivity(), FixerTimer.class);
			launchColor.putExtra(KEY_ISFROMCOMMAND, isFromCommand);
			startActivity(launchColor);
			FragmentListener fragmentListener = (FragmentListener) getActivity();
			fragmentListener.onItemClicked(FragmentListener.actionRemove,
					DisplayFragment.this);
		}
	}
}
