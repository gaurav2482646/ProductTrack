package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Window;
import android.view.WindowManager;

/**
 * This Screen Reduces the brightness of the screen if battery is low and starts
 * a new activity {@link RefreshScreen} to let the settings take place.
 * 
 * @author nishant.kumar
 * 
 */
public class ReduceBrightnessScreen extends Activity {

	private String tag = "ReduceBrightnessScreen";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		Settings.System.putInt(getContentResolver(),
				Settings.System.SCREEN_BRIGHTNESS, 102);

		WindowManager.LayoutParams lp = getWindow().getAttributes();

		lp.screenBrightness = 0.4f;// 100 / 100.0f;
		getWindow().setAttributes(lp);

		finish();
	}

}
