package com.kochartech.gizmodoctor.HelperClass;



import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.kochartech.devicemax.ToastPackage.SettingsToast_Messages;
import com.kochartech.gizmodoctor.R;

public class SettingsToast implements SettingsToast_Messages,Parcelable
{

	public static final int ARROW_UP=0;
	public static final int ARROW_DOWN=1;
	public static final int ARROW_LEFT=2;
	public static final int GRAVITY_TOP=Gravity.TOP;
	public static final int GRAVITY_CENTER=Gravity.CENTER;
	public static final int GRAVITY_BOTTOM=Gravity.BOTTOM;
	
//	private Hashtable<String, String> actionModelDependent;
	
	private String tag = "SettingsToast";
	private Activity activityContext;
	private LayoutInflater inflater;
	private View layout;
	private TextView textview;
	private Toast toast;
	private Timer timer ; 
	private int timerCount = 0;
	private TimerTask timerTask ;
//	private Typeface typeFace ;
	private String singtelItem = "";
	private boolean isItemHandle = false;
	private boolean state = true;
	
//	String deviceModel;
	
	int bottomMargin =0;
	int centerMargin =0;
	int topMargin =0 ;
	
	public SettingsToast(Context context) {
		try {
//			deviceModel = android.os.Build.MODEL.trim();	
			
			//LogWrite.d(tag,"Model = "+deviceModel);
			this.activityContext = (Activity) context;
//			singtelItemsAnalyzer = new SingtelItemAnalyzer(activityContext);
			int height;
			if(android.os.Build.VERSION.SDK_INT>=13)
			{
				Display display = activityContext.getWindowManager().getDefaultDisplay();
				Point size = new Point();
				display.getSize(size);
				height = size.y;
			}
			else
			{
				height = activityContext.getWindowManager().getDefaultDisplay().getHeight();
			}
			
			bottomMargin = (20*height)/100;	
			
		} catch (Exception e) {
		//LogWrite.d(tag,"ExceptionDTO...."+e);
		}
	}	
	public void show(String singtelItem)
	{
		this.singtelItem = singtelItem;
//			singtelToastShow();
	}
	public void show(int index)
	{
		String messageToDisplay = "";
		if(index == 0)
		{
			messageToDisplay  = "Tap on Force Stop.";
			show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,centerMargin,true);	
		}
//		else if(index == 1)
//		{
//			messageToDisplay  = "Tap on Clear data."; 
//			show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,bottomMargin,true);	
//		}
//		else if(index == 2)
//		{
//			messageToDisplay  = "Tap on Force stop.";
//			show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,bottomMargin,true);	
//		}
//		else if(index == 3)
//		{
//			messageToDisplay  = "Tap on Force stop.";
//			show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,bottomMargin,true);	
//		}
	}

//	public void singtelToastShow()
//	{
//		String messageToDisplay = "";
//		if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.MobileDATA))
//		{
//			boolean mobileDataStatus = singtelItemsAnalyzer.isMobileDataOn();
////			if(!getMessage(mobileDataStatus).equalsIgnoreCase(""))
////			{
////				messageToDisplay = getMessage(mobileDataStatus);
////				/*show(getMessage(flag),SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);*/
////			}
//			if(mobileDataStatus)
//			{
//				messageToDisplay = SettingsToast.MOBILE_DATA_ON;
//			}
////				show(SettingsToast.MOBILE_DATA_OFF,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
//			else
//			{
//				messageToDisplay = SettingsToast.MOBILE_DATA_OFF;
//			}
//			show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);	
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.DataRomaing))
//		{
//			if(singtelItemsAnalyzer.isDataRoamingOn())
//			{
//				messageToDisplay = SettingsToast.DATA_ROAMING_ON;
//			}
////				show(SettingsToast.DATA_ROAMING_ON,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
//			else
//			{
//				messageToDisplay = SettingsToast.DATA_ROAMING_OFF;
//			}
//				show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);						
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.APN))
//		{
////			if(Flag.isDeviceSamsung(activityContext))
////			{
////				SamsungApi samsungApi = new SamsungApi(activityContext);
////				if(samsungApi.isPreferAPNOk())
////				{
////					messageToDisplay = SettingsToast.APN_CORRECTLY_SELECTED;
////				}
////				else if(samsungApi.isAPNExsist())
////				{
////					messageToDisplay = SettingsToast.APN_WRONG_SELECTED;
////				}
////				else
////				{
////					messageToDisplay = SettingsToast.APN_NOTAT_ALL;
////				}
////			}
////			else
////			{
//				if(APNReader.getInstance(activityContext).isPreferAPNOk())
//				{
//				
//					messageToDisplay = SettingsToast.APN_CORRECTLY_SELECTED;
//				}
//				else if(APNReader.getInstance(activityContext).isAPNExsist())
//				{
//					messageToDisplay = SettingsToast.APN_WRONG_SELECTED;
//				}
//				else
//				{
//					messageToDisplay = SettingsToast.APN_NOTAT_ALL;
//				}
////			}
//			
//			show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.Wifi))
//		{
//			if(singtelItemsAnalyzer.isWifiOn())
//			{
//				messageToDisplay = SettingsToast.WIFI_ON;
//			}
////				show(SettingsToast.WIFI_ON,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,centerMargin,true);
//			else
//			{
//				messageToDisplay = SettingsToast.WIFI_OFF;
//			}
//				show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,centerMargin,true);				
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.BlueTooth))
//		{
//			if(singtelItemsAnalyzer.isBlueToothOn())
//			{
//				messageToDisplay = SettingsToast.BT_ON;
//			}
////				show(SettingsToast.BT_ON,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,centerMargin,true);
//			else
//			{
//				messageToDisplay = SettingsToast.BT_OFF;
//			}
//				show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_CENTER,0,centerMargin,true);				
//		}
//			
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.GPS))
//		{
//			if(singtelItemsAnalyzer.isGPSOn())
//			{
////				if(deviceModel.startsWith("Nexus"))
////				{
////					messageToDisplay = "Tap Location to disable Location service";
////				}
////					show("Tap Location to disable Location service.",SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
////				else
////				{
//					messageToDisplay = SettingsToast.GPS_ON;
////				}
////					show(SettingsToast.GPS_ON,SettingsToast.ARROW_DOWN,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);	
//			}
//			else
//			{
////				if(deviceModel.startsWith("Nexus"))
////				{
////					messageToDisplay = SettingsToast.BT_ON;
////				}
////					show("Ensure Location service is disabled",SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
////				else
////				{
//					messageToDisplay = SettingsToast.GPS_OFF;
////				}
////					show(SettingsToast.GPS_OFF,SettingsToast.ARROW_DOWN,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);	
//			}
//			show(messageToDisplay,SettingsToast.ARROW_DOWN,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
//			
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.AirplaneMode))
//		{
//			if(singtelItemsAnalyzer.isFlightModeOn())
//			{
//				messageToDisplay = SettingsToast.FLIGHT_MODE_ON;
//			}
////				show(SettingsToast.FLIGHT_MODE_ON,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
//			else
//			{
//				messageToDisplay = SettingsToast.FLIGHT_MODE_OFF;
//			}
//				show(messageToDisplay,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_BOTTOM,0,bottomMargin,true);
//							
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.RAM))
//		{
//			   show(SettingsToast.MEMORY,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_TOP,0,170,true);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.InternalStorage))
//		{
//			   show(SettingsToast.INTERNAL_STORAGE,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_TOP,0,170,true);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.ExternalStorage))
//		{
//			show(SettingsToast.EXTERNAL_STORAGE,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_TOP,0,170,true);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.Battery))
//		{
//			show(SettingsToast.Battery,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_TOP,0,170,true);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.Singnal))
//		{
//			show(SettingsToast.Signal,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_TOP,0,170,true);
//		}
//	}
	public void show(String message,int arrowDirection,int gravity,int x,int y,boolean isFullscreen)
	{
		//LogWrite.d(tag,"Work...");
		//LogWrite.d(tag,"Message..."+y);
		
		try {
//			this.activityContext = (Activity) context;
//			typeFace = Typeface.createFromAsset(activityContext.getAssets(),"fonts/fonnt.ttf");
			inflater = activityContext.getLayoutInflater();
			
//			if(arrowDirection == ARROW_UP )
				layout = inflater.inflate(R.layout.settings_toast_arrow_up,null);
//			else if(arrowDirection == ARROW_DOWN )
//			    layout = inflater.inflate(R.layout.settings_toast_arrow_down,null);
//			else
//				 layout = inflater.inflate(R.layout.settings_toast_arrow_left,null);
			
//			layout.setOnClickListener(this);
			textview = (TextView) layout.findViewById(R.id.settingstoast_textview);
			textview.setText(message);
//			textview.setTypeface(typeFace);
			
			textview.setTextColor(Color.BLACK);
			
			toast = new Toast(activityContext);
			toast.setGravity(Gravity.LEFT|gravity, 0,0);
			toast.setView(layout);      
			
			if(isFullscreen==false)
			{
				Display display = activityContext.getWindowManager().getDefaultDisplay();
				Point size = new Point();
				display.getSize(size);
				int width = size.x;
				 
	            int toastWidth = (76*width)/100;		
	            
	            //LogWrite.d(tag,"Width = "+toastWidth);
				LinearLayout linearLayout = (LinearLayout) layout.findViewById(R.id.main);
				LinearLayout.LayoutParams params = new LayoutParams(toastWidth, LinearLayout.LayoutParams.WRAP_CONTENT);
				params.setMargins(0,0,0,y);
				linearLayout.setLayoutParams(params);   
				
			}
			else
			{
//				Display display = activityContext.getWindowManager().getDefaultDisplay();
//				Point size = new Point();
//				display.getSize(size);
//				int height = size.y;
//				
//				//LogWrite.d(tag,"Height.."+height);
//				 
//	            int toastHeigth_Margin = (76*height)/100;	
	            
				LinearLayout linearLayout = (LinearLayout) layout.findViewById(R.id.main);
				LinearLayout.LayoutParams params = new LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				params.setMargins(0,0,0,y);
				linearLayout.setLayoutParams(params); 
			}

			
//			this.timerCount = count;
			timer= new Timer();
			timerTask = new TimerTask() {
				@Override
				public void run() {
					try {
							if(state == false)
							{
								toast.cancel();
							    timer.cancel();	
//							    timer.purge();
							}
							else
							{
//								if(timerCount==10)
//								{
//									toast.cancel();
//								    timer.cancel();	
//									handleMultipleMsg();
//								}
								if(timerCount==20)
								{
									toast.cancel();
									timer.cancel();	
									return;
								}
								timerCount++;
								toast.show();
								
							}
							//LogWrite.d(tag,"State ="+state);
						//LogWrite.d(tag,"Timer is Running"+timerCount);
					} catch (Exception e) {
						//LogWrite.d(tag,"ExceptionDTO....."+e);
					}					
				}
			} ;
			timer.schedule(timerTask,2000,500);
			
			//LogWrite.d(tag,"Finsih Sucessfully");
		} catch (Exception e) {
			//LogWrite.d(tag,"ExceptionDTO....."+e);
		}
	}
//	public void initHashTable(){
//		actionModelDependent = new Hashtable<String, String>();
//		actionModelDependent.put(DiagnoseSingtelItems.MobileDATA+"HTC Incredible S","");
//	}
//	private String getMessage(boolean flag)
//	{
//		if((DiagnoseSingtelItems.MobileDATA+"HTC Incredible S").equalsIgnoreCase(singtelItem+deviceModel))	
//		{
//			if(flag)
//				return "Ensure Mobile network in on";				
//			else
//				return "Turn on Mobile network";			
//		}
//		return "";
//	}
	public void cancel()
	{
		try
		{
			toast.cancel();
			timer.cancel();			
		}
		catch (Exception e)
		{
			//LogWrite.d(tag,"ExceptionDTO...."+e);
//			Toast.makeText(activityContext, ""+e, Toast.LENGTH_LONG).show();
		}
	}
	public void setToastVisibility(boolean state)
	{
		this.state=state;
		//LogWrite.d(tag,"....State ==="+state);
	}
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void writeToParcel(Parcel arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}
	
//	private void handleMultipleMsg()
//	{
//		if(singtelItem.equalsIgnoreCase("APN"))
//		{
//			activityContext.runOnUiThread(new Runnable() {
//				
//				@Override
//				public void run() {					
//					setToastDelayBeforeStart(0);
//					show(SettingsToast.APN2,SettingsToast.ARROW_UP,SettingsToast.GRAVITY_TOP,0,150,11);
//					
//				}
//		});
//			
//		}
//	}
	
	
}
