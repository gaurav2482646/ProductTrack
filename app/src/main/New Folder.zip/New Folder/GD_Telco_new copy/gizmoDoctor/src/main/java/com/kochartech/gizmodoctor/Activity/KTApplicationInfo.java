//package com.kochartech.gizmodoctor.Activity;
//
//import android.graphics.drawable.Drawable;
//
//public class KTApplicationInfo
//{
//	private String appName;
//	private String processName;
//	private Drawable icon;	
//	private int pid;
//	private String usage;
//	public KTApplicationInfo()
//	{
//		
//	}
//	public String getAppName() {
//		return appName;
//	}
//	public void setAppName(String appName) {
//		this.appName = appName;
//	}
//	public Drawable getIcon() {
//		return icon;
//	}
//	public void setIcon(Drawable icon) {
//		this.icon = icon;
//	}
//	public String getProcessName() {
//		return processName;
//	}
//	public void setProcessName(String processName) {
//		this.processName = processName;
//	}
//	public int getPid() {
//		return pid;
//	}
//	public void setPid(int pid) {
//		this.pid = pid;
//	}	
//	public String getUsage() {
//		return usage;
//	}
//	public void setUsage(String usage) {
//		this.usage = usage;
//	}	
//}
