package com.kochartech.devicemax.Activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
/*
 *  Key "LCKHSET" value boolean ( true means Lock false means unlock)
 *                        
 */
public class MyPreference
{	
	public static void setBoolean(Context context,String key,Boolean value)
	{
		SharedPreferences sharedPreferences = PreferenceManager
				.getDefaultSharedPreferences(context);
		Editor editor = sharedPreferences.edit();
		editor.putBoolean(key,value);	
		editor.commit();
	}
	public static boolean getBoolean(Context context,String key)
	{
		SharedPreferences sharedPreferences = PreferenceManager
				.getDefaultSharedPreferences(context);
		return sharedPreferences.getBoolean(key,false);	
	}
}
