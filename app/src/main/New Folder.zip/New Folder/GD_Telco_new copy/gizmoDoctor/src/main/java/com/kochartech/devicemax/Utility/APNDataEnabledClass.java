package com.kochartech.devicemax.Utility;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.Log;

public class APNDataEnabledClass 
{
	private static String tag = "APNDataEnabledClass";
	public static boolean checkforMobileData(Context context)
	{
		boolean mobileDataEnabled = false; // Assume disabled
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		try 
		{
			Class cmClass = Class.forName(cm.getClass().getName());
			Method method = cmClass.getDeclaredMethod("getMobileDataEnabled");
			method.setAccessible(true); // Make the method callable
			// get the setting for "mobile data"
			mobileDataEnabled = (Boolean) method.invoke(cm);
			// //LogWrite.d(">>>>>>>>>>>>", "MOBILE DATA: "
			// + (mobileDataEnabled ? "enabled" : "disabled"));

		}
		catch (Exception e) 
		{
			
		}
		return mobileDataEnabled;
//		boolean enabled = true;
//        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
//        if ((info == null || !info.isConnected() || !info.isAvailable()))
//        {
//            enabled = false;
//        }
//        return enabled;
	}
	public static void setMobileDataEnabled(Context context, boolean enabled) 
	{
		int bv = Build.VERSION.SDK_INT;
		try
		{
			if(bv == Build.VERSION_CODES.FROYO)
			{
	
			    Log.i("version:", "Found Froyo");
			    Method dataConnSwitchmethod;
			    Class telephonyManagerClass;
			    Object ITelephonyStub;
			    Class ITelephonyClass;
			    TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			    Log.i("version:", "........................1");
			    telephonyManagerClass = Class.forName(telephonyManager.getClass().getName());
			    Log.i("version:", "........................2");
			    Method getITelephonyMethod = telephonyManagerClass.getDeclaredMethod("getITelephony");
			    Log.i("version:", "........................3");
			    getITelephonyMethod.setAccessible(true);
			    Log.i("version:", "........................4");
			    ITelephonyStub = getITelephonyMethod.invoke(telephonyManager);
			    Log.i("version:", "........................5");
			    ITelephonyClass = Class.forName(ITelephonyStub.getClass().getName());
			    Log.i("version:", "........................6");
	
			    if (enabled) 
			    {
			    	Log.i("version:", "........................7" + enabled);
			         dataConnSwitchmethod = ITelephonyClass.getDeclaredMethod("enableDataConnectivity");
			    } 
			    else 
			    {
			    	Log.i("version:", "........................8" + enabled);
			        dataConnSwitchmethod = ITelephonyClass.getDeclaredMethod("disableDataConnectivity");
			    }
			    Log.i("version:", "........................9");
			    dataConnSwitchmethod.setAccessible(true);
			    Log.i("version:", "........................10");
			    dataConnSwitchmethod.invoke(ITelephonyStub);
			    Log.i("version:", "........................11");
			}
			else
			{
			   Log.i("version:", "Found Gingerbread+");
			   final ConnectivityManager conman = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			   final Class conmanClass = Class.forName(conman.getClass().getName());
			   final Field iConnectivityManagerField = conmanClass.getDeclaredField("mService");
			   iConnectivityManagerField.setAccessible(true);
			   final Object iConnectivityManager = iConnectivityManagerField.get(conman);
			   final Class iConnectivityManagerClass =  Class.forName(iConnectivityManager.getClass().getName());
			   final Method setMobileDataEnabledMethod = iConnectivityManagerClass.getDeclaredMethod("setMobileDataEnabled", Boolean.TYPE);
			   setMobileDataEnabledMethod.setAccessible(true);
			   setMobileDataEnabledMethod.invoke(iConnectivityManager, enabled);
			}
		}
		catch(Exception e)
		{
			Log.e(tag,"ExceptionDTO ----> "+ e.toString());
		}
	}
}
