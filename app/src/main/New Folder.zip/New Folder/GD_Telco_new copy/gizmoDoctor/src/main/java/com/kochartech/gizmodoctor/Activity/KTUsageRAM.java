//package com.kochartech.gizmodoctor.Activity;
//
//import java.io.IOException;
//import java.io.RandomAccessFile;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.kochartech.gizmodoctor.POJO.KTMemoryInfo;
//
//import android.app.ActivityManager;
//import android.app.ActivityManager.MemoryInfo;
//import android.app.ActivityManager.RunningAppProcessInfo;
//import android.content.Context;
//import android.content.pm.ApplicationInfo;
//import android.content.pm.PackageManager;
//import android.util.Log;
//
//
///**
// * This class has been used to calculate RAM Usage.
// * @author aman.arora
// * 
// *  we skip the applications, that do not have application info.
// */
//public class KTUsageRAM extends KTUsage
//{
//	String tag = "KTUsageRAM";
////	private Context context;
////	private List<KTApplicationInfo> runningAppUsageInfo = new ArrayList<KTApplicationInfo>();
////	private PackageManager pkgManager;
////	private ActivityManager activityManager;
//	private KTMemoryInfo ktMemoryInfo;
//	/**
//	 *  Constructor
//	 */
//	public KTUsageRAM(Context context) 
//	{
//		// TODO Auto-generated constructor stub
//		super(context);
//		ktMemoryInfo = new KTMemoryInfo();
////		this.context = context;
////		pkgManager = context.getPackageManager();
////		activityManager = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE); 
//		
//	}	
//	
//	public List<KTApplicationInfo> getPerAppUsage()
//	{		
//		refreshPerAppUsage();
//		return runningAppUsageInfo;
//	}
//	
//	public void refreshPerAppUsage()
//	{		
//		resetPerAppUsage();
//		calculatePerAppUsage();	
//	}
//	public String getUsage(String processName)
//	{
//		for(KTApplicationInfo ktAppInfo: runningAppUsageInfo)
//		{
//			if(ktAppInfo.getProcessName().equals(processName))
//			{
//				return ktAppInfo.getUsage();
//			}
//		}
//		return String.valueOf(0); 
//	}
//	
//	
//	public KTMemoryInfo getMeoryInfo()
//	{
//			float totalMemory = geTotal();
//			float totalAvail =  getAvail();
//			float used = totalMemory - totalAvail;
//			ktMemoryInfo.setTotal(totalMemory);
//			ktMemoryInfo.setFree(totalAvail);
//			ktMemoryInfo.setUsed(used);
//		
//		
//		return ktMemoryInfo;
//	}
//	
//	
//	private float geTotal()
//	{
//		float finaltotalRam = 0;
//		try {
//
//			RandomAccessFile reader = new RandomAccessFile("/proc/meminfo", "r"); // TOTAL
//			String load;
//			while ((load = reader.readLine()) != null) {
//				if (load.contains("MemTotal")) {
//					break;
//				}
//			}
//			// //LogWrite.d(tag, "FINAL:> " + string.toString());
//			String totalRAM = load.trim().substring(9, load.indexOf("kB"));
//			// //LogWrite.d(tag, "TOTAL RAM IS:> " + totalRAM);
//			long total = Long.parseLong(totalRAM.trim());
//			finaltotalRam = (long) ( total /  1024);
//
//		} catch (IOException ex) {
//			ex.printStackTrace();
//		}
//		return finaltotalRam;
//	}
//	private float getAvail()
//	{
//		MemoryInfo mi = new MemoryInfo();
//		ActivityManager activityManager = (ActivityManager)context.getSystemService(context.ACTIVITY_SERVICE);
//		activityManager.getMemoryInfo(mi);
//		float availableMegs = mi.availMem / (1024 * 1024);
//		return availableMegs;		
//	}
//	
//	
//	
//	private void calculatePerAppUsage()
//	{	
//		List<RunningAppProcessInfo> runningAppProcesses = activityManager.getRunningAppProcesses();
//		for(RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses)
//		{
//			KTApplicationInfo ktAppInfo = new KTApplicationInfo();
//			ktAppInfo.setPid(runningAppProcessInfo.pid);
//			ktAppInfo.setProcessName(runningAppProcessInfo.processName);
//			ApplicationInfo appInfo = getApplicationInfo(ktAppInfo.getProcessName());
////			only include those applications that have application info
//			if(appInfo != null)
//			{				 
//				ktAppInfo.setAppName(getAppName(appInfo));
//				ktAppInfo.setIcon(getAppIcon(appInfo));
//				ktAppInfo.setUsage(getRAMUsage(ktAppInfo.getPid()));	
//				
//				runningAppUsageInfo.add(ktAppInfo);
//			}			
//		}		
//	}	
//	private void resetPerAppUsage()
//	{
//		runningAppUsageInfo.clear();
//	}
//	private String getRAMUsage(int pid)
//	{
//		 int pids[] = new int[1];  
//		 pids[0] = pid;  
//		 android.os.Debug.MemoryInfo[] memoryInfoArray = activityManager.getProcessMemoryInfo(pids);		
//		 return String.valueOf(memoryInfoArray[0].getTotalPss());     
//	}	
//	
//}
