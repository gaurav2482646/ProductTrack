
package com.kochartech.gizmodoctor.HelperClass;

import com.kochartech.devicemax.Activities.LogWrite;

public class TaskTimeNote
{
	String TAG = "TaskTimeNote";
	String taskName;
	long startTime,endTime;
	
	public TaskTimeNote(String taskName)
	{
		this.taskName = taskName;
	}
	public void setStartTime(long startTime)
	{
		this.startTime = startTime;
	}
	public void setEndTime(long endTime)
	{
		this.endTime = endTime;
	}
	public void printConsumedTime()
	{
		LogWrite.d(TAG,taskName+" Consumed Time :"+(endTime-startTime));
	}
}
