package com.kochartech.gizmodoctor.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.HelperClass.FragmentTitles;
import com.kochartech.gizmodoctor.HelperClass.KTEnum;
import com.kochartech.gizmodoctor.Preferences.AppSettingsPreference;

public class AppSettingsFragment extends Fragment implements OnClickListener,
		MyFragment {

	private Context context;
	private RadioButton celciusRadioBtn, fahrenheitRadioBtn;
	private View rootView;
	private RadioGroup temperatureRadioGroup;
	private int unitOfTemperature;
	private AppSettingsPreference appSettingPreference;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		appSettingPreference = new AppSettingsPreference(context);
		unitOfTemperature = appSettingPreference.getTemperatureUnitToShow();

	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_settings, container,
				false);
		temperatureRadioGroup = (RadioGroup) rootView
				.findViewById(R.id.tempRadioGroup);
		RadioButton radioBtn = (RadioButton) temperatureRadioGroup
				.getChildAt(unitOfTemperature);
		radioBtn.setChecked(true);
		celciusRadioBtn = (RadioButton) rootView
				.findViewById(R.id.celsiusRadioBtn);
		fahrenheitRadioBtn = (RadioButton) rootView
				.findViewById(R.id.fahrenheitRadioBtn);

		registerOnClick(celciusRadioBtn);
		registerOnClick(fahrenheitRadioBtn);
	}

	public void registerOnClick(View view) {
		view.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v instanceof RadioButton) {
			if (v.getId() == R.id.celsiusRadioBtn) {
				appSettingPreference
						.setTemperatureUnitToShow(KTEnum.TEMPERATURE_UNIT.CELSIUS);
			} else if (v.getId() == R.id.fahrenheitRadioBtn) {
				appSettingPreference
						.setTemperatureUnitToShow(KTEnum.TEMPERATURE_UNIT.FAHRENHEIT);
			}
		}
	}

	@Override
	public String getTitle() {
		return FragmentTitles.SETTINGS;
	}

}
