package com.kochartech.gizmodoctor.Service;

public class MyEnum {
	
	public static enum PREFERENCES_NAMES {
		ActivationTime,	
		LastTrialCheckTime,
		IsUserRegister
	}
}
