package com.kochartech.gizmodoctor.HelperClass;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

public class AppInfo {

	public static String getApplicationVersionName(Context context) {

		try {
			PackageInfo pInfo = context.getPackageManager().getPackageInfo(
					context.getPackageName(), PackageManager.GET_META_DATA);
			return String.valueOf(pInfo.versionName);
		} catch (Exception e) {
			return "NA";
		}
	}
}
