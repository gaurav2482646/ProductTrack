package com.kochartech.devicemax.Receivers;
//package com.kochar.MDMS.Recievers;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.OutputStream;
//
//import org.apache.commons.net.ftp.FTP;
//import org.apache.commons.net.ftp.FTPClient;
//import org.apache.commons.net.ftp.FTPReply;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.AsyncTask;
//import android.os.Environment;
//import android.preference.PreferenceManager;
//import android.util.Log;
////http://zanailhan.blogspot.in/2012/03/android-connect-to-ftp-server-example.html
//public class FtpUploadReceiver extends BroadcastReceiver {
//	String TAG = "FtpUploadReceiver";
//	public FTPClient mFTPClient = null;
//	String imei=null;
////	@Override
////	public void onCreate(Bundle savedInstanceState) {
////		super.onCreate(savedInstanceState);
////		setContentView(R.layout.main);
////		NetConnection netconn = new NetConnection();
////		netconn.execute(null);
////	}
//	public class NetConnection extends AsyncTask<String, String, String> {
//
//		@Override
//		protected String doInBackground(String... params) {
//			LogWrite.d(TAG, "before Connect");
//			mFTPClient = new FTPClient();
//			try {
//				//goforIt();
//				LogWrite.d(TAG,"(NetConnection) imei inside ftp class:> "+imei);
//				fetchfiles();
//				
//				ftpConnect("202.164.36.76", "development", "FcasurS&CG");
//				String[] liste = mFTPClient.listNames();
//				for (int i = 0; i < liste.length; i++) {
//					LogWrite.d(TAG, i + "==" + liste[i]);
//				}
//				ftpDisconnect();
//				//goforDownload();
//				
//				
//			}
//			
//			catch (ExceptionDTO e) {
//				// TODO: handle exception
//			}
//			return null;
//		}
//	}
////	public void goforIt() {
////		FTPClient con = null;
////		try {
////			con = new FTPClient();
////			con.connect("202.164.36.76");
////			if (con.login("development", "FcasurS&CG")) {
////				LogWrite.d(TAG, "in if==");
////				con.enterLocalPassiveMode(); // important!
////				con.setFileType(FTP.BINARY_FILE_TYPE);
////				con.setConnectTimeout(10*60*1000);
////				String data = Environment.getExternalStorageDirectory()
////						+ "/AA.txt";
////				FileInputStream in = new FileInputStream(new File(data));
////				LogWrite.d(TAG, "GGGGGGGGGGGGGG");
////				con.makeDirectory("Images");
////				
////				boolean result = con.storeFile("/Images/AA.txt", in);
////				LogWrite.d(TAG, "result=" + result);
////				
////				if (result)
////					LogWrite.d(TAG,"upload result succeeded");
////				else {
////					LogWrite.d(TAG,"upload result failed");
////				}
////				in.close();
////				con.logout();
////				con.disconnect();
////			}
////		} catch (ExceptionDTO e) {
////			LogWrite.d(TAG, "Upload error=="+e.toString());
////			e.printStackTrace();
////		}
////	}
//	public void fetchfiles() {
//		try
//		{
//		boolean status=ftpConnect("202.164.36.76", "development", "FcasurS&CG");
//		LogWrite.d(TAG, "ftpConnect status=="+status);
//		status=makeDirectory(imei);
////		 status=makeDirectory("files_telynet");
//		 LogWrite.d(TAG, "makeDirectory status=="+status);
//		ftpDisconnect() ;
//		//07-11 17:03:00.694: D/JaapuActivity(3170): /mnt/sdcard/files_telynet/
//
//		String path = Environment.getExternalStorageDirectory().toString()+"/files_telynet";
//		
//		//String path = Environment.getExternalStorageDirectory().toString();
//		getFiles(path);
//		//getFiles(path,"txt");
//		}
//		catch(ExceptionDTO e)
//		{
//			LogWrite.d(TAG, "ExceptionDTO"+e);
//		}
//	}
//
//	public void getFiles(String path) {
//		try
//		{
//		File mfile = new File(path);
//		File[] files = mfile.listFiles();
//
//		LogWrite.d(TAG, "list" + mfile.listFiles().length);
//		for (int i = 0; i < mfile.listFiles().length; i++) {
//			File file = files[i];
//			/*
//			 * if(files[i].isHidden()) {
//			 * //System.out.println("hidden path files.."
//			 * +list[i].getAbsolutePath());
//			 * LogWrite.d(TAG,"hidden path files.."+files[i].getAbsolutePath()); }
//			 * else { LogWrite.d(TAG,"else path files.."+list[i].getAbsolutePath());
//			 * }
//			 */
//
//			// path.add(file.getPath());
//			if (!file.isHidden()) {
//				if (file.isDirectory()) {
//					ftpConnect("202.164.36.76", "development", "FcasurS&CG");
//					LogWrite.d(TAG, "file.getName()=="+file.getName());
//					makeDirectory(imei+"/"+file.getName());
////					makeDirectory("files_telynet/"+file.getName());
//					ftpDisconnect() ;
//					LogWrite.d(TAG,"absolute path of file =="+ file.getAbsolutePath() + "/");
//					getFiles(file.getAbsolutePath() + "/");
//				} else
//				{
//					LogWrite.d(TAG, "file path=="+file.getAbsolutePath());
//					
//					String path1=file.getAbsolutePath();
//				//	LogWrite.d("inside else part","absl path=="+path1+">>>");
//					int indexsdCard=path1.indexOf("sdcard");
//					int indexfilestely=path1.indexOf("files_telynet");
//					//LogWrite.d("index of telynet",indexfilestely+"<<>>");
//				//	LogWrite.d("index", "indexsdCard=="+indexsdCard);
//					String p=path1.substring(indexsdCard+7,path1.length());
//					//LogWrite.d("p==","path is "+p);
//					String p1=path1.substring(indexfilestely+14,path1.length());
//					//LogWrite.d("p1==","2nd path is "+p1);
//					String getpath=imei+"/"+p1;
//				//	LogWrite.d("actual created path==","path iisss  "+getpath);
//				//	LogWrite.d("p==","path is "+p);
//					try {
//						LogWrite.d(TAG, "file path=="+file.getParent());
//					} catch (ExceptionDTO e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					ftpConnect("202.164.36.76", "development", "FcasurS&CG");
//					ftpUploadFile(p,getpath);
////					ftpUploadFile(getpath);
//					ftpDisconnect() ;
//					//addtoList(file);
//				}
//			}
//
//		}
//	  }//End try
//		catch(ExceptionDTO e)
//		{
//			LogWrite.d(TAG, "exception "+e);
//		}
//
//	}
//	public boolean ftpConnect(String host, String username, String password) {
//		try {
//			mFTPClient.connect(host);
//			LogWrite.d(TAG, "1");
//			// now check the reply code, if positive mean connection success
//			if (FTPReply.isPositiveCompletion(mFTPClient.getReplyCode())) {
//				// login using username & password
//				boolean status = mFTPClient.login(username, password);
//				LogWrite.d(TAG, "status====" + status);
//				/*
//				 * Set File Transfer Mode
//				 * 
//				 * To avoid corruption issue you must specified a correct
//				 * transfer mode, such as ASCII_FILE_TYPE, BINARY_FILE_TYPE,
//				 * EBCDIC_FILE_TYPE .etc. Here, I use BINARY_FILE_TYPE for
//				 * transferring text, image, and compressed files.
//				 */
//				mFTPClient.setConnectTimeout(5*60*1000);
//				mFTPClient.enterLocalPassiveMode();
//				mFTPClient.setFileType(FTP.BINARY_FILE_TYPE);
//				
//				return status;
//			}
//		} catch (ExceptionDTO e) {
//			LogWrite.d(TAG, "Error: could not connect to host " + host);
//		}
//
//		return false;
//	}
//	public boolean makeDirectory(String dirctoryName)
//	{
//		boolean status=false;
//		try {
//			status=mFTPClient.makeDirectory(dirctoryName);
//			LogWrite.d(TAG, "makeDirectory status=="+status);
//		} catch (ExceptionDTO e) {
//			LogWrite.d(TAG, "unable to make directory error=="+e.toString());
//			e.printStackTrace();
//		}
//		return status;
//	}
//	public void ftpUploadFile(String path,String setpath) {
//		FTPClient con = null;
//		try {
//			/*con = new FTPClient();
//			con.connect("202.164.36.76");
//			if (con.login("aircel.sftp", "Domoc@117tma")) {
//				LogWrite.d(TAG, "in if==");
//				con.enterLocalPassiveMode(); // important!
//				con.setFileType(FTP.BINARY_FILE_TYPE);*/
//				//mFTPClient.setConnectTimeout(5*60*1000);
//				String data = Environment.getExternalStorageDirectory()
//						+ "/"+path;
//			
//			    LogWrite.d("files to upload", "path=="+path);
//				FileInputStream in = new FileInputStream(new File(data));
//				LogWrite.d(TAG, "GGGGGGGGGGGGGG");
//				//con.makeDirectory("Images");
//				
//				boolean result = mFTPClient.storeFile(setpath, in);
//				LogWrite.d(TAG, "result=" + result);
//				
//				if (result)
//					LogWrite.d(TAG,"upload result succeeded");
//				else {
//					LogWrite.d(TAG,"upload result failed");
//				}
//				in.close();
//				mFTPClient.logout();
//				//con.disconnect();
//			//}
//		} catch (ExceptionDTO e) {
//			LogWrite.d(TAG, "Upload error=="+e.toString());
//			e.printStackTrace();
//		}
//	}
//	public boolean ftpDisconnect() {
//		try {
//			mFTPClient.logout();
//			mFTPClient.disconnect();
//			return true;
//		} catch (ExceptionDTO e) {
//			LogWrite.d(TAG, "Error occurred while disconnecting from ftp server.");
//		}
//
//		return false;
//	}
//
//	public void goforDownload() {
//		FTPClient con = null;
//		try {
//			con = new FTPClient();
//			con.connect("202.164.36.76");
//			if (con.login("development", "FcasurS&CG")) 
//			{
//				LogWrite.d(TAG, "in if Download");
//				con.enterLocalPassiveMode(); // important!
//				con.setConnectTimeout(10*60*1000);
//				con.setFileType(FTP.BINARY_FILE_TYPE);
//				String data = Environment.getExternalStorageDirectory()
//				+ "/ip.txt";
//				OutputStream out = new FileOutputStream(new File(data));
//				LogWrite.d(TAG, "before Download");
//				boolean result = con.retrieveFile("ip.txt", out);
//				LogWrite.d(TAG, "result=="+result);
//				if (result)
//					LogWrite.d(TAG,"download result succeeded");
//				else
//					LogWrite.d(TAG,"download result failed");
//				out.close();
//				con.logout();
//				con.disconnect();
//			}
//		} catch (ExceptionDTO e) {
//			LogWrite.d(TAG,"download result error failed"+e.toString());
//			e.printStackTrace();
//		}
//
//	}
//	@Override
//	public void onReceive(Context context, Intent intent) {
//		// TODO Auto-generated method stub
//
//		SharedPreferences sharedPreferences = null;
//		sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
//		imei=sharedPreferences.getString("imei",null);
//		LogWrite.d("imei inside receive method",imei+"NNN");
//		NetConnection netconn = new NetConnection();
//		netconn.execute(null);
//		
//	}
//}