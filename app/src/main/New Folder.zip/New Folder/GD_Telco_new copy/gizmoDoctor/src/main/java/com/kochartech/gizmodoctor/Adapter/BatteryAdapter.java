package com.kochartech.gizmodoctor.Adapter;

import java.text.DecimalFormat;
import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.DataBase.DataSource_DischargeRate;
import com.kochartech.library.Battery.KTApplicationDTO;

public class BatteryAdapter extends ArrayAdapter{
	private ArrayList<KTApplicationDTO> appList;
	private Context context;
	DataSource_DischargeRate data_Source;
	public BatteryAdapter(Context context, ArrayList<KTApplicationDTO> appList2)
	{
		super(context, R.layout.battery_app_item , appList2);
		
//		KTApplication app = new KTApplication();
		this.context = context;
		this.appList = appList2;
		
		data_Source = DataSource_DischargeRate.getInstance(context);
//		data_Source.open();
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{
		LayoutInflater inflater 	= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View rowView 				= inflater.inflate(R.layout.battery_app_item, parent, false);
		ImageView imageView 		= (ImageView) rowView.findViewById(R.id.icon);
		TextView textView 			= (TextView) rowView.findViewById(R.id.applicationName);
		TextView textView1 			= (TextView) rowView.findViewById(R.id.percentage);
		KTApplicationDTO app 					= appList.get(position);
		imageView.setBackgroundDrawable(app.getAppIcon());
		textView.setText(app.getAppName());
		
//		if(app.getAppPercentage().equalsIgnoreCase("Idle"))
//		{
//			textView1.setText("Idle");	
//		}
//		else
//		{
		double disachargeRate = data_Source.getDischargeRate();
		if(disachargeRate == 0)
			disachargeRate = .33;
		
		Float ff = Float.valueOf(app.getAppPercentage().split("%")[0].trim());
		
		String  usedPercentage = String.valueOf(new DecimalFormat("##.##").format((disachargeRate/100) * ff));
		
		textView1.setText(usedPercentage+" % ");
		
//		}
//		textView1.setText(app.getAppPercentage());
		return rowView;
	}
}
