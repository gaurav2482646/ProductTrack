package com.kochartech.devicemax.dm;

import java.util.Enumeration;
import java.util.Hashtable;

public class ConvertHashTableToString {

	public String createMessageFromHashtable(
			Hashtable<String, String> hsCreateCommand) {
		String key, value;
		String message = "";
		Enumeration<String> e = hsCreateCommand.keys();
		while (e.hasMoreElements()) {
			key = (e.nextElement());
			value = hsCreateCommand.get(key);

			message += key + ":" + value + ";";
		}
		return message;
	}

	public Hashtable<String, String> putInHashTable(String splitStr) {
		// create hashtable
		Hashtable<String, String> items = new Hashtable<String, String>();
		// array of string to hold key value pairs splitted on ";"

		String keyValue[] = splitStr.split(";");

		// now we have key value pairs we break them on ":" in key and value

		for (int i = 0; i < keyValue.length; i++) {
			String sepkeyVal[] = keyValue[i].split(":");
			items.put(sepkeyVal[0], sepkeyVal[1]);

		}

		// String
		// splitStr="MessageId:45-67-845837379357;Value:5;MessageClass:Action;Command:RegisterUser;IMEI:1561521545155151;Brand:NOKIA;Model:N72;";

		// Hashtable<String,String> hs= ob.putInHashTable(splitStr);
		// System.out.println("Hashtable Contents"+ hs.toString());
		// System.out.println("String from hashtable ->" +
		// ob.createMessageFromHashtable(hs));
		return items;
	}

}