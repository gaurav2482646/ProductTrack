package com.kochartech.devicemax.Utility;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Activities.MDMMainActivity;
import com.kochartech.devicemax.ToastPackage.OpenSettingReceiver;
import com.kochartech.devicemax.ToastPackage.SettingsToast;
import com.kochartech.devicemax.ToastPackage.SettingsToast_Messages;

/**
 * Utility class for opening settings screens.
 * 
 * 
 * @author aman.arora
 * 
 */
public class OpenSettingsUtility {
	String tag = "OpenSettingsUtility";
	boolean settingErrorFlag = false;
	private static OpenSettingsUtility instance;
	private Activity currentActivity;
	public static SettingsToast settingsToast;
	private String message = "";

	public static OpenSettingsUtility getOpenSettingsUtility() {
		if (instance == null) {
			instance = new OpenSettingsUtility();
		}
		return instance;
	}

	/**
	 * Opens Setting Window as per the setting option provided in the parameter.
	 * 
	 * @param setting
	 */
	public void openSetting(Activity activity, String setting, Context context) {
		try {
			MDMMainActivity.GetIns().addtoLog("Opening Settings.");
			currentActivity = activity;
			settingErrorFlag = false;
			String settingToOpen = "Settings." + setting;
			LogWrite.d(tag, "setting " + settingToOpen);

			// startActivity(new Intent(settingToOpen));
			if (setting.equals("ACTION_SETTINGS")) {
				activity.startActivity(new Intent(Settings.ACTION_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_ADD_ACCOUNT")) {
				activity.startActivity(new Intent(Settings.ACTION_ADD_ACCOUNT)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_ADD_ACCOUNT;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);

			} else if (setting.equals("ACTION_SYNC_SETTINGS")) {
				activity.startActivity(new Intent(Settings.ACTION_SYNC_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_SYNC_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_DISPLAY_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_DISPLAY_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_DISPLAY_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_LOCATION_SOURCE_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_LOCATION_SOURCE_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_LOCATION_SOURCE_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_SOUND_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_SOUND_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_SOUND_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_INTERNAL_STORAGE_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_INTERNAL_STORAGE_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_MEMORY_CARD_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_MEMORY_CARD_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_MEMORY_CARD_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_INPUT_METHOD_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_INPUT_METHOD_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_INPUT_METHOD_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_SCREEN_LOCK_SETTING")) {
				activity.startActivity(new Intent(
						Settings.ACTION_SECURITY_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_SCREEN_LOCK_SETTING;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_LOCALE_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_LOCALE_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_LOCALE_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_WIFI_SETTINGS")) {
				activity.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_WIFI_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_WIFI_IP_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_WIFI_IP_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_WIFI_IP_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_WIRELESS_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_WIRELESS_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_WIRELESS_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_APN_SETTINGS")) {
				activity.startActivity(new Intent(Settings.ACTION_APN_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_APN_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_DATA_ROAMING_SETTINGS")) {
				Intent intent = new Intent(
						Settings.ACTION_DATA_ROAMING_SETTINGS);
				ComponentName cName = new ComponentName("com.android.phone",
						"com.android.phone.Settings");
				intent.setComponent(cName);
				activity.startActivity(intent
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_CLEAR_TASK));
				message = SettingsToast_Messages.ACTION_DATA_ROAMING_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_BLUETOOTH_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_BLUETOOTH_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_BLUETOOTH_SETTINGS;
				LogWrite.d(tag, "Message    93929  " + message);
				startServiceAlarm(context);

			} else if (setting.equals("ACTION_APPLICATION_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_APPLICATION_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_APPLICATION_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_MANAGE_APPLICATIONS_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_MANAGE_APPLICATIONS_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_AIRPLANE_MODE_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_AIRPLANE_MODE_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_AIRPLANE_MODE_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("com.android.phone.NetworkSetting")) {
				// Intent intent=new
				// Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS);
				// ComponentName cName = new
				// ComponentName("com.android.phone","com.android.phone.NetworkSetting");
				// intent.setComponent(cName);
				Intent intent = new Intent(Intent.ACTION_MAIN);
				intent.setClassName("com.android.phone",
						"com.android.phone.NetworkSetting");
				activity.startActivity(intent
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.NetworkSetting;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_SECURITY_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_SECURITY_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_SECURITY_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_ACCESSIBILITY_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_ACCESSIBILITY_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_ACCESSIBILITY_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_DATE_SETTINGS")) {
				activity.startActivity(new Intent(Settings.ACTION_DATE_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_DATE_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_DEVICE_INFO_SETTINGS")) {
				LogWrite.d(tag,
						"***********************************************************************");
				LogWrite.d(tag, "Open Device Info Settings");
				activity.startActivity(new Intent(
						Settings.ACTION_DEVICE_INFO_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				LogWrite.d(tag,
						"***********************************************************************");
				message = SettingsToast_Messages.ACTION_DEVICE_INFO_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_PRIVACY_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_PRIVACY_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_PRIVACY_SETTINGS;
				startServiceAlarm(context);
			} else if (setting.equals("ACTION_SEARCH_SETTINGS")) {
				activity.startActivity(new Intent(
						Settings.ACTION_SEARCH_SETTINGS)
						.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
								| Intent.FLAG_ACTIVITY_NO_HISTORY));
				message = SettingsToast_Messages.ACTION_SEARCH_SETTINGS;
				startServiceAlarm(context);
			} else {
				MDMMainActivity.GetIns().addtoLog("Unable to open settings.");
			}
			MDMMainActivity.GetIns().addtoLog("Settings opened.");
		} catch (Exception e) {
			e.printStackTrace();
			settingErrorFlag = true;
			MDMMainActivity.GetIns().addtoLog("Failed to open settings.");
			LogWrite.d(tag, "ERROR OCCURRED WHILE OPENING SETTINGS, Flag = "
					+ settingErrorFlag);
			Log.d(tag, "openSetting: "+ e.getMessage());
		}
	}

	public boolean isSettingErrorFlag() {
		return settingErrorFlag;
	}

	public void setSettingErrorFlag(boolean settingErrorFlag) {
		this.settingErrorFlag = settingErrorFlag;
	}

	/*
	 * These methods are used to send last sync time and Speed Test Results
	 */
	public void startServiceAlarm(Context context) {
		LogWrite.d(tag, "Start Service Method enters");
		try {
			Intent intent = new Intent(currentActivity,
					OpenSettingReceiver.class);
			LogWrite.d(tag, "Message ----------> " + message);
			intent.putExtra("Message", message);
			AlarmManager alarmManager = (AlarmManager) context
					.getSystemService(Context.ALARM_SERVICE);
			PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
					10101, intent, PendingIntent.FLAG_UPDATE_CURRENT);
			alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP,
					SystemClock.elapsedRealtime(), pendingIntent);
		} catch (Exception e) {
			LogWrite.d(tag, "------" + e);
		}
	}

	public void stopServiceAlarm(Context context) {
		LogWrite.d(tag, "Stop Service Method enters");
		try {
			Intent intent = new Intent(context, OpenSettingReceiver.class);
			AlarmManager alarmManager = (AlarmManager) context
					.getSystemService(Context.ALARM_SERVICE);
			PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
					10101, intent, 0);
			alarmManager.cancel(pendingIntent);
		} catch (Exception e) {
			LogWrite.d(tag, "------" + e);
		}
	}
}
