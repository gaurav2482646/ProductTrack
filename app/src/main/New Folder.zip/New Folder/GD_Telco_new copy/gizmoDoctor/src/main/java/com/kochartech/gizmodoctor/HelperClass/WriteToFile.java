package com.kochartech.gizmodoctor.HelperClass;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import android.os.Environment;
import android.util.Log;

public class WriteToFile {
	private static final String tag = "WriteToFile";

	private static boolean flag = false;

	public static synchronized void write(String fileName, String msg) {
		if (flag) {
			try {
				String path = Environment.getExternalStorageDirectory()
						+ File.separator + fileName;
				File file = new File(path);
				boolean isFilExsits = file.exists();
				if (!isFilExsits) {
					try {
						isFilExsits = file.createNewFile();
					} catch (IOException e) {
						Log.d(tag, "Unable to create File.");
					}
				}

				if (isFilExsits) {
					try {
						FileWriter fileWriter = new FileWriter(file, true);
						fileWriter.write(msg + "\n");
						fileWriter.flush();
						fileWriter.close();
					} catch (IOException e) {
						Log.d(tag, "ExceptionDTO while file creation: " + e);
					}
				}
			} catch (Exception e) {
				Log.d(tag, "ExceptionDTO while file creation: " + e);
			}
		}
	}
}