package com.kochartech.gizmodoctor.Activity;

import android.support.v4.app.Fragment;

public interface FragmentListener {

	public static int actionReplace = 0;
	public static int actionAdd = 1;
	public static int actionRemove = 2;
	public static int actionOnlyRemove = 3;
	public void onItemClicked(int action, Fragment fragment);
	public boolean isTopFargment(Fragment fragment);
}
