package com.kochartech.gizmodoctor.Fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Fragment.GUIPowerSavingSetting.ViewType;
import com.kochartech.gizmodoctor.HelperClass.PowerSavingSettings;

public class GUIPowerSavingProfile extends Fragment implements OnClickListener,
		MyFragment {

//	private String TAG = GUIPowerSavingProfile.class.getSimpleName();

	private Context context;
	private View rootView;

	private ToggleButton powerSavingProfile_Toggle, customSavingProfile_Toggle;
	private TextView powerSavingSettings, customSavingSettings,
			completePowerSavingLimitTextView, customPowerSavingLimitTextView;

	private PowerSavingSettings powerSavingSetting;

	private LinearLayout competePowerSavingBatteryLimitUi,
			customPowerSavingBatteryLimitUi;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		powerSavingSetting = new PowerSavingSettings(context);
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {

		rootView = inflater.inflate(R.layout.fragment_powersavingprofile,
				container, false);
		powerSavingProfile_Toggle = (ToggleButton) rootView
				.findViewById(R.id.completeSavingProfile_ToggleBt);
		powerSavingProfile_Toggle.setChecked(powerSavingSetting
				.getToggleStateCompletePowerSaving());

		customSavingProfile_Toggle = (ToggleButton) rootView
				.findViewById(R.id.customSavingProfile_ToggleBt);
		customSavingProfile_Toggle.setChecked(powerSavingSetting
				.getToggleStateCustomPowerSaving());

		powerSavingSettings = (TextView) rootView
				.findViewById(R.id.completePowerSavingSettings);
		customSavingSettings = (TextView) rootView
				.findViewById(R.id.customPowerSavingSettings);

		completePowerSavingLimitTextView = (TextView) rootView
				.findViewById(R.id.competePowerSavingProfileBatteryLimit);
		completePowerSavingLimitTextView.setText(powerSavingSetting.getBatteryLimitCompletePowerSaving() + " %");
		customPowerSavingLimitTextView = (TextView) rootView
				.findViewById(R.id.customPowerSavingProfileBatteryLimit);
		customPowerSavingLimitTextView.setText(powerSavingSetting
				.getBatteryLimitCustomPowerSaving() + " %");

		competePowerSavingBatteryLimitUi = (LinearLayout) rootView
				.findViewById(R.id.competeBatteryLimitUi);
		customPowerSavingBatteryLimitUi = (LinearLayout) rootView
				.findViewById(R.id.customBatteryLimitUi);

		registerOnClick(powerSavingProfile_Toggle);
		registerOnClick(customSavingProfile_Toggle);
		registerOnClick(powerSavingSettings);
		registerOnClick(customSavingSettings);
		registerOnClick(competePowerSavingBatteryLimitUi);
		registerOnClick(customPowerSavingBatteryLimitUi);

	}

	private void registerOnClick(View view) {
		view.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.completeSavingProfile_ToggleBt) {

			powerSavingSetting
					.setToggleStateCompletePowerSaving(powerSavingProfile_Toggle
							.isChecked());
		} 
		else if (v.getId() == R.id.customSavingProfile_ToggleBt) {

			powerSavingSetting
					.setToggleStateCustomPowerSaving(customSavingProfile_Toggle
							.isChecked());
		}
		else if (v.getId() == R.id.completePowerSavingSettings) {

			GUIPowerSavingSetting guiPowerSavingSetting = new GUIPowerSavingSetting(
					ViewType.COMPLETE);
			FragmentListener fragmentListener = (FragmentListener) getActivity();
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					guiPowerSavingSetting);
		}
		else if (v.getId() == R.id.customPowerSavingSettings) {
			
			GUIPowerSavingSetting guiPowerSavingSetting = new GUIPowerSavingSetting(
					ViewType.CUSTOM);
			FragmentListener fragmentListener = (FragmentListener) getActivity();
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					guiPowerSavingSetting);
		}
		else if (v.getId() == R.id.competeBatteryLimitUi) {
				showUiBatteryLimit(true);

		} else if (v.getId() == R.id.customBatteryLimitUi) {
				showUiBatteryLimit(false);
		}	
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "Power Saving Settings";
	}

	public void showUiBatteryLimit(final boolean type) {
		try {
			final RadioGroup radioButtonGroup;
			final AlertDialog alert = new AlertDialog.Builder(getActivity())
					.create();

//			alert.
			alert.getWindow().setLayout(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
			
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View v = inflater.inflate(R.layout.batterylimit_ui, null, false);
			radioButtonGroup = (RadioGroup) v.findViewById(R.id.radioButtonGroup);

			int currentLevel = 0;
			if (type)
				currentLevel = powerSavingSetting
						.getBatteryLimitCompletePowerSaving();
			else
				currentLevel = powerSavingSetting
						.getBatteryLimitCustomPowerSaving();
			
			RadioButton  radioButton1 = null;
			if (currentLevel == 10) {
				radioButton1 = (RadioButton) radioButtonGroup.getChildAt(0);
				
			} else if (currentLevel == 20) {
				radioButton1 = (RadioButton) radioButtonGroup.getChildAt(1);
			} else if (currentLevel == 30) {
				radioButton1 = (RadioButton) radioButtonGroup.getChildAt(2);
			} else if (currentLevel == 40) {
				radioButton1 = (RadioButton) radioButtonGroup.getChildAt(3);
			}
			
			radioButton1.setChecked(true);
			
//			alert.setContentView(v);
			alert.setView(v);
			alert.show();
			Button okBtn = (Button) v.findViewById(R.id.ok);

			okBtn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					// powerSavingSetting.setBatteryLimitCompletePowerSaving(radioButtonGroup.getS)
					int radioButtonID = radioButtonGroup.getCheckedRadioButtonId();
					View radioButton = radioButtonGroup
							.findViewById(radioButtonID);
					int idx = radioButtonGroup.indexOfChild(radioButton);
					int levelToSet = 0;

					if (idx == 0)
						levelToSet = 10;
					else if (idx == 1)
						levelToSet = 20;
					else if (idx == 2)
						levelToSet = 30;
					else if (idx == 3)
						levelToSet = 40;

					if (type)
						powerSavingSetting
								.setBatteryLimitCompletePowerSaving(levelToSet);
					else
						powerSavingSetting
								.setBatteryLimitCustomPowerSaving(levelToSet);

					completePowerSavingLimitTextView.setText(powerSavingSetting
							.getBatteryLimitCompletePowerSaving() + " %");

					customPowerSavingLimitTextView.setText(powerSavingSetting
							.getBatteryLimitCustomPowerSaving() + " %");

					alert.dismiss();
				}
			});
			Button cancelBtn = (Button) v.findViewById(R.id.cancel);
			cancelBtn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					alert.dismiss();
				}
			});

		} catch (Exception e) {
//			Log.d(TAG, "ExceptionDTO: " + e);
		}
	}
}
