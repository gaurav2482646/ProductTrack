package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.os.Bundle;
/**
 * Screen that finishes when it is created. Just like a refresh screen.
 * @author nishant.kumar
 *
 */
public class RefreshScreen extends Activity{
	
	private String tag="RefreshScreen";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//Log.d(tag, "Inside Refresh Class..........");
		finish();
	}

}
