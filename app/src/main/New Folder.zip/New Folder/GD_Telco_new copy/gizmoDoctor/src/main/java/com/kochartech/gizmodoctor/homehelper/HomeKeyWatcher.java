package com.kochartech.gizmodoctor.homehelper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.Fragment.KeysTestFragment;

public class HomeKeyWatcher {
	static final String TAG = HomeKeyWatcher.class.getSimpleName();
	private Context mContext;
	private IntentFilter mFilter;
	private OnHomePressedListener mListener;
	private InnerRecevier mRecevier;
	private boolean flag;

	public HomeKeyWatcher(Context context, boolean flag) {
		mContext = context;
		mFilter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
		mFilter.setPriority(100);
		this.flag = flag;
	}

	public void setOnHomePressedListener(OnHomePressedListener listener) {
		mListener = listener;
		mRecevier = new InnerRecevier();
	}

	public void startWatch() {
		if (mRecevier != null) {
			mContext.registerReceiver(mRecevier, mFilter);
		}
	}

	public void stopWatch() throws Exception {
		if (mRecevier != null) {
			mContext.unregisterReceiver(mRecevier);
		}
	}

	class InnerRecevier extends BroadcastReceiver {
		final String SYSTEM_DIALOG_REASON_KEY = "reason";
		final String SYSTEM_DIALOG_REASON_GLOBAL_ACTIONS = "globalactions";
		final String SYSTEM_DIALOG_REASON_RECENT_APPS = "recentapps";
		final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";
		final String SYSTEM_DIALOG_REASON_MENU_KEY = "menukey";
		private Intent closeDialog;

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			LogWrite.d(TAG, "action is " + action);
			// String reason1 = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
			// LogWrite.e(TAG, "action:" + action + ",reason:" + reason1);

			if (action.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {
				String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
				LogWrite.d(TAG, "Reason is " + reason);
				if (reason != null) {
					LogWrite.e(TAG, "action:" + action + ",reason:" + reason);
					if (mListener != null) {
						if (reason.equals(SYSTEM_DIALOG_REASON_HOME_KEY)) {
							if (flag) {
								try {
									Thread.sleep(100);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								Intent start_intent = new Intent(context,
										KeysTestFragment.class);
								start_intent
										.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT
												| Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
								context.startActivity(start_intent);
							}
							mListener.onHomePressed();
						} else if (reason
								.equals(SYSTEM_DIALOG_REASON_RECENT_APPS)) {
							if (flag) {
								closeDialog = new Intent(
										Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
								context.sendBroadcast(closeDialog);
							}
							mListener.onHomeLongPressed();
						}
					}
				} else {
					LogWrite.e(TAG, "Power key pressed!");
				}
			}
		}
	}
}
