package com.kochartech.devicemax.ToastPackage;

public interface SettingsToast_Messages
{
	String ACTION_SETTINGS 						=	"Here you can configure Device related settings";
	String ACTION_ADD_ACCOUNT 					= 	"Tap on the Account you want to add";
	String ACTION_SYNC_SETTINGS 				= 	"Tap on the Autosync to Enable / Disable it";
	String ACTION_DISPLAY_SETTINGS 				= 	"Here you can change Display Settings" ;
	String ACTION_LOCATION_SOURCE_SETTINGS 		=	"Tap to Enable / Disable GPS";
	String ACTION_SOUND_SETTINGS 				= 	"Here you can change Sound Settings";
	String ACTION_INTERNAL_STORAGE_SETTINGS 	= 	"Internal Storage details are visible here";
	String ACTION_MEMORY_CARD_SETTINGS 			= 	"SD Card related options are visible here";
	String ACTION_INPUT_METHOD_SETTINGS 		= 	"You can change the language Input settings here";
	String ACTION_SCREEN_LOCK_SETTING 			= 	"Here you can do your Screen Lock settings";
	String ACTION_LOCALE_SETTINGS 				= 	"Tap on the language you want for your device";
	String ACTION_WIFI_SETTINGS 				= 	"Tap on Wi-Fi to Turn it On or Off" ;
	String ACTION_WIFI_IP_SETTINGS 				= 	"Here you can define Static IP Address";
	String ACTION_WIRELESS_SETTINGS 			= 	"You can change Wireless and Network Settings here";
	String ACTION_APN_SETTINGS 					= 	"Tap New APN to create new APN Settings";
	String ACTION_DATA_ROAMING_SETTINGS 		=	"Tap on Data Roaming to Turn it On or Off";
	String ACTION_BLUETOOTH_SETTINGS		 	= 	"Tap to Enable / Disable Bluetooth";
	String ACTION_APPLICATION_SETTINGS 			= 	"Click on desired app to Manage";
	String ACTION_MANAGE_APPLICATIONS_SETTINGS 	=	"Click on desired app to Uninstall / Manage";
	String ACTION_AIRPLANE_MODE_SETTINGS 		= 	"Tap to Enable / Disable Airplane Mode";
	String NetworkSetting 						= 	"Tap on the network name you want to select manually";
	String ACTION_SECURITY_SETTINGS 			= 	"Here you can do Device Security Settings";
	String ACTION_ACCESSIBILITY_SETTINGS 		= 	"Here you can do Device Accessibility Settings";
	String ACTION_DATE_SETTINGS 				= 	"Tap to change Date and Time Settings";
	String ACTION_DEVICE_INFO_SETTINGS 			= 	"See devcie OS version, make, and model etc.";
	String ACTION_PRIVACY_SETTINGS 				= 	"Here you can do Privacy Settings";
	String ACTION_SEARCH_SETTINGS 				= 	"Here you can do Search Related Settings";

//	String  DATA_ROAMING="Tap Data Roaming to disbale it";
//	String  APN="Please change your APN";
//	String  WIFI="Tap Wifi to disbale it";
//	String  BT="Tap Bluetooth to disbale it";
//	String  GPS="Tap USE GPS Satellites to disbale it";
//	String  FLIGHT_MODE="Tap Flight Mode to disable it";
	
}
