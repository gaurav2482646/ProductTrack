package com.kochartech.devicemax.dm;

public class EditProfile extends DmCommand
{

	public EditProfile()
	{
	}

	public EditProfile(String strToParse)
	{

		System.out.println("In Edit Profile" + strToParse);

		String dataKey = "", dataValue = "";
//		String cmd1 = "CMD-1", startSesssion = "STRTSESS", cmdInfo1 =
//				"CMDINF-1", cmdInfo2 = "CMDINF-2", cmdInfo3 = "CMDINF-3", cmdInfo4 =
//				"CMDINF-4", cmdInfo5 = "CMDINF-5", cmdInfo6 = "CMDINF-6", cmdInfo7 =
//				"CMDINF-7", cmdInfo8 = "CMDINF-8";
//		String cNo = "CNo", ht = "HT", nw = ";NW", pr = "PR", em = "EM";
//		String prCount;
		int cmdCount = 1;
		boolean flag = true;
// System.out.println("in create pdsafrofile -> " + createProfileCmd);

		char[] dataCharArray = strToParse.toCharArray();
		int dataCharArrayLength = dataCharArray.length;

		for (int j = 0; j < dataCharArrayLength; j++)
		{

			if (dataCharArray[j] == ':')
			{
				while (flag)
				{
					if (dataKey.equals("CMDINF-" + cmdCount))
					{
						j++;
						j++;
						while (dataCharArray[j] != '>')
						{
							dataValue += dataCharArray[j];
							j++;
						}
						System.out.println("latest  " + dataValue);
						// parsePRCmd(dataValue);
						findPRCount(dataValue);
						System.out.println("char " + dataCharArray[j]);
						dataKey = "";
						dataValue = "";
						flag = false;
					} else
					{
						cmdCount++;
					}
				} // end while

				// so that < gets removed

			}

			else
			{
				dataKey += dataCharArray[j];
				// System.out.println(dataKey);
			}
		}

	}

	void findPRCount(String str)
	{
		System.out.println("Removed " + str);
		String dataKey = "";
//		String dataValue = "";
//		String cmdInfo1 = "CMDINF-1";
		String pr = "PR";
		char[] dataCharArray = str.toCharArray();
		int dataCharArrayLength = dataCharArray.length;

		for (int j = 0; j < dataCharArrayLength; j++)
		{

			if (dataCharArray[j] == ':')
			{
				if (dataKey.substring(0, dataKey.length() - 2).equals(pr))
				{
					// so that < gets removed
// j++;j++;
					hashTable.put("EPRCount", dataKey.substring(3));
					String toSendParseCmd = str.substring(j + 2, str.length());
					System.out.println("tosend parser" + toSendParseCmd);
					parsePRCmd(toSendParseCmd);
// while(dataCharArray[j]!='>')
// {
// dataValue+=dataCharArray[j];
// // j++;
// }
					// System.out.println("string without pr   "+dataValue);
					// parsePRCmd(dataValue);
// findPRCount(dataValue);
					// System.out.println("char " + dataCharArray[j]);
// dataKey="";
// dataValue="";
				}

			}

			else
			{
				dataKey += dataCharArray[j];
// System.out.println(dataKey);
			}
		}

	}

	void parsePRCmd(String parsePRCmd)
	{
		System.out.println("parse cmd PR   >>>" + parsePRCmd);

//		char charArrayPR[] = parsePRCmd.toCharArray();

		String[] keyValuesPairs = parsePRCmd.split(";");
		for (String keyValue : keyValuesPairs)
		{
			String keyValueSeprated[] = keyValue.split(":");
			hashTable.put("E" + keyValueSeprated[0], keyValueSeprated[1]);
			// hashTable.put(keyValuesPairs, value)
			System.out.println("E "
					+ keyValueSeprated[0] + " its " + keyValueSeprated[1]);

		}
		System.out.println(hashTable.toString());
		// System.out.println(hashTable.toString());
	}

}
