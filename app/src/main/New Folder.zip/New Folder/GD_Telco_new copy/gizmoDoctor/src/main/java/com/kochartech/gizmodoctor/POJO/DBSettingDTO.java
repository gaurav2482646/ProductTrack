package com.kochartech.gizmodoctor.POJO;

public class DBSettingDTO {
	
	private String name;
	private boolean isToMonitor, lastState;

	public DBSettingDTO(String SettingName, boolean isToMonitor,
			boolean lastState) {

		this.name = SettingName;
		this.isToMonitor = isToMonitor;
		this.lastState   = lastState;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isToMonitor() {
		return isToMonitor;
	}

	public void setToMonitor(boolean isToMonitor) {
		this.isToMonitor = isToMonitor;
	}

	public boolean getLastState() {
		return lastState;
	}

	public void setLastState(boolean lastState) {
		this.lastState = lastState;
	}

	
	
}
