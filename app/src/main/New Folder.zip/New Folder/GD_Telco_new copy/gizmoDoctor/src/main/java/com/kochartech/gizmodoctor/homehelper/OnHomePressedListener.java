package com.kochartech.gizmodoctor.homehelper;

public interface OnHomePressedListener {
	public void onHomePressed();

	public void onHomeLongPressed();
}
