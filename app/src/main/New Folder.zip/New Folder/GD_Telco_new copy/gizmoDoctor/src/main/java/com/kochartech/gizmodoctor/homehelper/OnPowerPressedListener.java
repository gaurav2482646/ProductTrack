package com.kochartech.gizmodoctor.homehelper;

public interface OnPowerPressedListener {
	public void onPowerKeyPressed(boolean batteryFlag);
}
