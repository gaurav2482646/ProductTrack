package com.kochartech.gizmodoctor.Receiver;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.IBinder;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.DataBase.DataSource_DischargeRate;
import com.kochartech.gizmodoctor.DataBase.WriteToFile;
import com.kochartech.gizmodoctor.Preferences.MyEnum;
import com.kochartech.gizmodoctor.Preferences.MyPreference;

public class BatteryChangeService extends Service {
	private String fileName = "GizmoBattery.txt";
	private String TAG = BatteryChangeService.class.getSimpleName();
	private Context context;
	private IntentFilter filter;
	private MyReceiver batteryListener;
	private DataSource_DischargeRate dsDischargeRate;

	// int count = 15;
	// long currentTime = System.currentTimeMillis();
	@Override
	public void onCreate() {
		super.onCreate();

		context = this;

		LogWrite.d(TAG, "BatteryChangeService: work");
		dsDischargeRate = DataSource_DischargeRate.getInstance(context);
		filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		filter.addAction(Intent.ACTION_SCREEN_OFF);
		filter.addAction(Intent.ACTION_SCREEN_ON);

		batteryListener = new MyReceiver();
		getApplicationContext().registerReceiver(batteryListener, filter);

	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		// LogWrite.d(tag, "onStart");
		return START_STICKY;
	}

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		getApplicationContext().unregisterReceiver(batteryListener);
	}

	class MyReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {

			Log.d(TAG, "Action: " + intent.getAction());
			if (intent.getAction().equalsIgnoreCase(
					Intent.ACTION_BATTERY_CHANGED)) {
				LogWrite.d(TAG, "ACTION_BATTERY_CHANGED: Yes");
				try {
					int rawLevel = intent.getIntExtra("level", -1);

					LogWrite.d(TAG, "level: " + rawLevel);
					// PowerSaver powerSaver = new PowerSaver(context);
					// powerSaver.savePower(rawLevel, false);

					SharedPreferences preference = getSharedPreferences(
							"Battery", 0);
					boolean isFirst = preference.getBoolean("isFirst", true);
					WriteToFile.write(fileName, "working.");

					if (isFirst) {
						Editor editor = preference.edit();
						editor.putBoolean("isFirst", false);
						editor.putInt("lastlevel", rawLevel);
						editor.putLong("time", System.currentTimeMillis());
						editor.commit();

						WriteToFile.write(fileName,
								rawLevel + " : " + System.currentTimeMillis());
					} else {
						int lastLevel = preference.getInt("lastlevel", -1);
						long lastTime = preference.getLong("time", -1);
						if (rawLevel < lastLevel) {
							int levelDifference = lastLevel - rawLevel;
							long timeDifference = System.currentTimeMillis()
									- lastTime;

							/*
							 * Insert Data in DB
							 */
							// dsDischargeRate.open();
							dsDischargeRate.insertLevel(levelDifference,
									timeDifference);

							WriteToFile.write(fileName, rawLevel + " : "
									+ System.currentTimeMillis());

							Editor editor = preference.edit();
							editor.putInt("lastlevel", rawLevel);
							editor.putLong("time", System.currentTimeMillis());
							editor.commit();

						} else if (rawLevel > lastLevel) {
							Editor editor = preference.edit();
							editor.putInt("lastlevel", rawLevel);
							editor.putLong("time", System.currentTimeMillis());
							editor.commit();

							WriteToFile.write(fileName, rawLevel + " : "
									+ System.currentTimeMillis());
						}
					}
				} catch (Exception e) {
					WriteToFile.write(fileName, "ExceptionDTO" + e);
					LogWrite.d(TAG, "ExceptionDTO..." + e);
				}

			} else if (intent.getAction().equalsIgnoreCase(
					Intent.ACTION_SCREEN_ON)) {
				LogWrite.d(TAG, "ACTION_SCREEN_ON: Yes");
				SharedPreferences sharePreference = context
						.getSharedPreferences(MyPreference.PREFERENCE_NAME,
								MyPreference.PREFERENCE_MODE);
				sharePreference
						.edit()
						.putBoolean(
								MyEnum.PREFERENCES_KEYS.DEVICE_ONOFF.getValue(),
								true).commit();

			} else if (intent.getAction().equalsIgnoreCase(
					Intent.ACTION_SCREEN_OFF)) {
				LogWrite.d(TAG, "ACTION_SCREEN_OFF: Yes");
				SharedPreferences sharePreference = context
						.getSharedPreferences(MyPreference.PREFERENCE_NAME,
								MyPreference.PREFERENCE_MODE);
				sharePreference
						.edit()
						.putBoolean(
								MyEnum.PREFERENCES_KEYS.DEVICE_ONOFF.getValue(),
								false).commit();

				// PowerSaver powerSaver = new PowerSaver(context);
				// powerSaver.savePower(null, true);

			}

		}
	}

}
