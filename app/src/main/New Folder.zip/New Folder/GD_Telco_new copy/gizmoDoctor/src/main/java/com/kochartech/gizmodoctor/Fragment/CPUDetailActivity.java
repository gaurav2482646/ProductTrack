//package com.kochartech.gizmodoctor.Fragment;
//
//import java.util.List;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.Adapter.CPUDetailAdapter;
//import com.kochartech.gizmodoctor.Fragment.CpuDetailFragment.UpdateUIAsync;
//import com.kochartech.library.CPU.KTApplicationInfo;
//import com.kochartech.library.CPU.KTUsageCPU;
//
//import android.app.Activity;
//import android.content.Context;
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ListView;
//


//public class CPUDetailActivity extends Activity
//{
//	private String tag = "CpuDetailFragment";
//	private Context context;
//	private View rootView;
//	private ListView listView_CpuDetail;
////	private ActivityManager activityManager ; 
//	private List<KTApplicationInfo> runningAppProcesses;
//	private KTUsageCPU ktCpuUsage;
//	private CPUDetailAdapter cpuDetailAapter;
//	
//	UpdateUIAsync updater;
//	protected void onCreate(Bundle savedInstanceState) {
//		
//		super.onCreate(savedInstanceState);
//			context = this;
//			
//			setContentView(R.layout.fragment_cpudetail);
////			rootView = inflater.inflate(R.layout.fragment_cpudetail, container, false);
//			listView_CpuDetail = (ListView) findViewById(R.id.cpuDetail_ListView);
//			
//			
//			ktCpuUsage = new KTUsageCPU(context);
//			runningAppProcesses = ktCpuUsage.getPerAppUsage(25);
//			
//			cpuDetailAapter = new CPUDetailAdapter(context,runningAppProcesses);
//
//			listView_CpuDetail.setAdapter(cpuDetailAapter);
////			
////			updater = new UpdateUIAsync();
////			updater.execute("");
//			
////			return rootView;
//	}
//}
