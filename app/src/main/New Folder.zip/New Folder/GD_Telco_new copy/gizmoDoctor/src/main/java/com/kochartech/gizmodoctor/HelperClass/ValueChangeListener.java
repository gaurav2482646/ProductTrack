package com.kochartech.gizmodoctor.HelperClass;


public interface ValueChangeListener {
	void onValueChange(int value);
}
