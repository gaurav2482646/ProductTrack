package com.kochartech.gizmodoctor.MonitorInBackground;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Utility.Response;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.DataBase.AppInfo;
import com.kochartech.gizmodoctor.DataBase.AppUsageInfo;
import com.kochartech.gizmodoctor.DataBase.DBHelperDataSettingsToMonitor;
import com.kochartech.gizmodoctor.DataBase.DataSource_AppsInfo;
import com.kochartech.gizmodoctor.DataBase.DataSource_BatteryUsage;
import com.kochartech.gizmodoctor.DataBase.DataSource_CPUUsage;
import com.kochartech.gizmodoctor.DataBase.DataSource_DischargeRate;
import com.kochartech.gizmodoctor.DataBase.DataSource_Monitoring;
import com.kochartech.gizmodoctor.DataBase.DataSource_RAMUsage;
import com.kochartech.gizmodoctor.DataBase.DataSource_Settings;
import com.kochartech.gizmodoctor.HelperClass.CheckOsUpdate;
import com.kochartech.gizmodoctor.HelperClass.DeviceInformation;
import com.kochartech.gizmodoctor.HelperClass.NotificationCheckerManager;
import com.kochartech.gizmodoctor.HelperClass.Utility;
import com.kochartech.gizmodoctor.HelperClass.WriteToFile;
import com.kochartech.gizmodoctor.POJO.AppUsageDTO;
import com.kochartech.gizmodoctor.POJO.DBSettingDTO;
import com.kochartech.gizmodoctor.POJO.MonitoringDTO;
import com.kochartech.gizmodoctor.Preferences.MonitoringPreference;
import com.kochartech.gizmodoctor.Preferences.SavingFailureMonitorResults;
import com.kochartech.library.Application.KTInstalled;
import com.kochartech.library.Battery.KTApplicationDTO;
import com.kochartech.library.Battery.KTBatteryApps;
import com.kochartech.library.Battery.KTBatteryInfo;
import com.kochartech.library.CPU.KTApplicationInfo;
import com.kochartech.library.CPU.KTUsageCPU;
import com.kochartech.library.Device.KTDeviceInfo;
import com.kochartech.library.Device.KTInformation;
import com.kochartech.library.Memory.KTMemoryInfo;
import com.kochartech.library.Memory.KTUsageRAM;

@SuppressLint("SimpleDateFormat")
public class RunnableTask implements Runnable {
	private String tag = RunnableTask.class.getSimpleName();
	private Context context;
	private DataSource_Settings settingToMonitor_DS;
	private DBHelperDataSettingsToMonitor dbHelperDATASettingToMonitor;

	// private DBHelper_PerAppCPU dbHelper_PerAppCPU;
	// private DBHelper_TotalCPU dbHelper_TotalCPU;
	private DataSource_BatteryUsage dsBatteryUsage;
	private DataSource_CPUUsage dsCPUUsage;
	private DataSource_RAMUsage dsRAMUsage;
	private DataSource_Monitoring monitoring;
	private DataSource_DischargeRate dischargeRate;

	private DataSource_AppsInfo dsApps;
	private ArrayList<KTApplicationDTO> batteryList;

	private int monitor_wifi = 0;
	private int monitor_gps = 0;
	private int monitor_bluetooth = 0;
	private int monitor_hotspot = 0;

	private KTBatteryApps batteryApps;
	private KTBatteryInfo batteryInfo;
	private KTDeviceInfo deviceInfo;
	private KTUsageCPU ktCpuUsage;
	private KTUsageRAM ktRamUsage;

	private String MONITOR_SERVICE_URL; // =
										// "http://192.161.0.207/gh_crm_service/GHCRMService.svc/ghcrmclient/gizmodoctor/savemonitorapplog";
	protected int signalStrength = 0;

	PhoneStateListener phonestate = new PhoneStateListener() {
		public void onSignalStrengthChanged(int asu) {
			signalStrength = asu;
			int dbm = -113 + (2 * asu);
			dbm = dbm * (-1);
			if (dbm >= 60 && dbm < 70) {
				dbm = 95;
			} else if (dbm >= 70 && dbm < 87) {
				dbm = 85;
			} else if (dbm >= 87) {
				dbm = 60;
			}
			signalStrength = dbm;
			LogWrite.d("SignalStrength", "SignalStrength : " + signalStrength);
		}
	};

	public RunnableTask(Context context) {
		this.context = context;
		LogWrite.d(tag, "........ Running .........");
		// dbHelper_PerAppCPU = DBHelper_PerAppCPU.getInstance(context);
		// dbHelper_TotalCPU = DBHelper_TotalCPU.getInstance(context);
		// this.batteryList = batteryList;

		MONITOR_SERVICE_URL = context.getString(R.string.MonitorUrl).trim();

		batteryApps = new KTBatteryApps(context.getApplicationContext());

		dsBatteryUsage = DataSource_BatteryUsage.getInstance(context);
		dsCPUUsage = DataSource_CPUUsage.getInstance(context);
		dsRAMUsage = DataSource_RAMUsage.getInstance(context);
		dsApps = DataSource_AppsInfo.getInstance(context);

		batteryInfo = KTBatteryInfo.getInstance();
		batteryInfo.calculate(context.getApplicationContext());
		deviceInfo = new KTDeviceInfo(context);

		monitoring = DataSource_Monitoring.getInstance(context);

		ktCpuUsage = new KTUsageCPU(context);
		ktRamUsage = new KTUsageRAM(context);
		dischargeRate = DataSource_DischargeRate.getInstance(context);
	}

	@SuppressWarnings("deprecation")
	@Override
	public void run() {

		CheckOsUpdate osUpdate = new CheckOsUpdate(context);
		osUpdate.check();

		// DevicePerformance performanceIssue = new DevicePerformance(
		// context);
		// performanceIssue.check();

		intervalTasks();
		recordCPUUsage();
		recordRAMUsage();
		// totalCPUMonitor();
		// perAppCPUMonitor();

		// getBatteryTemperature();

		MonitoringPreference monitoringPreference = new MonitoringPreference(
				context);

		boolean monitoring_start = monitoringPreference
				.getMonitoringStartStatus();
		if (monitoring_start) {
			batteryApps.refreshView();

			recordBatteryUsage();
			settingsMonitor();

			ktCpuUsage.refresh(25);
			LogWrite.i(tag, "Start Monitoring........");

			monitor_wifi = monitoringPreference.getMonitoringWifiValue();
			monitor_gps = monitoringPreference.getMonitoringGpsValue();
			monitor_bluetooth = monitoringPreference
					.getMonitoringBluetoothValue();
			monitor_hotspot = monitoringPreference.getMonitoringHotspotValue();
			if (deviceInfo.isWifiEnabled()) {
				LogWrite.d(tag, "Wifi is ON");
				monitor_wifi += 2;
				monitoringPreference.setMonitoringWifiValue(monitor_wifi);
			} else {
				monitoringPreference.deleteMonitoringWifiValue();
			}

			if (deviceInfo.isGPSEnabled()) {
				LogWrite.d(tag, "GPS is ON");
				monitor_gps += 2;
				monitoringPreference.setMonitoringGpsValue(monitor_gps);
			} else {
				monitoringPreference.deleteMonitoringGpsValue();
			}

			if (deviceInfo.isBluetoothEnabled()) {
				LogWrite.d(tag, "Bluetooth is ON");
				monitor_bluetooth += 2;
				monitoringPreference
						.setMonitoringBluetoothValue(monitor_bluetooth);
			} else {
				monitoringPreference.deleteMonitoringBluetoothValue();
			}

			if (isHotspotEnabled()) {
				LogWrite.d(tag, "Hotspot is ON");
				monitor_hotspot += 2;
				monitoringPreference.setMonitoringHotspotValue(monitor_hotspot);
			} else {
				monitoringPreference.deleteMonitoringHotspotValue();
			}

			int count = monitoringPreference.getCount();
			if (count < (MonitoringPreference.THREE_HOURS_COUNT - 1)) {
				LogWrite.d(tag, "Count is " + count);
				int monitor_value = monitoringPreference.getMonitoringValue();
				LogWrite.d(tag, "MonitorValue : " + monitor_value);
				if (monitor_value == 2) {
					LogWrite.i(tag, "Saving Data to Monitor........");
					((android.telephony.TelephonyManager) context
							.getApplicationContext().getSystemService(
									Context.TELEPHONY_SERVICE)).listen(
							phonestate,
							PhoneStateListener.LISTEN_SIGNAL_STRENGTH);
					monitorigDevice(count);
					monitoringPreference.deleteMonitoringValue();

					count++;
					monitoringPreference.setCount(count);
					((android.telephony.TelephonyManager) context
							.getApplicationContext().getSystemService(
									Context.TELEPHONY_SERVICE)).listen(
							phonestate, PhoneStateListener.LISTEN_NONE);
					int sendCount = monitoringPreference.getSendCount();
					LogWrite.e(tag, "Count for Sending Logs is "
							+ (sendCount * 2));
					LogWrite.e(tag, "Count is " + count);
					if (count == sendCount * 2) {
						LogWrite.e(tag, "Sending logs to server...");
						LogWrite.e(tag, count + " = " + sendCount * 2);
						sendDatatoServer(context.getApplicationContext());
						// getMonitorRecord();
						sendCount++;
						monitoringPreference.setSendCount(sendCount);
					}
					SavingFailureMonitorResults resultSave = new SavingFailureMonitorResults(
							context);
					// Set<String> resultArray = resultSave.getJsonSet();
					// LogWrite.i(tag, "ResultArraySize : " +
					// resultArray.size());
					if (resultSave.getCount() > 0) {
						LogWrite.i(tag, "Need to send failure result");
						ResponseAsync async = new ResponseAsync(context, "",
								true);
						async.execute("");
					}
				} else {
					LogWrite.e(tag, "Still Monitoring...........");
					monitor_value++;
					monitoringPreference.setMonitoringValue(monitor_value);
				}
			} else {
				monitoringPreference.setMonitoringStartStatus(false);
				monitoringPreference.deleteCount();
				monitoring.delete();
			}
			batteryApps.stopBackgroundWorking();
		} else {
			LogWrite.i(tag, "Monitoring Command not received yet....");
			SavingFailureMonitorResults resultSave = new SavingFailureMonitorResults(
					context);
			// Set<String> resultArray = resultSave.getJsonSet();
			// LogWrite.i(tag, "ResultArraySize : " + resultArray.size());
			if (resultSave.getCount() > 0) {
				LogWrite.i(tag, "Need to send failure result");
				ResponseAsync async = new ResponseAsync(context, "", true);
				async.execute("");
			}
		}

		// isToNotify();
	}

	private void sendDatatoServer(Context applicationContext) {
		LogWrite.d(tag, "-------------------- Testing");
		List<MonitoringDTO> apps = monitoring.queryTableRecId();
		LogWrite.d(tag, "AppsInMonitoringDB: numApps: " + apps.size());
		try {
			JSONArray array = new JSONArray();
			JSONObject jsonObject = new JSONObject();
			DeviceInformation information = new DeviceInformation(context);
			jsonObject.put("IMEI", information.getIMEI());
			JSONArray jsonArray = new JSONArray();
			for (MonitoringDTO monitoringDTO : apps) {
				jsonArray.put(monitoringDTO.toJsonString());
			}
			jsonObject.put("DeviceInfo", jsonArray);
			array.put(jsonObject);

			LogWrite.e(tag, "JSON to Send : " + array.toString());

			ResponseAsync async = new ResponseAsync(applicationContext,
					array.toString(), false);
			async.execute("");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void monitorigDevice(int count) {
		try {
			String tag = "monitorigDevice";

			float discharge = dischargeRate.getDischargeRate();
			DecimalFormat df = new DecimalFormat();
			df.setMinimumFractionDigits(2);
			String discharge_rate_minutes = df.format(discharge);

			float usedRamUsage = ktRamUsage.getMeoryInfo().getUsed();
			int totalRamUsage = (int) ktRamUsage.getMeoryInfo().getTotal();
			int ram_percentage = (int) ((usedRamUsage * 100) / totalRamUsage);

			int cpu_percentage = ktCpuUsage.getTotalCPUUsage();

			List<AppInfo> apps = dsApps.queryAllRecord();
			LogWrite.d(tag, "AppsInDB: numApps: " + apps.size());
			for (AppInfo appInfo : apps) {
				int rowId = appInfo.getRowId();
				String appName = appInfo.getAppName();
				String processName = appInfo.getPkName();

				DataSource_CPUUsage cpuUsage = DataSource_CPUUsage
						.getInstance(context);
				DataSource_RAMUsage ramUsage = DataSource_RAMUsage
						.getInstance(context);
				DataSource_BatteryUsage batteryUsage = DataSource_BatteryUsage
						.getInstance(context);
				AppUsageInfo ramUsageInfo = ramUsage.queryAppDetail(rowId);
				ArrayList<AppUsageDTO> ramUsageList = ramUsageInfo
						.getAppUsage();
				AppUsageDTO ramUsageDTO = ramUsageList.get(0);
				LogWrite.d("Ashish", "RAM Usage : " + ramUsageDTO.getAppUsage());
				int RAM_USAGE = ramUsageDTO.getAppUsage();

				AppUsageInfo cpuUsageInfo = cpuUsage.queryAppDetail(rowId);
				ArrayList<AppUsageDTO> cpuUsageList = cpuUsageInfo
						.getAppUsage();
				AppUsageDTO cpuUsageDTO = cpuUsageList.get(0);
				LogWrite.d("Ashish", "CPU Usage : " + cpuUsageDTO.getAppUsage());
				int CPU_USAGE = cpuUsageDTO.getAppUsage();

				AppUsageInfo batteryUsageInfo = batteryUsage
						.queryAppDetail(rowId);
				ArrayList<AppUsageDTO> batteryUsageList = batteryUsageInfo
						.getAppUsage();
				AppUsageDTO batteryUsageDTO = batteryUsageList.get(0);
				LogWrite.d(
						"Ashish",
						"Battery Usage : "
								+ batteryUsageDTO.getAppUsageString());
				String BATTERY_USAGE = batteryUsageDTO.getAppUsageString();
				if (CPU_USAGE != 0 || !BATTERY_USAGE.equals("0")
						|| RAM_USAGE != 0) {
					LogWrite.d(tag, "RowId : " + rowId);
					LogWrite.d(tag, "Data to be stored at : " + count);
					LogWrite.d(tag, "AppName : " + appName);
					LogWrite.d(tag, "ProcessName : " + processName);
					LogWrite.d(tag, "Cpu Usage : " + CPU_USAGE);
					LogWrite.d(tag, "Battery Usage : " + BATTERY_USAGE);
					LogWrite.d(tag, "RAM Usage : " + RAM_USAGE);

					String appTypeAndUpdate = getAppUpdateAndType(context,
							processName);
					LogWrite.d(tag, "AppType and Update Time is "
							+ appTypeAndUpdate);
					String[] list = appTypeAndUpdate.split("::");
					String appType = "System";
					String last_update_time = "0";
					if (list.length >= 2) {
						appType = list[0].trim();
						String update_time_String = list[1].trim();
						long update = Long.parseLong(update_time_String);
						last_update_time = getDate(update);
					}
					LogWrite.i(tag, "RecordID : " + count);
					LogWrite.e(tag, "AppName : " + appName);
					LogWrite.e(tag, "AppType : " + appType);
					LogWrite.e(tag, "LastUpdateTime : " + last_update_time);
					LogWrite.e(tag, "DeviceBatteryDischargeRate : "
							+ discharge_rate_minutes);
					LogWrite.e(tag, "RAM in Percentage : " + ram_percentage);
					LogWrite.e(tag, "CPU in Percentage : " + cpu_percentage);
					LogWrite.e(tag, "SignalStrength : " + signalStrength);
					String bearer = getBearerInfo(context);
					LogWrite.e(tag, "BearerInfo: " + bearer);

					MonitoringDTO monitoringDTO = new MonitoringDTO(
							context.getApplicationContext());
					monitoringDTO.setRecord_id(count);
					monitoringDTO.setApp_name(appName);
					monitoringDTO.setProcess_name(processName);
					monitoringDTO.setCpu_usage("" + CPU_USAGE);
					monitoringDTO.setRam_usage("" + RAM_USAGE);
					monitoringDTO.setDischarge_rate("" + BATTERY_USAGE);
					monitoringDTO.setBattery_level(""
							+ batteryInfo.getBatteryLevel());
					monitoringDTO.setBattery_temp(""
							+ batteryInfo.getTemperature());
					monitoringDTO
							.setDevice_health("" + batteryInfo.getHealth());
					if (batteryInfo.getChargingState())
						monitoringDTO.setCharging_state("Charging");
					else
						monitoringDTO.setCharging_state("Not on charging");
					monitoringDTO.setTime_stamp(Utility.getCurrentDate());
					monitoringDTO.setWifi_time("" + monitor_wifi);
					monitoringDTO.setBluetooth_time("" + monitor_bluetooth);
					monitoringDTO.setGps_time("" + monitor_gps);
					monitoringDTO.setHotspot_time("" + monitor_hotspot);
					monitoringDTO.setApp_type("" + appType);
					monitoringDTO.setLast_update_time("" + last_update_time);
					monitoringDTO.setTotal_cpu("" + cpu_percentage);
					monitoringDTO.setTotal_ram("" + ram_percentage);
					monitoringDTO.setTotal_discharge(""
							+ discharge_rate_minutes);
					monitoringDTO.setSignal_strength("" + signalStrength);
					monitoringDTO.setBearer_type("" + bearer);

					LogWrite.d(tag, "DeviceHealth: " + batteryInfo.getHealth());
					LogWrite.d(tag,
							"BatteryLevel: " + batteryInfo.getBatteryLevel());
					LogWrite.d(
							tag,
							"BatteryTemperature: "
									+ batteryInfo.getTemperature());
					LogWrite.d(tag,
							"ChargingState: " + batteryInfo.getChargingState());
					LogWrite.d(tag, "CurrentDate: " + Utility.getCurrentDate());
					monitoring.insertRecord(monitoringDTO);
				}
			}
		} catch (Exception e) {
			LogWrite.e(tag, "MonitoringException : " + e.toString());
		}
	}

	private String getAppUpdateAndType(Context context, String package_name) {
		KTInstalled installed = new KTInstalled(context);
		ArrayList<com.kochartech.library.Application.KTApplicationInfo> appsList = installed
				.getInstalledApps();
		for (com.kochartech.library.Application.KTApplicationInfo ktApplicationInfo : appsList) {
			if (ktApplicationInfo.getPackageName().equals(package_name)) {
				return ktApplicationInfo.getAppType() + "::"
						+ ktApplicationInfo.getLastUpdateTime();
			} else
				continue;
		}
		return "";
	}

	public void recordBatteryUsage() {
		try {
			String tag = "recordBatteryUsage";
			Thread.sleep(10000);
			batteryList = batteryApps.refreshView();
			if (batteryList != null) {
				List<AppInfo> apps = dsApps.queryAllRecord();
				LogWrite.d(tag, "AppsInDB: numApps: " + apps.size());

				long diagnoseTime = System.currentTimeMillis();
				for (AppInfo appInfo : apps) {
					int appId = appInfo.getRowId();
					String appName = appInfo.getAppName();
					String batteryUsage = getBatteryUsage(batteryList, appName);
					if (!batteryUsage.equals("0")) {
						LogWrite.e(tag, "-------------------");
						LogWrite.d(tag, "appId: " + appId);
						LogWrite.d(tag, "appName: " + appName);
						LogWrite.d(tag, "batteryUsage: " + batteryUsage);
					}

					dsBatteryUsage.insertRecord(appId, batteryUsage,
							diagnoseTime);
				}
			}
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO :---> " + e.toString());
		}
	}

	// public void getBatteryTemperature() {
	//
	// KTBatteryInfo ktBatteryInfo = KTBatteryInfo.getInstance();
	// ktBatteryInfo.calculate(context);
	// int temperature = (int) ktBatteryInfo.getTemperature();
	// int level = (int) ktBatteryInfo.getBatteryLevel();
	//
	// // if(temperature >= 40) {
	// NotificationHelper helper = NotificationHelper.getInstance(context);
	// helper.createNotification("Level: "+level+"% Temperature: "+temperature+" \u2103",
	// 10100,true);
	// //
	// // }
	// }
	public void recordCPUUsage() {
		try {
			String tag = "recordCPUUsage";
			// dsCPUUsage.open();
			/*
			 * Fetch the CPU Consuming Apps
			 */
			// ktCpuUsage.refresh();
			List<KTApplicationInfo> cpuConsumingApps = ktCpuUsage.refresh(25);
			// LogWrite.d(tag, "numApps= "+cpuConsumingApps.size());
			//
			// for(KTApplicationInfo ktAppInfo : cpuConsumingApps)
			// {
			// LogWrite.d(tag, "AppName: "+ktAppInfo.getAppName());
			// LogWrite.d(tag, "Usage  : "+ktAppInfo.getUsage());
			// }
			/*
			 * Fetch App List
			 */

			// dsApps.open();
			List<AppInfo> apps = dsApps.queryAllRecord();
			LogWrite.d(tag, "AppsInDB: numApps: " + apps.size());
			/*
			 * prints Apps data
			 */
			// for(AppInfo appInfo : apps)
			// {
			// LogWrite.d(tag, "rowId: "+appInfo.getRowId());
			// LogWrite.d(tag, "AppName  : "+appInfo.getAppName());
			// }
			LogWrite.d(tag, "AppsInDB: numApps: ");
			/*
			 * update database
			 */
			long diagnoseTime = System.currentTimeMillis();
			for (AppInfo appInfo : apps) {
				int appId = appInfo.getRowId();
				String appName = appInfo.getAppName();
				int cpuUsage = getCPUUsage(cpuConsumingApps, appName);
				if (cpuUsage != 0) {
					LogWrite.d(tag, "appId: " + appId);
					LogWrite.d(tag, "appName: " + appName);
					LogWrite.d(tag, "cpuUsage: " + cpuUsage);
				}

				dsCPUUsage.insertRecord(appId, cpuUsage, diagnoseTime);
			}
		} catch (Exception e) {

		}

	}

	// public void getAppInfo(List<AppInfo> apps, String packageName) {
	// for(AppInfo appInfo : apps)
	// {
	// if(appInfo.getPkName().equalsIgnoreCase(packageName) {
	// return
	// }
	// }
	// }

	public void recordRAMUsage() {
		try {
			String tag = "recordRAMUsage";

			// dsRAMUsage.open();

			/*
			 * Fetch the CPU Consuming Apps
			 */
			KTUsageRAM ktUsageRAM = new KTUsageRAM(context);
			List<com.kochartech.library.Memory.KTApplicationInfo> ramConsumingApps = ktUsageRAM
					.getPerAppUsage();

			// LogWrite.d(tag, "numApps= "+cpuConsumingApps.size());
			//
			// for(KTApplicationInfo ktAppInfo : cpuConsumingApps)
			// {
			// LogWrite.d(tag, "AppName: "+ktAppInfo.getAppName());
			// LogWrite.d(tag, "Usage  : "+ktAppInfo.getUsage());
			// }
			/*
			 * Fetch App List
			 */
			// dsApps.open();
			List<AppInfo> apps = dsApps.queryAllRecord();
			LogWrite.d(tag, "AppsInDB: numApps: " + apps.size());
			/*
			 * prints Apps data
			 */
			// for(AppInfo appInfo : apps)
			// {
			// LogWrite.d(tag, "rowId: "+appInfo.getRowId());
			// LogWrite.d(tag, "AppName  : "+appInfo.getAppName());
			// }
			LogWrite.d(tag, "AppsInDB: numApps: ");
			/*
			 * update database
			 */
			KTUsageRAM ktRamUsage = new KTUsageRAM(context);
			KTMemoryInfo ktmemoryInfo = ktRamUsage.getMeoryInfo();
			float totalRAM = ktmemoryInfo.getTotal();
			long diagnoseTime = System.currentTimeMillis();
			for (AppInfo appInfo : apps) {
				int appId = appInfo.getRowId();
				String appName = appInfo.getAppName();
				int ramUsage = (int) getRAMUsage(ramConsumingApps, appName,
						totalRAM);
				if (ramUsage != 0) {
					LogWrite.d(tag, "appId: " + appId);
					LogWrite.d(tag, "appName: " + appName);
					LogWrite.d(tag, "ramUsage: " + ramUsage);
				}
				dsRAMUsage.insertRecord(appId, ramUsage, diagnoseTime);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getBatteryUsage(ArrayList<KTApplicationDTO> batteryList2,
			String appName) {
		DataSource_DischargeRate obj = DataSource_DischargeRate
				.getInstance(context.getApplicationContext());
		// obj.open();
		double dischargeRate = obj.getDischargeRate();
		// LogWrite.d(tag, "dischargeRate: " + dischargeRate);
		if (dischargeRate == 0)
			dischargeRate = .33;
		for (int i = 0; i < batteryList.size(); i++) {
			KTApplicationDTO app = batteryList.get(i);
			// LogWrite.d(tag, "AppName: " + app.getAppName());
			// LogWrite.d(tag, "Percentage: " + app.getAppPercentage());
			if (app.getAppName().equalsIgnoreCase("GizmoDoctor"))
				batteryList.remove(i);
		}
		for (int i = 0; i < batteryList.size(); i++) {
			KTApplicationDTO app = batteryList.get(i);
			if (app.getAppName().equalsIgnoreCase("GizmoDoctor"))
				continue;
			String appPercentage = "";
			if (app.getAppName().equalsIgnoreCase(appName)) {
				try {
					Float ff = Float
							.valueOf(app.getAppPercentage().split("%")[0]
									.trim());
					// LogWrite.d(tag, "ff: " + ff);
					// LogWrite.d(tag, "AppName: " + app.getAppName());
					if (dischargeRate > 0) {
						appPercentage = String.valueOf(new DecimalFormat(
								"##.##").format((dischargeRate / 100) * ff));

						// LogWrite.d(tag, "appPercentage: " + appPercentage);
					} else {
						appPercentage = "0";
					}
					// appPercentage = Math.round(ff);
					return appPercentage;
				} catch (Exception e) {
					// LogWrite.e(tag,
					// "RecordBatteryUsageException: " + e.toString());
				}
			}
		}
		return "0";
	}

	public int getCPUUsage(List<KTApplicationInfo> ktApplicationInfo,
			String appName) {
		for (KTApplicationInfo ktAppInfo : ktApplicationInfo) {
			if (ktAppInfo.getAppName().equalsIgnoreCase(appName))
				return Integer.parseInt(ktAppInfo.getUsage().split("%")[0]
						.trim());
		}
		return 0;
	}

	public long getRAMUsage(
			List<com.kochartech.library.Memory.KTApplicationInfo> ktApplicationInfo,
			String appName, float totalRAM) {
		for (com.kochartech.library.Memory.KTApplicationInfo ktAppInfo : ktApplicationInfo) {
			if (ktAppInfo.getAppName().equalsIgnoreCase(appName)) {
				return (long) ((ktAppInfo.getUsage() / totalRAM) * 100);
			}
		}
		return 0;
	}

	// public void isToNotify()
	// {
	// try {
	// SharedPreferences preference =
	// context.getSharedPreferences("Notification",Context.MODE_PRIVATE);
	// String keyBattery = "battery";
	// String keyBatteryNotificationShow = "nbattery";
	// String keyCPU = "cpu";
	// String keyCPUNotificationShow = "ncpu";
	// String keyRAM = "ram";
	// String keyRAMNotificationShow = "nram";
	//
	// String tag = "isToNotify";
	// com.kochartech.library.Battery.KTInformation batteryInfo =
	// com.kochartech.library.Battery.KTInformation.getInstance();
	//
	// int batteryTemp = (int) batteryInfo.getTemperature();
	// LogWrite.d(tag,"Battery Temerature: "+batteryTemp);
	//
	// if(!preference.getBoolean(keyBatteryNotificationShow,false))
	// {
	// if(batteryTemp>=45)
	// {
	// preference.edit().putBoolean(keyBatteryNotificationShow, true).commit();
	// LogWrite.d(tag,"Battery Notifiy: Yes");
	// NotificationHelper.getInstance(context).createNotification("Battery temperature("+batteryTemp+"\u2103)is above than normal.",0);
	//
	// }
	// }
	// else
	// {
	// int count = preference.getInt(keyBattery, 0); count++;
	// if(count == 30)
	// {
	// count = 0;
	// preference.edit().putBoolean(keyBatteryNotificationShow, false).commit();
	// }
	// preference.edit().putInt(keyBattery, count).commit();
	// }
	//
	//
	//
	//
	// //CPU Usage Notification.
	// KTUsageCPU ktCPUUsage = new KTUsageCPU(context);
	// int cpuUsage = ktCPUUsage.getTotalCPUUsage();
	// LogWrite.d(tag,"CPU: "+cpuUsage);
	//
	// if(!preference.getBoolean(keyCPUNotificationShow,false))
	// {
	// if(cpuUsage>=85)
	// {
	// if(cpuUsage<=100)
	// {
	// preference.edit().putBoolean(keyCPUNotificationShow, true).commit();
	// LogWrite.d(tag,"CPU Notifiy: Yes");
	// NotificationHelper.getInstance(context).createNotification("CPU("+cpuUsage+" %)usage is above than normal.",1);
	// }
	// }
	// }
	// else
	// {
	// int count = preference.getInt(keyCPU, 0); count++;
	// if(count == 30)
	// {
	// count = 0;
	// preference.edit().putBoolean(keyCPUNotificationShow, false).commit();
	// }
	// preference.edit().putInt(keyCPU, count).commit();
	// }
	//
	//
	// //RAM Usage Notification.
	// KTUsageRAM ktUsageRAM = new KTUsageRAM(context);
	// int ramUsage = ktUsageRAM.getMeoryInfo().getUsedInPercentage();
	// LogWrite.d(tag,"RAM: "+ramUsage);
	//
	// if(!preference.getBoolean(keyRAMNotificationShow,false))
	// {
	// if(ramUsage>=85)
	// {
	// preference.edit().putBoolean(keyRAMNotificationShow, true).commit();
	// LogWrite.d(tag,"RAM Notifiy: Yes");
	// NotificationHelper.getInstance(context).createNotification("RAM("+ramUsage+" %)usage is above than normal.",2);
	//
	// }
	// }
	// else
	// {
	// int count = preference.getInt(keyRAM, 0); count++;
	// if(count == 30)
	// {
	// count = 0;
	// preference.edit().putBoolean(keyRAMNotificationShow, false).commit();
	// }
	// preference.edit().putInt(keyRAM, count).commit();
	// }
	// } catch (ExceptionDTO e) {
	//
	// LogWrite.d(tag,"ExceptionDTO..."+e);
	// }
	//
	// }
	public void settingsMonitor() {

		try {
			String tag = "SettingsMonitoring";
			settingToMonitor_DS = DataSource_Settings.getInstance(context);
			// settingToMonitor_DS.open();
			dbHelperDATASettingToMonitor = DBHelperDataSettingsToMonitor
					.getInstance(context);
			// dbHelperDATASettingToMonitor.open();
			// Cursor cursor = settingToMonitor_DS.getAllColumns();
			ArrayList<DBSettingDTO> dbSettingDTOList = settingToMonitor_DS
					.getAllColumns();
			// if (cursor.getCount() > 0) {
			// if (cursor.moveToFirst()) {
			// do {
			if (dbSettingDTOList != null) {
				for (DBSettingDTO dbSettingDTO : dbSettingDTOList) {
					boolean currentState = gecurrentState(dbSettingDTO
							.getName());
					LogWrite.d(tag, dbSettingDTO.getName() + " : "
							+ currentState);
					if (currentState) {
						LogWrite.d(
								tag,
								"DB last state : "
										+ dbSettingDTO.getLastState());
						if (!dbSettingDTO.getLastState()) {
							LogWrite.d(tag, "insert new entry");
							// Insert new Entry
							dbHelperDATASettingToMonitor
									.insertEntry(dbSettingDTO.getName());
							settingToMonitor_DS.updateTheLastState(
									dbSettingDTO.getName(), 1);
						} else {
							LogWrite.d(tag, "update old entry");
							// update End Time of Last entry
							LogWrite.d(
									tag,
									"DB last state : "
											+ dbSettingDTO.getLastState());
							LogWrite.d(tag, "update the entry");
							dbHelperDATASettingToMonitor
									.updateSettingEndTime(dbSettingDTO
											.getName());
						}
					} else {
						if (dbSettingDTO.getLastState()) {
							LogWrite.d(tag, "off the monitoring in last entry");
							dbHelperDATASettingToMonitor
									.setSettingMonitorningOff(dbSettingDTO
											.getName());
							// update LastState
							settingToMonitor_DS.updateTheLastState(
									dbSettingDTO.getName(), 0);
						}
					}

				}// End Of If Statement.
					// dbHelperDATASettingToMonitor.printTable();
			}
		} catch (Exception e) {

		}
	}

	// public void settingsMonitor() {
	// settingToMonitor_DS = SettingToMonitor_DS.getInstance(context);
	// dbHelperDATASettingToMonitor = DBHelperDataSettingsToMonitor
	// .getInstance(context);
	//
	// Cursor cursor = settingToMonitor_DS.getColumnIsToMonitor();
	// if (cursor.getCount() > 0) {
	// if (cursor.moveToFirst()) {
	// do {
	// int indexOfColumnIsToMonitor = cursor
	// .getColumnIndex(MySQLiteOpenHelper.SettingToMonitor_ColumnIsToMonitor);
	// if (cursor.getInt(indexOfColumnIsToMonitor) == 1)
	// {
	// //Yes to Monitor the Settings.
	//
	// int indexOfColumnSettingName = cursor
	// .getColumnIndex(MySQLiteOpenHelper.SettingToMonitor_ColumnSettingName);
	// int indexOfColumnLastState = cursor
	// .getColumnIndex(MySQLiteOpenHelper.SettingToMonitor_ColumnLastState);
	//
	// String settingName = cursor
	// .getString(indexOfColumnSettingName);
	// int settingLastState = cursor
	// .getInt(indexOfColumnLastState);
	// boolean currentState = gecurrentState(settingName);
	// if (currentState)
	// {
	// if (settingLastState == 0)
	// {
	// // Insert new Entry
	// dbHelperDATASettingToMonitor
	// .insertEntry(settingName);
	// }
	// else
	// {
	// // update End Time of Last entry
	// dbHelperDATASettingToMonitor.updateSettingEndTime(settingName);
	// }
	// }
	// else
	// {
	// dbHelperDATASettingToMonitor.updateSettingEndTime(settingName);
	// if (settingLastState == 1)
	// {
	// // update LastState
	//
	// }
	// }
	// }
	// } while (cursor.moveToNext());
	// }
	// }// End Of If Statement.
	// }

	// private void network
	// private void totalCPUMonitor() {
	// LogWrite.d(tag, "CpuUsage Monitor Starts :");
	//
	// int indexColumnUsage, indexColumnNumOfDiagnose;
	//
	// dbHelper_TotalCPU.open();
	// Cursor cursor = dbHelper_TotalCPU.getAllColumns();
	// if (cursor.getCount() > 0) {
	// if (cursor.moveToFirst()) {
	// do {
	// indexColumnUsage = cursor
	// .getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnUsage);
	// indexColumnNumOfDiagnose = cursor
	// .getColumnIndex(MySQLiteOpenHelper.CPUUsageTotal_ColumnNumOfDiagnose);
	//
	// numOfDiagnoseInDb = cursor.getInt(indexColumnNumOfDiagnose);
	// nowNumofDiagnose = numOfDiagnoseInDb + 1;
	//
	// avgCPUUsageInDb = cursor.getFloat(indexColumnUsage);
	//
	// int cpuUsageNow = ktCpuUsage.getTotalCPUUsage();
	//
	// LogWrite.d(tag, "cpuUsageNow :" + cpuUsageNow);
	//
	// float avgToActualValue = avgCPUUsageInDb
	// * numOfDiagnoseInDb;
	// LogWrite.d(tag, "avgToActualValue :" + avgToActualValue);
	//
	// avgCPUUsageNow = (avgToActualValue + cpuUsageNow)
	// / nowNumofDiagnose;
	// LogWrite.d(tag, "avgCPUUsageNow :" + avgCPUUsageNow);
	//
	// dbHelper_TotalCPU.update(avgCPUUsageNow, nowNumofDiagnose);
	//
	// } while (cursor.moveToNext());
	// }
	// }
	// dbHelper_TotalCPU.close();
	// }

	// private void perAppCPUMonitor() {
	//
	// int indexColumnAppName, indexColumnUsage;
	// dbHelper_PerAppCPU.open();
	// Cursor cursor = dbHelper_PerAppCPU.getAllColumns();
	// List<KTApplicationInfo> runningAppProcesses = ktCpuUsage
	// .getPerAppUsage(25);
	//
	// // for(int i=0;i<runningAppProcesses.size();i++)
	// // {
	// //
	// LogWrite.d(tag,"******** AppName :"+runningAppProcesses.get(i).getAppName());
	// //
	// LogWrite.d(tag,"******** Usage :"+runningAppProcesses.get(i).getUsage());
	// // }
	//
	// if (cursor.getCount() > 0) {
	// if (cursor.moveToFirst()) {
	// indexColumnAppName = cursor
	// .getColumnIndex(MySQLiteOpenHelper.CPUUsagePerApp_ColumnAppName);
	// indexColumnUsage = cursor
	// .getColumnIndex(MySQLiteOpenHelper.CPUUsagePerApp_ColumnUsage);
	// do {
	//
	// String appName = cursor.getString(indexColumnAppName);
	// float avgCPUUsageInDb = cursor.getFloat(indexColumnUsage);
	//
	// LogWrite.d(tag, "appName         :" + appName);
	// LogWrite.d(tag, "avgCPUUsageInDb :" + avgCPUUsageInDb);
	//
	// KTApplicationInfo ktAppInfo = getKTApplicationInfo(
	// runningAppProcesses, appName);
	//
	// LogWrite.d(tag, "ktAppInfo :" + ktAppInfo);
	//
	// if (ktAppInfo != null) {
	// // LogWrite.d(tag, "Now CPUUsage :" +
	// // ktAppInfo.getUsage());
	// float avgToActualValue = (avgCPUUsageInDb * numOfDiagnoseInDb);
	// float currentCPUUsage = (avgToActualValue + Integer
	// .valueOf(ktAppInfo.getUsage().split("%")[0]
	// .trim()))
	// / nowNumofDiagnose;
	// dbHelper_PerAppCPU.updateRow(appName, currentCPUUsage);
	// } else {
	// float avgToActualValue = (avgCPUUsageInDb * numOfDiagnoseInDb);
	// float currentCPUUsage = (avgToActualValue + 0)
	// / nowNumofDiagnose;
	//
	// dbHelper_PerAppCPU.updateRow(appName, currentCPUUsage);
	// }
	// } while (cursor.moveToNext());
	//
	// }
	// }
	// }

	public KTApplicationInfo getKTApplicationInfo(
			List<KTApplicationInfo> runningAppProcesses, String appName) {
		for (KTApplicationInfo ktAppInfo : runningAppProcesses) {

			if (ktAppInfo.getAppName().equalsIgnoreCase(appName))
				return ktAppInfo;
		}
		return null;
	}

	public boolean gecurrentState(String settingName) {
		KTInformation ktInformation = new KTInformation(context);
		if (settingName.equalsIgnoreCase("WiFi")) {
			return ktInformation.isWifiEnabled();
		} else if (settingName.equalsIgnoreCase("Bluetooth")) {
			return ktInformation.isBluetoothEnabled();
		} else if (settingName.equalsIgnoreCase("GPS")) {
			return ktInformation.isGPSEnabled();
		} else if (settingName.equalsIgnoreCase("WiFi hotspot")) {
			return isHotspotTetheringEnabled(context);
		}
		return false;
	}

	private boolean isHotspotTetheringEnabled(Context context) {
		boolean state = false;
		WifiManager wifi = (WifiManager) context
				.getSystemService(Context.WIFI_SERVICE);
		Method[] wmMethods = wifi.getClass().getDeclaredMethods();
		for (Method method : wmMethods) {
			if (method.getName().equals("isWifiApEnabled")) {
				try {
					state = (Boolean) method.invoke(wifi);
					return state;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
			}
		}
		return state;
	}

	// private int numOfDiagnoseInDb, nowNumofDiagnose;
	// private float avgCPUUsageInDb, avgCPUUsageNow;

	String fileName = "monitoring.txt";

	// public void getMonitorRecord() {
	// String tag = "DisplayMonitoringRecord";
	// List<MonitoringDTO> apps = monitoring.queryAllRecord();
	// LogWrite.d(tag, "AppsInMonitoringDB: numApps: " + apps.size());
	// for (MonitoringDTO monitoringDTO : apps) {
	// LogWrite.d(tag, "RowId : " + monitoringDTO.getRecord_id());
	// LogWrite.d(tag, "AppName : " + monitoringDTO.getApp_name());
	// LogWrite.d(tag, "ProcessName : " + monitoringDTO.getProcess_name());
	// LogWrite.d(tag, "Cpu Usage : " + monitoringDTO.getCpu_usage());
	// LogWrite.d(tag,
	// "Battery Usage : " + monitoringDTO.getDischarge_rate());
	// LogWrite.d(tag, "RAM Usage : " + monitoringDTO.getRam_usage());
	// LogWrite.d(tag, "BatteryLevel: " + monitoringDTO.getBattery_level());
	// LogWrite.d(tag, "DeviceHealth: " + monitoringDTO.getDevice_health());
	// LogWrite.d(tag,
	// "BatteryTemperature: " + monitoringDTO.getBattery_temp());
	// LogWrite.d(tag,
	// "ChargingState: " + monitoringDTO.getCharging_state());
	// LogWrite.d(tag, "WifiTime: " + monitoringDTO.getWifi_time());
	// LogWrite.d(tag,
	// "BluetoothTime: " + monitoringDTO.getBluetooth_time());
	// LogWrite.d(tag, "GPSTime: " + monitoringDTO.getGps_time());
	// LogWrite.d(tag, "HotspotTime: " + monitoringDTO.getHotspot_time());
	//
	// LogWrite.d(tag, "Date: " + monitoringDTO.getTime_stamp());
	// }
	// }

	private boolean isHotspotEnabled() {
		boolean state = false;
		LogWrite.d(tag, "checkTethering");
		WifiManager wifi = (WifiManager) context
				.getSystemService(Context.WIFI_SERVICE);
		Method[] wmMethods = wifi.getClass().getDeclaredMethods();
		for (Method method : wmMethods) {
			if (method.getName().equals("isWifiApEnabled")) {
				try {
					state = (Boolean) method.invoke(wifi);
					if (state == true) {
						// Toast.makeText(getApplicationContext(), "on",
						// Toast.LENGTH_LONG).show();
						return state;
					} else {
						// Toast.makeText(getApplicationContext(), "off",
						// Toast.LENGTH_LONG).show();
						return state;
					}

				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
			}
		}
		return state;
	}

	private class ResponseAsync extends AsyncTask<String, String, String> {
		private String TAG = ResponseAsync.class.getSimpleName();
		private String jsonString = "";
		private Context context;
		private SavingFailureMonitorResults resultSave;

		private boolean success = false;

		private boolean failureFlag = false;

		public ResponseAsync(Context context, String monitoringDTO,
				boolean failureFlag) {
			this.context = context;
			this.failureFlag = failureFlag;
			jsonString = monitoringDTO.toString();

			resultSave = new SavingFailureMonitorResults(
					context.getApplicationContext());
			// if (!jsonString.equals(""))
			// resultSave.saveJson(jsonString);
		}

		@Override
		protected String doInBackground(String... params) {
			// Set<String> resultArray = resultSave.getJsonSet();
			// Object[] array = resultArray.toArray();
			// LogWrite.d(TAG, "ArraySize  : " + array.length);
			// ArrayList<String> newArrayList = new ArrayList<String>();
			// for (int i = 0; i < array.length; i++) {
			// String result = array[i].toString();
			if (!failureFlag) {
				LogWrite.d(TAG, "Result JSON To Send : " + jsonString);
				WriteToFile.write(fileName, "JSON To Send : ");
				WriteToFile.write(fileName, jsonString);
				Response response = new Response();
				success = response.send(context, MONITOR_SERVICE_URL,
						jsonString);
				if (success) {
					WriteToFile.write(fileName, "Result Success!!!");
					// resultArray.remove(array[i]);
					// monitoring.delete();
				} else {
					WriteToFile.write(fileName, "Result Fail!!!");
					int count = resultSave.getCount();
					resultSave.setSendingJSON(jsonString, count);
					count++;
					resultSave.setCount(count);

					// newArrayList.add(result);
				}
			} else {
				ArrayList<String> failureList = resultSave.getSendingJSON();
				for (int i = 0; i < failureList.size(); i++) {
					LogWrite.i(TAG,
							"Failure[" + i + "] : " + failureList.get(i));
					if (!failureList.get(i).equals("")) {
						Response response = new Response();
						success = response.send(context, MONITOR_SERVICE_URL,
								failureList.get(i));
						if (success) {
							resultSave.setSendingJSON("", i);
						}
					}
				}
			}

			// }
			// resultSave.resetAll();
			// if (!newArrayList.isEmpty()) {
			// for (String string : newArrayList) {
			// resultSave.saveJson(string);
			// }
			// }

			// while (!success) {
			// success = response.send(context, MONITOR_SERVICE_URL,
			// jsonString);
			// try {
			// Thread.sleep(1 * 60 * 1000);
			// } catch (InterruptedException e) {
			// e.printStackTrace();
			// }
			// }
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			// if (success)
			// WriteToFile.write(fileName, "Send Success....");
			// else
			// WriteToFile.write(fileName, "Send Fail....");
		}
	}

	private String getDate(long time) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		return format.format(time);
	}

	private String getBearerInfo(Context context) {
		String bearerInfo = "";

		TelephonyManager teleMan = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		// if (teleMan.getSimSerialNumber() == null) {
		// if (isWifiNetwork(context)) {
		// bearerInfo = "WiFi";
		// } else {
		// bearerInfo = "Unknown";
		// }
		// } else {
		// if (isWifiNetwork(context)) {
		// bearerInfo = "WiFi";
		// } else {
		int networkType = teleMan.getNetworkType();

		switch (networkType) {
		case TelephonyManager.NETWORK_TYPE_1xRTT:
			bearerInfo = "1xRTT";
			break;
		case TelephonyManager.NETWORK_TYPE_CDMA:
			bearerInfo = "CDMA";
			break;
		case TelephonyManager.NETWORK_TYPE_EDGE:
			bearerInfo = "EDGE";
			break;
		case TelephonyManager.NETWORK_TYPE_EHRPD:
			bearerInfo = "eHRPD";
			break;
		case TelephonyManager.NETWORK_TYPE_EVDO_0:
			bearerInfo = "EVDO rev. 0";
			break;
		case TelephonyManager.NETWORK_TYPE_EVDO_A:
			bearerInfo = "EVDO rev. A";
			break;
		case TelephonyManager.NETWORK_TYPE_EVDO_B:
			bearerInfo = "EVDO rev. B";
			break;
		case TelephonyManager.NETWORK_TYPE_GPRS:
			bearerInfo = "GPRS";
			break;
		case TelephonyManager.NETWORK_TYPE_HSDPA:
			bearerInfo = "HSDPA";
			break;
		case TelephonyManager.NETWORK_TYPE_HSPA:
			bearerInfo = "HSPA";
			break;
		case TelephonyManager.NETWORK_TYPE_HSPAP:
			bearerInfo = "HSPA+";
			break;
		case TelephonyManager.NETWORK_TYPE_HSUPA:
			bearerInfo = "HSUPA";
			break;
		case TelephonyManager.NETWORK_TYPE_IDEN:
			bearerInfo = "iDen";
			break;
		case TelephonyManager.NETWORK_TYPE_LTE:
			bearerInfo = "LTE";
			break;
		case TelephonyManager.NETWORK_TYPE_UMTS:
			bearerInfo = "UMTS";
			break;
		case TelephonyManager.NETWORK_TYPE_UNKNOWN:
			bearerInfo = "Unknown";
			break;

		// }
		// }
		}
		return bearerInfo;
	}

	private void intervalTasks() {
		LogWrite.d(tag, "Notifications Going to check...");
		NotificationCheckerManager notificationManager = new NotificationCheckerManager(
				context.getApplicationContext());
		notificationManager.checkNotifications();
	}
}
