package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Adapter.RAMdDetailAdapter;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.HelperClass.LineGraph;
import com.kochartech.gizmodoctor.HelperClass.SettingsToast;
import com.kochartech.gizmodoctor.UpdateUi.UiRequireUpdate;
import com.kochartech.gizmodoctor.UpdateUi.UiUpdateAsync;
import com.kochartech.library.Memory.KTApplicationInfo;
import com.kochartech.library.Memory.KTMemoryInfo;
import com.kochartech.library.Memory.KTUsageRAM;

public class GUIRAM extends Fragment implements UiRequireUpdate,
		OnItemClickListener, MyFragment {
	private String TAG = GUIRAM.class.getSimpleName();
	private Context context;
	private View rootView;
	private ListView listView_CpuDetail;
	private List<KTApplicationInfo> runningAppProcesses = new ArrayList<KTApplicationInfo>();
	private KTUsageRAM ktRAMUsage;
	private RAMdDetailAdapter cpuDetailAapter;
	private LineGraph lineGraphView;
	private LinearLayout mLayout;
	private TextView cpuPercentageTextView;
	private UiUpdateAsync uiUpdateAsync;
	private KTMemoryInfo ktMemoryUsage;
	private MyProgressDialog myProgressDialog;

	private boolean isToShowProgressDialog = false;

	public String getTitle() {
		return "RAM Diagnosis";
	}

	@SuppressWarnings("deprecation")
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		context = getActivity().getApplicationContext();
		lineGraphView = new LineGraph(getActivity());
		rootView = inflater.inflate(R.layout.fragment_ramdetail, container,
				false);
		listView_CpuDetail = (ListView) rootView
				.findViewById(R.id.cpuDetail_ListView);
		listView_CpuDetail.setOnItemClickListener(this);
		cpuPercentageTextView = (TextView) rootView
				.findViewById(R.id.cpuPercentage);
		mLayout = (LinearLayout) rootView.findViewById(R.id.graph);
		mLayout.addView(lineGraphView.getView(), new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT,
				LinearLayout.LayoutParams.FILL_PARENT, 1));

		ktRAMUsage = new KTUsageRAM(context);

		cpuDetailAapter = new RAMdDetailAdapter(context, runningAppProcesses);
		listView_CpuDetail.setAdapter(cpuDetailAapter);

		if (savedInstanceState == null) {
			myProgressDialog = new MyProgressDialog(getActivity());
			myProgressDialog.show();
		} else {
			isToShowProgressDialog = true;
		}

		uiUpdateAsync = new UiUpdateAsync();
		LogWrite.d(TAG, "is Running :" + uiUpdateAsync.isRunning());

		return rootView;
	}

	@Override
	public void runInBackGround() {
		if (isToShowProgressDialog) {
			isToShowProgressDialog = false;
			getActivity().runOnUiThread(new Runnable() {
				@Override
				public void run() {
					myProgressDialog = new MyProgressDialog(getActivity());
					myProgressDialog.show();
				}
			});
		}
		ArrayList<KTApplicationInfo> runningAppProcesses = (ArrayList<KTApplicationInfo>) ktRAMUsage
				.getPerAppUsage();
		this.runningAppProcesses.clear();
		this.runningAppProcesses.addAll(runningAppProcesses);
		Collections.sort(this.runningAppProcesses,
				new Comparator<KTApplicationInfo>() {
					@Override
					public int compare(KTApplicationInfo lhs,
							KTApplicationInfo rhs) {
						LogWrite.i(TAG, "Comparing........");
						long appSize1 = lhs.getUsage();
						long appSize2 = rhs.getUsage();

						if (lhs.getProcessName().toLowerCase()
								.contains("kochar")) {
							return 1;
						}

						if (rhs.getProcessName().toLowerCase()
								.contains("kochar")) {
							return -1;
						}

						// ascending order
						if (appSize1 < appSize2)
							return 1;
						else if (appSize1 > appSize2)
							return -1;
						else
							return 0;

					}
				});

		// LogWrite.d(TAG, "ProcessListSize : " + runningAppProcesses.size());

		// moveItemById(runningAppProcesses, runningAppProcesses.size() - 1);

		ktMemoryUsage = ktRAMUsage.getMeoryInfo();
	}

	public void moveItemById(ArrayList<KTApplicationInfo> runningAppProcesses,
			int newPosition) {
		int positionOfItem = -1;
		for (KTApplicationInfo ktApplicationInfo : runningAppProcesses) {
			if (ktApplicationInfo.getProcessName().contains("kochar")) {
				int index = runningAppProcesses.indexOf(ktApplicationInfo);
				LogWrite.d(TAG, "Index of Kochar App : " + index);
				positionOfItem = index;
			}
		}
		LogWrite.d(TAG, "Position of item : " + positionOfItem);
		LogWrite.d(TAG, "New Position of item : " + newPosition);
		if (positionOfItem != -1) {
			moveItem(runningAppProcesses, positionOfItem, newPosition);
		}
	}

	public void moveItem(ArrayList<KTApplicationInfo> runningAppProcesses,
			int idxToMove, int targetIdx) {
		KTApplicationInfo removed = runningAppProcesses.remove(idxToMove);
		runningAppProcesses.add(targetIdx, removed);
	}

	@Override
	public void updateUI() {
		if (myProgressDialog.isShowing())
			myProgressDialog.dismiss();
		cpuDetailAapter.notifyDataSetChanged();
		cpuPercentageTextView.setText("" + ktMemoryUsage.getUsedInPercentage()
				+ " %");
		lineGraphView.refresh(ktMemoryUsage.getUsedInPercentage());
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		uiUpdateAsync.stop();
		LogWrite.d(TAG, "onDestroy :");

		setToastVisibilty(false);
	}

	@Override
	public void onStop() {
		super.onStop();
		uiUpdateAsync.stop();
		LogWrite.d(TAG, "onStop :");
	}

	@Override
	public void onResume() {
		super.onResume();
		uiUpdateAsync = uiUpdateAsync.start(this);
		LogWrite.d(TAG, "onResume :");

		setToastVisibilty(false);
	}

	@Override
	public void onPause() {
		super.onPause();
		uiUpdateAsync.stop();
		LogWrite.d(TAG, "onPause :");
		setToastVisibilty(true);
	}

	private void setToastVisibilty(boolean flag) {
		if (settingToast != null) {
			settingToast.setToastVisibility(flag);
		}
	}

	// @Override
	// public void onDetach() {
	// // TODO Auto-generated method stub
	// super.onDetach();
	//
	// getActivity().getSupportFragmentManager().getFragments().get(0).onResume();
	// LogWrite.d(TAG, "onDetach :");
	// }

	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		LogWrite.d(TAG, "onAttach :");
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		KTApplicationInfo ktApplicationInfo = runningAppProcesses.get(arg2);
		if (!context.getPackageName()
				.equals(ktApplicationInfo.getProcessName())) {
			Bundle bundle = new Bundle();
			bundle.putString(GUIUsageStats.KEY_APPNAME,
					ktApplicationInfo.getAppName());
			bundle.putString(GUIUsageStats.KEY_PKGNAME,
					ktApplicationInfo.getProcessName());

			Fragment fragment = new GUIUsageStats();
			fragment.setArguments(bundle);

			FragmentListener fragmentListener = (FragmentListener) getActivity();
			fragmentListener
					.onItemClicked(FragmentListener.actionAdd, fragment);
			LogWrite.d(TAG, "onItem Click Finish.");
		}
	}

	private SettingsToast settingToast;

	// @Override
	// public boolean isToUpdateUi() {
	// // TODO Auto-generated method stub
	// return false;
	// }

}
