package com.kochartech.devicemax.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
//import com.kochar.AsyncTask.ApplicationUpdatehandler;
//import com.kochar.MDMS.Services.ServiceEg;

//@SuppressWarnings("deprecation")
public class BootReceiver extends BroadcastReceiver
{
	private SharedPreferences.Editor editor;
	private SharedPreferences preferences;
	private String tag="bootreceiver";
	public static boolean restartFlag = false;
	/*
	 * flag for calling the method selfCare() of SelfDiagnosis class once on each light on of phone screen 
	 */
	@Override
	public void onReceive(Context context, Intent intent) 
	{
//		try
//		{
//			String action = intent.getAction();
//			if (action.equals(Intent.ACTION_BOOT_COMPLETED)) 
//			{
//				context.startService(new Intent(context, DataChangeListener.class));
//			}
//		}
//		catch(ExceptionDTO e)
//		{
//			LogWrite.d(tag, "ExceptionDTO ----> " + e.toString());
//		}
	}
}
