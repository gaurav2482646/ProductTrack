package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.kochartech.gizmodoctor.R;

public class GUICleanActivityFinish extends Activity {

	public static void launch(Context context) {
		Intent intent = new Intent(context, GUICleanActivityFinish.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
				| Intent.FLAG_ACTIVITY_NO_HISTORY);
		context.startActivity(intent);
	}

	private ImageView cleanView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_clean_finish);
		cleanView = (ImageView) findViewById(R.id.clean_tick_image);
		Animation rotate = AnimationUtils.loadAnimation(
				getApplicationContext(), R.anim.bounce);
		rotate.setRepeatMode(Animation.INFINITE);
		cleanView.startAnimation(rotate);
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

}
