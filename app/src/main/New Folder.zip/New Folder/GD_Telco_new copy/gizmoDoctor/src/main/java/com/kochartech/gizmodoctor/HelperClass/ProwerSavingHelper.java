package com.kochartech.gizmodoctor.HelperClass;

import java.util.ArrayList;

import android.content.Context;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.POJO.PowerSavingSettingsDTO;

public class ProwerSavingHelper {

	private final String TAG = ProwerSavingHelper.class.getSimpleName();
	
	private ArrayList<Boolean> settingsStateArray; 
	ArrayList<PowerSavingSettingsDTO> powerSavingSettingDTOList;
	public ProwerSavingHelper(Context context) {			
		PowerSavingSettings powerSavingSetting = new PowerSavingSettings(context);
		powerSavingSettingDTOList = powerSavingSetting.getSettings();				
	}
	
	public void actionOnProfile() {
		for(PowerSavingSettingsDTO powerSavingSettingDTO : powerSavingSettingDTOList) {
			if(powerSavingSettingDTO.getState()) {
				action(powerSavingSettingDTO.getName());
			}
		}		
	}
	
	public void action(String name) 
	{
		if(name.equals(PowerSavingSettings.TURNOFF_BT)) {
			LogWrite.d(TAG, "Bluetooth turn off");
		}
		else if(name.equals(PowerSavingSettings.TURNOFF_WIFI)) {
			LogWrite.d(TAG, "Wifi turn off");
		}		
	}	
}
