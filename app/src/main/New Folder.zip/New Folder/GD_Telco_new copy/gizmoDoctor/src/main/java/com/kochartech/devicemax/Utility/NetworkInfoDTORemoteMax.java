package com.kochartech.devicemax.Utility;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;


import com.kochartech.devicemax.Activities.MDMMainActivity;
import com.kochartech.library.Network.Network;

import org.json.JSONObject;


public class NetworkInfoDTORemoteMax {

    public static String NetworkId = null;
    public static String NetworkName = "";
    public static String SignalStrength = "";
    public static String roamingstatus = "";
    public static String dataroaming = "";
    public static String bearerType = "";

    public static String __type = "";
    /*
     * CatLog tag
     */
    static private String tag = "NetworkInfoDTO";
    Network networkinfo = null;

    public JSONObject toJSONObject() {
        JSONObject jsonObject = new JSONObject();
        try {


            jsonObject.put("BearerType", getBearerType());
            jsonObject.put("NetworkId", getNetworkId().toString());
            jsonObject.put("NetworkName", getNetworkName());
            jsonObject.put("SignalStrength", String.valueOf(getSignalStrength()));
            jsonObject.put("DataRoaming", String.valueOf(getRoamingStatus()));
            jsonObject.put("RoamingStatus", String.valueOf(getRoamingStatus()));

        } catch (Exception e) {
            Log.e(tag,
                    "NetworkInfoDTO-> Tojsonobject -> exception ->"
                            + e.toString());
        }
        return jsonObject;
    }

    public String getBearerType() {

        return bearerType;
    }

    public void setBearerType(String bearerType) {
        this.bearerType = bearerType;
    }

    public String getRoamingStatus() {

        return roamingstatus;
    }

    public void setRoamingstatus(String roamingstatus) {
        this.roamingstatus = roamingstatus;
    }

    public String getNetworkId() {
        return NetworkId;
    }

    public void setNetworkId(String networkId) {
        NetworkId = networkId;
    }

    public String getNetworkName() {
        return NetworkName;
    }

    public void setNetworkName(String networkName) {
        NetworkName = networkName;
    }

    public String getSignalStrength() {
        return SignalStrength;
    }

    public void setSignalStrength(String signalStrength) {
        SignalStrength = signalStrength;
    }

    public NetworkInfoDTORemoteMax getNetworkInfo(Context context) {
//		NetworkInfoDTO networkInfoDTO = new NetworkInfoDTO();
        try {

//			Log.e("Dummy", "inside the networkinfo dto method");
            networkinfo = new Network(context);
//			Log.e("Dummy", "1");
//			FeatureInfo info = new FeatureInfo();
//			Log.e("Dummy", "2");
//			Log.d(tag, "Network Id is: " + String.valueOf(getCellID(context)));
            setNetworkId(String.valueOf(setCellIdAndLoc((context))));
            setNetworkName(networkinfo.getNetworkOperatorName());
//			Log.e("Dummy", "3");
//			setSignalStrength(String.valueOf(FeatureInfoRemoteMax.signalStrength));
            setSignalStrength(String.valueOf(MDMMainActivity.signalStrength));
//			Log.e("Dummy", "4");
            setRoamingstatus(String.valueOf(networkinfo.checkRoaming()));
//			Log.e("Dummy", "5");
            setBearerType(networkinfo.getBearerType());

//			Log.d(tag, ""+networkinfo.getNetworkOperatorName()+"  "+info.signalStrength+"   "+networkinfo.checkRoaming()
//					+"  "+networkinfo.checkRoaming());
//			Log.d(tag + "n/w info", networkInfoDTO.toJSONObject().toString());

        } catch (Exception e) {
            e.printStackTrace();
//			Log.e("Dummy", "exception: "+e.toString());
        }
        return null;
    }

    private String setCellIdAndLoc(Context context) {
        String lac = "";
        String cellId = "";
        try {

            final TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (telephony.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) {
                final GsmCellLocation location = (GsmCellLocation) telephony.getCellLocation();
                if (location != null) {
                    lac = String.valueOf(location.getLac());
                }
                int cellID = location.getCid();
                cellID = cellID & 0xffff;
                cellId = String.valueOf(cellID);
                return cellId;
            } else {
//                showToast("Not on GSM Network", 2000);
            }
        } catch (Exception e) {
            Log.d(tag, "Exception =CellIdLoc = " + e);
        }
        return cellId;
    }


//	public int getCellID(Context context)
//	{
//
//		int ci = 0;
//		try
//		{
//
//			TelephonyManager telephonyManager = (TelephonyManager) context
//					.getSystemService(Context.TELEPHONY_SERVICE);
//			String NetworkMode = networkinfo.getBearerType();
//			// Log.d(TAG, "NetworkMode=="+NetworkMode);
//			if (NetworkMode.equalsIgnoreCase("GSM"))
//			{
//				GsmCellLocation location = (GsmCellLocation) telephonyManager
//						.getCellLocation();
//				int CELLID = location.getCid();
//				Log.d(tag, "CELLID: " + CELLID);
//				ci = CELLID & 0xffff;
//				Log.d(tag, "cell id: " + ci);
//			} else if (NetworkMode.equalsIgnoreCase("CDMA"))
//			{
//
//				CdmaCellLocation location1 = (CdmaCellLocation) telephonyManager
//						.getCellLocation();
//				int cellID = location1.getBaseStationId();
//				ci = cellID & 0xffff;
//
//			}
//			Log.d(tag, "cell id: " + ci);
//		} catch (Exception e)
//		{
//
//			e.printStackTrace();
//		}
//
//		/*
//		 * if(ci==0) { cell=""; } else { cell=""+ci; }
//		 */
//		return ci;
//
//	}

}