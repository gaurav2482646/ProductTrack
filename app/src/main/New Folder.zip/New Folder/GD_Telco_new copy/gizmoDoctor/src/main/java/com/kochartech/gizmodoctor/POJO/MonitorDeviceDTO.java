package com.kochartech.gizmodoctor.POJO;

public class MonitorDeviceDTO {

}
