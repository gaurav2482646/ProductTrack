package com.kochartech.library.Memory;

import android.graphics.drawable.Drawable;

public class KTApplicationInfo
{
	private String appName;
	private String processName;
	private Drawable icon;	
	private int pid;
	private long usage;
	public KTApplicationInfo()
	{
		
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public Drawable getIcon() {
		return icon;
	}
	public void setIcon(Drawable icon) {
		this.icon = icon;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}	
	public long getUsage() {
		return usage;
	}
	public void setUsage(long usage) {
		this.usage = usage;
	}	
}
