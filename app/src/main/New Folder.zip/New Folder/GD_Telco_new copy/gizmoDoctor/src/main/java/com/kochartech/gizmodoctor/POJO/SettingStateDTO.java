package com.kochartech.gizmodoctor.POJO;

public class SettingStateDTO {
	private String settingName, onTime;

	public String getSettingName() {
		return settingName;
	}

	public void setSettingName(String settingName) {
		this.settingName = settingName;
	}

	public String getOnTime() {
		return onTime;
	}

	public void setOnTime(String onTime) {
		this.onTime = onTime;
	}

}
