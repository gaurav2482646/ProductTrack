package com.kochartech.gizmodoctor.Adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Fragment.GUIPowerSavingSetting.ViewType;
import com.kochartech.gizmodoctor.POJO.PowerSavingSettingsDTO;

public class PowerSavingSettingsAdapter extends BaseAdapter {
	private String TAG = PowerSavingSettingsAdapter.class.getSimpleName();
	private ArrayList<PowerSavingSettingsDTO> dataSetDTOList;
	private LayoutInflater inflator;
	private ViewType viewType;
	public PowerSavingSettingsAdapter(Context context,
			ArrayList<PowerSavingSettingsDTO> dataSetDTOList, ViewType viewType) {
		this.dataSetDTOList = dataSetDTOList;
		this.viewType = viewType;
		inflator = LayoutInflater.from(context);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		if (convertView == null)
		{
			if(viewType.getValue() ==  ViewType.COMPLETE.getValue()) {
				convertView = inflator.inflate(R.layout.prowersavingprofile_listviewitem, null);
			}
			else if(viewType.getValue() ==  ViewType.CUSTOM.getValue()) {
				convertView = inflator.inflate(R.layout.custompowersavingprofile_listviewitem, null);
			}
		}
		
		
		PowerSavingSettingsDTO powerSavingSettingDTO = dataSetDTOList.get(position);
		
		ImageView iconImageView = (ImageView) convertView.findViewById(R.id.icon);
		TextView titleTxtView = (TextView) convertView.findViewById(R.id.title);
		TextView desxriptionTxtView = (TextView) convertView.findViewById(R.id.description);
		CheckBox checkBox = (CheckBox) convertView.findViewById(R.id.checkbox);
		
		iconImageView.setImageResource(powerSavingSettingDTO.getIcon()); 
		titleTxtView.setText(powerSavingSettingDTO.getName());		
		desxriptionTxtView.setText(powerSavingSettingDTO.getDescription());			
		
		/*
		 * if Adapter is for CustomPowerSavingSetting
		 * 	then set actual state of checkbox
		 * else 
		 *  set they are just for display and mark as tick
		 */
		
		if(viewType.getValue() ==  ViewType.CUSTOM.getValue())
			checkBox.setChecked(powerSavingSettingDTO.getState());
		
		return convertView;
	}
	

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return dataSetDTOList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return dataSetDTOList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODOAuto-generated method stub
		return position;
	}
}
