package com.kochartech.devicemax.dto;

/**
 * Created by gauravjeetsingh on 20/3/18.
 */

public class ExceptionDTO
{
    private String ErrorMessage;

    public ExceptionDTO(String errorMessage, String errorCode) {
        ErrorMessage = errorMessage;
        ErrorCode = errorCode;
    }

    private String ErrorCode;

    public String getErrorMessage ()
    {
        return ErrorMessage;
    }

    public void setErrorMessage (String ErrorMessage)
    {
        this.ErrorMessage = ErrorMessage;
    }

    public String getErrorCode ()
    {
        return ErrorCode;
    }

    public void setErrorCode (String ErrorCode)
    {
        this.ErrorCode = ErrorCode;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ErrorMessage = "+ErrorMessage+", ErrorCode = "+ErrorCode+"]";
    }
}
