//package com.kochartech.gizmodoctor.Activity;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.util.ArrayList;
//import java.util.Hashtable;
//import java.util.List;
//
//import android.app.ActivityManager;
//import android.app.ActivityManager.RunningAppProcessInfo;
//import android.content.Context;
//import android.content.pm.ApplicationInfo;
//import android.content.pm.PackageManager;
//import android.content.pm.PackageManager.NameNotFoundException;
//import android.graphics.drawable.Drawable;
//import android.util.Log;
///**
// * This class has been used to calculate CPU Usage.
// * @author aman.arora
// */
//public class KTUsageCPU extends KTUsage
//{
//	
//	private String tag = "CpuUsage";
////	private Context context;
//	private Hashtable<String,Integer> hashTable = new Hashtable<String, Integer>();
//	private ArrayList<String> headerName = null;
//	
////	private List<KTApplicationInfo> runningAppUsageInfo = new ArrayList<KTApplicationInfo>();
////	private PackageManager pkgManager;
////	private ActivityManager activityManager;	
//	private Hashtable<Integer, ApplicationInfo> pidMap_ApplicationInfo = new Hashtable<Integer, ApplicationInfo>(); 
//	private int countNumApps;
//	private int numOfAppsRequire =0;
//	private int total = 0;
//	public KTUsageCPU(Context context) 
//	{
//		super(context);
////		this.context = context;
////		pkgManager = context.getPackageManager();
////		activityManager = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);		
//	}	
//	public List<KTApplicationInfo> getPerAppUsage(int numOfAppsRequire)
//	{	
//		this.numOfAppsRequire =  numOfAppsRequire>25?25:numOfAppsRequire;
//		refreshPerAppUsage();
//		return runningAppUsageInfo;
//	}
//	
//	public void refreshPerAppUsage()
//	{		
//		initPIDMap();
//		resetPerAppUsage();
//		calculatePerAppUsage(false);
//	}
//	public String getUsage(String processName)
//	{
//		for(KTApplicationInfo ktAppInfo: runningAppUsageInfo)
//		{
//			if(ktAppInfo.getProcessName().equals(processName))
//			{
//				return ktAppInfo.getUsage();
//			}
//		}
//		return String.valueOf("0%");
//	}	
//	public int getTotalCPUUsage()
//	{		
//		resetTotalCPUsage();
//		calculatePerAppUsage(true);
//		return total;
//	}	
//	
//	public int getFreeCPUUsage()
//	{
//		return (100-total);
//	}
//	private void initPIDMap()
//	{
//		pidMap_ApplicationInfo.clear();		
//		List<RunningAppProcessInfo> runningAppProcessList = activityManager.getRunningAppProcesses();
//		for(RunningAppProcessInfo runningAppProcess : runningAppProcessList)
//		{
//			int pid = runningAppProcess.pid;
//			String processName = runningAppProcess.processName;			
//			// try to fetch application info from process name
//			ApplicationInfo applicationInfo = getApplicationInfo(processName);
//			if(applicationInfo == null) {
//				/*
//				 *  fail to fetch the application info from the process name
//				 *  then try with pkgname
//				 */				
//				 String[] packages = runningAppProcess.pkgList;
//				 applicationInfo = getApplicationInfo(packages[0]);
//			}
//			// application info found
//			if(applicationInfo != null)
//			{
//				 pidMap_ApplicationInfo.put(pid, applicationInfo);
//			}			
//		}
//		LogWrite.d(tag, "HashMap Size :"+pidMap_ApplicationInfo.size());
//	}
//	private void calculatePerAppUsage(boolean isToCalculateTotal)
//	{				
//		try 
//		{
//			Process process = Runtime.getRuntime().exec("top -d 1 -n 1");
//			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
//			String line = null;	
//			process.waitFor();
//			while ((line = reader.readLine().trim().toLowerCase()) != null)
//			{				
//				LogWrite.d(tag,"Line :"+line);
//				if (line.length() == 0)
//				{
//					continue;
//				}
//				else if(line.startsWith("user"))
//				{
//					if(isToCalculateTotal) {
//						total = calculateTotalUsage(line);
//					    break;						
//					}
//				}
//				else if(line.startsWith("pid"))
//				{
//					headerName = stringToArrayList(line);
//					for(int i=0 ; i<headerName.size() ; i++)
//						hashTable.put(headerName.get(i).toLowerCase(),i);
//				}
//				else
//				{
//					
//					if(countNumApps == numOfAppsRequire)
//						break;					
//					LogWrite.d(tag, "Work");
//					ArrayList<String> elements = stringToArrayList(line);	
//					
//					int pid = Integer.valueOf(elements.get(hashTable.get("pid")));
//					String processName = elements.get(elements.size()-1);
//					LogWrite.d(tag, "pid :"+pid);
//					
//					if(pidMap_ApplicationInfo.containsKey(pid))
//					{						
//						ApplicationInfo applicationInfo = pidMap_ApplicationInfo.get(pid);
//						KTApplicationInfo ktApplicationInfo = new KTApplicationInfo();
//						ktApplicationInfo.setPid(pid);
//						ktApplicationInfo.setProcessName(processName);
//						ktApplicationInfo.setIcon(getAppIcon(applicationInfo));
//						ktApplicationInfo.setAppName(getAppName(applicationInfo));
//						ktApplicationInfo.setUsage(elements.get(hashTable.get("cpu%")));
//						runningAppUsageInfo.add(ktApplicationInfo);
//						countNumApps++;
//					}
//				}
//			}
//		} 
//		catch (ExceptionDTO e)
//		{
//			LogWrite.d(tag,"ExceptionDTO..."+e);
//		}
//	}
//
//	private int calculateTotalUsage(String line)
//	{
//		int usage = 0;
//		String[] commaSplitedArrayOfLine = line.split(",");
//		for(String token : commaSplitedArrayOfLine)
//		{
//			token = token.toLowerCase().trim();			
//			if(token.startsWith("user") || token.startsWith("system"))
//			{
//				String[] spaceSplitedArrayOfToken = token.split(" ");
//				int lengthOfArray = spaceSplitedArrayOfToken.length;
//				String cpuUsageToken = spaceSplitedArrayOfToken[lengthOfArray-1].trim();				
//				int indexOfPercentage = cpuUsageToken.indexOf("%");
//				usage += Integer.parseInt(cpuUsageToken.substring(0, indexOfPercentage));
//			}
//		}
//		return usage;
//	}	
//	private ArrayList<String> stringToArrayList(String line)
//	{
//		ArrayList<String> arrayList = new ArrayList<String>();
//		String [] lineSplit = line.split(" ");			
//		for(int i=0;i<lineSplit.length;i++)
//		{
//			String token = lineSplit[i].trim();
//			if(token.length()>0)
//			{
//				token = token.toLowerCase();
//				arrayList.add(token);
//			}
//		}
//		return arrayList;
//	}	
//	private void resetTotalCPUsage()
//	{
//		total = 0;
//	}
//	private void resetPerAppUsage()	{
//		
//		runningAppUsageInfo.clear();		
//		countNumApps = 0;
//		hashTable.clear();
//	}
//}
//
