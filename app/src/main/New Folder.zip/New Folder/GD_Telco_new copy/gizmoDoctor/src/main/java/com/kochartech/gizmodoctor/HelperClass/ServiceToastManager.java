package com.kochartech.gizmodoctor.HelperClass;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.view.Display;

import com.kochartech.devicemax.Activities.LogWrite;

public class ServiceToastManager{
	
	private Activity activityContext;
	private boolean state = false;
//	private String singtelItem;
//	private SingtelItemAnalyzer singtelItemsAnalyzer;
//	private String deviceModel,brand,osVersion;
	private Timer timer;
	private Intent serviceIntent;
	private int timerCount;
//	private ActivityManager am;
	private String TAG = "ServiceToastManager";
	private boolean isServiceToastStarted = false;
	private String message;
	private int bottomMargin =0;
//	private DataSourceVarientSettings2 dataSource;
//	private Hashtable<String,String> dbSettingHash = new Hashtable<String, String>();
	public ServiceToastManager(Activity activityContext, String message) {
		 this.activityContext = activityContext;
		 this.message = message;
//		 this.singtelItem = singtelItem;		 
//		 dataSource = new DataSourceVarientSettings2(activityContext);
		 
//		 deviceModel = DeviceInfo.getModel();
//		 brand = DeviceInfo.getBrand();
//		 osVersion = DeviceInfo.getOSVersion();
		 
//		 singtelItemsAnalyzer = new SingtelItemAnalyzer(activityContext);
	
		 serviceIntent = new Intent(activityContext, ServiceToast.class);
//		 am = (ActivityManager) activityContext.getSystemService(Context.ACTIVITY_SERVICE);	 
		 bottomMargin = (20*getDisplayHeight())/100;	
	}
	
	
	
	public void showToast() {
		timerCount = 0;
		timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				
				LogWrite.d(TAG, "Manager is Running");
				if(state == false)
				{					
					activityContext.stopService(serviceIntent);
				    timer.cancel();				    
				}
				else
				{
					if(timerCount == 20)
					{
						activityContext.stopService(serviceIntent);
						timer.cancel();	
						return;
					}
					timerCount++;
					if(!isServiceToastStarted){
						LogWrite.d(TAG, "Service Started");
						isServiceToastStarted = true;
						
//						ToastInfo toastInfo = getServiceToastInfo();
						serviceIntent.putExtra(ServiceToast.KEY_MESSAGETODISAPLY, message);
//						serviceIntent.putExtra(ServiceToast.KEY_Gravity, Gravity.BOTTOM);
						serviceIntent.putExtra(ServiceToast.KEY_YCoordinate, bottomMargin);
						activityContext.startService(serviceIntent);	
					}
					
				} 					
			}
		}, 1000,500);
	}
	
	
	public void cancel(){
		
		state = false;
	}
	public void setToastVisibility(boolean state)
	{
		this.state=state;	
	}	
	
//	private boolean isSettingMessageInDB() {		
//		
//		dbSettingHash.clear();
//		String handsetId = dataSource.getHandsetId(deviceModel);
//		if(handsetId != null) {
//			String dbSettingMessage = dataSource.getMessage(handsetId, singtelItem, osVersion).trim();
//			if(dbSettingMessage.length()>0)
//			{
//				String[] splitMessage = dbSettingMessage.split("::");
//				for(String message : splitMessage) {
//					String[] keyValuePair =  message.split(":");
//					if(keyValuePair.length == 2) {
//						dbSettingHash.put(keyValuePair[0].trim(), keyValuePair[1].trim());
//					}			
//				}
//				return true;
//			}
//		}
//		return false;				
//	}
	
	
//	private ToastInfo getServiceToastInfo()
//	{
//		ToastInfo toastInfo = new ToastInfo();
//		// check is Setting Exsists in DB
//		boolean  isMesageInDB = isSettingMessageInDB();		
//		Logger.d(TAG,"isMesageInDB: "+isMesageInDB);
//		
//		String messageToDisplay = "";
//		if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.MobileDATA))
//		{
//			boolean mobileDataStatus = singtelItemsAnalyzer.isMobileDataOn();
//			if(mobileDataStatus)
//			{
//					if(isMesageInDB) 
//					{
//						if(dbSettingHash.containsKey(MOBILE_DATA_OK_KEY)) 
//						{
//							messageToDisplay = dbSettingHash.get(MOBILE_DATA_OK_KEY);
//						}
//					}
//					else 
//					{
//						messageToDisplay = ServiceToastManager.MOBILE_DATA_OK;
//					}					
//			}
//			else
//			{
//				if(isMesageInDB) 
//				{
//					if(dbSettingHash.containsKey(MOBILE_DATA_WRONG_KEY)) 
//					{
//						messageToDisplay = dbSettingHash.get(MOBILE_DATA_WRONG_KEY);
//					}
//				}
//				else
//				{
//					messageToDisplay = ServiceToastManager.MOBILE_DATA_WRONG;
//				}
//			}
//			toastInfo.setBottomMargin(bottomMargin);
//			toastInfo.setGravity(Gravity.BOTTOM);
//			toastInfo.setMessageToDisplay(messageToDisplay);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.DataRomaing))
//		{			
//			try
//			{
//				/*
//				 *  if data roaming on 
//				 *  	then it is ok
//				 *  else
//				 *  	if Roaming network 
//				 *  		then wrong
//				 *  	else
//				 *  		ok
//				 */
//				
//				if(Settings.Secure.getInt(activityContext.getContentResolver(), Settings.Secure.DATA_ROAMING) == 1) 
//				{
//					if(isMesageInDB) 
//					{
//						if(dbSettingHash.containsKey(ServiceToastManager.DATAROAMING_OK_KEY)) 
//						{
//							messageToDisplay = dbSettingHash.get(ServiceToastManager.DATAROAMING_OK_KEY);
//						}
//					}
//					else
//					{
//						messageToDisplay = ServiceToastManager.DATAROAMING_OK;
//					}
//				}
//				else
//				{
//					// Roaming Network
//					if(Operator.networkRoaming(activityContext))
//					{
//						if(isMesageInDB) 
//						{
//							if(dbSettingHash.containsKey(ServiceToastManager.DATAROAMING_WRONG_KEY)) 
//							{
//								messageToDisplay = dbSettingHash.get(ServiceToastManager.DATAROAMING_WRONG_KEY);
//							}
//						}
//						else
//						{
//							messageToDisplay = ServiceToastManager.DATAROAMING_WRONG;
//						}
//					}
//					else // Home Network
//					{
//						if(isMesageInDB) 
//						{
//							if(dbSettingHash.containsKey(ServiceToastManager.DATAROAMING_OK_KEY)) 
//							{
//								messageToDisplay = dbSettingHash.get(ServiceToastManager.DATAROAMING_OK_KEY);
//							}
//						}
//						else
//						{
//							messageToDisplay = ServiceToastManager.DATAROAMING_OK;
//						}						
//					}							
//				}			
//			}
//			catch (ExceptionDTO e)
//			{
//			}
//			
//			toastInfo.setBottomMargin(bottomMargin);
//			toastInfo.setGravity(Gravity.BOTTOM);
//			toastInfo.setMessageToDisplay(messageToDisplay);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.APN))
//		{
//			    boolean isToChangeIcon = false;
//				if(APNReader.getInstance(activityContext).isPreferAPNOk())
//				{
//					if(isMesageInDB) 
//					{
//						if(dbSettingHash.containsKey(APN_OK_KEY)) 
//						{
//							messageToDisplay = dbSettingHash.get(APN_OK_KEY);
//						}
//					}
//					else 
//					{
//						messageToDisplay = ServiceToastManager.APN_OK;
//					}
//					
//				}
//				else if(APNReader.getInstance(activityContext).isAPNExsist())
//				{
//					if(isMesageInDB) 
//					{
//						if(dbSettingHash.containsKey(APN_WRONG_SELECTED_KEY)) 
//						{
//							messageToDisplay = dbSettingHash.get(APN_WRONG_SELECTED_KEY);
//						}
//					}
//					else
//					{
//						messageToDisplay = ServiceToastManager.APN_WRONG_SELECTED;
//					}
//					
//				}
//				else
//				{
//					isToChangeIcon = true;
//					if(isMesageInDB) 
//					{
//						if(dbSettingHash.containsKey(APN_NOTAT_ALL_KEY)) 
//						{
//							messageToDisplay = dbSettingHash.get(APN_NOTAT_ALL_KEY);
//						}
//					}
//					else
//					{
//						messageToDisplay = ServiceToastManager.APN_NOTAT_ALL;
//					}
//					
//				}
//				
//				toastInfo.setBottomMargin(bottomMargin);
//				toastInfo.setGravity(Gravity.BOTTOM);
//				toastInfo.setMessageToDisplay(messageToDisplay);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.Wifi))
//		{
//			if(singtelItemsAnalyzer.isWifiOnAndConnected()) 
//			{
//				if(isMesageInDB) 
//				{
//					if(dbSettingHash.containsKey(WIFI_OK_KEY)) 
//					{
//						messageToDisplay = dbSettingHash.get(WIFI_OK_KEY);
//					}
//				}
//				else
//				{
//					messageToDisplay = ServiceToastManager.WIFI_OK;
//				}
//				
//			}
//			else if(MyWifiManager.isWifiEnabled(activityContext)) 
//			{
//				if(isMesageInDB) 
//				{
//					if(dbSettingHash.containsKey(WIFI_ON_Not_Connected_KEY)) 
//					{
//						messageToDisplay = dbSettingHash.get(WIFI_ON_Not_Connected_KEY);
//					}
//				}
//				else
//				{
//					messageToDisplay = ServiceToastManager.WIFI_ON_Not_Connected;
//				}
//				
//			}
//			else 
//			{
//				if(isMesageInDB) 
//				{
//					if(dbSettingHash.containsKey(WIFI_OFF_KEY)) 
//					{
//						messageToDisplay = dbSettingHash.get(WIFI_OFF_KEY);
//					}
//				}
//				else
//				{
//					messageToDisplay = ServiceToastManager.WIFI_OFF;
//				}
//				
//			}
//			
//			
//			toastInfo.setBottomMargin(0);
//			toastInfo.setGravity(Gravity.CENTER);
//			toastInfo.setMessageToDisplay(messageToDisplay);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.AirplaneMode))
//		{
//			if(singtelItemsAnalyzer.isFlightModeOn())
//			{				
//				//Samsung Galaxy Note EDGE
//				if(deviceModel.equalsIgnoreCase("SM-N915A"))
//				{
//					messageToDisplay = ServiceToastManager.FLIGHT_MODE_ON_SamsungGalaxyNoteEdge;
//				}
//				else if(isMesageInDB) 
//				{
//					if(dbSettingHash.containsKey(FLIGHT_MODE_WRONG_KEY)) 
//					{
//						messageToDisplay = dbSettingHash.get(FLIGHT_MODE_WRONG_KEY);
//					}
//				}
//				else 
//				{
//					messageToDisplay = ServiceToastManager.FLIGHT_MODE_WRONG;
//				}
//				
//			}
//			else
//			{
//				if(deviceModel.equalsIgnoreCase("SM-N915A"))
//				{
//					messageToDisplay = ServiceToastManager.FLIGHT_MODE_OFF_SamsungGalaxyNoteEdge;
//				}
//				else if(isMesageInDB) 
//				{
//					if(dbSettingHash.containsKey(FLIGHT_MODE_OK_KEY)) 
//					{
//						messageToDisplay = dbSettingHash.get(FLIGHT_MODE_OK_KEY);
//					}
//				}
//				else
//				{
//					messageToDisplay = ServiceToastManager.FLIGHT_MODE_OK;
//				}
//			}
//			
//			toastInfo.setBottomMargin(bottomMargin);
//			toastInfo.setGravity(Gravity.BOTTOM);
//			toastInfo.setMessageToDisplay(messageToDisplay);
//		}
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.RAM))
//		{
//			messageToDisplay = ServiceToastManager.MEMORY;
//			toastInfo.setBottomMargin(0);
//			toastInfo.setGravity(Gravity.TOP);
//			toastInfo.setMessageToDisplay(messageToDisplay);
//		}		
//		else if(singtelItem.equalsIgnoreCase(DiagnoseSingtelItems.OperatorSelection))
//		{
//			messageToDisplay = ServiceToastManager.OperatorSelection;
//			toastInfo.setBottomMargin(bottomMargin);
//			toastInfo.setGravity(Gravity.BOTTOM);
//			toastInfo.setMessageToDisplay(messageToDisplay);
//		}
//		
//		
//		return toastInfo;
//	}
//   
//	class ToastInfo {
//		private String messageToDisplay;
//		private int gravity;
//		private int bottomMargin;
//		public String getMessageToDisplay() {
//			return messageToDisplay;
//		}
//		public void setMessageToDisplay(String messageToDisplay) {
//			this.messageToDisplay = messageToDisplay;
//		}
//		public int getGravity() {
//			return gravity;
//		}
//		public void setGravity(int gravity) {
//			this.gravity = gravity;
//		}
//		public int getBottomMargin() {
//			return bottomMargin;
//		}
//		public void setBottomMargin(int bottomMargin) {
//			this.bottomMargin = bottomMargin;
//		}		
//	}
	
	private int getDisplayHeight() {
		 if(android.os.Build.VERSION.SDK_INT>=13)
		 {
				Display display = activityContext.getWindowManager().getDefaultDisplay();
				Point size = new Point();
				display.getSize(size);
				return size.y;
		 }
		 else
		 {
			 return activityContext.getWindowManager().getDefaultDisplay().getHeight();
		 }
		
	}
	
}
