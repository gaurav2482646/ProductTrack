package com.kochartech.devicemax.APNPackage;
import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Telephony;

import com.kochartech.devicemax.Activities.LogWrite;

public class APNReader 
{
	private String tag = "APNReader";
	private final static Uri PREFERRED_APN_URI = Uri.parse("content://telephony/carriers/preferapn");
	private final static Uri APN_URI = Uri.parse("content://telephony/carriers/current");
	private final static String[] APN_PROJECTION = {Telephony.Carriers.APN};
	private static Cursor cursor = null;

	public static APNReader classInstance;
	public static APNReader getInstance(Context context)
	{
		if(classInstance==null)
			classInstance = new APNReader();		
		return classInstance;
		
	}
//	public APNReader(Context context)
//	{
//		
//	}
//	public boolean isPreferAPNOk()
//	{
//		preferAPN = getPreferAPN(context);
////		LogWrite.d(tag,"preferAPN..."+preferAPN);
////		LogWrite.d(tag,"PreferAPN = "+preferAPN);
//		if(preferAPN != null)
//		{
//			if(APN_TOMATCH.equalsIgnoreCase(preferAPN))
//				return true;
//		}
//		return false;
//	}
	public String getPreferAPN(Context context)
	{	
		String apn = null, apnName  = null;
		try 
		{
			cursor =SqliteWrapper.query(context,context.getContentResolver(), PREFERRED_APN_URI, APN_PROJECTION, null, null, null);
			if (cursor.moveToFirst())
			{
				   do
				   {
					   apn = cursor.getString(cursor.getColumnIndex(Telephony.Carriers.APN));
					   LogWrite.d(tag,"Preffered APN ..."+ apn);
				   }
				   while(cursor.moveToNext());				  
			}
			cursor.close();
		} 
		catch (Exception e)
		{
			LogWrite.d(tag,"Excepytion..."+e);
		}
		return apn;		   
	}
	public ArrayList<String> getAllAPN(Context context)
	{	
		String apn = null;
		ArrayList<String> apnList = new ArrayList<String>();
		try 
		{
			cursor =SqliteWrapper.query(context,context.getContentResolver(), APN_URI, APN_PROJECTION, null, null, null);
			if (cursor.moveToFirst())
			{
				do
				{
					apn = cursor.getString(cursor.getColumnIndex(Telephony.Carriers.APN));
					LogWrite.d(tag,"APN ..."+apn);
					apnList.add(apn);
				}
				while(cursor.moveToNext());				  
			}
			cursor.close();
		} 
		catch (Exception e)
		{
			LogWrite.d(tag,"ExceptionDTO..."+e);
		}
		return apnList;		   
	}
	
	
//	public boolean isAPNExsist()
//	{
//		//LogWrite.d(tag,"isAPNExsist Starts");
//		String apn = null;
//		try
//		{	cursor =SqliteWrapper.query(context,context.getContentResolver(), Uri.withAppendedPath(Telephony.Carriers.CONTENT_URI, "current"), APN_PROJECTION, null, null, null);
//			//LogWrite.d(tag,"ExceptionDTO.."+cursor.getCount());
//			if (cursor.moveToFirst())
//			{
//				   do
//				   {
//					   apn = cursor.getString(cursor.getColumnIndex(Telephony.Carriers.APN));
//					   //LogWrite.d(tag,"APN = "+apn);
//					   if(APN_TOMATCH.equalsIgnoreCase(apn))
//					   	   return true;
//				   }
//				   while(cursor.moveToNext());				   
//			}
//			cursor.close();
//		} 
//		catch (ExceptionDTO e)
//		{
//			//LogWrite.d(tag,"ExceptionDTO.."+e);
//		}		
//		return false;
//	}	
}
