package com.kochartech.devicemax.Receivers;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

import com.kochartech.devicemax.Activities.LogWrite;

public class StopTestReceiver extends BroadcastReceiver {
	String TAG = "StopTestReceiver";

	@Override
	public void onReceive(Context context, Intent intent) {
		LogWrite.d(TAG, "Stop Speed Test Called...");
		Intent startTestIntent = new Intent(context, StartTestReceiver.class);
		Intent stopTestIntent = new Intent(context, StopTestReceiver.class);
		
		SharedPreferences sharePerference = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
		Editor editor = sharePerference.edit();
		editor.putBoolean("enable",false);
		editor.commit();
		
		AlarmManager alarmManager = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
		PendingIntent pendingstartTestIntent = PendingIntent.getBroadcast(
				context.getApplicationContext(), 232324, startTestIntent, 0);
		PendingIntent pendingstopTestIntent = PendingIntent.getBroadcast(
				context.getApplicationContext(), 232324, stopTestIntent, 0);
		
		alarmManager.cancel(pendingstartTestIntent);
		alarmManager.cancel(pendingstopTestIntent);
		LogWrite.d(TAG, "Speed Test Cancelled");
		
		
	}
}