package com.kochartech.gizmodoctor.Adapter;

import android.content.Context;
import android.widget.ArrayAdapter;

public class Temp extends ArrayAdapter{

	public Temp(Context context, int resource) {
		super(context, resource);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
