package com.kochartech.gizmodoctor.HelperClass;

import android.content.Context;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.Preferences.Preference_NotificationManager;

public class NotificationCheckerManager {
	private String TAG = NotificationCheckerManager.class.getSimpleName();
	private Context context;
	private Preference_NotificationManager preferenceNotificationManager;
	private int count = 0;

	public NotificationCheckerManager(Context context) {
		this.context = context;
		preferenceNotificationManager = new Preference_NotificationManager(
				context);
	}

	public void checkNotifications() {
		LogWrite.d(TAG, "checkNotifications");
		count = preferenceNotificationManager.getCount();
		LogWrite.d(TAG, "count:" + count);
		if (isToNotify()) {

			LogWrite.d(TAG, "Notify: Yes");
			preferenceNotificationManager.setDiagnoseTime(System
					.currentTimeMillis());

			// check notifications
			NotificationsChecker checkBatteryNotification = new NotificationsChecker(
					context);
			checkBatteryNotification.check();

			// work on power saving profile
			PowerSaver powerSaver = new PowerSaver(context);
			powerSaver.savePower(null, false);
		}
		if (count >= 5)
			count = 0;
		else
			count++;

		preferenceNotificationManager.setCount(count);
	}

	private boolean isToNotify() {
		if (count == 0)
			return true;
		else
			return false;
	}
}
