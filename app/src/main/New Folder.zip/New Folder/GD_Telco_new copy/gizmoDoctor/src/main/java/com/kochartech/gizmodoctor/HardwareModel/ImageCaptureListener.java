package com.kochartech.gizmodoctor.HardwareModel;

import java.io.File;

public interface ImageCaptureListener {
	public abstract void onImageCapture(File file, String reason);
}
