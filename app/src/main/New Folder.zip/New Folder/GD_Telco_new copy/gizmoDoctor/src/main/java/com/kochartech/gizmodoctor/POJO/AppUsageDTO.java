package com.kochartech.gizmodoctor.POJO;

public class AppUsageDTO implements Comparable {
	private int appUsage;
	private long usageTime;
	private String appUsageString;
	public AppUsageDTO() {

	}

	public AppUsageDTO(int appUsage, long usageTime) {
		this.appUsage = appUsage;
		this.usageTime = usageTime;
	}

	public AppUsageDTO(String appUsageString, long usageTime) {
		this.appUsageString = appUsageString;
		this.usageTime = usageTime;
	}
	
	public String getAppUsageString() {
		return appUsageString;
	}

	public void setAppUsageString(String appUsageString) {
		this.appUsageString = appUsageString;
	}
	
	public int getAppUsage() {
		return appUsage;
	}

	public void setAppUsage(int appUsage) {
		this.appUsage = appUsage;
	}

	public long getUsageTime() {
		return usageTime;
	}

	public void setUsageTime(long usageTime) {
		this.usageTime = usageTime;
	}

	// @Override
	// public int compareTo(AppUsageDTO another) {
	// double compareTime = ((AppUsageDTO) another).getUsageTime();
	//
	// // ascending order
	// // return (int) (this.salary - compareSalary);
	//
	// // descending order
	// return (int) (compareTime - this.usageTime);
	// }
	@Override
	public int compareTo(Object another) {
		double compareTime = ((AppUsageDTO) another).getUsageTime();

		// ascending order
		// return (int) (this.salary - compareSalary);

		// descending order
		return (int) (compareTime - this.usageTime);
	}

}
