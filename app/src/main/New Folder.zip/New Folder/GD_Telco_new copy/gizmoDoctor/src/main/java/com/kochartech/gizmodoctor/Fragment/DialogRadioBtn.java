package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.POJO.KeyValueDTO;
import com.kochartech.gizmodoctor.Preferences.MyPreference;

public class DialogRadioBtn implements OnClickListener {

	private View rootView;
	private RadioGroup radioBtnGroup;
	private ArrayList<KeyValueDTO> dataSetElements;

	private MyPreference myPreference;
	private KeyValueDTO preferenceKeyValue;
	private Button btnOk, btnCanel;
	private AlertDialog alert;

	public DialogRadioBtn(Activity activityContext, MyPreference preference,
			KeyValueDTO preferenceKeyValue, ArrayList<KeyValueDTO> dataSetElements, int titleId) {

		this.myPreference = preference;
		this.preferenceKeyValue = preferenceKeyValue;
		this.dataSetElements = dataSetElements;

		LayoutInflater inflater = (LayoutInflater) activityContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		rootView 				= inflater.inflate(R.layout.dialog_radiobtn, null, false);
		radioBtnGroup 			= (RadioGroup) rootView.findViewById(R.id.radioButtonGroup);
		btnOk 					= (Button) rootView.findViewById(R.id.ok);
		btnCanel 				= (Button) rootView.findViewById(R.id.cancel);
		
		((TextView)rootView.findViewById(R.id.title)).setText(activityContext.getResources().getString(titleId));
		registerOnClick(btnOk);
		registerOnClick(btnCanel);

		int numOfRadioButtons = radioBtnGroup.getChildCount();
		int numofElements 	  = dataSetElements.size();
		int currentSelectedIndex = getSelectedChildIndex();

		for (int i = 0; i < numOfRadioButtons; i++) {	
			RadioButton radioBtn = (RadioButton) radioBtnGroup.getChildAt(i);
			if (i < numofElements) {
				radioBtn.setText(dataSetElements.get(i).getKey());
				if(currentSelectedIndex == i)
					radioBtn.setChecked(true);
			}
			else
				radioBtn.setVisibility(View.GONE);
			
		}

		alert = new AlertDialog.Builder(activityContext).create();
		alert.setView(rootView);
		alert.show();

	}

	public int getSelectedChildIndex() {
		int index = -1;
		int preferenceValue = preferenceKeyValue.getValue();
		for(int i=0; i<dataSetElements.size(); i++) 
		{
			if(dataSetElements.get(i).getValue() == preferenceValue) {
				index = i; 
			}
		}
		return index;
	}
			
	private void registerOnClick(View view) {
		view.setOnClickListener(this); 
	}
	public void show() {

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ok) {
			
			int  radioBtnId    = radioBtnGroup.getCheckedRadioButtonId();
			View radioBtn     = radioBtnGroup.findViewById(radioBtnId);
			int  radioBtnIndex = radioBtnGroup.indexOfChild(radioBtn);
			if(radioBtnIndex != -1) {
				myPreference.setKeyValue(preferenceKeyValue.getKey(), dataSetElements.get(radioBtnIndex).getValue());
			}
			alert.dismiss();
			GUISetNotification.refreshView();
		}
		else if(v.getId() == R.id.cancel) {
		
			alert.dismiss();
		}

	}
	


}
