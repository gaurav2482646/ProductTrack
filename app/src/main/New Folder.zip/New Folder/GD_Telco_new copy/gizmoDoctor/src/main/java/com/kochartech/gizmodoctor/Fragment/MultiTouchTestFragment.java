package com.kochartech.gizmodoctor.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
import com.kochartech.gizmodoctor.HelperClass.ValueChangeListener;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;

public class MultiTouchTestFragment extends Fragment implements
		ValueChangeListener, OnClickListener, MyFragment {

	private String TAG = MultiTouchTestFragment.class.getSimpleName();
	private Context context;
	private View rootView;
	private TextView textView;

	private boolean isFromCommand = false;
	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
	private OnCommandListener onCommandListener;
	// private boolean isClickWork = false;
	private MultitouchView multitouchView;

	// private long ONE_MINUTE = 1 * 60 * 1000;
	// private boolean timeCompleteFlag = false;
	// private long current_time = 0;
	private boolean flag = false;
	// private Button okButton;
	private CircularProgressBar timerProgress;

	private boolean success = false;
	private String FAILURE_MESSAGE = "Multitouch test fails.";

	private boolean backFlag = false;
	private OnAutoHardwareTestListener onAutoHardwareTestListener;

	public MultiTouchTestFragment(OnCommandListener onCommandListener) {
		this.onCommandListener = onCommandListener;
	}

	public void setOnAutoHardwareTestListener(
			OnAutoHardwareTestListener onAutoHardwareTestListener) {
		this.onAutoHardwareTestListener = onAutoHardwareTestListener;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		LogWrite.d(TAG, "On Create Method Enters");
		initDataSet();
		LogWrite.d(TAG, "On Create Method Enters.......1");
		initUi(inflater, container);
		LogWrite.d(TAG, "On Create Method Enters.......2");
		// try {
		// TestTouchAsync async = new TestTouchAsync();
		// async.execute("");
		// } catch (ExceptionDTO e) {
		// LogWrite.e(TAG, "AsyncException : " + e.toString());
		// }
		return rootView;
	}

	// @Override
	// public void onResume() {
	// try {
	// TestTouchAsync async = new TestTouchAsync();
	// async.execute("");
	// } catch (ExceptionDTO e) {
	// LogWrite.e(TAG, "AsyncException : " + e.toString());
	// }
	// super.onResume();
	// }

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		Bundle bundle = getArguments();
		if (bundle != null) {
			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
			}

		}
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {
		context = getActivity().getApplicationContext();
		rootView = inflater
				.inflate(R.layout.multi_touch_view, container, false);
		multitouchView = (MultitouchView) rootView
				.findViewById(R.id.multi_touch_view);
		textView = (TextView) rootView.findViewById(R.id.textView);
		textView.setText(R.string.multi_touch_screen);

		// okButton = (Button) rootView.findViewById(R.id.ok_button);
		// okButton.setOnClickListener(this);
		timerProgress = (CircularProgressBar) rootView
				.findViewById(R.id.circularprogressbar2);
		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {
			@Override
			public void onAnimationStart() {
			}

			@Override
			public void onAnimationProgress(int progress) {
				timerProgress.setTitle(progress + "");
				timerProgress.setSubTitle("");
			}

			@Override
			public void onAnimationFinish() {
				if (!success) {
					if (!backFlag) {
						textView.setText(FAILURE_MESSAGE);
						textView.setTextAppearance(context,
								R.style.textStyleRed);
						timerProgress.setSubTitle("");
						timerProgress.setVisibility(View.GONE);
						// okButton.setVisibility(View.VISIBLE);

						if (HardwareTestFragment.isAutoStartClicked) {
							onAutoHardwareTestListener.onHardwareTestFinish(6,
									"Multitouch Sensor", false);
							getActivity().getSupportFragmentManager()
									.beginTransaction()
									.remove(MultiTouchTestFragment.this)
									.commit();
							getActivity().getFragmentManager().popBackStack();
						}
						if (isFromCommand) {
							LogWrite.i(TAG, "Is From Command");
							onCommandListener.onCommand(false);
							FragmentListener fragmentListener = (FragmentListener) getActivity();
							fragmentListener.onItemClicked(
									FragmentListener.actionRemove,
									MultiTouchTestFragment.this);
						}
					}
				}
			}
		});

		multitouchView.setValueChangeListener(this);
	}

	@Override
	public void onDetach() {
		backFlag = true;
		super.onDetach();
	}

	@Override
	public void onDestroy() {
		LogWrite.d(TAG, "onDestroy is working...");
		super.onDestroy();
		// if (onCommandListener != null) {
		// onCommandListener.onCommand(isClickWork);
		// }
	}

	@Override
	public void onValueChange(int value) {
		LogWrite.e(TAG, "Current Value : " + value);
		if (value >= 2) {
			if (!flag) {
				try {
					Vibrator vibrator = (Vibrator) context
							.getSystemService(Context.VIBRATOR_SERVICE);
					vibrator.vibrate(500);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				textView.setText(R.string.multi_touch_is_working_fine);
				textView.setTextAppearance(getActivity(),
						R.style.textStyleGreen);
				success = true;
				timerProgress.setVisibility(View.GONE);
				if (HardwareTestFragment.isAutoStartClicked) {
					onAutoHardwareTestListener.onHardwareTestFinish(6,
							"Multitouch Sensor", true);
					getActivity().getSupportFragmentManager()
							.beginTransaction()
							.remove(MultiTouchTestFragment.this).commit();
					getActivity().getFragmentManager().popBackStack();
				}

				if (isFromCommand) {
					LogWrite.i(TAG, "Is From Command");
					onCommandListener.onCommand(true);
					FragmentListener fragmentListener = (FragmentListener) getActivity();
					fragmentListener.onItemClicked(
							FragmentListener.actionRemove,
							MultiTouchTestFragment.this);
				}
				// isClickWork = true;
				flag = true;
			}
		}
	}

	@Override
	public void onClick(View v) {
		// if (v.getId() == R.id.ok_button) {
		// Vibrator vibrator = (Vibrator) context
		// .getSystemService(Context.VIBRATOR_SERVICE);
		// vibrator.vibrate(500);
		// textView.setText("Multitouch test fails.");
		// if (isFromCommand) {
		// onCommandListener.onCommand(false);
		// FragmentListener fragmentListener = (FragmentListener) getActivity();
		// fragmentListener.onItemClicked(FragmentListener.actionRemove,
		// this);
		// }
		// okButton.setVisibility(View.GONE);
		// }
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "MultiTouch Sensor";
	}
}
// private class TestTouchAsync extends AsyncTask<String, String, String> {
//
// @Override
// protected synchronized String doInBackground(String... params) {
// boolean status = multitouchView.getStatus();
// LogWrite.d(TAG, "Multi Touch Status : " + status);
// while (!status) {
// LogWrite.d(TAG, "MultiTouch Not Working....");
// status = multitouchView.getStatus();
// LogWrite.d(TAG, "Multi Touch Status : " + status);
// sleep(1000);
// current_time += 2000;
// if (current_time > ONE_MINUTE) {
// timeCompleteFlag = true;
// break;
// }
// }
// // if (status)
// // publishProgress("");
// return null;
// }
//
// @Override
// protected void onPostExecute(String result) {
// if (!timeCompleteFlag) {
// LogWrite.i(TAG, "MultiTouch Working....");
// try {
// Vibrator vibrator = (Vibrator) context
// .getSystemService(Context.VIBRATOR_SERVICE);
// vibrator.vibrate(500);
// } catch (ExceptionDTO e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// textView.setText(R.string.multi_touch_is_working_fine);
// textView.setTextAppearance(getActivity(),
// R.style.textStyleGreen);
//
// if (isFromCommand) {
// LogWrite.i(TAG, "Is From Command");
// FragmentListener fragmentListener = (FragmentListener) getActivity();
// fragmentListener.onItemClicked(
// FragmentListener.actionRemove,
// MultiTouchTestFragment.this);
// }
// isClickWork = true;
// }
// super.onPostExecute(result);
// }
//
// // @Override
// // protected void onProgressUpdate(String... values) {
// // try {
// // Vibrator vibrator = (Vibrator) context
// // .getSystemService(Context.VIBRATOR_SERVICE);
// // vibrator.vibrate(500);
// // } catch (ExceptionDTO e) {
// // // TODO Auto-generated catch block
// // e.printStackTrace();
// // }
// // textView.setText(R.string.multi_touch_is_working_fine);
// // textView.setTextAppearance(getActivity(), R.style.textStyleGreen);
// //
// // if (isFromCommand) {
// // FragmentListener fragmentListener = (FragmentListener) getActivity();
// // fragmentListener.onItemClicked(FragmentListener.actionRemove,
// // MultiTouchTestFragment.this);
// // }
// // isClickWork = true;
// // super.onProgressUpdate(values);
// // }
//
// private void sleep(long time) {
// try {
// Thread.sleep(time);
// } catch (InterruptedException e) {
// e.printStackTrace();
// }
// }
//
// }

