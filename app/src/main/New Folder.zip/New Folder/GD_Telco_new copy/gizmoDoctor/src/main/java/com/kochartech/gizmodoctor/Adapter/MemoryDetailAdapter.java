package com.kochartech.gizmodoctor.Adapter;
//package com.kochartech.Adapter;
//
//import java.util.ArrayList;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.BaseAdapter;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.kochartech.POJO.AppInfo;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.library.Application.KTInformation;
//
//public class MemoryDetailAdapter extends BaseAdapter
//{
//	private Context context;
//	private ArrayList<KTInformation> ktInformationList;
//	private LayoutInflater inflator;
//	public MemoryDetailAdapter(Context context, ArrayList<KTInformation> ktInformationList)
//	{
//		this.context = context;
//		this.ktInformationList = ktInformationList;
//		inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//	}
//	@Override
//	public int getCount() {
//		// TODO Auto-generated method stub
//		return ktInformationList.size();
//	}
//
//	@Override
//	public Object getItem(int position) {
//		// TODO Auto-generated method stub
//		return ktInformationList.get(position);
//	}
//
//	@Override
//	public long getItemId(int position) {
//		// TODO Auto-generated method stub
//		return position;
//	}
//
//	@Override
//	public View getView(int position, View convertView, ViewGroup parent) {
//		// TODO Auto-generated method stub
//		
//		if(convertView == null) {
//			
//			convertView = inflator.inflate(R.layout.rowlayout_memorydetail, null);
//		}		
//		
//		KTInformation ktInformation = ktInformationList.get(position);
//
//		((ImageView)convertView.findViewById(R.id.icon)).setBackgroundDrawable(ktInformation.getAppIcon());
//		((TextView)convertView.findViewById(R.id.appname)).setText(ktInformation.getAppName());
//		((TextView)convertView.findViewById(R.id.appinfo)).setText("Hello :"+String.valueOf(ktInformation.getCodeSize()));
//		
//		return convertView;
//		
//	}
//
//}
