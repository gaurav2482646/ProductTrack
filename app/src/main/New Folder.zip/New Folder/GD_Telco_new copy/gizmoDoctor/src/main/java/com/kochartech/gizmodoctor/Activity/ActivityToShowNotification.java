//package com.kochartech.gizmodoctor.Activity;
//
//import android.app.Activity;
//import android.app.Notification;
//import android.app.Notification.Builder;
//import android.app.NotificationManager;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.Service.CountActivationPeriod;
//
//public class ActivityToShowNotification extends Activity {
//	
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_button);	
//	}
//	
//	public void onClick(View view) {		
//		if(view.getId() == R.id.start) {			
//			startService(new Intent(getApplicationContext(),CountActivationPeriod.class));
//		}
//		else if(view.getId() == R.id.stop) {
//			stopService(new Intent(getApplicationContext(),CountActivationPeriod.class));
//		}
//	}
//	
//
//}
