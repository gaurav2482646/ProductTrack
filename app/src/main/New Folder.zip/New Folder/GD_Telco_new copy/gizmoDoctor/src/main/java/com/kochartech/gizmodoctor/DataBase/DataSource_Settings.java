package com.kochartech.gizmodoctor.DataBase;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.POJO.DBSettingDTO;

/*
 *  it holds the name of the settings, that we monitoring
 *  column name:  SettingName, IsToMonitor, LastState
 *  
 */

public class DataSource_Settings {
	private String tag = "SettingToMonitor_DS";
	// private Context context;
	private MySQLiteOpenHelper mySQLiteOpenHelper;
	private SQLiteDatabase db;

	private final int lastStateOn = 1;
	private final int lastStateOff = 0;

	private String[] settingToMonitor = { "WiFi", "Bluetooth", "GPS",
			"WiFi hotspot" };
	private static DataSource_Settings classInstance = null;

	public static DataSource_Settings getInstance(Context context) {
		if (classInstance == null)
			classInstance = new DataSource_Settings(context);
		return classInstance;

	}

	private DataSource_Settings(Context context) {
		LogWrite.d(tag, "constructor");
		// this.context = context;
		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
	}

	private void open() {
		LogWrite.d(tag, "open");
		db = mySQLiteOpenHelper.getWritableDatabase();
	}

	private void close() {
		LogWrite.d(tag, "close");
		db.close();
	}

	public synchronized ArrayList<DBSettingDTO> getAllColumns() {
		open();
		ArrayList<DBSettingDTO> dbSettingDTOList = null;
		try {
			dbSettingDTOList = new ArrayList<DBSettingDTO>();
			Cursor cursor = db.query(
					MySQLiteOpenHelper.SettingToMonitor_TableName, null, null,
					null, null, null, null);
			LogWrite.d(tag, "cursor  size: " + cursor.getCount());
			if (cursor.getCount() > 0) {
				if (cursor.moveToFirst()) {

					int index_name = cursor
							.getColumnIndex(MySQLiteOpenHelper.SettingToMonitor_ColumnSettingName);
					int index_isToMonitor = cursor
							.getColumnIndex(MySQLiteOpenHelper.SettingToMonitor_ColumnIsToMonitor);
					int index_LastState = cursor
							.getColumnIndex(MySQLiteOpenHelper.SettingToMonitor_ColumnLastState);

					do {
						String name = cursor.getString(index_name);
						boolean isToMonitor = intToBool(cursor
								.getInt(index_isToMonitor));
						boolean lastState = intToBool(cursor
								.getInt(index_LastState));

						DBSettingDTO dbSettingDTO = new DBSettingDTO(name,
								isToMonitor, lastState);

						dbSettingDTOList.add(dbSettingDTO);

					} while (cursor.moveToNext());

				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		close();
		return dbSettingDTOList;
	}

	private boolean intToBool(int value) {
		return value == 1 ? true : false;
	}

	public synchronized void updateRow(String name, int state) {
		open();
		ContentValues values = new ContentValues();
		values.put(MySQLiteOpenHelper.SettingToMonitor_ColumnSettingName, name);
		values.put(MySQLiteOpenHelper.SettingToMonitor_ColumnIsToMonitor, state);
		long id = db.update(MySQLiteOpenHelper.SettingToMonitor_TableName,
				values, MySQLiteOpenHelper.SettingToMonitor_ColumnSettingName
						+ " =?", new String[] { name });

		LogWrite.d(tag, "updateRow() insert Id: " + id);

		close();
	}

	public synchronized void init(SQLiteDatabase db) {
		try {
			for (int i = 0; i < settingToMonitor.length; i++) {
				ContentValues values = new ContentValues();
				values.put(
						MySQLiteOpenHelper.SettingToMonitor_ColumnSettingName,
						settingToMonitor[i]);
				values.put(
						MySQLiteOpenHelper.SettingToMonitor_ColumnIsToMonitor,
						lastStateOn);
				values.put(MySQLiteOpenHelper.SettingToMonitor_ColumnLastState,
						lastStateOff);
				long id = db.insertOrThrow(
						MySQLiteOpenHelper.SettingToMonitor_TableName, null,
						values);
				LogWrite.d(tag, "init() insert Id: " + id);
			}
		} catch (Exception e) {
			LogWrite.d(tag, "ExceptionDTO..." + e);
		}
	}

	public synchronized void updateTheLastState(String settingName,
			int lastState) {
		open();
		ContentValues values = new ContentValues();
		values.put(MySQLiteOpenHelper.SettingToMonitor_ColumnLastState,
				lastState);
		db.update(MySQLiteOpenHelper.SettingToMonitor_TableName, values,
				MySQLiteOpenHelper.SettingToMonitor_ColumnSettingName + " =?",
				new String[] { settingName });
		close();
	}

}
