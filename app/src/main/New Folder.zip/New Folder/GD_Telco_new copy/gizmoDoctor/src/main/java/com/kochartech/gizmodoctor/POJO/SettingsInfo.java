package com.kochartech.gizmodoctor.POJO;

public class SettingsInfo 
{
	private String  name;
	private boolean isToMonitor;
	
	public SettingsInfo()
	{
		
	}
	public SettingsInfo(String name,boolean isToMonitor)
	{
		this.name = name;
		this.isToMonitor = isToMonitor;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isToMonitor() {
		return isToMonitor;
	}
	public void setToMonitor(boolean isToMonitor) {
		this.isToMonitor = isToMonitor;
	}
	
	
}
