//package com.kochartech.gizmodoctor.HelperClass;
//
//import android.app.Service;
//import android.bluetooth.BluetoothAdapter;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.database.Cursor;
//import android.location.LocationManager;
//import android.net.wifi.WifiManager;
//import android.os.IBinder;
//import android.util.Log;
//
//import com.kochartech.gizmodoctor.DataBase.DBHelperDataSettingsToMonitor;
//import com.kochartech.gizmodoctor.DataBase.MySQLiteOpenHelper;
//import com.kochartech.gizmodoctor.DataBase.SettingToMonitor_DS;
//import com.kochartech.library.Device.KTInformation;
//
//public class SettingsMonitorService extends Service implements
//		android.location.GpsStatus.Listener {
//	private String tag = "SettingsMonitorService";
//	private Context context;
//	IntentFilter filter;
//	SettingChangeListener listener;
//	private DBHelperDataSettingsToMonitor dbHelperSettingsToMonitor;
//
//	@Override
//	public void onCreate() {
//		// TODO Auto-generated method stub
//		super.onCreate();
//
//		LogWrite.d(tag, "onCreate Work");
//		context = this;
//		// Intent.AC
//		filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
//		filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
//		filter.addAction("android.location.PROVIDERS_CHANGED");
//
//		listener = new SettingChangeListener();
//
//		getApplicationContext().registerReceiver(listener, filter);
//
//		LocationManager locationManager = (LocationManager) getApplicationContext()
//				.getSystemService(Context.LOCATION_SERVICE);
//		locationManager.addGpsStatusListener(this);
//
//		dbHelperSettingsToMonitor = DBHelperDataSettingsToMonitor
//				.getInstance(getApplicationContext());
//		dbHelperSettingsToMonitor.open();
//
//		SettingToMonitor_DS settingToMonitor = SettingToMonitor_DS
//				.getInstance(context);
//
//		DBHelperDataSettingsToMonitor dbHelperDataSettingsToMonitor = DBHelperDataSettingsToMonitor
//				.getInstance(context);
//		Cursor cursor = settingToMonitor.getAllColumns();
//		if (cursor.getCount() > 0) {
//			if (cursor.moveToFirst()) {
//				do {
//					int indexOfColumnSettingName = cursor
//							.getColumnIndex(MySQLiteOpenHelper.SettingToMonitor_ColumnSettingName);
//					String settingName = cursor
//							.getString(indexOfColumnSettingName);
//
//					boolean state = getSettingsOnOffState(settingName);
//
//					if (state) {
//						dbHelperDataSettingsToMonitor.insertEntry(settingName);
//					}
//				} while (cursor.moveToNext());
//			}
//		}
//	}
//
//	@Override
//	public int onStartCommand(Intent intent, int flags, int startId) {
//		// TODO Auto-generated method stub
//		LogWrite.d(tag, "onStartCommand Work");
//		return START_STICKY;
//	}
//
//	@Override
//	public IBinder onBind(Intent intent) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public void onGpsStatusChanged(int arg0) {
//		// TODO Auto-generated method stub
//
//		LogWrite.d(tag, "***********************");
//		// Toast.makeText(getApplicationContext(),"GPS State: "+arg0,
//		// Toast.LENGTH_LONG).show();
//	}
//
//	public boolean getSettingsOnOffState(String settingName) {
//		KTInformation ktDeviceInfo = new KTInformation(context);
//		if (settingName.equalsIgnoreCase("WiFi")) {
//			return ktDeviceInfo.isWifiEnabled();
//		} else if (settingName.equalsIgnoreCase("Bluetooth")) {
//			return ktDeviceInfo.isBluetoothEnabled();
//		} else if (settingName.equalsIgnoreCase("Gps")) {
//			return ktDeviceInfo.isGPSEnabled();
//		} else if (settingName.equalsIgnoreCase("MobileData")) {
//			return ktDeviceInfo.isMobileDataEnabled();
//		}
//		return false;
//	}
//
//}
