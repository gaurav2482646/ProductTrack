package com.kochartech.gizmodoctor.Activity;

import java.util.ArrayList;
import java.util.Random;

import com.kochartech.gizmodoctor.R;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;


@SuppressLint("ClickableViewAccessibility")
@SuppressWarnings("deprecation")
@TargetApi(Build.VERSION_CODES.KITKAT)
public class DisplayTestActivity extends Activity implements // OnTouchListener,
		OnClickListener {
	private String TAG = DisplayTestActivity.class.getSimpleName();

	private Context context;

	private LinearLayout view1, view2, view3, view4;

	private LinearLayout dotView1Layout1, dotView1Layout2, dotView1Layout3,
			dotView1Layout4;
	private LinearLayout dotView2Layout1, dotView2Layout2, dotView2Layout3,
			dotView2Layout4;
	private LinearLayout dotView3Layout1, dotView3Layout2, dotView3Layout3,
			dotView3Layout4;

	private ImageView dotView1ImageView1, dotView1ImageView2,
			dotView1ImageView3;
	private ImageView dotView2ImageView1, dotView2ImageView2,
			dotView2ImageView3;
	private ImageView dotView3ImageView1, dotView3ImageView2,
			dotView3ImageView3;

	private int view1MinHeight, view1MinWidth;
	private int view1MaxHeight, view1MaxWidth;
	private int view2MinHeight, view2MinWidth;
	private int view2MaxHeight, view2MaxWidth;
	private int view3MinHeight, view3MinWidth;
	private int view3MaxHeight, view3MaxWidth;
	private int view4MinHeight, view4MinWidth;
	private int view4MaxHeight, view4MaxWidth;

	private ArrayList<TouchItem> arrayList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display);
		try {
			View decorView = getWindow().getDecorView();
			// Hide both the navigation bar and the status bar.
			// SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and
			// higher, but as
			// a general rule, you should design your app to hide the status bar
			// whenever you
			// hide the navigation bar.
			int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
					| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			decorView.setSystemUiVisibility(uiOptions);
		} catch (Exception e) {
			e.printStackTrace();
		}
		context = this;
		Display d = getWindowManager().getDefaultDisplay();

		DisplayMetrics realDisplayMetrics = new DisplayMetrics();
		d.getRealMetrics(realDisplayMetrics);

		int screenHeight = realDisplayMetrics.heightPixels;
		int screenWidth = realDisplayMetrics.widthPixels;

		Log.i(TAG, "ScreenWidth X ScreenHeight  = " + screenWidth + " X "
				+ screenHeight);

		view1MinHeight = 0;
		view1MaxHeight = screenHeight / 2;
		view1MinWidth = 0;
		view1MaxWidth = screenWidth / 2;
		Log.e(TAG, "------------------------------");
		Log.d(TAG, "View1MinHeight : " + view1MinHeight);
		Log.d(TAG, "View1MaxHeight : " + view1MaxHeight);
		Log.d(TAG, "View1MinWidth : " + view1MinWidth);
		Log.d(TAG, "View1MaxWidth : " + view1MaxWidth);
		view2MinHeight = 0;
		view2MaxHeight = screenHeight / 2;
		view2MinWidth = screenWidth / 2;
		view2MaxWidth = screenWidth;
		Log.e(TAG, "------------------------------");
		Log.d(TAG, "View2MinHeight : " + view2MinHeight);
		Log.d(TAG, "View2MaxHeight : " + view2MaxHeight);
		Log.d(TAG, "View2MinWidth : " + view2MinWidth);
		Log.d(TAG, "View2MaxWidth : " + view2MaxWidth);
		view3MaxHeight = screenHeight;
		view3MinHeight = screenHeight / 2;
		view3MinWidth = 0;
		view3MaxWidth = screenWidth / 2;
		Log.e(TAG, "------------------------------");
		Log.d(TAG, "View3MinHeight : " + view3MinHeight);
		Log.d(TAG, "View3MaxHeight : " + view3MaxHeight);
		Log.d(TAG, "View3MinWidth : " + view3MinWidth);
		Log.d(TAG, "View3MaxWidth : " + view3MaxWidth);
		view4MinHeight = screenHeight / 2;
		view4MaxHeight = screenHeight;
		view4MinWidth = screenWidth / 2;
		view4MaxWidth = screenWidth;
		Log.e(TAG, "------------------------------");
		Log.d(TAG, "View4MinHeight : " + view4MinHeight);
		Log.d(TAG, "View4MaxHeight : " + view4MaxHeight);
		Log.d(TAG, "View4MinWidth : " + view4MinWidth);
		Log.d(TAG, "View4MaxWidth : " + view4MaxWidth);

		view1 = (LinearLayout) findViewById(R.id.view1);
		view2 = (LinearLayout) findViewById(R.id.view2);
		view3 = (LinearLayout) findViewById(R.id.view3);
		view4 = (LinearLayout) findViewById(R.id.view4);

		dotView1Layout1 = (LinearLayout) findViewById(R.id.view1dotLayout1);
		dotView1Layout2 = (LinearLayout) findViewById(R.id.view1dotLayout2);
		dotView1Layout3 = (LinearLayout) findViewById(R.id.view1dotLayout3);

		dotView1ImageView1 = (ImageView) findViewById(R.id.view1dot1);
		dotView1ImageView2 = (ImageView) findViewById(R.id.view1dot2);
		dotView1ImageView3 = (ImageView) findViewById(R.id.view1dot3);

		// dotView1ImageView1.setOnTouchListener(this);
		// dotView1ImageView2.setOnTouchListener(this);
		// dotView1ImageView3.setOnTouchListener(this);

		dotView1Layout1.setOnClickListener(this);
		dotView1Layout2.setOnClickListener(this);
		dotView1Layout3.setOnClickListener(this);

		view1.setVisibility(View.VISIBLE);
		view2.setVisibility(View.INVISIBLE);
		view3.setVisibility(View.INVISIBLE);
		view4.setVisibility(View.INVISIBLE);

		arrayList = new ArrayList<TouchItem>();

		boolean whileFlag = true;
		for (int i = 0; i < 3; i++) {
			int y = getRandomNumber(50, view1MaxHeight);
			whileFlag = true;
			while (whileFlag) {
				Log.i(TAG, "While loop is working!");
				int diff = view1MaxHeight - y;
				Log.i(TAG, "Difference is " + diff + " ::: y is " + y
						+ " ::: view1MaxHeight is " + view1MaxHeight);
				if (diff > 310)
					whileFlag = false;
				else
					y = getRandomNumber(50, view1MaxHeight);
			}

			Log.d(TAG, "y-axis : " + y);
			if (i == 0) {
				MarginLayoutParams marginParams = (MarginLayoutParams) dotView1ImageView1
						.getLayoutParams();
				marginParams.setMargins(y, 0, 0, 0);
				TouchItem touchItem = new TouchItem();
				touchItem.setIndex(0);
				touchItem.setImageView(dotView1ImageView1);
				touchItem.setTouchStatus(false);
				arrayList.add(touchItem);
			} else if (i == 1) {
				MarginLayoutParams marginParams = (MarginLayoutParams) dotView1ImageView2
						.getLayoutParams();
				marginParams.setMargins(y, 0, 0, 0);
				TouchItem touchItem = new TouchItem();
				touchItem.setIndex(1);
				touchItem.setImageView(dotView1ImageView2);
				touchItem.setTouchStatus(false);
				arrayList.add(touchItem);
			} else if (i == 2) {
				MarginLayoutParams marginParams = (MarginLayoutParams) dotView1ImageView3
						.getLayoutParams();
				marginParams.setMargins(y, 0, 0, 0);
				TouchItem touchItem = new TouchItem();
				touchItem.setIndex(2);
				touchItem.setImageView(dotView1ImageView3);
				touchItem.setTouchStatus(false);
				arrayList.add(touchItem);
			}
		}
	}

	private int getRandomNumber(int min, int max) {
		Random r = new Random();
		int number = r.nextInt(max - min + 1) + min;
		return number;
	}

	@Override
	public void onClick(View view) {
		Log.e(TAG, "----------------OnClick----");
		switch (view.getId()) {
		case R.id.view1dotLayout1:
			if (isTopLeftPannelWorkingFine(arrayList)) {
				// view1.setVisibility(View.INVISIBLE);
				view2.setVisibility(View.VISIBLE);
			} else {
				for (int i = 0; i < arrayList.size(); i++) {
					TouchItem touchItem = arrayList.get(i);
					if (touchItem.getIndex() == 0) {
						touchItem.setTouchStatus(true);
						arrayList.add(0, touchItem);
						// dotView1ImageView1.setVisibility(View.INVISIBLE);
						dotView1ImageView1.setBackground(context.getResources()
								.getDrawable(R.drawable.sample_green));
						dotView1ImageView1.setClickable(false);
						break;
					}
				}
				if (isTopLeftPannelWorkingFine(arrayList)) {
					// view1.setVisibility(View.INVISIBLE);
					view2.setVisibility(View.VISIBLE);
				}
			}
			break;
		case R.id.view1dotLayout2:
			if (isTopLeftPannelWorkingFine(arrayList)) {
				// view1.setVisibility(View.INVISIBLE);
				view2.setVisibility(View.VISIBLE);
			} else {
				for (int i = 0; i < arrayList.size(); i++) {
					TouchItem touchItem = arrayList.get(i);
					if (touchItem.getIndex() == 1) {
						touchItem.setTouchStatus(true);
						arrayList.add(1, touchItem);
						// dotView1ImageView2.setVisibility(View.INVISIBLE);
						dotView1ImageView2.setBackground(context.getResources()
								.getDrawable(R.drawable.sample_green));
						dotView1ImageView2.setClickable(false);
						break;
					}
				}
				if (isTopLeftPannelWorkingFine(arrayList)) {
					// view1.setVisibility(View.INVISIBLE);
					view2.setVisibility(View.VISIBLE);
				}
			}
			break;
		case R.id.view1dotLayout3:
			if (isTopLeftPannelWorkingFine(arrayList)) {
				// view1.setVisibility(View.INVISIBLE);
				view2.setVisibility(View.VISIBLE);
			} else {
				for (int i = 0; i < arrayList.size(); i++) {
					TouchItem touchItem = arrayList.get(i);
					if (touchItem.getIndex() == 2) {
						touchItem.setTouchStatus(true);
						arrayList.add(2, touchItem);
						// dotView1ImageView3.setVisibility(View.INVISIBLE);
						dotView1ImageView3.setBackground(context.getResources()
								.getDrawable(R.drawable.sample_green));
						dotView1ImageView3.setClickable(false);
						break;
					}
				}
				if (isTopLeftPannelWorkingFine(arrayList)) {
					// view1.setVisibility(View.INVISIBLE);
					view2.setVisibility(View.VISIBLE);
				}
			}
			break;

		default:
			break;
		}

	}

	private boolean isTopLeftPannelWorkingFine(ArrayList<TouchItem> arrayList) {
		for (TouchItem touchItem : arrayList)
			if (!touchItem.isTouchStatus())
				return false;
		return true;
	}

	@SuppressWarnings("unused")
	private class TouchItem {
		private ImageView imageView;
		private boolean touchStatus = false;
		private int index = 0;

		public int getIndex() {
			return index;
		}

		public void setIndex(int index) {
			this.index = index;
		}

		public ImageView getImageView() {
			return imageView;
		}

		public void setImageView(ImageView imageView) {
			this.imageView = imageView;
		}

		public boolean isTouchStatus() {
			return touchStatus;
		}

		public void setTouchStatus(boolean touchStatus) {
			this.touchStatus = touchStatus;
		}

	}

}
