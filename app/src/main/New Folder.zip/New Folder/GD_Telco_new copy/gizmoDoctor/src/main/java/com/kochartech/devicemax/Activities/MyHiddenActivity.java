package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;

public class MyHiddenActivity extends Activity {
	private String tag = "MyHiddenActivity";
	int width = 0, height = 0;
	private boolean isActivityShown = false;
	private Activity activity;
	private String commandID;
	static String commandID_TAG = "commandID";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		isActivityShown = true;
		activity = this;
		// dialog = new Dialog(this);
		// dialog.setTitle(R.string.PackageAdded_dialog_lable);
		commandID = getIntent().getStringExtra(commandID_TAG);
		MDMMainActivity.longAsyncFlag = false;
		setContentView(R.layout.remote_dialog_activity_layout);
		Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE))
				.getDefaultDisplay();
		height = display.getHeight();
		width = display.getWidth();

		((Button) findViewById(R.id.cancel))
				.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						finish();
						MDMMainActivity.GetIns().addtoLog(
								"Support Session Declined.");
						MDMMainActivity.GetIns().addtoLog(
								"You have Denied Control to GizmoDoctor.");
						// MDMMainActivity.mdmActivity.finish();
						MDMMainActivity.GetIns().createStartSessiondata(true,commandID);
					}
				});
		Button yes = ((Button) findViewById(R.id.AddApp));
		yes.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (isActivityShown) {
					MDMMainActivity.GetIns().addtoLog(
							"Support Session Established.");
					MDMMainActivity.GetIns().addtoLog(
							"You have Granted Control to GizmoDoctor.");
					new AsyncTask<String, String, String>() {
						private MyProgressDialog myProgressDialog;

						@Override
						protected void onPreExecute() {
							myProgressDialog = new MyProgressDialog(activity);
							myProgressDialog.show();
						}

						@Override
						protected String doInBackground(String... params) {
							while (MDMMainActivity.longAsyncFlag) {
								Log.e(tag,
										"MyLongRunning task is running need to stop it first!");
								try {
									Thread.sleep(2000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							MDMMainActivity.GetIns().createStartSessiondata(false, commandID);
							return "";
						}

						protected void onPostExecute(String result) {
							MDMMainActivity
									.GetIns()
									.addtoLog(
											"Device information requested by and sent to server.");
							finish();
							if (myProgressDialog.isShowing())
								myProgressDialog.dismiss();
						}

					}.execute("");
					isActivityShown = false;
				}
			}
		});
	}
}
