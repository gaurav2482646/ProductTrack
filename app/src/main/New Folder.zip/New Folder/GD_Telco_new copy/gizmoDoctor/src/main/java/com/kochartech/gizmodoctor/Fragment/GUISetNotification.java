package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.HelperClass.FragmentTitles;
import com.kochartech.gizmodoctor.POJO.KeyValueDTO;
import com.kochartech.gizmodoctor.Preferences.GUISetNotificationPreference;

public class GUISetNotification extends Fragment implements MyFragment,
		OnClickListener {

	private String TAG = GUISetNotification.class.getSimpleName();
	private CheckBox cpuTempNotification_CheckBox,
			batteryTempNotification_CheckBox,
			batteryLevelNotification_CheckBox,
			dataConnectionNotification_CheckBox, cpuNotification_CheckBox,
			ramNotification_CheckBox, settingNotification_CheckBox;

	private LinearLayout setRAMLimitLinearLayout, setCPULimitLinearLayout;

	private static GUISetNotificationPreference guiSetNotificationPreference;
	private View rootView;
	private Context context;

	private static TextView ramLimitDescriptionTxtView;
	private static TextView cpuLimitDescriptionTxtView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	public void initDataSet() {
		context = getActivity().getApplicationContext();
		guiSetNotificationPreference = new GUISetNotificationPreference(context);
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {

		rootView = inflater.inflate(R.layout.fragment_setnotification,
				container, false);

		cpuTempNotification_CheckBox = (CheckBox) rootView
				.findViewById(R.id.cpuTemperature_CheckBox);

		batteryTempNotification_CheckBox = (CheckBox) rootView
				.findViewById(R.id.batteryTemperature_CheckBox);
		batteryLevelNotification_CheckBox = (CheckBox) rootView
				.findViewById(R.id.batteryLevel_CheckBox);
		dataConnectionNotification_CheckBox = (CheckBox) rootView
				.findViewById(R.id.dataConnection_CheckBox);
		cpuNotification_CheckBox = (CheckBox) rootView
				.findViewById(R.id.cpuNotificationOnOff_CheckBox);
		ramNotification_CheckBox = (CheckBox) rootView
				.findViewById(R.id.ramNotificationOnOff_CheckBox);
		settingNotification_CheckBox = (CheckBox) rootView
				.findViewById(R.id.setting_display_CheckBox);

		setRAMLimitLinearLayout = (LinearLayout) rootView
				.findViewById(R.id.ramLimitUi);
		setCPULimitLinearLayout = (LinearLayout) rootView
				.findViewById(R.id.cpuLimitUi);

		ramLimitDescriptionTxtView = (TextView) rootView
				.findViewById(R.id.ramLimitDescription);
		cpuLimitDescriptionTxtView = (TextView) rootView
				.findViewById(R.id.cpuLimitDescription);

		// register onclick listener.
		registerOnClick(cpuTempNotification_CheckBox);
		registerOnClick(batteryTempNotification_CheckBox);
		registerOnClick(batteryLevelNotification_CheckBox);
		registerOnClick(dataConnectionNotification_CheckBox);
		registerOnClick(cpuNotification_CheckBox);
		registerOnClick(ramNotification_CheckBox);
		registerOnClick(settingNotification_CheckBox);
		registerOnClick(setRAMLimitLinearLayout);
		registerOnClick(setCPULimitLinearLayout);

		setCheckBoxOnOff(cpuTempNotification_CheckBox,
				guiSetNotificationPreference.getCPUTemperature());
		setCheckBoxOnOff(batteryTempNotification_CheckBox,
				guiSetNotificationPreference.getBatteryTemperature());
		setCheckBoxOnOff(batteryLevelNotification_CheckBox,
				guiSetNotificationPreference.getBatteryLevel());
		setCheckBoxOnOff(dataConnectionNotification_CheckBox,
				guiSetNotificationPreference.getDataConnection());
		setCheckBoxOnOff(cpuNotification_CheckBox,
				guiSetNotificationPreference.isCPUUsageNotificationOn());
		setCheckBoxOnOff(ramNotification_CheckBox,
				guiSetNotificationPreference.isRAMUsageNotificationOn());
		setCheckBoxOnOff(settingNotification_CheckBox,
				guiSetNotificationPreference.isSettingNotificationOn());
		ramLimitDescriptionTxtView.setText(guiSetNotificationPreference
				.getRAMThreashHoldLimit() + " %");
		cpuLimitDescriptionTxtView.setText(guiSetNotificationPreference
				.getCPUThreashHoldLimit() + " %");

	}

	private void registerOnClick(View view) {
		view.setOnClickListener(this);
	}

	private void setCheckBoxOnOff(CheckBox checkBox, boolean isChecked) {
		checkBox.setChecked(isChecked);
	}

	@Override
	public void onClick(View view) {

		if (view instanceof CheckBox) {
			if (view.getId() == R.id.cpuTemperature_CheckBox) {
				if (cpuTempNotification_CheckBox.isChecked())
					guiSetNotificationPreference.setCPUTemperature(true);
				else
					guiSetNotificationPreference.setCPUTemperature(false);
			} else if (view.getId() == R.id.batteryTemperature_CheckBox) {
				if (batteryTempNotification_CheckBox.isChecked())
					guiSetNotificationPreference.setBatteryTemperature(true);
				else
					guiSetNotificationPreference.setBatteryTemperature(false);
			} else if (view.getId() == R.id.batteryLevel_CheckBox) {
				if (batteryLevelNotification_CheckBox.isChecked())
					guiSetNotificationPreference.setBatteryLevel(true);
				else
					guiSetNotificationPreference.setBatteryLevel(false);
			} else if (view.getId() == R.id.dataConnection_CheckBox) {
				if (dataConnectionNotification_CheckBox.isChecked())
					guiSetNotificationPreference.setDataConnection(true);
				else
					guiSetNotificationPreference.setDataConnection(false);
			} else if (view.getId() == R.id.cpuNotificationOnOff_CheckBox) {
				if (cpuNotification_CheckBox.isChecked())
					guiSetNotificationPreference.setCPUUsageNotification(true);
				else
					guiSetNotificationPreference.setCPUUsageNotification(false);
			} else if (view.getId() == R.id.ramNotificationOnOff_CheckBox) {
				if (ramNotification_CheckBox.isChecked())
					guiSetNotificationPreference.setRAMUsageNotification(true);
				else
					guiSetNotificationPreference.setRAMUsageNotification(false);
			} else if (view.getId() == R.id.setting_display_CheckBox) {
				if (settingNotification_CheckBox.isChecked())
					guiSetNotificationPreference.setSettingNotification(true);
				else
					guiSetNotificationPreference.setSettingNotification(false);
			}
		} else if (view instanceof LinearLayout) {

			if (view.getId() == R.id.ramLimitUi) {
				Log.d(TAG, "Ram Limit Ui Click");

				showDialog(R.array.DialogDisplayValue_CPURAM,
						R.array.DialogActualValue_CPURAM,
						guiSetNotificationPreference
								.getKEYRAMThreashHoldLimit(),
						R.string.set_ram_limit);

			} else if (view.getId() == R.id.cpuLimitUi) {
				Log.d(TAG, "CPU Limit Ui Click");
				showDialog(R.array.DialogDisplayValue_CPURAM,
						R.array.DialogActualValue_CPURAM,
						guiSetNotificationPreference
								.getKEYCPUThreashHoldLimit(),
						R.string.set_cpu_limit);

			}
		}

	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return FragmentTitles.NOTIFICATION;
	}

	public void showDialog(int idStringArrayNameToDisplay, int idIntArrayValue,
			KeyValueDTO keyValueDTO, int title) {

		String[] dialogDisplayValue = context.getResources().getStringArray(
				idStringArrayNameToDisplay);
		int[] dialogActualValue = context.getResources().getIntArray(
				idIntArrayValue);
		ArrayList<KeyValueDTO> arrayList = new ArrayList<KeyValueDTO>();
		for (int i = 0; i < dialogDisplayValue.length; i++) {
			Log.d(TAG, "dialogDisplayValue: " + dialogDisplayValue[i]);
			arrayList.add(new KeyValueDTO(dialogDisplayValue[i],
					dialogActualValue[i]));
		}
		DialogRadioBtn dialogRadioBtn = new DialogRadioBtn(getActivity(),
				guiSetNotificationPreference, keyValueDTO, arrayList, title);
		dialogRadioBtn.show();

	}

	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	public static void refreshView() {
		ramLimitDescriptionTxtView.setText(guiSetNotificationPreference
				.getRAMThreashHoldLimit() + " %");
		cpuLimitDescriptionTxtView.setText(guiSetNotificationPreference
				.getCPUThreashHoldLimit() + " %");
	}
}
