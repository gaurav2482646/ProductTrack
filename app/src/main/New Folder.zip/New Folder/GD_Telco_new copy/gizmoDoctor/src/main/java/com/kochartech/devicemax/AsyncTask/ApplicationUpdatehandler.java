package com.kochartech.devicemax.AsyncTask;
//package com.kochar.AsyncTask;
//
//import com.kochar.MDMS.Activities.LogWrite;
//import com.kochar.MDMS.Recievers.ApplicationUpdateReceiver;
//import com.kochar.MDMS.Recievers.StartTestReceiver;
//import com.kochar.MDMS.Recievers.StopTestReceiver;
//
//import android.app.AlarmManager;
//import android.app.PendingIntent;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.os.AsyncTask;
//import android.preference.PreferenceManager;
//
//public class ApplicationUpdatehandler 
//{
//	public static void startAlarm(Context context)
//	{
//		String tag = "ApplicationUpdatehandler";
//		try 
//		{
//			Intent startUpdateReceiver = new Intent(context, ApplicationUpdateReceiver.class);
//			AlarmManager alarmManager = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
//			PendingIntent pendingstartTestIntent = PendingIntent.getBroadcast(
//					context, 211324, startUpdateReceiver,0);
//			alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
//					System.currentTimeMillis(), (5*60*1000),
//					pendingstartTestIntent);
//		}
//		catch (ExceptionDTO e)
//		{
//			LogWrite.d(tag,"ExceptionDTO...."+e);
//		}
//	}
//	public static void stopAlarm(Context context)
//	{
//		String tag = "ApplicationUpdatehandler";
//		try 
//		{
////			Intent startUpdateReceiver = new Intent(context, ApplicationUpdateReceiver.class);
////			AlarmManager alarmManager = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
////			PendingIntent pendingstartTestIntent = PendingIntent.getBroadcast(
////					context.getApplicationContext(), 211324, startUpdateReceiver,0);
////			alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
////					System.currentTimeMillis(), (1*60*1000),
////					pendingstartTestIntent);
//			
////			Intent startUpdateReceiver = new Intent(context, ApplicationUpdateReceiver.class);
////			
////			AlarmManager alarmManager = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
////			PendingIntent pendingstartTestIntent = PendingIntent.getBroadcast(
////					context.getApplicationContext(), 211324, startUpdateReceiver, 0);
//////			PendingIntent pendingstopTestIntent = PendingIntent.getBroadcast(
//////					context.getApplicationContext(), 232324, stopTestIntent, 0);
//////			
//////			pendingIntent = PendingIntent.getActivity(CellManage_AddShowActivity.this,
//////		             id, myntent,PendingIntent.FLAG_UPDATE_CURRENT);
////			pendingstartTestIntent.cancel();
////			
////			
////		   alarmManager.cancel(pendingstartTestIntent);
//			
//			Intent startUpdateReceiver = new Intent(context, ApplicationUpdateReceiver.class);
//			AlarmManager alarmManager = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
//			PendingIntent pendingstartTestIntent = PendingIntent.getBroadcast(
//					context, 211324, startUpdateReceiver,PendingIntent.FLAG_UPDATE_CURRENT);
////			alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
////					System.currentTimeMillis(), (1*60*1000),
////					pendingstartTestIntent);
//			
//			alarmManager.cancel(pendingstartTestIntent);
//		  
//		}
//		catch (ExceptionDTO e)
//		{
//			LogWrite.d(tag,"ExceptionDTO...."+e);
//		}
//	}
//}
