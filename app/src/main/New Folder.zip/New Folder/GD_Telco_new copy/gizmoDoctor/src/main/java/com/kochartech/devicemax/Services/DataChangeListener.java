package com.kochartech.devicemax.Services;

import java.util.ArrayList;
import java.util.List;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.TrafficStats;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Activities.RegisterUserActivity;
import com.kochartech.devicemax.Utility.HandSetUtilty;
import com.kochartech.devicemax.Utility.MyDataBaseHandlerClass;
import com.kochartech.gizmodoctor.R;

public class DataChangeListener extends Service 
{
	String tag = "DataChangeListener";
	String sendText = "";
	HandSetUtilty handSetUtilty;
	long dataUpdateInAllAPP;
	String IMSI;
	long previousDataUsage = 0;
	String prevData = "";
	boolean isDataSent = false;
	SharedPreferences.Editor editor;
	SharedPreferences preferences;
	RegisterUserActivity instance;
	public DataChangeListener() 
	{
		instance = RegisterUserActivity.GetInstance();
	}
	@Override
	public void onCreate()
	{
		super.onCreate();
		LogWrite.d(tag, "In onCreate of DataChangeListener..");
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) 
	{
		dataUpdateInAllAPP = 0;
		LogWrite.d(tag, "In onStartCommand of DataChangeListener..");
		TelephonyManager mTelmgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		PhoneStateListener phonestate = new PhoneStateListener() {
			@Override
			public void onDataActivity(int direction) {
				super.onDataActivity(direction);
				LogWrite.d(tag, "Data change occured...!!! Inside onDataActivity");
				SharedPreferences sharedprefrence = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				final SharedPreferences.Editor editor = sharedprefrence.edit();
				long lastupdate = sharedprefrence.getLong("lastupdate", 1);
				long difference = System.currentTimeMillis() - lastupdate;
				if (difference > (60 * 1000)) 
				{
					if (TelephonyManager.DATA_ACTIVITY_NONE == direction) 
					{

					}
					else 
					{
						editor.putLong("lastupdate", System.currentTimeMillis());
						editor.commit();
						Thread UpdateAddress = new Thread() 
						{
							public void run() 
							{
								try 
								{
									MyDataBaseHandlerClass obj = new MyDataBaseHandlerClass(getApplicationContext(),"operators.db", null, 1);
									obj.getWritableDatabase();
									PackageManager pm = RegisterUserActivity.GetInstance().getPackageManager();
							        final IntentFilter filter = new IntentFilter(Intent.ACTION_MAIN);
							        filter.addCategory(Intent.CATEGORY_LAUNCHER);
							        List<IntentFilter> filters = new ArrayList<IntentFilter>();
							        filters.add(filter);

							        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
							        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
							        List<ResolveInfo> list = pm.queryIntentActivities(mainIntent, 0);
									LogWrite.d(tag, "internal Apps ="+list.size());
//									Toast.makeText(, "Size ="+list.size(),Toast.LENGTH_LONG);
									for (int n = 0; n < list.size(); n++)
									{
										LogWrite.d(tag, list.get(n).loadLabel(pm).toString());
										if ((list.get(n).activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 1)
										{
											// 1 to unblock apps  0 to block third party app
											if (!list.get(n).loadLabel(pm).toString().equalsIgnoreCase(RegisterUserActivity.GetInstance().getString(R.string.app_name)))
											{
												long rx = TrafficStats.getUidRxBytes(list.get(n).activityInfo.applicationInfo.uid);
												long tx = TrafficStats.getUidTxBytes(list.get(n).activityInfo.applicationInfo.uid);
												long rxTx = rx + tx;
												if(rxTx<0)
												{
													rxTx = 0;
												}
												LogWrite.d(tag, "Current Usage :  " + rxTx);
												obj.updateAppDataUsage(list.get(n).activityInfo.packageName,
														rxTx + "");
												
											}
										}
										else
										{
											long rx = TrafficStats.getUidRxBytes(list.get(n).activityInfo.applicationInfo.uid);
											long tx = TrafficStats.getUidTxBytes(list.get(n).activityInfo.applicationInfo.uid);
											long rxTx = rx + tx;
											if(rxTx<0)
											{
												rxTx = 0;
											}
											LogWrite.d(tag, "Current Usage :  " + rxTx);
											obj.updateAppDataUsage(list.get(n).activityInfo.packageName, rxTx + "");
										}
									}
									obj.close();
//									for (ApplicationInfo app : getPackageManager()
//											.getInstalledApplications(0)) {
//										long rx = TrafficStats
//												.getUidRxBytes(app.uid);
//										long tx = TrafficStats
//												.getUidTxBytes(app.uid);
//										long rxTx = rx + tx;
//
//										obj.updateAppDataUsage(app.packageName,
//												rxTx + "");
//										obj.close();
//									}

								} 
								catch (Exception e) 
								{
									LogWrite.d(tag, "errror==" + e.toString());
									e.printStackTrace();
								}
							}
						};
						UpdateAddress.start();
					}
				}
			}
		};
		mTelmgr.listen(phonestate, PhoneStateListener.LISTEN_DATA_ACTIVITY);
		return START_STICKY;
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

}
