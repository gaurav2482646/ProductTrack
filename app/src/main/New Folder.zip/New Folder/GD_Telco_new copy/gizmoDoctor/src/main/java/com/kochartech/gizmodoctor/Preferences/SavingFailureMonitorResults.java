package com.kochartech.gizmodoctor.Preferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class SavingFailureMonitorResults {
	private final String PREFERENCE_NAME = "gizmodoctor";
	private final int PREFERENCE_MODE = 0;

	private final String KEY_FailureResult = "failure_result_key";
	private final String KEY_FAILURE_ARRAY = "key_failure_";
	private final String KEY_FAILURE_COUNT = "key_failure_count";

	private SharedPreferences myPreference;
	private Editor editor;

	public SavingFailureMonitorResults(Context context) {
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();
	}

	// public void saveJson(String jsonString) {
	// Set<String> set = getJsonSet();
	// set.add(jsonString);
	// editor.putStringSet(KEY_FailureResult, set);
	// editor.commit();
	//
	// }
	//
	// public Set<String> getJsonSet() {
	// Set<String> set = myPreference.getStringSet(KEY_FailureResult, null);
	// if (set == null)
	// set = new HashSet<String>();
	// return set;
	// }

	public void setSendingJSON(String jsonString, int count) {
		editor.putString(KEY_FAILURE_ARRAY + count, jsonString).commit();
	}

	public ArrayList<String> getSendingJSON() {
		ArrayList<String> list = new ArrayList<String>();
		if (getCount() > 0) {
			for (int i = 0; i < getCount(); i++) {
				list.add(myPreference.getString(KEY_FAILURE_ARRAY + i, ""));
			}
		}
		return list;
	}

	public void setCount(int count) {
		editor.putInt(KEY_FAILURE_COUNT, count).commit();
	}

	public int getCount() {
		return myPreference.getInt(KEY_FAILURE_COUNT, 0);
	}

	public void resetAll() {
		editor.clear().commit();
	}
}
