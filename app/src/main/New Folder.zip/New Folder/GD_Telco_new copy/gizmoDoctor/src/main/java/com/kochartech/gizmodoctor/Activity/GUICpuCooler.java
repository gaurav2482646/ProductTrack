package com.kochartech.gizmodoctor.Activity;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Fragment.MyFragment;
import com.kochartech.gizmodoctor.HelperClass.KTEnum;
import com.kochartech.gizmodoctor.HelperClass.Utility;
import com.kochartech.gizmodoctor.deviceissues.CpuTemp;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager;
import com.kochartech.gizmodoctor.deviceissues.RunningAppDTO;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager.Process;

@SuppressWarnings("deprecation")
public class GUICpuCooler extends Fragment implements MyFragment {
	private String TAG = GUICpuCooler.class.getSimpleName();
	private View rootView;
	private TextView cpuTempView;
	private Activity context;
	private LinearLayout cpuLinearLayout;

	private boolean isWorking = false;
	private Handler handler;

	private CpuTemp cpuTemp;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	public void initDataSet() {
		context = getActivity();
		handler = new Handler();
		cpuTemp = new CpuTemp(context);
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_cpucooler, container,
				false);
		cpuLinearLayout = (LinearLayout) rootView
				.findViewById(R.id.cpu_temp_layout);
		cpuTempView = (TextView) rootView.findViewById(R.id.cpu_temp);
	}

	@Override
	public String getTitle() {
		return "CPU Cooler";
	}

	@Override
	public void onResume() {
		super.onResume();
		isWorking = true;
		BackgroundTask backgroundTask = new BackgroundTask(context);
		backgroundTask.start();
		// new Thread(new Task()).start();
	}

	@Override
	public void onPause() {
		super.onPause();
		isWorking = false;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		isWorking = false;
	}

	private class BackgroundTask extends AsyncTask<String, String, String> {
		private Activity activity;
		private ArrayList<RunningAppDTO> arrayList;

		public BackgroundTask(Activity activity) {
			this.activity = activity;
		}

		public void start() {
			this.execute("");
		}

		@Override
		protected String doInBackground(String... params) {
			while (isWorking) {
				int temp = (int) cpuTemp.getCpuTemp();
				String str = "" + temp;
				String first2char = str.substring(0, 2);
				int currentTemp = Integer.parseInt(first2char);
				LogWrite.d(TAG, "Current CPU Temp : " + currentTemp);
				publishProgress("" + currentTemp);

				List<Process> appList = ProcessManager.getRunningApps();
				arrayList = new ArrayList<RunningAppDTO>();
				for (Process process : appList) {
					String appName = "";
					try {
						ApplicationInfo appInfo = context.getPackageManager()
								.getApplicationInfo(process.getPackageName(),
										PackageManager.GET_META_DATA);
						appName = (String) context.getPackageManager()
								.getApplicationLabel(appInfo);

						if (!appName.equals("")) {
							if (!isAppNameAlreadyExists(appName, arrayList)) {
								RunningAppDTO appDTO = new RunningAppDTO();
								LogWrite.d(TAG, "AppName : " + appName);
								LogWrite.d(
										TAG,
										"PackageName : "
												+ process.getPackageName());
								appDTO.setAppName(appName);
								appDTO.setPackageName(process.getPackageName());

								if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
									LogWrite.e(TAG, "App is system!");
									appDTO.setSystemApp(1);
								} else {
									LogWrite.e(TAG, "App is external!");
									appDTO.setSystemApp(0);
								}
								arrayList.add(appDTO);
							}
						}
					} catch (NameNotFoundException e) {
						e.printStackTrace();
					}

				}

				try {
					Thread.sleep(1 * 60 * 1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return "";
		}

		@Override
		protected void onProgressUpdate(String... values) {
			int batteryTemp = Integer.parseInt(values[0]);
			try {
				cpuTempView.setText(Utility.tempWithUnits(batteryTemp,
						KTEnum.TEMPERATURE_UNIT.CELSIUS.getValue()));
			} catch (Exception e) {
				LogWrite.e(TAG, "CPUTempTextViewException : " + e.toString());
			}

			if (batteryTemp < 40)
				cpuLinearLayout.setBackgroundResource(R.drawable.cpu_temp_good);
			else if (batteryTemp >= 40 && batteryTemp < 50)
				cpuLinearLayout
						.setBackgroundResource(R.drawable.cpu_temp_average);
			else
				cpuLinearLayout.setBackgroundResource(R.drawable.cpu_temp_poor);
			super.onProgressUpdate(values);
		}

		private boolean isAppNameAlreadyExists(String appName,
				ArrayList<RunningAppDTO> foundList) {
			for (RunningAppDTO runningAppDTO : foundList) {
				if (runningAppDTO.getAppName().equals(appName))
					return true;
			}
			return false;
		}

	}

	// class Task implements Runnable {
	// @Override
	// public void run() {
	// while (isWorking) {
	//
	// handler.post(new Runnable() {
	//
	// @Override
	// public void run() {
	// int temp = (int) cpuTemp.getCpuTemp();
	// String str = "" + temp;
	// String first2char = str.substring(0, 2);
	// int currentTemp = Integer.parseInt(first2char);
	// LogWrite.d(TAG, "Current CPU Temp : " + currentTemp);
	// try {
	// cpuTempView.setText(Utility.tempWithUnits(
	// currentTemp,
	// KTEnum.TEMPERATURE_UNIT.CELSIUS.getValue()));
	// } catch (ExceptionDTO e) {
	// LogWrite.e(
	// TAG,
	// "CPUTempTextViewException : "
	// + e.toString());
	// }
	//
	// if (currentTemp < 40) {
	// cpuLinearLayout
	// .setBackgroundResource(R.drawable.cpu_temp_good);
	// cpuTempView.clearAnimation();
	// } else if (currentTemp >= 40 && currentTemp < 50) {
	// cpuLinearLayout
	// .setBackgroundResource(R.drawable.cpu_temp_average);
	// // AnimationSet mAnimationSet = new
	// // AnimationSet(false);
	// Animation fadeInAnimation = AnimationUtils
	// .loadAnimation(context, R.anim.fade_in);
	// // Animation fadeOutAnimation = AnimationUtils
	// // .loadAnimation(context, R.anim.fade_out);
	// // mAnimationSet.addAnimation(fadeInAnimation);
	// // mAnimationSet.addAnimation(fadeOutAnimation);
	// // mAnimationSet.setRepeatCount(Animation.INFINITE);
	// cpuTempView.startAnimation(fadeInAnimation);
	// } else {
	// cpuLinearLayout
	// .setBackgroundResource(R.drawable.cpu_temp_poor);
	// // AnimationSet mAnimationSet = new
	// // AnimationSet(false);
	// Animation fadeInAnimation = AnimationUtils
	// .loadAnimation(context, R.anim.fade_in);
	// // Animation fadeOutAnimation = AnimationUtils
	// // .loadAnimation(context, R.anim.fade_out);
	// // mAnimationSet.addAnimation(fadeInAnimation);
	// // mAnimationSet.addAnimation(fadeOutAnimation);
	// // mAnimationSet.setRepeatCount(Animation.INFINITE);
	// cpuTempView.startAnimation(fadeInAnimation);
	// }
	//
	// // try {
	// // List<Process> appList = ProcessManager
	// // .getRunningApps();
	// //
	// // for (Process process : appList) {
	// // LogWrite.d(TAG, "Process : " + process.name);
	// // }
	// // } catch (ExceptionDTO e) {
	// // LogWrite.e(TAG,
	// // "AppListException : " + e.toString());
	// // }
	// }
	// });
	//
	// try {
	// Thread.sleep(2000);
	// } catch (InterruptedException e) {
	// e.printStackTrace();
	// }
	// }
	// }
	// }
}