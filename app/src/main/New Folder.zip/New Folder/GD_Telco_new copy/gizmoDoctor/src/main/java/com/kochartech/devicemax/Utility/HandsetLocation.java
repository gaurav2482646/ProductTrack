package com.kochartech.devicemax.Utility;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.Context;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Activities.MDMMainActivity;

public class HandsetLocation 
{
	private static final String TAG = "HandsetLocation";


	public String getLocation(Context context)
	{
		String location = null;
		try 
		{
			int cellID = MDMMainActivity.getCellID(context);
			int lac = MDMMainActivity.getLocationAreaCode(context);
			LogWrite.d(TAG, cellID +" lac  in dib"+ lac );
			location = getLocationFromGoogle(cellID, lac);
		} 
		catch (Exception e) 
		{
			LogWrite.d("Location ExceptionDTO", "ExceptionDTO---->" + e.toString());
		}
		return location;
		
	}
	public String getLocationFromGoogle(int aCellID, int aLAC) 
	{
		String latitudteLongitudeString = "0~0";
		try
		{
			LogWrite.d(TAG," LatitudeLongitudeClass " + aCellID + "  a lac " + aLAC);
			
			latitudteLongitudeString = "";
			String baseURL = "http://www.google.com/glm/mmap";
			
			HttpClient client = new DefaultHttpClient();
			HttpPost httpPost = new HttpPost(baseURL);
			httpPost.setEntity(new LocationHelper(aCellID, aLAC));
			HttpResponse response = client.execute(httpPost);
			StatusLine statusLine = response.getStatusLine();
			HttpEntity resEntity = response.getEntity();
			if (resEntity != null) 
			{
				// LogWrite.d(TAG,"RESPONSE"+EntityUtils.toString(resEntity));+
			}
			InputStream response2 = resEntity.getContent();
			DataInputStream dis = new DataInputStream(response2);
			// Read some prior data
			dis.readShort();
			dis.readByte();
			// Read the error-code
			int errorCode = dis.readInt();
			LogWrite.d(TAG, "errorcode==" + errorCode);
			if (errorCode == 0) {
				double lat = dis.readInt() / 1000000D;
				double lng = dis.readInt() / 1000000D;
				LogWrite.d(TAG, "lat==" + lat + "lng=" + lng);
				// Read the rest of the data
				dis.readInt();
				dis.readInt();
				dis.readUTF();
			
			
				latitudteLongitudeString=lat+"~"+lng;
				LogWrite.d(TAG,"lat"+latitudteLongitudeString);
				//String ad = getUserLocation(lat + "", lng + "");
				//String result = "lat:" + lat + "\nlng:" + lng + "\n";
				//result += "add:" + ad;
			}
			else
			{
				latitudteLongitudeString=0+"~"+0;
				LogWrite.d(TAG,"lat"+latitudteLongitudeString);
			}
			LogWrite.d(TAG, "statusLine%%%%%%%%%%%%%%%%%" + statusLine);
		} catch (ClientProtocolException e) 
		{
			LogWrite.d("Location ExceptionDTO", "ClientProtocolException---->" + e.toString());
		} catch (IllegalStateException e) 
		{
			LogWrite.d("Location ExceptionDTO", "IllegalStateException---->" + e.toString());
		} catch (IOException e) 
		{
			LogWrite.d("Location ExceptionDTO", "IOException---->" + e.toString());
		}
		return latitudteLongitudeString;

	}

	/*
	 * commented on 24/09/2013 as this method is not being used
	 * 
	 */
	
	/*private String getUserLocation(String lat, String lon) {
		String userlocation = null;
		String readUserFeed = readUserLocationFeed(lat.trim() + ","
				+ lon.trim());
		try {
			JSONObject Strjson = new JSONObject(readUserFeed);
			JSONArray jsonArray = new JSONArray(Strjson.getString("results"));
			userlocation = jsonArray.getJSONObject(1)
					.getString("formatted_address").toString();
		} catch (ExceptionDTO e) {
			e.printStackTrace();
		}
		Log.i("User Location ", userlocation);
		return userlocation;
	}*/
	

	/*public static String readUserLocationFeed(String address) {
		String TAG="readUserLocationFeed";
		StringBuilder builder = new StringBuilder();
		HttpClient client = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(
				"http://maps.google.com/maps/api/geocode/json?latlng="
						+ address + "&sensor=false");
		try {
			HttpResponse response = client.execute(httpGet);
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			if (statusCode == 200) {
				HttpEntity entity = response.getEntity();
				InputStream content = entity.getContent();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(content));
				String line;
				while ((line = reader.readLine()) != null) {
					builder.append(line);
				}
			} else {
				LogWrite.d(TAG, "Failed to download file");
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return builder.toString();
	}
	*/
	class LocationHelper extends AbstractHttpEntity{

		protected int myCellID;
	    protected int myLAC;

	    public LocationHelper(int aCellID, int aLAC) {
	            this.myCellID = aCellID;
	            this.myLAC = aLAC;
	    }
		@Override
		public InputStream getContent() throws IOException, IllegalStateException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getContentLength() {
			// TODO Auto-generated method stub
			return -1;
		}

		@Override
		public boolean isRepeatable() {
			// TODO Auto-generated method stub
			return true;
		}

		@Override
		public boolean isStreaming() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void writeTo(OutputStream outputStream) throws IOException 
		{
			 DataOutputStream os = new DataOutputStream(outputStream);
	         os.writeShort(21);
	         os.writeLong(0);
	         os.writeUTF("fr");
	         os.writeUTF("Sony_Ericsson-K750");
	         os.writeUTF("1.3.1");
	         os.writeUTF("Web");
	         os.writeByte(27);

	         os.writeInt(0); os.writeInt(0); os.writeInt(3);
	         os.writeUTF("");
	         os.writeInt(myCellID); // CELL-ID
	         os.writeInt(myLAC); // LAC
	         os.writeInt(0); os.writeInt(0);
	         os.writeInt(0); os.writeInt(0);
	         os.flush();
			
		}
		

	}
}
