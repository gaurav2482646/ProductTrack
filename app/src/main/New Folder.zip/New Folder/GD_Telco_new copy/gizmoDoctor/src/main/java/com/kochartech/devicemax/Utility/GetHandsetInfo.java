package com.kochartech.devicemax.Utility;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;

import com.kochartech.devicemax.Activities.LogWrite;

public class GetHandsetInfo 
{
		Context context;
		TelephonyManager telephonyManager;
	    NetworkInfo networkInfo;
	    ConnectivityManager connectivityManager;
	    String TAG="GetHandsetInfo";
	    
		public GetHandsetInfo(Context context)
		{
			this.context=context;
		}
	
	   
	    /*
		 *  returns the network mode 
		 */
		
		public String getNetworkMode()
		{
			try{
			telephonyManager=(TelephonyManager)context. getSystemService(Context.TELEPHONY_SERVICE);
			int phoneType = telephonyManager.getPhoneType();
			 switch(phoneType)
			 {
			 	case TelephonyManager.PHONE_TYPE_NONE:
			    return "NONE";
			 
			  case TelephonyManager.PHONE_TYPE_GSM:
			   return "GSM";
			 
			  case TelephonyManager.PHONE_TYPE_CDMA:
			   return "CDMA";
			 }
			}
			catch(Exception e)
			{
				LogWrite.d(TAG, "exception "+e);
			}
			  return "";
			
		}
		
		
		
		public int getLocationAreaCode()
		{
			int loc=-1;
			try {
				telephonyManager=(TelephonyManager)context. getSystemService(Context.TELEPHONY_SERVICE);
				String NetworkMode=getNetworkMode();
				if(NetworkMode.equalsIgnoreCase("GSM"))
				{
				GsmCellLocation location = (GsmCellLocation)telephonyManager.getCellLocation();
				loc=location.getLac();
				}
				else if(NetworkMode.equalsIgnoreCase("CDMA"))
				{
				 CdmaCellLocation location1 = (CdmaCellLocation) telephonyManager.getCellLocation();
				loc = location1.getNetworkId();

				}
				return loc;
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
			return loc;
		}
		/*
		 * gsm cell id, -1 if unknown, 0xffff max legal value 
		 */
		
		public int getCellID()
		{
			String cell="";
			int ci=0;
			try {
				telephonyManager=(TelephonyManager)context. getSystemService(Context.TELEPHONY_SERVICE);
				String NetworkMode=getNetworkMode();
				LogWrite.d(TAG, "NetworkMode=="+NetworkMode);
				if(NetworkMode.equalsIgnoreCase("GSM"))
				{
					GsmCellLocation location = (GsmCellLocation) telephonyManager.getCellLocation();
				int CELLID=location.getCid();
				ci = CELLID & 0xffff;
				}
				else if(NetworkMode.equalsIgnoreCase("CDMA"))
				{
				 CdmaCellLocation location1 = (CdmaCellLocation) telephonyManager.getCellLocation();
				  int  cellID = location1.getBaseStationId();
				  ci = cellID & 0xffff;

				}
				System.out.println("ci==="+ci);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
			/*if(ci==0)
			{
				cell="";
			}
			else
			{
				cell=""+ci;
			}*/
			return ci;
			
		}
		
		
		
	
}
