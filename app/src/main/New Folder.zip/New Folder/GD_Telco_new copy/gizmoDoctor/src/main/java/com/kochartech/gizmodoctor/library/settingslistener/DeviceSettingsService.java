package com.kochartech.gizmodoctor.library.settingslistener;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.preference.PreferenceManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.DataBase.DBHelperDataSettingsToMonitor;
import com.kochartech.gizmodoctor.DataBase.DataSource_Settings;
import com.kochartech.library.Device.KTDeviceInfo;

public class DeviceSettingsService extends Service {
	private static String TAG = DeviceSettingsService.class.getSimpleName();
	private static String PREF_IS_RUNNING = DeviceSettingsService.class
			.getSimpleName();
	public final static String KEY_BLUETOOTH = "Bluetooth";
	public final static String KEY_GPS = "GPS";
	public final static String KEY_HOTSPOT = "WiFi hotspot";
	public final static String KEY_WIFI = "WiFi";
	private DeviceSettingsListener mReceiver;

	public static void start(Context context) {
		if (!isRunning(context)) {
			LogWrite.i(TAG, "Need to start DeviceSettingsService...........");
			context.startService(new Intent(context,
					DeviceSettingsService.class));

		}
	}

	private Context context;
	private DataSource_Settings settingToMonitor_DS;
	private DBHelperDataSettingsToMonitor settingsToMonitor;

	@Override
	public void onCreate() {
		super.onCreate();
		context = getApplicationContext();
		setRunning(context, true);
		// Toast.makeText(getBaseContext(), "Service on create",
		// Toast.LENGTH_SHORT).show();
		// Register receiver that handles screen on and screen off logic
		IntentFilter filter = new IntentFilter(
				"android.net.wifi.WIFI_AP_STATE_CHANGED");
		filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
		filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
		filter.addAction("android.location.PROVIDERS_CHANGED");
		mReceiver = new DeviceSettingsListener();
		registerReceiver(mReceiver, filter);

		settingToMonitor_DS = DataSource_Settings.getInstance(context);
		settingsToMonitor = DBHelperDataSettingsToMonitor.getInstance(context);

		KTDeviceInfo deviceInfo = new KTDeviceInfo(getApplicationContext());
		if (deviceInfo.isBluetoothEnabled()) {
			settingToMonitor_DS.updateTheLastState(KEY_BLUETOOTH, 1);
			settingsToMonitor.insertEntry(KEY_BLUETOOTH);
		} else {
			settingToMonitor_DS.updateTheLastState(KEY_BLUETOOTH, 0);
			settingsToMonitor.setSettingMonitorningOff(KEY_BLUETOOTH);
		}

		if (deviceInfo.isGPSEnabled()) {
			settingToMonitor_DS.updateTheLastState(KEY_GPS, 1);
			settingsToMonitor.insertEntry(KEY_GPS);
		} else {
			settingToMonitor_DS.updateTheLastState(KEY_GPS, 0);
			settingsToMonitor.setSettingMonitorningOff(KEY_GPS);
		}

	}

	@Override
	public void onStart(Intent intent, int startId) {
		int bluetoothOn = -1;
		int gpsOn = -1;
		int hotspotOn = -1;
		int wifiOn = -1;

		try {
			bluetoothOn = intent.getIntExtra(KEY_BLUETOOTH, bluetoothOn);
			switch (bluetoothOn) {
			case 0:
				// Toast.makeText(context, "Bluetooth OFF", Toast.LENGTH_SHORT)
				// .show();
				settingToMonitor_DS.updateTheLastState(KEY_BLUETOOTH, 0);
				settingsToMonitor.setSettingMonitorningOff(KEY_BLUETOOTH);
				break;
			case 1:
				// Toast.makeText(context, "Bluetooth ON", Toast.LENGTH_SHORT)
				// .show();
				settingToMonitor_DS.updateTheLastState(KEY_BLUETOOTH, 1);
				settingsToMonitor.insertEntry(KEY_BLUETOOTH);
				break;

			default:
				break;
			}
		} catch (Exception e) {
			LogWrite.e(TAG, "BluetoothDbException : " + e.toString());
		}

		try {
			gpsOn = intent.getIntExtra(KEY_GPS, gpsOn);
			switch (gpsOn) {
			case 0:
				// Toast.makeText(context, "GPS OFF",
				// Toast.LENGTH_SHORT).show();
				settingToMonitor_DS.updateTheLastState(KEY_GPS, 0);
				settingsToMonitor.setSettingMonitorningOff(KEY_GPS);
				break;
			case 1:
				// Toast.makeText(context, "GPS ON", Toast.LENGTH_SHORT).show();
				settingToMonitor_DS.updateTheLastState(KEY_GPS, 1);
				settingsToMonitor.insertEntry(KEY_GPS);
				break;

			default:
				break;
			}
		} catch (Exception e) {
			LogWrite.e(TAG, "GPSDbException : " + e.toString());
		}

		try {
			hotspotOn = intent.getIntExtra(KEY_HOTSPOT, hotspotOn);
			switch (hotspotOn) {
			case 0:
				// Toast.makeText(context, "Hotspot OFF", Toast.LENGTH_SHORT)
				// .show();
				settingToMonitor_DS.updateTheLastState(KEY_HOTSPOT, 0);
				settingsToMonitor.setSettingMonitorningOff(KEY_HOTSPOT);
				break;
			case 1:
				// Toast.makeText(context, "Hotspot ON", Toast.LENGTH_SHORT)
				// .show();
				settingToMonitor_DS.updateTheLastState(KEY_HOTSPOT, 1);
				settingsToMonitor.insertEntry(KEY_HOTSPOT);
				break;

			default:
				break;
			}
		} catch (Exception e) {
			LogWrite.e(TAG, "HotspotDbException : " + e.toString());
		}

		try {
			wifiOn = intent.getIntExtra(KEY_WIFI, wifiOn);
			switch (wifiOn) {
			case 0:
				// Toast.makeText(context, "WiFi OFF",
				// Toast.LENGTH_SHORT).show();
				settingToMonitor_DS.updateTheLastState(KEY_WIFI, 0);
				settingsToMonitor.setSettingMonitorningOff(KEY_WIFI);
				break;
			case 1:
				// Toast.makeText(context, "WiFi ON",
				// Toast.LENGTH_SHORT).show();
				settingToMonitor_DS.updateTheLastState(KEY_WIFI, 1);
				settingsToMonitor.insertEntry(KEY_WIFI);
				break;

			default:
				break;
			}
		} catch (Exception e) {
			LogWrite.e(TAG, "WifiDbException: " + e.toString());
		}
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onDestroy() {
		LogWrite.i(TAG, "Service  destroy");
		if (mReceiver != null)
			unregisterReceiver(mReceiver);
		setRunning(getApplicationContext(), false);
		Intent intent = new Intent("com.android.kochar.servicestop");
		sendBroadcast(intent);
	}

	public static void setRunning(Context context, boolean running) {
		SharedPreferences pref = PreferenceManager
				.getDefaultSharedPreferences(context);
		SharedPreferences.Editor editor = pref.edit();

		editor.putBoolean(PREF_IS_RUNNING, running);
		editor.apply();
	}

	private static boolean isRunning(Context context) {
		SharedPreferences pref = PreferenceManager
				.getDefaultSharedPreferences(context.getApplicationContext());
		return pref.getBoolean(PREF_IS_RUNNING, false);
	}
}
