package com.kochartech.MyLibs;

import java.util.List;

import com.kochartech.devicemax.Activities.LogWrite;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;

public class MemoryCleaner {
	private String TAG = MemoryCleaner.class.getSimpleName();
	private Context context;

	public MemoryCleaner(Context context) {
		this.context = context;
	}

	/*
	 * clean Background Application processes.
	 */
	public void clean() {
		ActivityManager activityManager = (ActivityManager) context
				.getSystemService(Activity.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> runningAppProcessInfoList = activityManager
				.getRunningAppProcesses();
		LogWrite.d(TAG, "runningAppProcesses: " + runningAppProcessInfoList.size());
		for (RunningAppProcessInfo runningAppProcessInfo : runningAppProcessInfoList) {
			int runningAppProcessImportance = runningAppProcessInfo.importance;
			LogWrite.d(TAG, "processName: " + runningAppProcessInfo.processName);
			LogWrite.d(TAG, "importance: " + runningAppProcessImportance);

			if (runningAppProcessImportance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND
					|| runningAppProcessImportance == RunningAppProcessInfo.IMPORTANCE_VISIBLE)
				continue;

			cleanProcess(activityManager, runningAppProcessInfo);

		}
	}

	private boolean cleanProcess(ActivityManager activityManager,
			RunningAppProcessInfo runningAppProcessInfo) {

		try {
			// Log.d(TAG, "clean: yes");
			String[] pkgList = runningAppProcessInfo.pkgList;
			for (String packageName : pkgList) {
				// Log.d(TAG, "packageName: "+packageName);
				activityManager.killBackgroundProcesses(packageName);
			}
			return true;
		} catch (Exception e) {
			LogWrite.e(TAG, "ExceptionDTO: " + e);
		}
		return false;

	}
}
