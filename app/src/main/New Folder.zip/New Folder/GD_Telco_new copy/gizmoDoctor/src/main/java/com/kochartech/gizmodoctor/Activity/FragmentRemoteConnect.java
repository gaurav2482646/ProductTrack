package com.kochartech.gizmodoctor.Activity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kochartech.devicemax.Activities.DecisionMakerActivity;
import com.kochartech.devicemax.Activities.DialogActivity;
import com.kochartech.devicemax.Activities.MDMMainActivity;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.Fragment.MyFragment;
import com.kochartech.gizmodoctor.deviceissues.AccessibilityHelper;

public class FragmentRemoteConnect extends Fragment implements OnClickListener,
		MyFragment {
	private Context context;
	private View rootView;
	private Button btConnect;
	private EditText editTextPh;

	private MyProgressDialog myprogressDialog;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		context = getActivity().getApplicationContext();
		myprogressDialog = new MyProgressDialog(getActivity());
		rootView = inflater.inflate(R.layout.fragment_remoteconnection,
				container, false);
		editTextPh = (EditText) rootView
				.findViewById(R.id.editText_PhoneNumber);
		btConnect = (Button) rootView.findViewById(R.id.btConnect);

		btConnect.setOnClickListener(this);

		return rootView;
	}

	@Override
	public void onResume() {
		AccessibilityHelper accessibilityHelper = new AccessibilityHelper(
				getActivity());
		if (!accessibilityHelper.isAccessibilityEnabled()) {
			AccessibilityEnableDialog accessibilityEnableDialog = new AccessibilityEnableDialog(
					getActivity());
			accessibilityEnableDialog.show();
		}
		super.onResume();
	}

	private boolean isClickedFlag = false;

	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		final String phoneNumber = editTextPh.getText().toString().trim();

		if (!(phoneNumber.length() >= 10 && phoneNumber.length() <= 12)) {
			Toast.makeText(context, "Please enter a valid number.",
					Toast.LENGTH_SHORT).show();
			return;
		}
		if (!isClickedFlag) {
			isClickedFlag = true;
			InputMethodManager imm = (InputMethodManager) context
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(editTextPh.getWindowToken(), 0);
			new AsyncTask<String, String, String>() {
				private boolean internetFlag = false;

				protected void onPreExecute() {
					myprogressDialog.show();
				}

				@Override
				protected String doInBackground(String... params) {
					if (hasConnection(context)) {
						internetFlag = true;
					} else {
						internetFlag = false;
					}
					publishProgress("");
					return null;
				}

				protected void onProgressUpdate(String[] values) {
					if (internetFlag) {
						FragmentManager fm = getActivity()
								.getSupportFragmentManager();
						FragmentTransaction ft = fm.beginTransaction();
						ft.addToBackStack("1");

						Fragment fragment = new MDMMainActivity();
						Bundle bundle = new Bundle();
						bundle.putString("phoneNumber", phoneNumber);
						PreferenceManager.getDefaultSharedPreferences(context)
								.edit().putString("ph", phoneNumber).commit();
						DecisionMakerActivity.activityStatusFlag = true;
						fragment.setArguments(bundle);

						// ft.add(R.id.frame_container,
						// fragment).commit();

						FragmentListener fragmentListener = (FragmentListener) getActivity();
						fragmentListener.onItemClicked(
								FragmentListener.actionAdd, fragment);
					} else
						startActivity(new Intent(context, DialogActivity.class));
				}

				protected void onPostExecute(String result) {
					myprogressDialog.dismiss();
					isClickedFlag = false;
				}
			}.execute("");
		}
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return "Device Remote";
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		// Toast.makeText(getActivity(), "onDestory Remote Connect",
		// Toast.LENGTH_LONG).show();
	}

	/**
	 * Checks if the device has Internet connection.
	 * 
	 * @return <code>true</code> if the phone is connected to the Internet.
	 */
	private boolean hasConnection(Context context) {
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo wifiNetwork = cm
				.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		if (wifiNetwork != null && wifiNetwork.isConnected()) {
			return true;
		}

		NetworkInfo mobileNetwork = cm
				.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		if (mobileNetwork != null && mobileNetwork.isConnected()) {
			return true;
		}

		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		if (activeNetwork != null && activeNetwork.isConnected()) {
			return true;
		}

		return false;
	}
	// @Override
	// public boolean isToUpdateUi() {
	// // TODO Auto-generated method stub
	// return false;
	// }

}
