package com.kochartech.devicemax.Utility;

import android.content.Context;
import android.util.Log;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * This signleton class is created to post data to server.
 *
 * @author gaurav.gupta
 */

public class HttpOperations {

    private static final String TAG = "HttpOperationsTest";
    public static String responseString = "";
    private static HttpOperations instance = null;

    private HttpOperations() {

    }

    public static HttpOperations getInstance() {
        if (instance == null)
            instance = new HttpOperations();

        return instance;
    }

    public boolean doPost(String value, String url, Context context)
            throws IOException {
        if (value == null)
            return false;
        HttpURLConnection urlConnection = null;
        try {
            URL _url = new URL(url);
            urlConnection = (HttpURLConnection) _url.openConnection();
//			urlConnection.setConnectTimeout(2*1000);
//			urlConnection.setReadTimeout(2*1000);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json");
//			urlConnection.setRequestProperty("Content-Length", value.length()+"" );
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            DataOutputStream dos = new DataOutputStream(urlConnection.getOutputStream());
            byte[] bs = value.getBytes();
            Log.e(TAG, "Sending JSON String ji->" + new String(bs));
            dos.write(bs);
            dos.flush();
            dos.close();

            Log.e(TAG, "Response ->" + urlConnection.getResponseCode());
            Log.e(TAG, "response message ->" + urlConnection.getResponseMessage());
            if (urlConnection.getResponseCode() == 200) {
                InputStream is = urlConnection.getInputStream();
                long ch;
                StringBuffer b = new StringBuffer();
                while ((ch = is.read()) != -1) {
                    b.append((char) ch);
                }
                responseString = b.toString();
                Log.e(TAG, "responseString=" + responseString);

                bs = null;
                b = null;
                _url = null;
                urlConnection = null;


                return true;

            } // data sent successfully

        } catch (Exception e) {

            Log.d(TAG, "unable to post data ");

            return false;
        }

        return false;
    }


}

