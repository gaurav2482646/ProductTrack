package com.kochartech.gizmodoctor.DataBase;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.POJO.AppUsageDTO;

public class DataSource_CPUUsage {
	private String tag = DataSource_CPUUsage.class.getSimpleName();
	// private Context context;
	private static DataSource_CPUUsage classInstance = null;
	private MySQLiteOpenHelper mySQLiteOpenHelper;
	private SQLiteDatabase db;

	public static DataSource_CPUUsage getInstance(Context context) {
		if (classInstance == null)
			classInstance = new DataSource_CPUUsage(context);
		return classInstance;
	}

	private DataSource_CPUUsage(Context context) {
		LogWrite.d(tag, "constructor");
		// this.context = context;
		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
	}

	private void open() {
		LogWrite.d(tag, "open");
		db = mySQLiteOpenHelper.getWritableDatabase();
	}

	private void close() {
		LogWrite.d(tag, "close");
		db.close();
	}

	public synchronized void insertRecord(int appId, int cpuUsage, long time) {
		open();
		ContentValues values = new ContentValues();
		values.put(MySQLiteOpenHelper.CPUUSAGE_ColumnID, appId);
		values.put(MySQLiteOpenHelper.CPUUSAGE_ColumnUsage, cpuUsage);
		values.put(MySQLiteOpenHelper.CPUUSAGE_ColumnTime, time);

		long id = db.insert(MySQLiteOpenHelper.CPUUSAGE_TABLE, null, values);
		LogWrite.d(tag, "DataSource_CPUUsage insert id : " + id);

		close();
		// LogWrite.d(tag, "insertRecord: recordId: " + id);

	}

	public synchronized String getRecord(int recordId) {
		String cpu_usage = "0";
		open();
		LogWrite.d(tag, "----");
		Cursor cursor = db.query(MySQLiteOpenHelper.CPUUSAGE_TABLE, null,
				MySQLiteOpenHelper.CPUUSAGE_ColumnID + " =?",
				new String[] { String.valueOf(recordId) }, null, null, null);
		LogWrite.d(tag, "Cursor Size= " + cursor.getCount());
		if (cursor.getCount() > 0) {
			if (cursor.moveToNext()) {
				int index_Id = cursor
						.getColumnIndex(MySQLiteOpenHelper.CPUUSAGE_ColumnID);
				int index_Usage = cursor
						.getColumnIndex(MySQLiteOpenHelper.CPUUSAGE_ColumnUsage);
				int index_Time = cursor
						.getColumnIndex(MySQLiteOpenHelper.CPUUSAGE_ColumnTime);

				do {
					int id = cursor.getInt(index_Id);
					int usage = cursor.getInt(index_Usage);
					long time = cursor.getLong(index_Time);

					LogWrite.d(tag, "id= " + id);
					LogWrite.d(tag, "Usage= " + usage);
					LogWrite.d(tag, "Time= " + time);
					cpu_usage = ""+ usage;
				} while (cursor.moveToNext());
			}
		}
		close();
		return cpu_usage;
	}

	public synchronized AppUsageInfo queryAppDetail(int appId) {
		open();

		long queryTime = System.currentTimeMillis() - 60 * 60 * 1000;
		AppUsageInfo appinfo = new AppUsageInfo();
		appinfo.setAppId(appId);

		Cursor cursor = db
				.query(MySQLiteOpenHelper.CPUUSAGE_TABLE, null,
						MySQLiteOpenHelper.CPUUSAGE_ColumnID + " =? AND "
								+ MySQLiteOpenHelper.CPUUSAGE_ColumnTime
								+ " >=?", new String[] { String.valueOf(appId),
								String.valueOf(queryTime) }, null, null,
						MySQLiteOpenHelper.CPUUSAGE_ColumnTime + " DESC");

		ArrayList<AppUsageDTO> appUsageDTOList = new ArrayList<AppUsageDTO>();

		LogWrite.d(tag, "Cursor Size= " + cursor.getCount());
		if (cursor.getCount() > 0) {
			if (cursor.moveToNext()) {
				int index_Id = cursor
						.getColumnIndex(MySQLiteOpenHelper.CPUUSAGE_ColumnID);
				int index_Usage = cursor
						.getColumnIndex(MySQLiteOpenHelper.CPUUSAGE_ColumnUsage);
				int index_Time = cursor
						.getColumnIndex(MySQLiteOpenHelper.CPUUSAGE_ColumnTime);

				do {
					int id = cursor.getInt(index_Id);
					int usage = cursor.getInt(index_Usage);
					long time = cursor.getLong(index_Time);
					LogWrite.d(tag, "Query DataSource_CPUUsage id : " + id);
					AppUsageDTO appUsageDTO = new AppUsageDTO(usage, time);
					appUsageDTOList.add(appUsageDTO);
				} while (cursor.moveToNext());
			}
		}
		appinfo.setAppUsage(appUsageDTOList);
		close();
		return appinfo;
	}
}
