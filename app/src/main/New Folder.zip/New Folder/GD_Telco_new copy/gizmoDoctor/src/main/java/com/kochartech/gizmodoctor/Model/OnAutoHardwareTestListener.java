package com.kochartech.gizmodoctor.Model;

public interface OnAutoHardwareTestListener {
	void onHardwareTestFinish(int position, String testName,boolean result);
}
