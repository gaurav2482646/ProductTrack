package com.kochartech.devicemax.Receivers;



import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Utility.MyDataBaseHandlerClass;

public class PackageDeletedIntent extends BroadcastReceiver
{
	 
	@Override
	public void onReceive(Context context, Intent intent) 
	{    
		
		  MyDataBaseHandlerClass mydatabase=null;
		  mydatabase = new MyDataBaseHandlerClass(context,"operators.db",null,1);
		  mydatabase.getWritableDatabase();
		  //Toast.makeText(context, "App Del",Toast.LENGTH_SHORT).show();
		  String getData=intent.getData().toString();
		  String getPack;
		  ApplicationInfo ai ;
		 // PackageManager pm = context.getPackageManager();
		  String action= intent.getAction();
		  Log.i("U", "ACTION " + action);
		  LogWrite.d("data is",getData);
		  String[] arr;
		  arr=getData.split(":");
		  LogWrite.d("app package",arr[1]);
		  if(!arr[1].equalsIgnoreCase("com.kochar.MDMS"))
		  {
			//To start MDM again if stopped
			 // Toast.makeText(context, "in if ",Toast.LENGTH_LONG).show();
//			  Intent i=new Intent(context,PromptNumberActivity.class);
//			  i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//			  context.startActivity(i);
		  }
//		  else
//		  {
//			  Toast.makeText(context, "in else",Toast.LENGTH_LONG).show();
//		  }
		  mydatabase.DeleteAppbyPackage(arr[1]);
		  mydatabase.close(); 
	}

}
