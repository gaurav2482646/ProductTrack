//package com.kochartech.gizmodoctor.HardwareModel;
//
//import java.lang.reflect.Method;
//
//import android.content.Context;
//import android.hardware.Camera;
//import android.hardware.Camera.AutoFocusCallback;
//import android.hardware.Camera.Parameters;
//import android.hardware.camera2.CameraManager;
//import android.os.Build;
//import android.os.IBinder;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//
///**
// * Hardware Test for FlashLight ON/OFF state <br>
// * Uses permission: <b>android.permission.CAMERA </b>
// * 
// * @author aman.arora
// */
//@SuppressWarnings("deprecation")
//public class FlashLight {
//	private String TAG = FlashLight.class.getSimpleName();
//	private MarshTorch marshTorch;
//	private Camera cam;
//
//	public FlashLight(Context context) {
//		if (Build.VERSION.SDK_INT >= 23) {
//			marshTorch = new MarshTorch(context);
//		}
//	}
//
//	public void on() {
//		if (Build.VERSION.SDK_INT >= 23) {
//			try {
//				marshTorch.on(true);
//			} catch (ExceptionDTO e) {
//				e.printStackTrace();
//			}
//		} else {
//			ledon();
//		}
//	}
//
//	public void off() {
//		if (Build.VERSION.SDK_INT >= 23) {
//			try {
//				marshTorch.off(false);
//			} catch (ExceptionDTO e) {
//				e.printStackTrace();
//			}
//		} else {
//			ledoff();
//		}
//	}
//
//	/**
//	 * This method is used to check flash-light.
//	 */
//	private boolean ledon() {
//		boolean workFlag = false;
//		String manuName = android.os.Build.MANUFACTURER.toLowerCase();
//
//		if (manuName.toLowerCase().equals("micromax")
//				|| manuName.toLowerCase().equals("motorola")) {
//			DroidLED led;
//			try {
//				led = new DroidLED();
//				led.enable(true);
//				workFlag = true;
//			} catch (ExceptionDTO e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		} else {
//
//			try {
//				LogWrite.d(TAG, "FlashLight Check.....");
//				// KTCamera camera = new KTCamera(activity);
//				// cam = camera.getBackCameraInstance();
//				cam = Camera.open();
//				Parameters params = cam.getParameters();
//				params.setFlashMode(Parameters.FLASH_MODE_TORCH);
//				cam.setParameters(params);
//				cam.startPreview();
//				cam.autoFocus(new AutoFocusCallback() {
//					public void onAutoFocus(boolean success, Camera camera) {
//					}
//				});
//				workFlag = true;
//			} catch (ExceptionDTO e) {
//				e.printStackTrace();
//				LogWrite.e(TAG, "FlashException : " + e.toString());
//			}
//		}
//		return workFlag;
//	}
//
//	private void ledoff() {
//		String manuName = android.os.Build.MANUFACTURER.toLowerCase();
//		if (manuName.toLowerCase().equals("micromax")
//				|| manuName.toLowerCase().equals("motorola")) {
//			DroidLED led;
//			try {
//				led = new DroidLED();
//				led.enable(false);
//			} catch (ExceptionDTO e) {
//				e.printStackTrace();
//			}
//		} else {
//			if (cam != null) {
//				cam.stopPreview();
//				try {
//					cam.release();
//				} catch (ExceptionDTO e) {
//					e.printStackTrace();
//				}
//			}
//		}
//	}
//
//	private class MarshTorch {
//		private CameraManager mCameraManager;
//
//		public MarshTorch(Context context) {
//			mCameraManager = (CameraManager) context
//					.getSystemService(Context.CAMERA_SERVICE);
//		}
//
//		public void on(boolean flag) throws ExceptionDTO {
//			String cameraId = mCameraManager.getCameraIdList()[0]; // Usually
//																	// front
//																	// camera is
//																	// at 0
//																	// position.
//			mCameraManager.setTorchMode(cameraId, flag);
//			// mCameraManager.registerTorchCallback(torchCallback, null);
//		}
//
//		public void off(boolean flag) throws ExceptionDTO {
//			String cameraId = mCameraManager.getCameraIdList()[0]; // Usually
//																	// front
//																	// camera is
//																	// at 0
//																	// position.
//			mCameraManager.setTorchMode(cameraId, flag);
//			// mCameraManager.unregisterTorchCallback(torchCallback);
//		}
//
//		// CameraManager.TorchCallback torchCallback = new
//		// CameraManager.TorchCallback() {
//		// @Override
//		// public void onTorchModeUnavailable(String cameraId) {
//		// PrintLog.i(TAG, "onTorchModeUnavailable method enters");
//		// super.onTorchModeUnavailable(cameraId);
//		// }
//		//
//		// @Override
//		// public void onTorchModeChanged(String cameraId, boolean enabled) {
//		// super.onTorchModeChanged(cameraId, enabled);
//		// PrintLog.i(TAG, "onTorchModeChanged method enters : " + enabled);
//		// boolean currentTorchState = enabled;
//		// try {
//		// mCameraManager.setTorchMode(cameraId, !currentTorchState);
//		// } catch (CameraAccessException e) {
//		// }
//		//
//		// }
//		// };
//	}
//
//	class DroidLED {
//		private Object svc = null;
//		private Method getFlashlightEnabled = null;
//		private Method setFlashlightEnabled = null;
//
//		public DroidLED() throws ExceptionDTO {
//			try {
//				// call ServiceManager.getService("hardware") to get an IBinder
//				// for the service.
//				// this appears to be totally undocumented and not exposed in
//				// the SDK whatsoever.
//				Class<?> sm = Class.forName("android.os.ServiceManager");
//				Object hwBinder = sm.getMethod("getService", String.class)
//						.invoke(null, "hardware");
//
//				// get the hardware service stub. this seems to just get us one
//				// step closer to the proxy
//				Class<?> hwsstub = Class
//						.forName("android.os.IHardwareService$Stub");
//				Method asInterface = hwsstub.getMethod("asInterface",
//						android.os.IBinder.class);
//				svc = asInterface.invoke(null, (IBinder) hwBinder);
//
//				// grab the class (android.os.IHardwareService$Stub$Proxy) so we
//				// can reflect on its methods
//				Class<? extends Object> proxy = svc.getClass();
//
//				// save methods
//				getFlashlightEnabled = proxy.getMethod("getFlashlightEnabled");
//				setFlashlightEnabled = proxy.getMethod("setFlashlightEnabled",
//						boolean.class);
//			} catch (ExceptionDTO e) {
//				throw new ExceptionDTO("LED could not be initialized");
//			}
//		}
//
//		public boolean isEnabled() {
//			try {
//				return getFlashlightEnabled.invoke(svc).equals(true);
//			} catch (ExceptionDTO e) {
//				return false;
//			}
//		}
//
//		public void enable(boolean tf) {
//			try {
//				setFlashlightEnabled.invoke(svc, tf);
//			} catch (ExceptionDTO e) {
//			}
//		}
//	}
//}
