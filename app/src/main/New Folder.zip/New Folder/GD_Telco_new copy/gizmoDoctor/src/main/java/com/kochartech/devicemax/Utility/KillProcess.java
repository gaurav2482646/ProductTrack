package com.kochartech.devicemax.Utility;

import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.DataBase.AppInfo;
import com.kochartech.gizmodoctor.DataBase.DataSource_AppsInfo;

public class KillProcess {
	private String TAG = KillProcess.class.getSimpleName();
	private Context context;

	public KillProcess(Context context) {
		this.context = context;
	}

	public String getProcessName(String appName) {
		DataSource_AppsInfo dsApps = DataSource_AppsInfo.getInstance(context);
		List<AppInfo> apps = dsApps.queryAllRecord();
		LogWrite.d(TAG, "AppsInDB: numApps: " + apps.size());
		for (AppInfo appInfo : apps) {
			if (appInfo.getAppName().equals(appName))
				return appInfo.getPkName();
		}
		return "";
	}

	public boolean killProcess(String processName) {
		ActivityManager manager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> activityes = ((ActivityManager) manager)
				.getRunningAppProcesses();
		for (int iCnt = 0; iCnt < activityes.size(); iCnt++) {
			System.out.println("APP: " + iCnt + " "
					+ activityes.get(iCnt).processName);
			if (activityes.get(iCnt).processName.contains(processName)) {
				android.os.Process.sendSignal(activityes.get(iCnt).pid,
						android.os.Process.SIGNAL_KILL);
				android.os.Process.killProcess(activityes.get(iCnt).pid);
				System.out.println("Inside if");
				break;
			}
		}
		List<ApplicationInfo> packages;
		PackageManager pm;
		pm = context.getPackageManager();
		// get a list of installed apps.
		packages = pm.getInstalledApplications(0);
		ActivityManager mActivityManager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);

		for (ApplicationInfo packageInfo : packages) {
			if ((packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 1)
				continue;
			if (packageInfo.packageName.equals(processName)) {
				mActivityManager
						.killBackgroundProcesses(packageInfo.packageName);
				break;
			}
		}
		return true;
	}

	public boolean killAll() {
		LogWrite.d(TAG, "All processes going to be kill....");
		ActivityManager manager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> activityes = ((ActivityManager) manager)
				.getRunningAppProcesses();
		for (int iCnt = 0; iCnt < activityes.size(); iCnt++) {

			if (activityes.get(iCnt).processName.equals(context
					.getApplicationContext().getPackageName()))
				continue;
			LogWrite.i(TAG, "Killing Processes... "
					+ activityes.get(iCnt).processName);
			android.os.Process.sendSignal(activityes.get(iCnt).pid,
					android.os.Process.SIGNAL_KILL);
			android.os.Process.killProcess(activityes.get(iCnt).pid);
			LogWrite.d(TAG, "Inside If");
		}

		List<ApplicationInfo> packages;
		PackageManager pm;
		pm = context.getPackageManager();
		// get a list of installed apps.
		packages = pm.getInstalledApplications(0);
		ActivityManager mActivityManager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);

		for (ApplicationInfo packageInfo : packages) {
			if ((packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 1)
				continue;
			if (packageInfo.packageName.equals(context.getApplicationContext()
					.getPackageName()))
				continue;
			mActivityManager.killBackgroundProcesses(packageInfo.packageName);
			// KillApplication(packageInfo.packageName);
		}
		return true;
	}

	// private void KillApplication(String KillPackage) {
	// ActivityManager am = (ActivityManager) context
	// .getSystemService(Context.ACTIVITY_SERVICE);
	//
	// Intent startMain = new Intent(Intent.ACTION_MAIN);
	// startMain.addCategory(Intent.CATEGORY_HOME);
	// startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	// context.startActivity(startMain);
	//
	// am.killBackgroundProcesses(KillPackage);
	// Toast.makeText(context, "Process Killed : " + KillPackage,
	// Toast.LENGTH_LONG).show();
	// }
}
