package com.kochartech.devicemax.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Started on Adding Application Package to the device before the main activity
 * starts and do all the functionalities.
 * 
 * @author nishant.kumar
 * 
 */
public class PackageAddedIntent extends BroadcastReceiver 
{
	static String tag = "PackageAddedIntent";
	@Override
	public void onReceive(Context context, Intent intent) 
	{
//		LogWrite.d(tag, "INSIDE ONRECIEVE() >: New Package Added.Starting...");
//		MyDataBaseHandlerClass mydatabase = null;
//		mydatabase = new MyDataBaseHandlerClass(context, "operators.db", null,
//				1);
//		mydatabase.getWritableDatabase();
//		// Toast.makeText(context,
//		// "New Application Installed",Toast.LENGTH_SHORT).show();
//		String getData = intent.getData().toString();
//		String getPack;
//		ApplicationInfo ai;
//		PackageManager pm = context.getPackageManager();
//		// LogWrite.d("package is",context.getPackageName());
//		// String packAGE=context.getPackageName();
//		String[] arr;
//		arr = getData.split(":");
//		try {
//			ai = pm.getApplicationInfo(arr[1], 0);
//
//			// ai=pm.getApplicationInfo(context.getPackageName(),0);
//			pm.getApplicationLabel(ai);
//			LogWrite.d("app name is", pm.getApplicationLabel(ai) + "");
//			String getAppName = (String) pm.getApplicationLabel(ai);
//			String packageName = arr[1];
//
//			if (!getAppName.equalsIgnoreCase(context.getString(R.string.app_name))) 
//			{
//				mydatabase.AddApplicationInfo(getAppName, packageName, 1, 0, 0,"E",0);
//				mydatabase.close();
//				// To start MDM again if stopped
//				// Intent i=new Intent(context,PromptNumberActivity.class);
//				// i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				// context.startActivity(i);
//			}
//
//			// singelton.WriteToFile("New Application is Installed:"+pm.getApplicationLabel(ai));
//		} catch (NameNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		// LogWrite.d("package name is",getData);
	}// End onReceive
}// END CLASS
