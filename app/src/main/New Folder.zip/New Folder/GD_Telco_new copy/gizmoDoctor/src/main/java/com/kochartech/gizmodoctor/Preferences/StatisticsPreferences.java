package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class StatisticsPreferences {
	
	private final String PREFERENCE_NAME = "gizmodoctor";
	private final int    PREFERENCE_MODE = 0;	
	
	private String KEY_LastScanTime = "stats_last_scan_time";
		
	public  final long DEFAULTVALUE_IsAlarmAlive = System.currentTimeMillis();
		
	private Context context;
	private SharedPreferences myPreference;
	private Editor editor;
	
	public StatisticsPreferences(Context context) {
		this.context = context;
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();		
	}

	private long getKEY_IsAlarmAlive() {
		return myPreference.getLong(KEY_LastScanTime, DEFAULTVALUE_IsAlarmAlive);
	}

	public void setKEY_IsAlarmAlive(long value) {
		editor.putLong(KEY_LastScanTime, value).commit();
	}
	
	public void isAlarmAlive() {
		long lastScanTime = getKEY_IsAlarmAlive();		
		long currentScanTime = System.currentTimeMillis();
		
		
		
	}
}
