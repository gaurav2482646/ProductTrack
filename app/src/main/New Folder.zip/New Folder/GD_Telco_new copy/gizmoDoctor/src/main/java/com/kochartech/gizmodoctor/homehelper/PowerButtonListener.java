package com.kochartech.gizmodoctor.homehelper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.library.Battery.KTBatteryInfo;

public class PowerButtonListener extends BroadcastReceiver {
	private String TAG = PowerButtonListener.class.getSimpleName();
	private Context context;
	private KTBatteryInfo batteryInfo;
	private OnPowerPressedListener onPowerPressedListener;
	final String SYSTEM_DIALOG_REASON_KEY = "reason";
	final String SYSTEM_DIALOG_REASON_GLOBAL_ACTIONS = "globalactions";

	public PowerButtonListener(Context context) {
		this.context = context;
		batteryInfo = KTBatteryInfo.getInstance();
		batteryInfo.calculate(context);
	}

	public void register(OnPowerPressedListener onPowerPressedListener) {
		LogWrite.d(TAG, "register method enter!");
		try {
			IntentFilter filter = new IntentFilter();
			filter.addAction(Intent.ACTION_POWER_CONNECTED);
			filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
			filter.addAction(Intent.ACTION_SCREEN_ON);
			filter.addAction(Intent.ACTION_SCREEN_OFF);
			filter.addAction(Intent.ACTION_SHUTDOWN);
			filter.addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
			context.registerReceiver(this, filter);
		} catch (Exception e) {
			LogWrite.e(TAG, "register method exception : " + e.toString());
		}
		this.onPowerPressedListener = onPowerPressedListener;
	}

	public void unregister() {
		LogWrite.d(TAG, "unregister method enter!");
		try {
			context.unregisterReceiver(this);
		} catch (Exception e) {
			LogWrite.e(TAG, "unregister method exception : " + e.toString());
		}
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		LogWrite.i(TAG, "ActionString : " + intent.getAction());
		if (intent.getAction().toString()
				.equals(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)) {
			try {
				LogWrite.i(TAG, "----------------------1");
				String reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY);
				LogWrite.i(TAG, "----------------------2");
				if (reason.equals(SYSTEM_DIALOG_REASON_GLOBAL_ACTIONS)) {
					LogWrite.i(TAG, "----------------------3");
					LogWrite.i(TAG, "Long press on power button");
					onPowerPressedListener.onPowerKeyPressed(true);
				}
			} catch (Exception e) {
				e.printStackTrace();
				LogWrite.e(
						TAG,
						"ACTION_CLOSE_SYSTEM_DIALOGS_EXCEPTION : "
								+ e.toString());
			}
		} else {

			if (batteryInfo.getBatteryLevel() > 5) {
				LogWrite.d(TAG, "Power button clicked!");
				onPowerPressedListener.onPowerKeyPressed(true);
			} else {
				onPowerPressedListener.onPowerKeyPressed(false);
			}
		}
	}
}
