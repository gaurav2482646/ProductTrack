package com.kochartech.devicemax.AsyncTask;
//package com.kochar.AsyncTask;
//
//import java.lang.reflect.Method;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.Semaphore;
//
//import com.kochar.MDMS.Activities.LogWrite;
//import com.kochar.MDMS.Activities.R;
//import com.kochar.MDMS.Activities.RegisterUserActivity;
//import com.kochar.MDMS.Utility.AppSizer;
//
//import android.content.pm.ApplicationInfo;
//import android.content.pm.IPackageStatsObserver;
//import android.content.pm.PackageManager;
//import android.content.pm.PackageStats;
//import android.os.AsyncTask;
//import android.os.RemoteException;
//import android.util.Log;
//
//public class AppSizeAsync extends AsyncTask<String, String, String>
//{
//
//	protected String doInBackground(String... arg0) {
//		// TODO Auto-generated method stub
//		ArrayList<String> arrayList = new ArrayList<String>();
//		arrayList.add("email");
//		arrayList.add("camera");
//		arrayList.add("gmail");
//		arrayList.add("google play store");
//		arrayList.add("facebook");
//		arrayList.add("browser");
//		arrayList.add("internet");
//		arrayList.add("youtube");
//		arrayList.add("maps");
//		arrayList.add("superuser");
//		
//		PackageManager packageManager = RegisterUserActivity.GetInstance().getPackageManager();
//
//
////		final PackageManager packageManager = context.getPackageManager();
//		List<ApplicationInfo> installedApplications = 
//		    packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
//
//		// Semaphore to handle concurrency
//		final Semaphore codeSizeSemaphore = new Semaphore(1, true);
//
//		// Code size will be here
//		long codeSize = 0;
//
//		for (ApplicationInfo appInfo : installedApplications)
//		{
//			 if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 1)
//		     {
//		            //System app
//				 continue;
//		     }
//			 else
//			 {
//			    try
//			    {
//			        codeSizeSemaphore.acquire();
//			    }
//			    catch (InterruptedException e)
//			    {
//			        e.printStackTrace(System.err);
//			    }
//			    
//			    // Collect some other statistics
//			    
//			    // Collect code size
//			    try 
//			    {
//			        Method getPackageSizeInfo = 
//			            packageManager.getClass().getMethod("getPackageSizeInfo", 
//			                                                String.class,
//			                                                IPackageStatsObserver.class);
////			        Log.d(tag,"package Name ="+appInfo.packageName);
//			        getPackageSizeInfo.invoke(packageManager, appInfo.packageName, 
//			                                  new IPackageStatsObserver.Stub()
//			        {
//			            // Examples in the Internet usually have this method as @Override.
//			            // I got an error with @Override. Perfectly works without it.
//			            public void onGetStatsCompleted(PackageStats pStats, boolean succeedded) 
//			                throws    RemoteException
//			            {
//			              if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 1)
//						  {
//			            	if (!list.get(n).loadLabel(pm).toString().equalsIgnoreCase(RegisterUserActivity.GetInstance().getString(R.string.app_name)))
//							{
//								
////								AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
////										list.get(n).packageName,
////										1,
////										0,
////										0,
////										"E",AppSizer.getSize(RegisterUserActivity.GetInstance(), list.get(n).packageName));
//								
//							}
//							else if(arrayList.contains(list.get(n).loadLabel(pm).toString().toLowerCase()))
//								{
////									AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
////										list.get(n).packageName,
////										0,
////										0,
////										0,
////										"E",AppSizer.getSize(RegisterUserActivity.GetInstance(), list.get(n).packageName));
//								}
//						}
//						//to block some apps given in the list
//						else
//						{
//							if(arrayList.contains(list.get(n).loadLabel(pm).toString().toLowerCase()))
//							{
////								AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
////									list.get(n).packageName,
////									0,
////									0,
////									0,
////									"I",AppSizer.getSize(RegisterUserActivity.GetInstance(), list.get(n).packageName));
//							}
//						}
////			            	SharedPreferences sharedPreferences = PreferenceManager
////									.getDefaultSharedPreferences(context));
////							Editor editor = sharedPreferences.edit();
//							
//			            
//			            	long codeSize = pStats.codeSize/1024;
////			            	hash.put("ashish", new Long(codeSize));
////			            	hash.put("sharma", new Long(codeSize));
////			            	
//			                codeSizeSemaphore.release();
//			                
//			                
////			                Log.d(tag,"code size ="+codeSize/1024);
//			            }
//			        });
//			    }
//			    catch (ExceptionDTO e)
//			    {
//			        e.printStackTrace(System.err);
//			    }
//			}
//		}
//		
//		try
//		{
//			PackageManager pm = RegisterUserActivity.GetInstance().getPackageManager();
//			List<ApplicationInfo> list =RegisterUserActivity.GetInstance().
//			getPackageManager().getInstalledApplications(PackageManager.GET_UNINSTALLED_PACKAGES);
//			for (int n = 0; n < list.size(); n++)
//			{
//				LogWrite.d("Application Installed", list.get(n).loadLabel(pm).toString());
//				//
//				if ((list.get(n).flags & ApplicationInfo.FLAG_SYSTEM) != 1)
//				{
//					// 1 to unblock apps  0 to block third party app
//					if (!list.get(n).loadLabel(pm).toString().equalsIgnoreCase(RegisterUserActivity.GetInstance().getString(R.string.app_name)))
//					{
//						
//						AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
//								list.get(n).packageName,
//								1,
//								0,
//								0,
//								"E",AppSizer.getSize(RegisterUserActivity.GetInstance(), list.get(n).packageName));
//						
//					}
//					else if(arrayList.contains(list.get(n).loadLabel(pm).toString().toLowerCase()))
//						{
//							AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
//								list.get(n).packageName,
//								0,
//								0,
//								0,
//								"E",AppSizer.getSize(RegisterUserActivity.GetInstance(), list.get(n).packageName));
//						}
//				}
//				//to block some apps given in the list
//				else
//				{
//					if(arrayList.contains(list.get(n).loadLabel(pm).toString().toLowerCase()))
//					{
//						AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
//							list.get(n).packageName,
//							0,
//							0,
//							0,
//							"I",AppSizer.getSize(RegisterUserActivity.GetInstance(), list.get(n).packageName));
//					}
//				}
//			}
//		}
//		catch (ExceptionDTO e)
//		{
//			Log.e(tag,e+"");
//		}
//		return null;
//	}
//
//}
