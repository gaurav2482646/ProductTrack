package com.kochartech.gizmodoctor.Preferences;

import java.util.ArrayList;

import android.content.Context;

import com.kochartech.gizmodoctor.POJO.KeyValueDTO;

public class PowerSavingSettingsPreference extends MyPreference{

//	private final String PREFERENCE_NAME = "gizmodoctor";
//	private final int PREFERENCE_MODE = 0;

	private final String KEY_COMPLETE_POWERSAVING_TOGGLE = "complete_toggle_state";
	private final String KEY_CUSTOM_POWERSAVING_TOGGLE = "custom_toggle_state";

	private final boolean DEAFULT_COMPLETE_POWERSAVING_TOGGLE = false;
	private final boolean DEAFULT_CUSTOM_POWERSAVING_TOGGLE = false;

	private final String KEY_COMPLETE_POWERSAVING_BATTERYLIMIT = "batterylimitCompleProfile";
	private final String KEY_CUSTOM_POWERSAVING_BATTERYLIMIT = "batterylimitCUSTOMProfile";

	private final int DEAFULT_COMPLETE_POWERSAVING_BATTERYLIMIT = 20;
	private final int DEAFULT_CUSTOM_POWERSAVING_BATTERYLIMIT = 30;

	
	
//	private SharedPreferences myPreference;
//	private Editor editor;

	private final String arrayPrefix = "arrayPrefix";

	public PowerSavingSettingsPreference(Context context) {
		super(context);
//		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
//				PREFERENCE_MODE);
//		editor = myPreference.edit();
	}

	public boolean getPreference(int itemIndex) {
		return myPreference.getBoolean(arrayPrefix + itemIndex, false);

	}

	public void setPreference(int itemIndex, boolean value) {
		editor.putBoolean(arrayPrefix + itemIndex, value).commit();
	}

	public ArrayList<Boolean> getArrayOfState(int size) {
		ArrayList<Boolean> arrayOfState = new ArrayList<Boolean>();
		for (int i = 0; i < size; i++) {
			arrayOfState.add(getPreference(i));
		}
		return arrayOfState;
	}

	public void setToggleStateCompletePowerSaving(boolean value) {
		editor.putBoolean(KEY_COMPLETE_POWERSAVING_TOGGLE, value).commit();
	}

	public boolean getToggleStateCompletePowerSaving() {
		return myPreference.getBoolean(KEY_COMPLETE_POWERSAVING_TOGGLE,
				DEAFULT_COMPLETE_POWERSAVING_TOGGLE);
	}

	public void setToggleStateCustomPowerSaving(boolean value) {
		editor.putBoolean(KEY_CUSTOM_POWERSAVING_TOGGLE, value).commit();
	}

	public boolean getToggleStateCustomPowerSaving() {
		return myPreference.getBoolean(KEY_CUSTOM_POWERSAVING_TOGGLE,
				DEAFULT_CUSTOM_POWERSAVING_TOGGLE);
	}
	
	
	public void setBatteryLimitCompletePowerSaving(int value) {
		editor.putInt(KEY_COMPLETE_POWERSAVING_BATTERYLIMIT, value).commit();
	}

	public int getBatteryLimitCompletePowerSaving() {
		return myPreference.getInt(KEY_COMPLETE_POWERSAVING_BATTERYLIMIT,
				DEAFULT_COMPLETE_POWERSAVING_BATTERYLIMIT);
	}
	public KeyValueDTO getKeyValueDTO_BatteryLimitCompletePowerSavingPreference() {
		KeyValueDTO keyValueDTO = new KeyValueDTO(KEY_COMPLETE_POWERSAVING_BATTERYLIMIT, getBatteryLimitCompletePowerSaving());
		return keyValueDTO;
	}	
	
	
	public void setBatteryLimitCustomPowerSaving(int value) {
		editor.putInt(KEY_CUSTOM_POWERSAVING_BATTERYLIMIT, value).commit();
	}

	public int getBatteryLimitCustomPowerSaving() {
		return myPreference.getInt(KEY_CUSTOM_POWERSAVING_BATTERYLIMIT,
				DEAFULT_CUSTOM_POWERSAVING_BATTERYLIMIT);
	}
	
	public KeyValueDTO getKeyValueDTO_BatteryLimitCustomPowerSavingPreference() {
		KeyValueDTO keyValueDTO = new KeyValueDTO(KEY_CUSTOM_POWERSAVING_BATTERYLIMIT, getBatteryLimitCustomPowerSaving());
		return keyValueDTO;
	}	
	
	
	
	
}
