package com.kochartech.gizmodoctor.HardwareModel;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class FlashState {
	private String PREFRENCE_NAME = "KEY_CAMERA_FLASH";
	private String KEY_FLASH_STATUS = "key_flash_status";
	private boolean state = false;
	private SharedPreferences prefrences;
	private Editor editor;

	public FlashState(Context context) {
		prefrences = context.getSharedPreferences(PREFRENCE_NAME,
				Context.MODE_PRIVATE);
		editor = prefrences.edit();
	}

	public boolean isEnable() {
		return prefrences.getBoolean(KEY_FLASH_STATUS, state);
	}

	public void setEnable(boolean state) {
		editor.putBoolean(KEY_FLASH_STATUS, state).commit();
	}

	public void clear() {
		editor.clear().commit();
	}
}
