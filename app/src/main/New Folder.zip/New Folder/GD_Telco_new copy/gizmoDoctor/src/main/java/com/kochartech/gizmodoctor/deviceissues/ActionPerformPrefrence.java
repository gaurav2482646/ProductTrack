package com.kochartech.gizmodoctor.deviceissues;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class ActionPerformPrefrence {
	private String PREFRENCE_NAME = ActionPerformPrefrence.class
			.getSimpleName();
	private SharedPreferences preferences;
	private Editor editor;

	private String KEY_ACTION_TO_PERFORM = "action_to_perform";

	public static final int ACTION_NO = 0;
	public static final int ACTION_FORCE_CLOSE = 1;
	public static final int ACTION_UNINSTALL = 2;
	public static final int ACTION_GPS = 3;

	public ActionPerformPrefrence(Context context) {
		preferences = context.getSharedPreferences(PREFRENCE_NAME,
				Context.MODE_PRIVATE);
		editor = preferences.edit();
	}

	public void setActionToPerform(int action) {
		editor.putInt(KEY_ACTION_TO_PERFORM, action).commit();
	}

	public int getActionToPerform() {
		return preferences.getInt(KEY_ACTION_TO_PERFORM, ACTION_NO);
	}

	public void clear() {
		editor.clear().commit();
	}

}
