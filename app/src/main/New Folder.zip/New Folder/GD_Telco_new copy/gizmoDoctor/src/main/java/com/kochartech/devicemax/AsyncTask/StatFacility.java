package com.kochartech.devicemax.AsyncTask;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import com.kochartech.devicemax.Activities.LogWrite;

public class StatFacility 
{
	private static String tag="StatFacility";
	public static String getDowanloadSpeed()
	{
		LogWrite.d(tag,"getDowanloadSpeed  Work");
		final String filePath = "http://202.164.36.66/1mb/1mb.zip";
		int fileSize ;
		try
		{
			URL url = new URL(filePath);
			URLConnection conection = url.openConnection();
			conection.connect();
			int lengthOfFile = conection.getContentLength();
			fileSize = lengthOfFile / 1024;
		}
		catch (MalformedURLException e) 
		{
		}
		catch (IOException e)
		{
		}
		return null;
		
	}
}
