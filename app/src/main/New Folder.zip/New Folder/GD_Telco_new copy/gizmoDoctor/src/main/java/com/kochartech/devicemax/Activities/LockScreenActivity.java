//package com.kochartech.devicemax.Activities;
//
//import android.app.Activity;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.Window;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Toast;
//
//import com.kochartech.devicemax.Services.MyService;
//import com.kochartech.gizmodoctor.R;
//
//public class LockScreenActivity extends Activity
//{
//	public static boolean lockScreenFocus = true;
//	String TAG = "LockScreenActivity";
//
//	Button buttonStopService = null;
//	EditText editPassword = null;
//	Context context = null;
//	Intent intent = null;
//	boolean isServiceFound = false;
//	public static boolean stopServiceFlag = true;
//
//	/** Called when the activity is first created. */
//	@Override
//	public void onCreate(Bundle savedInstanceState)
//	{
//		super.onCreate(savedInstanceState);
//		setContentView(R.layout.main);
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		context = getApplicationContext();
//		editPassword = (EditText) findViewById(R.id.editPassword);
//		buttonStopService = (Button) findViewById(R.id.button1);
//		buttonStopService.setOnClickListener(new OnClickListener()
//		{
//			public void onClick(View v)
//			{
//				if (intent != null)
//				{
//					if (editPassword.length() > 0)
//					{
//						String fetchedPassword =	editPassword.getText().toString();
//						SharedPreferences preferences =	getSharedPreferences("registerUser", Context.MODE_PRIVATE);
//						String password =preferences.getString("userPassword", "default");
//						if (password.equals("default"))
//						{
//							Toast.makeText(context, "default password", 2000).show();
//						}
//						else
//						{
//							Toast.makeText(context, password, 2000).show();
//							if (password.equals(fetchedPassword))
//							{
//								lockScreenFocus = true;
//								stopServiceFlag = false;
//							}
//						}
//					}
//					LogWrite.d(TAG, "Service Stopped " + lockScreenFocus);
//				}
//			}
//		});
//		intent = new Intent(this, MyService.class);
//		startService(intent);
//	}
//
////	private boolean isMyServiceRunning()
////	{
////		ActivityManager manager =	(ActivityManager) getSystemService(ACTIVITY_SERVICE);
////		// LogWrite.d("------------","--call isMyServiceRunning--");
////		for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE))
////		{
////			// LogWrite.d("------------","--for isMyServiceRunning--");
////			if ("com.kochar.dm.MyService".equals(service.service.getClassName()))
////			{
////				// LogWrite.d("------------","--if isMyServiceRunning--");
////				isServiceFound = true;
////// AdminReceiver.editor.putBoolean("saved_isServiceFound",isServiceFound);
////// AdminReceiver.editor.commit();
////				return isServiceFound;
////// return true;
////			}
////		}
////		return false;
////	}// is my service running
//
//	@Override
//	public void onWindowFocusChanged(boolean hasFocus)
//	{
//		super.onWindowFocusChanged(hasFocus);
//		if (!hasFocus)
//		{
//			lockScreenFocus = false;
//			LogWrite.d(TAG, hasFocus + " has focus ");
//		} else
//		{
//			lockScreenFocus = true;
//			LogWrite.d(TAG, hasFocus + " has focus ");
//		}
//
//	}
//}