package com.kochartech.devicemax.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.kochartech.devicemax.Activities.LogWrite;


public class NetworkStateChangeListener extends BroadcastReceiver
{
	public void onReceive(Context context, Intent intent) 
	{
		 LogWrite.d("NetworkStateChange","NetworkStateChange");
	     if(intent.getExtras()!=null)
	     {
	        NetworkInfo ni=(NetworkInfo) intent.getExtras().get(ConnectivityManager.EXTRA_NETWORK_INFO);
	        if(ni!=null && ni.getState()==NetworkInfo.State.CONNECTED)
	        {
	        	LogWrite.d("NetworkStateChange","Connected");
	        	
	        } 
	        else  
	        {
	        	LogWrite.d("NetworkStateChange","DisConnected");
	        }
	     }
	}
}
