package com.kochartech.devicemax.Receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import com.kochartech.devicemax.Services.DownloadAppLatestService;

/**
 * Created by gauravjeetsingh on 29/3/18.
 */

public class BroadcastDownloaderManager extends BroadcastReceiver {

    private String tag = "BroadcastDownloadMngr";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(tag, "in on receive");
        try {
            DownloadAppLatestService service = new DownloadAppLatestService();
            service.new BroadcastAsync(context, intent).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } catch (Exception e) {
            Log.e(tag, "exception: " + e.toString());
        }
    }

}