package com.kochartech.gizmodoctor.Receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.kochartech.HttpConn.HttpAsync;
import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.Activity.GUIRegistration;
import com.kochartech.gizmodoctor.Preferences.ActivationKeyPreference;

public class HttpResultReceiver extends BroadcastReceiver{

	private String TAG = HttpResultReceiver.class.getSimpleName();
	private ActivationKeyPreference activationKeyPreference;
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
		String serverResponseMsg;
		
		activationKeyPreference = new ActivationKeyPreference(context);
		Bundle bundle = intent.getExtras();
		
		if(bundle.containsKey(HttpAsync.EXTRA_CONNECT_STATUS))		
			LogWrite.d(TAG, "EXTRA_CONNECT_STATUS: "+bundle.getBoolean(HttpAsync.EXTRA_CONNECT_STATUS));
		if(bundle.containsKey(HttpAsync.EXTRA_WRITE_STATUS))
			LogWrite.d(TAG, "EXTRA_WRITE_STATUS: "+bundle.getBoolean(HttpAsync.EXTRA_WRITE_STATUS));
		if(bundle.containsKey(HttpAsync.EXTRA_READ_STATUS))
			LogWrite.d(TAG, "EXTRA_READ_STATUS: "+bundle.getBoolean(HttpAsync.EXTRA_READ_STATUS));
		if(bundle.containsKey(HttpAsync.EXTRA_READ_MSG))
			LogWrite.d(TAG, "EXTRA_READ_MSG: "+bundle.getString(HttpAsync.EXTRA_READ_MSG));
		
		
		serverResponseMsg = bundle.getString(HttpAsync.EXTRA_READ_MSG);
		if(serverResponseMsg!= null) 
		{
			if(serverResponseMsg.trim().length()>0) 
			{		
				String serverResponseMessage = serverResponseMsg.replace("\"", "").trim();
				LogWrite.d(TAG, "serverResponseMessage: "+serverResponseMessage);
				if (GUIRegistration.isNumOfDaysReceived(serverResponseMessage))
				{
						int numOfDays = Integer.valueOf(serverResponseMessage);
						if (numOfDays > 0)
						{						
							//Num of Days greater than 0 it means Activation key is Valid. 
							long numOfDaysInMilliSeconds = GUIRegistration.convertDaysToMilliseconds(numOfDays);
							LogWrite.d(TAG, "NumOfDays in Milliseconds: "+ numOfDaysInMilliSeconds);
		
							activationKeyPreference.setIsActivationKeyRegister(true);
							activationKeyPreference.setLeftTime(numOfDaysInMilliSeconds);
							activationKeyPreference.setLastScanTime(System.currentTimeMillis());					
							
						}				
				 }
			}
		}
	}
}
