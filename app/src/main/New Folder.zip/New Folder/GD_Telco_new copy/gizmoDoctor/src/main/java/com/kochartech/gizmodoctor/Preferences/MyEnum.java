package com.kochartech.gizmodoctor.Preferences;


public class MyEnum {
	
	public enum PREFERENCES_KEYS {
		DEVICE_ONOFF("DEVICE_ONOFF");
		
		private String preferenceKey;       
	    private PREFERENCES_KEYS(String preferenceKey) {
	    	this.preferenceKey = preferenceKey;
	    }
	    public String getValue() {
	    	return preferenceKey;
	    }   
		
	}
}
