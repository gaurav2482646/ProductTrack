package com.kochartech.gizmodoctor.CustomView;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.POJO.SoftKey;

public class CustomGridAdapter extends BaseAdapter {

	private Context context;
	private final ArrayList<SoftKey> gridValues;

	// Constructor to initialize values
	public CustomGridAdapter(Context context, ArrayList<SoftKey> gridValues) {

		this.context = context;
		this.gridValues = gridValues;
	}

	@Override
	public int getCount() {

		// Number of times getView method call depends upon gridValues.length
		return gridValues.size();
	}

	@Override
	public SoftKey getItem(int position) {
		return gridValues.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	// Number of times getView method call depends upon gridValues.length

	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View gridView;
		if (convertView == null) {
			gridView = inflater.inflate(R.layout.grid_view_field, null);
		} else {
			gridView = (View) convertView;
		}
		SoftKey softKey = gridValues.get(position);
		// set value into textview
		TextView textView = (TextView) gridView
				.findViewById(R.id.grid_field_title);
		textView.setText(softKey.getName());

		TextView textView1 = (TextView) gridView
				.findViewById(R.id.grid_field_description);
		textView1.setText(softKey.getDescription());

		ImageView imageView = (ImageView) gridView
				.findViewById(R.id.grid_field_image);
		imageView.setImageResource(softKey.getIcon());

		return gridView;
	}
}
