package com.kochartech.gizmodoctor.Fragment;

import java.util.Timer;
import java.util.TimerTask;

import android.app.ActionBar;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.PointF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Activities.MDMMainActivity;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Activity.OnCommandListener;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;

public class AccelerometerBallTestFragment extends Fragment implements
		OnClickListener, MyFragment {
	private final static String TAG = AccelerometerBallTestFragment.class.getSimpleName();
	private FrameLayout mainView;

	private static Context context;
	private View rootView;
	private TextView textView;

	private boolean isFromCommand = false;
	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
	private OnCommandListener onCommandListener;
	private boolean isClickWork = false;

	private AccelerometerBallView mBallView = null;
	private Handler RedrawHandler = new Handler(); // so redraw occurs in main
													// thread
	private Timer mTmr = null;
	private TimerTask mTsk = null;
	private int mScrWidth, mScrHeight;
	private int mBallWidth, mBallHeight;
	private int mActionBarHeight;
	private PointF mBallPos, mBallSpd;

	private int count = 0;

	private Button okButton;

	private CircularProgressBar timerProgress;

	private boolean success = false;

	private String FAILURE_MESSAGE = "Press OK if accelerometer sensor not working";;

	private OnAutoHardwareTestListener onAutoHardwareTestListener;

	public AccelerometerBallTestFragment(OnCommandListener onCommandListener) {
		this.onCommandListener = onCommandListener;
	}

	public void setOnAutoHardwareTestListener(
			OnAutoHardwareTestListener onAutoHardwareTestListener) {
		this.onAutoHardwareTestListener = onAutoHardwareTestListener;
	}

	@SuppressWarnings("deprecation")
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		Log.d(TAG, "-----------------1 onCreateView");
		
		getActivity().getWindow()
				.setFlags(
						0xFFFFFFFF,
						LayoutParams.FLAG_FULLSCREEN
								| LayoutParams.FLAG_KEEP_SCREEN_ON);

		Display display = getActivity().getWindowManager().getDefaultDisplay();
		mScrWidth = display.getWidth();
		mScrHeight = display.getHeight();
		LogWrite.d("Aman", "Screen Height : " + mScrHeight);
		try {
			ActionBar actionBar = getActivity().getActionBar();
			mActionBarHeight = actionBar.getHeight();
			LogWrite.d("Aman", "Action Bar Height : " + mActionBarHeight);
		} catch (Exception e) {
			TypedValue tv = new TypedValue();

			if (getActivity().getTheme().resolveAttribute(R.attr.actionBarSize, tv, true))
			{
				mActionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data,getResources().getDisplayMetrics());
			}
		}
		mScrHeight = mScrHeight - mActionBarHeight;
		LogWrite.d("Aman", "Screen Width : " + mScrWidth);
		LogWrite.d("Aman", "New Screen Height : " + mScrHeight);
		initDataSet();
		initUi(inflater, container);
		// listener for accelerometer, use anonymous class for simplicity
		((SensorManager) context.getSystemService(Context.SENSOR_SERVICE))
				.registerListener(
						new SensorEventListener() {
							@Override
							public void onSensorChanged(SensorEvent event) {
								// set ball speed based on phone tilt (ignore Z
								// axis)
								mBallSpd.x = -event.values[0];
								mBallSpd.y = event.values[1];
								count++;
								if (count == 25) {
									try {
										Vibrator vibrator = (Vibrator) context
												.getSystemService(Context.VIBRATOR_SERVICE);
										vibrator.vibrate(500);
										textView.setText(R.string.accelerometer_working_fine);
										textView.setTextAppearance(
												getActivity(),
												R.style.textStyleGreen);
										timerProgress.setVisibility(View.GONE);
										success = true;
										// setToSendFlag();
										if (HardwareTestFragment.isAutoStartClicked) {
											onAutoHardwareTestListener
													.onHardwareTestFinish(
															3,
															"Accelerometer Sensor",
															true);
											// FragmentListener fragmentListener
											// = (FragmentListener)
											// getActivity();
											// fragmentListener.onItemClicked(FragmentListener.actionRemove,
											// AccelerometerBallTestFragment.this);
											// getFragmentManager().popBackStack();
											// getActivity().onBackPressed();
											getActivity()
													.getSupportFragmentManager()
													.beginTransaction()
													.remove(AccelerometerBallTestFragment.this)
													.commit();
											getActivity().getFragmentManager()
													.popBackStack();
										}

										if (isFromCommand) {
											onCommandListener.onCommand(true);
											FragmentListener fragmentListener = (FragmentListener) getActivity();
											fragmentListener
													.onItemClicked(
															FragmentListener.actionRemove,
															AccelerometerBallTestFragment.this);

											// try {
											// getActivity()
											// .getSupportFragmentManager()
											// .popBackStack();
											// FragmentListener fragmentListener
											// = (FragmentListener)
											// getActivity();
											// fragmentListener
											// .onItemClicked(
											// FragmentListener.actionAdd,
											// MDMMainActivity.ins);
											// } catch (ExceptionDTO e) {
											// LogWrite.e(
											// "AccelerometerBallTestFragment",
											// "popBackStackException : "
											// + e.toString());
											// }
										}
										isClickWork = true;
									} catch (Exception e) {
										LogWrite.e(
												"Aman",
												"Accel ExceptionDTO :: "
														+ e.toString());
										try {
											if (HardwareTestFragment.isAutoStartClicked) {
												onAutoHardwareTestListener
														.onHardwareTestFinish(
																3,
																"Accelerometer Sensor",
																true);
												// FragmentListener
												// fragmentListener =
												// (FragmentListener)
												// getActivity();
												// fragmentListener.onItemClicked(FragmentListener.actionRemove,
												// AccelerometerBallTestFragment.this);
												// getFragmentManager().popBackStack();
												// getActivity().onBackPressed();

												getActivity()
														.getSupportFragmentManager()
														.beginTransaction()
														.remove(AccelerometerBallTestFragment.this)
														.commit();
												getActivity()
														.getFragmentManager()
														.popBackStack();
											}

											if (isFromCommand) {
												onCommandListener
														.onCommand(true);
												getActivity()
														.getSupportFragmentManager()
														.popBackStack();
											}
											isClickWork = true;
										} catch (Exception e1) {
											e1.printStackTrace();
										}

									}
								}

								// timer event will redraw ball
							}

							@Override
							public void onAccuracyChanged(Sensor sensor,
									int accuracy) {
							} // ignore this event
						}, ((SensorManager) context
								.getSystemService(Context.SENSOR_SERVICE))
								.getSensorList(Sensor.TYPE_ACCELEROMETER)
								.get(0),
						SensorManager.SENSOR_DELAY_NORMAL);

		return rootView;
	}

	private void initDataSet() {
		Bundle bundle = getArguments();
		if (bundle != null) {
			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
			}
		}
		context = getActivity().getApplicationContext();
	}

	private void initUi(LayoutInflater inflater, ViewGroup container) {
		context = getActivity().getApplicationContext();
		rootView = inflater.inflate(R.layout.layout_textview, container, false);
		mainView = (FrameLayout) rootView.findViewById(R.id.mainLayout);
		textView = (TextView) rootView.findViewById(R.id.textView);
		textView.setText(R.string.tilt_your_device);

		mScrHeight = mScrHeight - textView.getHeight();
		// get screen dimensions

		mBallPos = new android.graphics.PointF();
		mBallSpd = new android.graphics.PointF();

		// create variables for ball position and speed
		mBallPos.x = mScrWidth / 2;
		mBallPos.y = mScrHeight / 2;
		mBallSpd.x = 0;
		mBallSpd.y = 0;

		// create initial ball
		mBallView = new AccelerometerBallView(context, mBallPos.x, mBallPos.y,
				50);
		mainView.addView(mBallView); // add ball to main screen
		mBallWidth = mBallView.getWidth();
		mBallHeight = mBallView.getHeight();
		LogWrite.d("Aman", "BallWidth : " + mBallWidth);
		LogWrite.d("Aman", "BallHeight : " + mBallHeight);

		if (mBallPos.x > mScrWidth || mBallPos.y > mScrHeight
				|| mBallPos.x < 0 - mBallWidth || mBallPos.y < 0 - mBallHeight) {
		} else
			mBallView.invalidate(); // call onDraw in BallView

		okButton = (Button) rootView.findViewById(R.id.ok_button);
		okButton.setOnClickListener(this);

		timerProgress = (CircularProgressBar) rootView
				.findViewById(R.id.circularprogressbar2);
		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {
			@Override
			public void onAnimationStart() {
			}

			@Override
			public void onAnimationProgress(int progress) {
				timerProgress.setTitle(progress + "");
				timerProgress.setSubTitle("");
			}

			@Override
			public void onAnimationFinish() {
				if (!success) {
					textView.setText(FAILURE_MESSAGE);
					textView.setTextAppearance(context, R.style.textStyleRed);
					okButton.setVisibility(View.VISIBLE);
					timerProgress.setSubTitle("");
					timerProgress.setVisibility(View.GONE);
				}
			}
		});
	}

	@Override
	public void onDestroy() {
		Log.d(TAG, "-----------------1 onDestroy");
		super.onDestroy();
		// if (getToSendFlag()) {
		// if (onCommandListener != null) {
		// onCommandListener.onCommand(getToSendFlag());
		// }
		// }
		if (mTmr != null && mTsk != null) {
			LogWrite.e("Aman", "Accelerometer task going to finish");
			mTmr.cancel(); // kill\release timer (our only background thread)
			mTsk.cancel();
		}
		mTmr = null;
		mTsk = null;
	}

	@Override
	public void onPause() {
		Log.d(TAG, "-----------------1 onPause");
		super.onPause();
		if (getToSendFlag()) {
			if (onCommandListener != null) {
				onCommandListener.onCommand(getToSendFlag());
			}
		}

		if (mTmr != null && mTsk != null) {
			LogWrite.e("Aman", "Accelerometer task going to finish");
			mTmr.cancel(); // kill\release timer (our only background thread)
			mTsk.cancel();
		}
		mTmr = null;
		mTsk = null;

	}

	@Override
	public void onResume() // app moved to foreground (also occurs at app
							// startup)
	{
		Log.d(TAG, "-----------------1 onResume");
		// create timer to move ball to new position
		mTmr = new Timer();
		mTsk = new TimerTask() {
			public void run() {
				// if debugging with external device,
				// a cat log viewer will be needed on the device
				LogWrite.d("TiltBall", "Timer Hit - " + mBallPos.x + ":"
						+ mBallPos.y);
				// move ball based on current speed
				mBallPos.x += mBallSpd.x;
				mBallPos.y += mBallSpd.y;
				// if ball goes off screen, reposition to opposite side of
				// screen
				if (mBallPos.x > (mScrWidth))
					mBallPos.x = mScrWidth;
				if (mBallPos.y > mScrHeight)
					mBallPos.y = mScrHeight;
				if (mBallPos.x < 0 - mBallWidth)
					mBallPos.x = -mBallWidth;
				if (mBallPos.y < 0 - mBallHeight)
					mBallPos.y = -mBallHeight;
				if (mBallPos.x > mScrWidth || mBallPos.y > mScrHeight
						|| mBallPos.x < 0 - mBallWidth
						|| mBallPos.y < 0 - mBallHeight) {
				} else {
					// update ball class instance
					mBallView.mX = mBallPos.x;
					mBallView.mY = mBallPos.y;
					// redraw ball. Must run in background thread to prevent
					// thread
					// lock.
					RedrawHandler.post(new Runnable() {
						public void run() {
							mBallView.invalidate();
						}
					});
				}
			}
		}; // TimerTask

		mTmr.schedule(mTsk, 10, 10); // start timer
		super.onResume();
	} // onResume

	private boolean getToSendFlag() {
		SharedPreferences sharedPreferences = getActivity()
				.getSharedPreferences("AccelerometerTestFrtagment",
						Context.MODE_PRIVATE);
		return sharedPreferences.getBoolean("SENDFLAG", false);
	}

	private void setToSendFlag() {
		SharedPreferences sharedPreferences = getActivity()
				.getSharedPreferences("AccelerometerTestFrtagment",
						Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putBoolean("SENDFLAG", true);
		editor.commit();

	}

	public static void clear() {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				"AccelerometerTestFrtagment", Context.MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.clear().commit();
	}

	@Override
	public void onClick(View v) {
		Vibrator vibrator = (Vibrator) context
				.getSystemService(Context.VIBRATOR_SERVICE);
		vibrator.vibrate(500);
		textView.setText("AccelerometerSensor test fails.");
		if (HardwareTestFragment.isAutoStartClicked) {
			onAutoHardwareTestListener.onHardwareTestFinish(3,
					"Accelerometer Sensor", false);
			// FragmentListener fragmentListener = (FragmentListener)
			// getActivity();
			// fragmentListener.onItemClicked(FragmentListener.actionRemove,
			// AccelerometerBallTestFragment.this);
			// getFragmentManager().popBackStack();
			// getActivity().onBackPressed();
			getActivity().getSupportFragmentManager().beginTransaction()
					.remove(AccelerometerBallTestFragment.this).commit();
			getActivity().getFragmentManager().popBackStack();
		}

		if (isFromCommand) {
			onCommandListener.onCommand(false);
			FragmentListener fragmentListener = (FragmentListener) getActivity();
			fragmentListener.onItemClicked(FragmentListener.actionRemove, this);
		}
		okButton.setVisibility(View.GONE);
	}

	@Override
	public String getTitle() {
		return "Accelerometer";
	}
}