package com.kochartech.gizmodoctor.HelperClass;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;

import com.kochartech.devicemax.Activities.LogWrite;

public class SettingChangeListener extends BroadcastReceiver {
	private String tag = "SettingChangeListener";

	@Override
	public void onReceive(Context arg0, Intent arg1) {
		// TODO Auto-generated method stub
		
		if (arg1.getAction().equalsIgnoreCase(
				BluetoothAdapter.ACTION_STATE_CHANGED)) 
		{
			
			LogWrite.d(tag, "onReceiver   Work" + arg1.getExtras());
			int BtSatet = arg1.getIntExtra(BluetoothAdapter.EXTRA_STATE,
					BluetoothAdapter.ERROR);
			switch (BtSatet)
			{
				case BluetoothAdapter.STATE_OFF:
					LogWrite.d(tag, "Bluetooth off");
					break;
				case BluetoothAdapter.STATE_TURNING_OFF:
					LogWrite.d(tag, "Turning Bluetooth off...");
					break;
				case BluetoothAdapter.STATE_ON:
					LogWrite.d(tag, "Bluetooth on");
					break;
				case BluetoothAdapter.STATE_TURNING_ON:
					LogWrite.d(tag, "Turning Bluetooth on...");
					break;
			}
		}
		else if (arg1.getAction().equalsIgnoreCase(
				WifiManager.WIFI_STATE_CHANGED_ACTION)) {
			LogWrite.d(tag, "onReceiver   Work: " + "Wifi");
		}
		else if (arg1.getAction().equalsIgnoreCase(
				"android.location.PROVIDERS_CHANGED"))
		{
			LogWrite.d(tag, "onReceiver   Work: GPS");		
		}
			
	

	}

}
