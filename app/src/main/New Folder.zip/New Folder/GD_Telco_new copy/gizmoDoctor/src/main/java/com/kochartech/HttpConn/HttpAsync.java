package com.kochartech.HttpConn;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

public class HttpAsync extends AsyncTask<String, String, String> {

	public  static final String  BROADCAST_ACTION = "com.kochar.http.server_response_data";
	private Context context;
	private String serverUrl = null, dataToPost= null, dataFormat = null;
	private String serverResponseData;
	private boolean isProgressDialog ;
	private boolean isToPostData, isToReadData;
	public  static final String DATAFORMAT_JSON = "application/json";
	private int    requestCode;
	private String TAG = "HttpAsync";

	private boolean isConnected,isWriteSucessfully,isReadSucessfully;
	public HttpAsync(Context context,int requestCode,String serverUrl, String data, String format, boolean isProgressDialog,
			boolean isToPostData, boolean isToReadData) {
		
		Log.d(TAG, "Consructor Work");
		
		this.context = context;
		this.requestCode = requestCode;
		this.serverUrl = serverUrl;
		this.dataToPost = data;
		this.dataFormat = format;
		this.isProgressDialog = isProgressDialog;
		this.isToPostData = isToPostData;
		this.isToReadData = isToReadData;
		
		
	}

	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		super.onPreExecute();
		if (isProgressDialog) {
			// code to show progress dialog
		}
	}

	@Override
	protected String doInBackground(String... arg0) {

		Log.d(TAG, "doInBackGroundStart");
		HttpPostConnection httpConnection = new HttpPostConnection();
		isConnected = httpConnection.connect(serverUrl, dataFormat);
		if(isConnected) 
		{
			if (isToPostData) 
			{
				// code to post http data
				isWriteSucessfully = httpConnection.writeToServer(dataToPost);
			}
			if (isToReadData) 
			{
				// code to read http data
				serverResponseData = httpConnection.readFromServer();
				isReadSucessfully = serverResponseData != null?true:false; 
			}
		}
		return serverResponseData;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);
		if (isProgressDialog) {
			// code to dismiss progress dialog
		}
		
		// send broadcast for http receive data
		Intent intent = new Intent(BROADCAST_ACTION);
		intent.putExtra(EXTRA_CONNECT_STATUS, isConnected);		
		if(isToPostData)
			intent.putExtra(EXTRA_WRITE_STATUS, isWriteSucessfully);
		if(isToReadData) {
			intent.putExtra(EXTRA_READ_STATUS, isReadSucessfully);
		    intent.putExtra(EXTRA_READ_MSG, result);
		}
		context.sendBroadcast(intent);		
	}
	
	public static String EXTRA_CONNECT_STATUS = "EXTRA_CONNECT_STATUS";
	public static String EXTRA_WRITE_STATUS   = "EXTRA_WRITE_STATUS";
	public static String EXTRA_READ_STATUS    = "EXTRA_READ_STATUS";
	public static String EXTRA_READ_MSG       = "EXTRA_READ_MSG";
}
