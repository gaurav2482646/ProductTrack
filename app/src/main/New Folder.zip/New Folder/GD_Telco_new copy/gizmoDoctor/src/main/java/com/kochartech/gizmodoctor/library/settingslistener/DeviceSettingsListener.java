package com.kochartech.gizmodoctor.library.settingslistener;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.library.Device.KTDeviceInfo;

public class DeviceSettingsListener extends BroadcastReceiver {
	private String TAG = DeviceSettingsListener.class.getSimpleName();
	private int bluetoothOn = -1;
	private int gpsOn = -1;
	private int hotspotOn = -1;
	private int wifiOn = -1;

	// 1 for ON, 0 for OFF
	@Override
	public void onReceive(Context context, Intent intent) {
		LogWrite.e(TAG, "ActionString : " + intent.getAction());
		bluetoothOn = -1;
		gpsOn = -1;
		hotspotOn = -1;
		wifiOn = -1;
		if (intent.getAction() == "android.net.wifi.WIFI_AP_STATE_CHANGED") {
			int apState = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, 0);
			if (apState == 13) {
				// Hotspot AP is enabled
				hotspotOn = 1;
				LogWrite.d(TAG, "Hotspot is enable!");
			} else {
				// Hotspot AP is disabled/not ready
				hotspotOn = 0;
				LogWrite.d(TAG, "Hotspot is disable!");
			}
			Intent i = new Intent(context, DeviceSettingsService.class);
			i.putExtra(DeviceSettingsService.KEY_HOTSPOT, hotspotOn);
			i.putExtra(DeviceSettingsService.KEY_WIFI, -1);
			i.putExtra(DeviceSettingsService.KEY_BLUETOOTH, -1);
			i.putExtra(DeviceSettingsService.KEY_GPS, -1);
			context.startService(i);
		} else if (intent.getAction() == WifiManager.WIFI_STATE_CHANGED_ACTION) {
			if (isWifiEnable(intent)) {
				wifiOn = 1;
				LogWrite.d(TAG, "Wifi is enable!");
			} else {
				wifiOn = 0;
				LogWrite.d(TAG, "Wifi is disable!");
			}
			Intent i = new Intent(context, DeviceSettingsService.class);
			i.putExtra(DeviceSettingsService.KEY_HOTSPOT, -1);
			i.putExtra(DeviceSettingsService.KEY_WIFI, wifiOn);
			i.putExtra(DeviceSettingsService.KEY_BLUETOOTH, -1);
			i.putExtra(DeviceSettingsService.KEY_GPS, -1);
			context.startService(i);
		} else if (intent.getAction() == BluetoothAdapter.ACTION_STATE_CHANGED) {
			if (isbluetoothEnable(intent)) {
				bluetoothOn = 1;
				LogWrite.d(TAG, "Bluetooth is enable!");
			} else {
				bluetoothOn = 0;
				LogWrite.d(TAG, "Bluetooth is disable!");
			}
			Intent i = new Intent(context, DeviceSettingsService.class);
			i.putExtra(DeviceSettingsService.KEY_HOTSPOT, -1);
			i.putExtra(DeviceSettingsService.KEY_WIFI, -1);
			i.putExtra(DeviceSettingsService.KEY_BLUETOOTH, bluetoothOn);
			i.putExtra(DeviceSettingsService.KEY_GPS, -1);
			context.startService(i);
		} else if (intent.getAction() == "android.location.PROVIDERS_CHANGED") {
			KTDeviceInfo deviceInfo = new KTDeviceInfo(context);
			if (deviceInfo.isGPSEnabled()) {
				gpsOn = 1;
				LogWrite.d(TAG, "GPS is enable!");
			} else {
				gpsOn = 0;
				LogWrite.d(TAG, "GPS is disable!");
			}
			Intent i = new Intent(context, DeviceSettingsService.class);
			i.putExtra(DeviceSettingsService.KEY_HOTSPOT, -1);
			i.putExtra(DeviceSettingsService.KEY_WIFI, -1);
			i.putExtra(DeviceSettingsService.KEY_BLUETOOTH, -1);
			i.putExtra(DeviceSettingsService.KEY_GPS, gpsOn);
			context.startService(i);
		}
	}

	private boolean isWifiEnable(Intent intent) {
		int extraWifiState = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE,
				WifiManager.WIFI_STATE_UNKNOWN);

		switch (extraWifiState) {
		case WifiManager.WIFI_STATE_DISABLED:
			return false;
		case WifiManager.WIFI_STATE_DISABLING:
			return false;
		case WifiManager.WIFI_STATE_ENABLED:
			return true;
		case WifiManager.WIFI_STATE_ENABLING:
			return true;
		case WifiManager.WIFI_STATE_UNKNOWN:
			return false;
		default:
			return false;
		}
	}

	private boolean isbluetoothEnable(Intent intent) {
		final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
				BluetoothAdapter.ERROR);
		switch (state) {
		case BluetoothAdapter.STATE_OFF:
			return false;
		case BluetoothAdapter.STATE_TURNING_OFF:
			return false;
		case BluetoothAdapter.STATE_ON:
			return true;
		case BluetoothAdapter.STATE_TURNING_ON:
			return true;
		default:
			return false;
		}
	}
}
