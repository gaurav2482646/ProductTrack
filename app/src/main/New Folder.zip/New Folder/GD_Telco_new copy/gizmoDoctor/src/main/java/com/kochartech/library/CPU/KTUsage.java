package com.kochartech.library.CPU;

import java.util.ArrayList;
import java.util.List;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;

public abstract class KTUsage {
	private String TAG = KTUsage.class.getSimpleName();
	public Context context;
	public List<KTApplicationInfo> runningAppUsageInfo = new ArrayList<KTApplicationInfo>();
	public PackageManager pkgManager;
	public ActivityManager activityManager;

	protected KTUsage(Context context) {
		this.context = context;
		pkgManager = context.getPackageManager();
		activityManager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
	}

	protected ApplicationInfo getApplicationInfo(String processName) {
		ApplicationInfo applInfo = null;
		try {
			applInfo = pkgManager.getApplicationInfo(processName,
					PackageManager.GET_META_DATA);
		} catch (NameNotFoundException e) {
			LogWrite.e(TAG, "NameNotFoundException : " + e.toString());
		}
		return applInfo;
	}

	protected String getAppName(ApplicationInfo appInfo) {

		return (String) (appInfo != null ? pkgManager
				.getApplicationLabel(appInfo) : "Unknown");
	}

	@SuppressWarnings("deprecation")
	protected Drawable getAppIcon(ApplicationInfo appInfo) {
		return (Drawable) (appInfo != null ? pkgManager
				.getApplicationIcon(appInfo) : context.getResources()
				.getDrawable(R.drawable.unknown));
		// return pkgManager.getApplicationIcon(appInfo);
	}

}
