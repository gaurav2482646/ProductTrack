package com.kochartech.gizmodoctor.Activity;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBarDrawerToggle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.kochartech.MyLibs.StorageInfo;
import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Activities.MDMMainActivity;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Fragment.AccelerometerBallTestFragment;
import com.kochartech.gizmodoctor.Fragment.AppSettingsFragment;
import com.kochartech.gizmodoctor.Fragment.CameraTestFragment;
import com.kochartech.gizmodoctor.Fragment.GPSTestFragment;
import com.kochartech.gizmodoctor.Fragment.GUIDeviceInfo;
import com.kochartech.gizmodoctor.Fragment.GUIDiagnose;
import com.kochartech.gizmodoctor.Fragment.GUIPowerSavingProfile;
import com.kochartech.gizmodoctor.Fragment.GUISetNotification;
import com.kochartech.gizmodoctor.Fragment.HardwareTestFragment;
import com.kochartech.gizmodoctor.Fragment.MultiTouchTestFragment;
import com.kochartech.gizmodoctor.Fragment.MyFragment;
import com.kochartech.gizmodoctor.Fragment.ProximitySensorTestFragment;
import com.kochartech.gizmodoctor.Fragment.SoftKeyTestFragment;
import com.kochartech.gizmodoctor.Fragment.TouchTestFragment;
import com.kochartech.gizmodoctor.UpdateUi.BroadcastService;
import com.kochartech.gizmodoctor.UpdateUi.UiRequireUpdate;
import com.kochartech.gizmodoctor.library.settingslistener.DeviceSettingsService;

public class NavDrawerActivity extends ActionBarActivity implements
		FragmentListener {
	private final static String tag = NavDrawerActivity.class.getSimpleName();
	private ListView mDrawerList;
	private ActionBarDrawerToggle mDrawerToggle;
	private List<RowItem> rowItems;
	private CustomAdapter adapter;
	private Stack<Fragment> fragmentStack;
	private String[] menutitles;
	private TypedArray menuIcons;
	private CharSequence mDrawerTitle;
	private CharSequence mTitle;
	private DrawerLayout mDrawerLayout;
	private Intent intentBroadcastService;

	@SuppressLint("NewApi")
	private ActionBar actionBar;
	private FragmentManager fragmentManager = getSupportFragmentManager();

	public void initDataSet() {
		LogWrite.i(tag, "Service Initialized..... 1");
		intentBroadcastService = new Intent(getApplicationContext(),
				BroadcastService.class);
		LogWrite.i(tag, "Stack Initialized..... 2");
		fragmentStack = new Stack<Fragment>();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {
			LogWrite.d(tag, "onCreate Work");
			setContentView(R.layout.activity_navigationdrawer);
			List<StorageInfo> listStorage = StorageInfo.getStorageList();
			for (StorageInfo storageInfo : listStorage) {
				String path = storageInfo.path;
				LogWrite.i(tag, "Path : " + path);
				LogWrite.i(tag, "DisplayName : " + storageInfo.getDisplayName());
			}

			initDataSet();

			mTitle = mDrawerTitle = getTitle();
			LogWrite.i(tag, "Title  =====> " + mTitle);
			menutitles = getResources().getStringArray(R.array.titles);
			menuIcons = getResources().obtainTypedArray(R.array.icons);

			mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
			mDrawerList = (ListView) findViewById(R.id.slider_list);

			rowItems = new ArrayList<RowItem>();

			for (int i = 0; i < menutitles.length; i++) {
				LogWrite.d(tag, "MenuItems  =====> " + menutitles[i]);
				RowItem items = new RowItem(menutitles[i],
						menuIcons.getResourceId(i, -1));
				rowItems.add(items);
			}

			menuIcons.recycle();

			adapter = new CustomAdapter(getApplicationContext(), rowItems);

			mDrawerList.setAdapter(adapter);
			mDrawerList.setOnItemClickListener(new SlideitemListener());

			// enabling action bar app icon and behaving it as toggle button
			getSupportActionBar().setDisplayHomeAsUpEnabled(true);
			getSupportActionBar().setHomeButtonEnabled(true);

			mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.app_name, R.string.app_name) {
				public void onDrawerClosed(View view) {
					LogWrite.d(tag, "onDrawerClosed");
					getSupportActionBar().setTitle(mTitle);
					// calling onPrepareOptionsMenu() to show action bar
					// icons
					supportInvalidateOptionsMenu();
					// invalidateOptionsMenu();
				}

				public void onDrawerOpened(View drawerView) {
					getSupportActionBar().setTitle(mDrawerTitle);
					LogWrite.d(tag, "onDrawerOpened");
					// calling onPrepareOptionsMenu() to hide action bar
					// icons
					supportInvalidateOptionsMenu();
					// invalidateOptionsMenu();
				}
			};

//			mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
//					R.drawable.ic_drawer, // nav menu toggle icon
//					R.string.app_name, // nav drawer open - description for
//										// accessibility
//					R.string.app_name // nav drawer close - description for
//										// accessibility
//			) {
//				public void onDrawerClosed(View view) {
//					LogWrite.d(tag, "onDrawerClosed");
//					getSupportActionBar().setTitle(mTitle);
//					// calling onPrepareOptionsMenu() to show action bar
//					// icons
//					supportInvalidateOptionsMenu();
//					// invalidateOptionsMenu();
//				}
//
//				public void onDrawerOpened(View drawerView) {
//					getSupportActionBar().setTitle(mDrawerTitle);
//					LogWrite.d(tag, "onDrawerOpened");
//					// calling onPrepareOptionsMenu() to hide action bar
//					// icons
//					supportInvalidateOptionsMenu();
//					// invalidateOptionsMenu();
//				}
//			};
			mDrawerLayout.setDrawerListener(mDrawerToggle);

			if (savedInstanceState == null) {
				LogWrite.i(tag, "savedInstanceState is null,"
						+ "update display method call upon");
				updateDisplay(0);
			} else {
				LogWrite.i(tag, "savedInstanceState is not null");
				List<Fragment> list = fragmentManager.getFragments();
				for (int i = 0; i < list.size(); i++) {
					LogWrite.d(tag, "StackList[" + i + "] :--> " + list.get(i));
					fragmentStack.push(list.get(i));
				}
			}
			LogWrite.i(tag, "Drawer Activity Finish Successfully");
			DeviceSettingsService.start(this);
			// }// Else Block
		} catch (Exception e) {
			LogWrite.e(tag,
					"NavDrawerActivity onCreate ExceptionDTO : " + e.toString());
		}
	} // onCreate Method Finish

	// @Override
	// public void onBackPressed() {
	// super.onBackPressed();
	// android.app.Fragment currentFragment =
	// NavDrawerActivity.this.getFragmentManager().findFragmentById(R.id.fragment_container);
	// Toast.makeText(getApplicationContext(), "Back click : " +
	// currentFragment, Toast.LENGTH_SHORT).show();
	//
	//
	// }

	// private boolean hasValue;
	private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			LogWrite.i(tag, "Action Received : "
					+ intent.getAction().toString());
			try {
				LogWrite.w(tag, "Receiver Work");
				if (fragmentStack != null && fragmentStack.size() > 0) {
					Fragment fragment = fragmentStack.lastElement();
					String lastFragmentName = fragmentStack.lastElement()
							.getClass().toString();
					LogWrite.i(tag, "Current Fragment: " + lastFragmentName);
					if (fragment instanceof UiRequireUpdate) {
						LogWrite.w(tag, "if Fragment need Ui Update.....");
						UiRequireUpdate uiRequireUpdate = (UiRequireUpdate) fragment;
						LogWrite.w(tag, "Async going to start........");
						if (myAsync == null) {
							LogWrite.e(tag, "Async is empty and null");
							myAsync = (MyAsync) new MyAsync(uiRequireUpdate);
							myAsync.execute("");
						} else if (myAsync.isDead()) {
							LogWrite.e(tag, "Async is Dead");
							myAsync = (MyAsync) new MyAsync(uiRequireUpdate);
							myAsync.execute("");
						}
					}
				}
			} catch (Exception e) {
				LogWrite.e(tag, "BroadcastReceiverException..." + e);
			}
		}
	};

	private MyAsync myAsync;

	class MyAsync extends AsyncTask<String, String, String> {
		private boolean isDead = false;
		UiRequireUpdate uiRequireUpdate;

		public MyAsync(UiRequireUpdate fragment) {
			uiRequireUpdate = (UiRequireUpdate) fragment;
		}

		@Override
		protected String doInBackground(String... params) {
			LogWrite.i(tag, "In doInBackground of MyAsync..");
			uiRequireUpdate.runInBackGround();
			publishProgress("");
			return null;
		}

		@Override
		protected void onProgressUpdate(String... values) {
			LogWrite.i(tag, "In publishProgress of MyAsync..");
			uiRequireUpdate.updateUI();
			isDead = true;
		}

		public boolean isDead() {
			return isDead;
		}
	}

	class SlideitemListener implements ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			LogWrite.i(tag, "Navigation Drawer List Clicked............");
			LogWrite.i(tag, "Display position of index : " + position);
			updateDisplay(position);
		}
	}

	// fragment = new GUIPowerSavingProfile();
	private void updateDisplay(int position) {
		LogWrite.i(tag, "updateDisplay(): position= " + position);
		Fragment fragment = null;
		switch (position) {
		case 0:
			LogWrite.i(tag, "GUI Diagnose opened");
			fragment = new GUIDiagnose();
			break;
		// case 1:
		// LogWrite.i(tag, "GUI CPU Cooler opened");
		// fragment = new GUICpuCooler();
		// break;
		case 1:
			LogWrite.i(tag, "Device Info opened");
			fragment = new GUIDeviceInfo();
			break;
		case 2:
			LogWrite.i(tag, "GUI Set Notification opened");
			fragment = new GUISetNotification();
			break;
		case 3:
			LogWrite.i(tag, "GUIPowerSavingProfile opened");
			fragment = new GUIPowerSavingProfile();
			break;
		case 4:
			LogWrite.i(tag, "Remote opened");
			fragment = new FragmentRemoteConnect();
			break;
		case 5:
			LogWrite.i(tag, "HardwareTestFragment opened");
			fragment = new HardwareTestFragment();
			break;
		case 6:
			LogWrite.i(tag, "SoftKeyTestFragment opened");
			fragment = new SoftKeyTestFragment();
			break;
		case 7:
			LogWrite.i(tag, "GPSFragment opened");
			fragment = new GPSTestFragment();
			break;
		case 8:
			LogWrite.i(tag, "AppSettingsFragment opened");
			fragment = new AppSettingsFragment();
			break;

		default:
			break;
		}
		if (fragment != null) {

			// if(fragment instanceof HardwareTestFragment)
			// onItemClicked(actionAdd, fragment);
			// else
			onItemClicked(actionReplace, fragment);
			mDrawerList.setItemChecked(position, true);
			mDrawerList.setSelection(position);
			mDrawerLayout.closeDrawer(mDrawerList);
		}
	}

	@Override
	public void setTitle(CharSequence title) {
		LogWrite.d(tag, "setTitle:" + title);
		mTitle = title;
		getSupportActionBar().setTitle(mTitle);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		// toggle nav drawer on selecting action bar app icon/title
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		// Handle action bar actions click
		switch (item.getItemId()) {
		case R.id.action_settings:
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/***
	 * Called when invalidateOptionsMenu() is triggered
	 */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// if nav drawer is opened, hide the action items
		// boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerList);
		// menu.findItem(R.id.action_settings).setVisible(false);
		return super.onPrepareOptionsMenu(menu);
	}

	/**
	 * When using the ActionBarDrawerToggle, you must call it during
	 * onPostCreate() and onConfigurationChanged()...
	 */
	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggls
		mDrawerToggle.onConfigurationChanged(newConfig);
	}

	@Override
	public void onAttachFragment(Fragment fragment) {
		// TODO Auto-generated method stub
		super.onAttachFragment(fragment);
	}

	/*
	 * it clearAll the BackStack entry
	 */

	private void popBackStack(FragmentManager fm) {
		int backStackEntryCount = fm.getBackStackEntryCount();
		for (int i = 0; i < backStackEntryCount; i++) {
			fm.popBackStack();
		}

	}

	@Override
	public void onItemClicked(int action, Fragment fragment) {
		try {
			Log.d("AMAN", "onItemClicked.............");
			Log.d("AMAN", "Action : " + action);
			FragmentTransaction ft = fragmentManager.beginTransaction();
			if (action == actionReplace) {
				Log.d("AMAN",
						"ActionReplace Stack Size : " + fragmentStack.size());
				popBackStack(fragmentManager);
				for (int i = 0; i < fragmentStack.size(); i++) {
					Fragment myFragment = fragmentStack.get(i);
					Log.d("AMAN", "onItemClicked............ " + myFragment);
					myFragment.onDestroy();
					
				}
				if(!fragmentStack.isEmpty())
					fragmentStack.pop();
				fragmentStack.removeAllElements();

				ft.replace(R.id.frame_container, fragment).commit();
				// Push the Fragment to BackStack
				fragmentStack.push(fragment);
			} else if (action == actionAdd) {
				Log.d("AMAN", "ActionAdd Stack Size : " + fragmentStack.size());
				if (fragmentStack.size() > 0)
					fragmentStack.lastElement().onPause();
				ft.add(R.id.frame_container, fragment);
				if (HardwareTestFragment.isAutoStartClicked) {
					if (fragment instanceof AccelerometerBallTestFragment
							|| fragment instanceof ProximitySensorTestFragment
							|| fragment instanceof AccelerometerBallTestFragment
							|| fragment instanceof TouchTestFragment
							|| fragment instanceof MultiTouchTestFragment
							|| fragment instanceof CameraTestFragment) {
						Log.e(tag, "Screen : " + fragment);
						// fragmentStack.removeElement(fragment);
						// fragmentStack.pop();
					} else {
						ft.addToBackStack("abc");
					}
				} else {
					ft.addToBackStack("abc");
				}
				ft.show(fragment);
				ft.commit();
				if (HardwareTestFragment.isAutoStartClicked) {
					if (fragment instanceof AccelerometerBallTestFragment
							|| fragment instanceof ProximitySensorTestFragment
							|| fragment instanceof AccelerometerBallTestFragment
							|| fragment instanceof TouchTestFragment
							|| fragment instanceof MultiTouchTestFragment
							|| fragment instanceof CameraTestFragment) {

					} else {
						// Push the Fragment to BackStack
						fragmentStack.push(fragment);
					}
				} else {
					fragmentStack.push(fragment);
				}
			} else if (action == actionRemove) {
				Log.d("AMAN",
						"ActionRemove Stack Size : " + fragmentStack.size());
				if (fragmentStack.size() > 0) {
					fragmentStack.lastElement().onPause();
					ft.remove(fragmentStack.pop());
					if (fragmentStack.size() > 0) {
						fragmentStack.lastElement().onResume();
					}

					fragmentManager.popBackStack();
					ft.show(fragmentStack.lastElement());
					ft.commit();
				}
			}
			MyFragment myfragment = (MyFragment) fragment;
			setTitle(myfragment.getTitle());

		} catch (Exception e) {
			Log.e(tag, "onItemClickedException: " + e.toString());
			// int ft =
			// fragmentManager.beginTransaction().remove(fragment).commit();
			// if(fragment.toString().equals(SOun))
			// if(ft == FragmentTransaction.TRANSIT_FRAGMENT_CLOSE)
			// {
			// LogWrite.d(tag, fragment.toString() +
			// " Fragment Close Success!!");
			// }
		}

	}

	private boolean getHardwareFragmentInstance(Stack<Fragment> fragmentStack) {
		for (int i = 0; i < fragmentStack.size(); i++) {
			Log.d("AMAN", "Aman Fragment : " + fragmentStack.get(i));

			if ((Fragment) fragmentStack.get(i) instanceof HardwareTestFragment)
				return true;
		}
		return false;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			try {
				LogWrite.w(tag, "Back Press...............");
				if (fragmentStack.size() > 1) {
					Fragment lastFragment = fragmentStack.lastElement();
					if (lastFragment instanceof MDMMainActivity) {
						LogWrite.d("Ansal", "01");
						return true;
					}
					FragmentTransaction ft = fragmentManager.beginTransaction();
					lastFragment.onPause();
					ft.remove(fragmentStack.pop());
					fragmentStack.lastElement().onResume();

					MyFragment myfragment = (MyFragment) fragmentStack
							.lastElement();
					setTitle(myfragment.getTitle());
					ft.show(fragmentStack.lastElement());
					ft.commit();

				}
			} catch (Exception e) {
				LogWrite.e(tag, "BackPressException : " + e.toString());
			}
		}
		return super.onKeyDown(keyCode, event);

	}

	@Override
	protected void onResume() {
		super.onResume();
		LogWrite.e(tag, "On Resume Enters................");
		LogWrite.w(tag, "Navigation Drawer onResume method enters");
		LogWrite.i(tag, "Start Service and BroadcastReceiver");

		startService(intentBroadcastService);
		registerReceiver(broadcastReceiver, new IntentFilter(
				BroadcastService.BROADCAST_ACTION));

		// try {
		// String hardware = getIntent().getExtras().getString(
		// HardwareTest.KEY_HARDWARE);
		// LogWrite.i(tag, "-------------------------------");
		// LogWrite.i(tag, "-------------------------------");
		// LogWrite.i(tag, "-------------------------------");
		// LogWrite.e(tag, "Hardware :-------> " + hardware);
		// } catch (ExceptionDTO e) {
		// LogWrite.e(tag, "NavDraweronResumeException : " + e.toString());
		// }
	}

	@Override
	protected void onPause() {
		super.onPause();
		LogWrite.e(tag, "On Pause Enters................");
		LogWrite.w(tag, "Navigation Drawer onPause method enters");
		LogWrite.i(tag, "Stop Service and BroadcastReceiver");
		this.stopService(intentBroadcastService);
		this.unregisterReceiver(broadcastReceiver);
	}

	@Override
	protected void onDestroy() {
		LogWrite.e(tag, "On Destroy Enters................");
		super.onDestroy();
	}

	@Override
	public boolean isTopFargment(Fragment fragment) {
		return false;
	}

}