package com.kochartech.gizmodoctor.POJO;

import org.json.JSONException;
import org.json.JSONObject;

public class MonitorAppDTO {
	private String app_name = "";
	private String process_name = "";
	private String cpu_usage = "0";
	private String ram_usage = "0";
	private String discharge_rate = "0";
	private String last_update_time = "0";
	private String app_type = "0";

	public String getApp_name() {
		return app_name;
	}

	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}

	public String getProcess_name() {
		return process_name;
	}

	public void setProcess_name(String process_name) {
		this.process_name = process_name;
	}

	public String getCpu_usage() {
		return cpu_usage;
	}

	public void setCpu_usage(String cpu_usage) {
		this.cpu_usage = cpu_usage;
	}

	public String getRam_usage() {
		return ram_usage;
	}

	public void setRam_usage(String ram_usage) {
		this.ram_usage = ram_usage;
	}

	public String getDischarge_rate() {
		return discharge_rate;
	}

	public void setDischarge_rate(String discharge_rate) {
		this.discharge_rate = discharge_rate;
	}

	public String getLast_update_time() {
		return last_update_time;
	}

	public void setLast_update_time(String last_update_time) {
		this.last_update_time = last_update_time;
	}

	public String getApp_type() {
		return app_type;
	}

	public void setApp_type(String app_type) {
		this.app_type = app_type;
	}

	public JSONObject toJsonString() {
		JSONObject object = new JSONObject();
		try {
			object.put("AppNameMonitor", getApp_name());
			object.put("ProcessName", getProcess_name());
			object.put("CPUUsage", getCpu_usage());
			object.put("RAMUsage", getRam_usage());
			object.put("BatteryUsage", getDischarge_rate());
			object.put("AppUpdateTime", getLast_update_time());
			object.put("AppType", getApp_type());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return object;
	}
}
