package com.kochartech.devicemax.dto;

/**
 * Created by gauravjeetsingh on 20/3/18.
 */

public class AppConstant {
    public static final String ACK_URL = "http://172.17.103.82/CommandService/AntitheftService.svc/webclient/device/commandacknowledge";
    public static final String SEND_RESPONSE_URL = "http://172.17.103.82/CommandService/AntitheftService.svc/webclient/device/pushresponse";
    public static final String STARTSESSION_INFO_URL= "http://172.17.103.82/CommandService/AntitheftService.svc/webclient/device/pushresponse/startsessioninfo";
    public static final String APP_GET_URL = "http://172.17.103.82/CommandService/AntitheftService.svc/webclient/device/pushresponse/appinfo";
    public static final String SERVER_URL = "http://172.17.103.82/CommandService/AntitheftService.svc/webclient/device/getcommand";
}
