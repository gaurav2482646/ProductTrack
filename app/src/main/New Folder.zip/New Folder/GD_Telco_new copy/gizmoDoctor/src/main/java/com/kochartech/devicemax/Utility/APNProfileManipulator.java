package com.kochartech.devicemax.Utility;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.kochartech.devicemax.APNPackage.SqliteWrapper;
import com.kochartech.devicemax.Activities.LogWrite;

public class APNProfileManipulator
{	
	private String rowAPN = "";
	private String row = "";
	String mnc = "";
	String mcc = "";	
	private String tag = "APNProfileManipulator";
	private static final Uri APN_TABLE_URI = Uri.parse("content://telephony/carriers");
	private static final Uri PREFERRED_APN_URI = Uri.parse("content://telephony/carriers/preferapn");
	Context context;
	private static APNProfileManipulator ins;

	public static APNProfileManipulator GetInstance(Context con) 
	{
		if (ins == null) 
		{
			ins = new APNProfileManipulator(con);
		}
		return ins;
	}
	public APNProfileManipulator(Context _context) 
	{
		context = _context;	
	}

	/**
	 * Deletes Profile passed to this method.<br>
	 * Called in response of <b>DELPRF</b>
	 * 
	 * @param profileName
	 * @return
	 */
	public int deleteCommandResponse(String profileName)
	{
		int i = 2;
		// Toast.makeText(getApplicationContext(),
		// "Entered into Delete PRF RES"+profileName,
		// Toast.LENGTH_LONG).show();
		try 
		{
			i = deleteAPN(profileName);
			// Toast.makeText(getApplicationContext(), "delete cmd res ()" + i,
			// Toast.LENGTH_LONG).show();
			return i;
		}
		catch (Exception e) 
		{
			Toast.makeText(context.getApplicationContext(), e.toString(),Toast.LENGTH_SHORT).show();
		}
		//
		return i;

	}

	/**
	 * Delete ALL Profiles. Called when response includes <b>DELALLPRF</b>
	 */
	public void deleteAll() 
	{
		deleteAllAPN();
	}

	// for deleting all profiles
	/**
	 * Delete ALL APN Profiles. Called when response includes <b>DELALLPRF</b>
	 */
	public void deleteAllAPN()
	{
		// Toast.makeText(getApplicationContext()," Delete all Apn method",Toast.LENGTH_LONG).show();
		String profileIdToDelete = getProfileDeleteID1();
		// Toast.makeText(getApplicationContext(),"Profile id to delete length "
		// +
		// profileIdToDelete.length(),Toast.LENGTH_LONG).show();
		int length = profileIdToDelete.length();

		// Toast.makeText(getApplicationContext(),"Length of profile id " +
		// profileIdToDelete.length(),2000).show();
		if (length == 0)
		{
			// Toast.makeText(getApplicationContext(), "No Id To delete " +
			// profileIdToDelete,Toast.LENGTH_LONG).show();
		}
		else
		{
			profileIdToDelete = profileIdToDelete.substring(0,profileIdToDelete.length() - 1);
			// Toast.makeText(getApplicationContext(), "Id To delete " +
			// profileIdToDelete,Toast.LENGTH_LONG).show();
			// Cursor mCursor=getContentResolver().query(APN_TABLE_URI, new
			// String
			// []{"_id"}," mnc like '"+name+"'" ,null, null );
			try 
			{
				String[] toDeleteProfilesArray = profileIdToDelete.split(":");
				ContentResolver resolver = context.getContentResolver();
				for (String id : toDeleteProfilesArray) 
				{
					SqliteWrapper.delete(context,resolver,APN_TABLE_URI, "_id=?", new String[] { id });
					// Toast.makeText(this, id, 1000).show();
				}
			} 
			catch (Exception e) 
			{
				Toast.makeText(context.getApplicationContext(), e.toString(),Toast.LENGTH_LONG).show();
			}
		}
	}

	public String getProfileDeleteID1()
	{
		String s = "";
		// Toast.makeText(getApplicationContext(), "Delete All Profiles "+
		// s.length(),
		// Toast.LENGTH_SHORT).show();
		Cursor mCursor = SqliteWrapper.query(context,context.getContentResolver(),APN_TABLE_URI, new String[] { "_id" }, null, null, null);
		// Cursor mCursor =
		// getContentResolver().query(Uri.parse("content://telephony/carriers"),
		// new
		// String[] {"_id"}, "current=1", null, null);
		// Toast.makeText(getApplicationContext(), "about to fetch id ",
		// Toast.LENGTH_SHORT).show();
		if (mCursor != null)
		{
			try 
			{
				s = printAllData(mCursor);
				// apnDetails.setText(s);
			} 
			catch (Exception ex) 
			{
				Toast.makeText(context.getApplicationContext(), ex.toString(),
						Toast.LENGTH_SHORT).show();
			}
			finally 
			{
				mCursor.close();
			}
		}
		// Toast.makeText(getApplicationContext(),
		// "value of s in while fetching id "+ s,
		// Toast.LENGTH_SHORT).show();
		return s;
		// return new String("");
	}

	/**
	 * Retrieves the Current APN.
	 * 
	 * @param id
	 * @return String
	 */
	public String getNameApnCurrentFromId(String id) 
	{
		String s = "";
		// Cursor mCursor =
		// getContentResolver().query(Uri.parse("content://telephony/carriers"),
		// new
		// String[] {"*"}, "current=1", null, null);
		// Cursor mCursor=getContentResolver().query(APN_TABLE_URI, new String
		// []{"name,apn,current"}," _id like "+id ,null, null );
		// edited on 14 apr 11 on 4.14 pm to fetch all data from profiles
		Cursor mCursor = SqliteWrapper.query(context,context.getContentResolver(),APN_TABLE_URI,
				new String[] { "name,apn,current,proxy,port" },
				" _id like " + id, null, null);
		// Toast.makeText(getApplicationContext(), "entered",
		// Toast.LENGTH_SHORT).show();
		if (mCursor != null) {
			try {
				s = printSelectiveData(mCursor);
				// apnDetails.setText(s);
			} catch (Exception ex) {
				Toast.makeText(context.getApplicationContext(), ex.toString(),
						Toast.LENGTH_SHORT).show();
			}

			finally {
				mCursor.close();
			}
		}
		return s;
	}

	/**
	 * Prints APN data in the Cursor passed as the parameter.
	 * 
	 * @param c
	 * @return String
	 */
	private String printRowAPNData(Cursor c) 
	{
		if (c == null)
			return null;
		String s = "";
		int record_cnt = c.getColumnCount();
		// LogWrite.d(tag, "Total # of records: " + record_cnt);

		if (c.moveToFirst()) 
		{
			String[] columnNames = c.getColumnNames();
			// LogWrite.d(tag, getAllColumnNames(columnNames));
			// s += getAllColumnNames(columnNames);
			rowAPN = c.getString(5);
			s = rowAPN;
			row += "\n";
			// LogWrite.d(tag, row);
			// LogWrite.d(tag, "End Of Records");
		}
		return s;
	}

	/**
	 * Prints selected data in the Cursor passed as the parameter.
	 * 
	 * @param c
	 * @return String
	 */
	public String printSelectiveData(Cursor c) {
		if (c == null)
			return null;
		String s = "";
		int record_cnt = c.getColumnCount();
		// LogWrite.d(tag, "Total # of records: " + record_cnt);

		if (c.moveToFirst()) {
			String[] columnNames = c.getColumnNames();
			// LogWrite.d(tag, getAllColumnNames(columnNames));
			// s += getAllColumnNames(columnNames);
			// s+=c.getString(0);
			do {
				String row = "";
				// if(c.getString(5).equals(""))
				// {}
				for (String columnIndex : columnNames) {
					int i = c.getColumnIndex(columnIndex);

					row += c.getString(i) + "~";
				}
				// row += ";";
				// LogWrite.d(tag, row);
				s += row;
			} while (c.moveToNext());
			// LogWrite.d(tag, "End Of Records");
		}
		return s;
	}

	/**
	 * Prints all the data in the Cursor passed as the parameter.
	 * 
	 * @param c
	 * @return String
	 */
	public String printAllData(Cursor c) 
	{
		if (c == null)
			return null;
		String s = "";
		// int record_cnt = c.getColumnCount();
		// LogWrite.d(TAG, "Total # of records: " + record_cnt);

		if (c.moveToFirst())
		{
			String[] columnNames = c.getColumnNames();
			// LogWrite.d(TAG,getAllColumnNames(columnNames));
			// s += getAllColumnNames(columnNames);
			// s+=c.getString(0);
			do
			{
				String row = "";
				// if(c.getString(5).equals(""))
				// {}
				for (String columnIndex : columnNames)
				{
					int i = c.getColumnIndex(columnIndex);
					row += c.getString(i) + ":";
				}
				// row += "\n";
				// LogWrite.d(TAG, row);
				s += row;
			} while (c.moveToNext());
			// LogWrite.d(TAG,"End Of Records");
		}
		return s;
	}

	public int InsertAPN(String name, String apn_addr, String ip, String port)
	{

		int id = -1;
		// mcc="405";
		// mnc="81";
		/*
		 * mcc and mnc retrieved from simoperator i.e.
		 */	
		try
		{
		    TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService(context.TELEPHONY_SERVICE);
			LogWrite.d(tag,"cmd from server 61");
			String mccMnc = telephonyManager.getSimOperator();
			LogWrite.d(tag,"cmd from server 62 mccMnc"+mccMnc);
			String mcc = mccMnc.substring(0, 3);
			LogWrite.d(tag,"cmd from server 63");
			String mnc = mccMnc.substring(3, mccMnc.length());
			LogWrite.d(tag,"cmd from server 64");
		}
		catch(Exception e)
		{
			
		}
		ContentResolver resolver = context.getContentResolver();
		LogWrite.d(tag,"cmd from server 65");
		ContentValues values = new ContentValues();
		values.put("name", name);
		LogWrite.d(tag,"cmd from server 66");
		values.put("apn", apn_addr);
		values.put("mcc", mcc);
		values.put("mnc", mnc);
		LogWrite.d(tag,"cmd from server 67");
		values.put("proxy", ip);
		values.put("port", port);
		LogWrite.d(tag,"cmd from server 68");	
		// String mncMcc=getDefaultApnMncMccDetails(getDefaultAPN());
		// String mncMccSeprated[]=mncMcc.split("#");
		// Toast.makeText(getApplicationContext(),
		// "MCC MNC from server ->"+mcc+mnc, 2000).show();

		// Toast.makeText(getApplicationContext(), "MNC->"+mnc, 2000).show();

		// values.put("numeric",
		// operatorMccReadFromPref+operatorMncReadFromPref);
		values.put("numeric", mcc + mnc);
//		LogWrite.d(tag,"cmd from server 69");
		Cursor c = null;
		try 
		{
			Uri newRow = resolver.insert(APN_TABLE_URI, values);
			if (newRow != null) 
			{
				c = SqliteWrapper.query(context,resolver,newRow, null, null, null, null);
//				LogWrite.d(tag, "Newly added APN:");
				printRowAPNData(c); // Print the entire result set
				// Obtain the apn id
				int idindex = c.getColumnIndex("_id");
				c.moveToFirst();
				id = c.getShort(idindex);
//				LogWrite.d(tag, "New ID: " + id + ": Inserting new APN succeeded!");
			}
		} 
		catch (SQLException e) 
		{
//			LogWrite.d(tag, "Adding ExceptionDTO ----> "+ e.toString());
			id = -1;
		}

		if (c != null)
			c.close();
		return id;
		// }//
		// return 0;
	}

	/*
	 * Set an apn to be the default apn for web traffic Require an input of the
	 * apn id to be set
	 */
	public boolean SetDefaultAPN(int id) 
	{
		boolean res = false;
		ContentResolver resolver = context.getContentResolver();
		ContentValues values = new ContentValues();

		// See /etc/apns-conf.xml. The TelephonyProvider uses this file to
		// provide
		// content://telephony/carriers/preferapn URI mapping
		values.put("apn_id", id);
		try 
		{
			SqliteWrapper.update(context,context.getContentResolver(), PREFERRED_APN_URI, values, null, null);
			Cursor c = SqliteWrapper.query(context,context.getContentResolver(),PREFERRED_APN_URI, new String[] { "name", "apn" }, "_id=" + id, null, null);
			if (c != null) 
			{
				res = true;
				c.close();
			}
		} 
		catch (SQLException e) 
		{
			LogWrite.d(tag, e.getMessage());
		}
		return res;
	}

	public int deleteAPN(String name)
	{
		// fetch the id of profiles to delete
		String profileIdToDelete = getProfileID(name);
		if (profileIdToDelete.equals("")) 
		{
			// Toast.makeText(getApplicationContext()," profile id is blank "
			// ,2000).show();
			return 0;
		}
		else 
		{
			profileIdToDelete = profileIdToDelete.substring(0, profileIdToDelete.length() - 1);
			// Toast.makeText(getApplicationContext(),name + "Id To delete " +
			// profileIdToDelete,Toast.LENGTH_LONG).show();
			// Cursor mCursor=getContentResolver().query(APN_TABLE_URI, new
			// String
			// []{"_id"}," mnc like '"+name+"'" ,null, null );

			try 
			{
				String[] toDeleteProfilesArray = profileIdToDelete.split(":");
				ContentResolver resolver = context.getContentResolver();
				for (String id : toDeleteProfilesArray) 
				{
					SqliteWrapper.delete(context,resolver,APN_TABLE_URI, "_id=?", new String[] { id });
					// Toast.makeText(this, id, 1000).show();
				}
			} 
			catch (Exception e) 
			{
				Toast.makeText(context.getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
			}
			return 1;
		}
	}

	public int updateAPN(String name, String apn_addr, boolean setDefault, String ip, String port) 
	{
		LogWrite.d("MDMMainActivity", "Update APN Method Enters");
		LogWrite.d("MDMMainActivity", "---Name"+name);
		LogWrite.d("MDMMainActivity", "---apnAddress"+apn_addr);
		LogWrite.d("MDMMainActivity", "---setDefault"+setDefault);
		LogWrite.d("MDMMainActivity", "---ip"+ip);
		LogWrite.d("MDMMainActivity", "---port"+port);
		String profileIdToEdit = getProfileID(name);
		LogWrite.d("MDMMainActivity", "Profile to Edit : "+profileIdToEdit);
		if (profileIdToEdit.equals("")) 
		{
			return 0;
		}
		else 
		{
			profileIdToEdit = profileIdToEdit.substring(0, profileIdToEdit.length() - 1);
			// Toast.makeText(getApplicationContext(),name + "Id To edit " +
			// profileIdToEdit,Toast.LENGTH_LONG).show();
			// Cursor mCursor=getContentResolver().query(APN_TABLE_URI, new
			// String
			// []{"_id"}," mnc like '"+name+"'" ,null, null );


				String[] toEditProfilesArray = profileIdToEdit.split(":");
				// int profileIdCount=toEditProfilesArray.length;
				// ContentResolver resolver = getContentResolver();

				for (String id : toEditProfilesArray)
				{
					// resolver.delete(APN_TABLE_URI,"_id=?", new String[]{id});

					ContentValues updateFields = new ContentValues();
					ContentResolver resolver = context.getContentResolver();
					updateFields.put("apn", apn_addr);
					if (ip.equals("")) 
					{
						updateFields.put("proxy", "");
						updateFields.put("port", "");
					}
					else 
					{
						updateFields.put("proxy", ip);
						updateFields.put("port", port);

					}
					
					SqliteWrapper.update(context,resolver, APN_TABLE_URI, updateFields, "_id=?", new String[] { id });
					if (setDefault) 
					{
						// updateFields.put("apn", apn_addr);
						boolean b = SetDefaultAPN(Integer.parseInt(id));

						if (b) 
						{
							// Toast.makeTextText(getApplicationContext(),name+
							// " set default ",Toast.LENGTH_LONG).show();
						} else {
							// Toast.makeTextText(getApplicationContext(),name+
							// " was not set default ",Toast.LENGTH_LONG).show();
						}
					}

				}

				// Toast.makeTextText(getApplicationContext(),name +
				// " Profile Edited from Device",Toast.LENGTH_LONG).show();
			return 1;
		}
	}
	public String getProfileID(String profileName) 
	{
		String s = "";
		// Toast.makeText(getApplicationContext(),
		// "Profile name for which id to fetch    "+
		// profileName, Toast.LENGTH_SHORT).show();
		Cursor mCursor = SqliteWrapper.query(context,context.getContentResolver(), APN_TABLE_URI,
				new String[] { "_id" }, " name like '" + profileName + "'",
				null, null);

		// Cursor mCursor =
		// getContentResolver().query(Uri.parse("content://telephony/carriers"),
		// new
		// String[] {"_id"}, "current=1", null, null);
		// Toast.makeText(getApplicationContext(), "about to fetch id ",
		// Toast.LENGTH_SHORT).show();

		if (mCursor != null) 
		{
			try 
			{
				s = printAllData(mCursor);
				// apnDetails.setText(s);

			} catch (Exception ex) {
				Toast.makeText(context.getApplicationContext(), ex.toString(),
						Toast.LENGTH_SHORT).show();
			}

			finally {
				mCursor.close();
			}
		}
		// Toast.makeText(getApplicationContext(),
		// "value of s in while fetching id "+ s,
		// Toast.LENGTH_SHORT).show();
		return s;
		// return new String("");
	}
	
	/**
	 * Retrieves the IDS
	 * 
	 * @return String
	 */
	public String getIDS() 
	{
		String s = "";
		try 
		{
			TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			// edited just now
			String mccMnc = telephonyManager.getSimOperator();
			LogWrite.d(tag, "***************************************************>" + mccMnc + "<");
			if (mccMnc.length() >= 5)
			{
				mcc = mccMnc.substring(0, 3);
				mnc = mccMnc.substring(3, mccMnc.length());
				LogWrite.d(tag, "MCC : " + mcc + "<");
				LogWrite.d(tag, "Mnc : " + mnc + "<");
				// String s = "";
				Cursor mCursor = SqliteWrapper.query(context,context.getContentResolver(), APN_TABLE_URI,
						new String[] { "_id" }, " mnc like '" + mnc + "' and mcc like '" + mcc + "'",
						null, null);
				LogWrite.d(tag, "Cursor : " + mCursor + "<");
				if(mCursor != null) 
				{
					try 
					{
						s = printAllData(mCursor);
						LogWrite.d(tag, "S String : " + s );
					} 
					catch (Exception ex) 
					{
						LogWrite.d(tag, "ExceptionDTO : " + ex.toString() );
					}
					finally 
					{
						mCursor.close();
					}
				}
				LogWrite.d(tag, "getIDS() ->" + s);
			}

		} 
		catch (Exception e) 
		{
			LogWrite.d(tag,"Get ID ExceptionDTO : " +  e.toString());
			e.printStackTrace();
		}
		return s;
	}
	
	public String APNFetcher() 
	{
		// PREFERRED_APN_URI = Uri.parse("content://telephony/carriers/");
		// PREFERRED_APN_URI =
		// Uri.parse("content://telephony/carriers/preferapn");
		Cursor cursor = null;
		String APN = "";
		try 
		{
			cursor = SqliteWrapper.query(context,context.getContentResolver(),PREFERRED_APN_URI, null, null, null, null);
			if (cursor.moveToFirst()) 
			{
				LogWrite.d(tag, "-----Count:" + cursor.getCount() + "     ColumnCount:" + cursor.getColumnCount());
				if (cursor != null) 
				{
					do 
					{
						// cursor.get
						for (int i = 0; i < cursor.getColumnCount(); i++) 
						{
							LogWrite.d(tag, "cursor  : " + i + " ---->" + cursor.getColumnName(i) + "  " + cursor.getString(i));
						}
						if (cursor.getString(17) != null || cursor.getString(16) != null) 
						{
							if(cursor.getString(16).equals("1"))
							{
								APN = cursor.getString(1);
								LogWrite.d(tag, "APN *******---->" + APN);
								return APN;
							}
							 
							if (cursor.getString(17).equals("1")) 
							{
								APN = cursor.getString(1);
								LogWrite.d(tag, "APN  *******---->" + APN);
								return APN;
							}
						}
					} while (cursor.moveToNext());
				}
			}
		}
		catch (Exception ex) 
		{
			LogWrite.d(tag, "APN Fetcher ExceptionDTO ---> " + ex.toString());
		}
		finally 
		{
			if (cursor != null)
				cursor.close();
		}
		return APN;
	}
}
