package com.kochartech.gizmodoctor.Fragment;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Adapter.MobileInfoAdapter;
import com.kochartech.gizmodoctor.HelperClass.AppInfo;
import com.kochartech.gizmodoctor.HelperClass.DeviceInformation;

public class GUIDeviceInfo extends Fragment implements MyFragment {

	private Context context;
	private View rootView;
	private ListView deviceInfoListView;
	private String[] infoTypeStringAraay = { "Brand", "Model", "OS Version",
			"Carrier", "Network Type", "RAM", "Storage Capacity", "IMEI",
			"Battery Level", "Version" };
	private String[] infoValueStringArray = { "NA", "NA", "NA", "NA", "NA",
			"NA", "NA", "NA", "NA", "NA" };
	private DeviceInformation deviceInfo;
	private MobileInfoAdapter deviceInfoAdapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	public void initDataSet() {

		context = getActivity();

		try {
			deviceInfo = new DeviceInformation(getActivity());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[0] = deviceInfo.getBrand();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[1] = deviceInfo.getModel();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[2] = deviceInfo.getOSVersion();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[3] = deviceInfo.getCarrierName();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[4] = deviceInfo.getNetworktype();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[5] = deviceInfo.getTotalRAM();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[6] = deviceInfo.getTotalStorageCapacity();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			infoValueStringArray[7] = deviceInfo.getIMEI();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// infoValueStringArray[7] = deviceInfo.getIMSI();
		try {
			infoValueStringArray[8] = deviceInfo.getBatteryLevel();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// to get Application Version
		infoValueStringArray[9] = AppInfo.getApplicationVersionName(context);
		deviceInfoAdapter = new MobileInfoAdapter(context, infoTypeStringAraay,
				infoValueStringArray, false);

	}

	public String getApplicationVersionName() {
		try {
			PackageInfo pInfo = context.getPackageManager().getPackageInfo(
					context.getPackageName(), PackageManager.GET_META_DATA);
			return String.valueOf(pInfo.versionName);
		} catch (Exception e) {
			return "NA";
		}
	}

	public void initUi(LayoutInflater inflater, ViewGroup container) {
		rootView = inflater.inflate(R.layout.fragment_deviceinfo, container,
				false);
		deviceInfoListView = (ListView) rootView
				.findViewById(R.id.deviceInfolistView);

		deviceInfoListView.setAdapter(deviceInfoAdapter);
	}

	@Override
	public String getTitle() { // TODO Auto-generated method stub

		return "Device Information";
	}

	// @Override
	// public boolean isToUpdateUi() {
	// // TODO Auto-generated method stub
	// return false;
	// }

}
