package com.kochartech.gizmodoctor.Activity;

public interface OnCommandListener {
	public void onCommand(boolean value);
}
