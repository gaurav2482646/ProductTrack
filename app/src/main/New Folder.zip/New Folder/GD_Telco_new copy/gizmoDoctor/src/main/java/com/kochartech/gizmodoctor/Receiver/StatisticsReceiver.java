package com.kochartech.gizmodoctor.Receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.MonitorInBackground.RunnableTask;

public class StatisticsReceiver extends BroadcastReceiver {
	private String tag = StatisticsReceiver.class.getSimpleName();

	@Override
	public void onReceive(Context context, Intent intent) {
		LogWrite.d(tag, "Receiver Work every 2 mins");
		// HardwareTest.test(context, HardwareTest.KEY_BLUETOOTH_HARDWARE);
		// ArrayList<KTApplicationDTO> list = null;
		try {
			// KTBatteryApps batteryApps = new KTBatteryApps(
			// context.getApplicationContext());
			// Thread.sleep(5000);
			// list = batteryApps.refreshView();
			Thread thread = new Thread(new RunnableTask(context));
			thread.start();
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO : " + e.toString());
		}

	}
}
