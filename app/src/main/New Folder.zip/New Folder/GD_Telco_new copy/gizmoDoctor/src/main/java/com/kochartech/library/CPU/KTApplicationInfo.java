package com.kochartech.library.CPU;

import android.graphics.drawable.Drawable;

/**
 * This class is getter/setter for Application
 * 
 * @author aman.arora
 */
public class KTApplicationInfo {
	private String appName;
	private String processName;
	private Drawable icon;
	private int pid;
	private String usage;

	public KTApplicationInfo() {

	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public Drawable getIcon() {
		return icon;
	}

	public void setIcon(Drawable icon) {
		this.icon = icon;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getUsage() {
//		if(Integer.parseInt(usage) > 100)
		if(Integer.valueOf(usage.split("%")[0].trim()) > 100)
			usage = "95%";
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		/*
		 * Check if o is an instance of Complex or not "null instanceof [type]"
		 * also returns false
		 */
		if (!(o instanceof KTApplicationInfo)) {
			return false;
		}
		// typecast o to Complex so that we can compare data members
		KTApplicationInfo applicationInfo = (KTApplicationInfo) o;
		// Compare the data members and return accordingly
		return applicationInfo.getAppName().equals(appName);
	}
}
