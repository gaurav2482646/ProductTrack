//package com.kochartech.gizmodoctor.Activity;
//
//import android.os.AsyncTask;
//import android.support.v4.app.Fragment;
//
//public class UpdateUiAsync extends AsyncTask<String,String,String>
//{
//	private Fragment fragment;
//	public UpdateUiAsync(Fragment fragment) 
//	{
//		this.fragment = fragment;
//	}
//	@Override
//	protected String doInBackground(String... params) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	@Override
//	protected void onProgressUpdate(String... values) {
//		// TODO Auto-generated method stub
//		super.onProgressUpdate(values);
//	
//	}
//	
//}
