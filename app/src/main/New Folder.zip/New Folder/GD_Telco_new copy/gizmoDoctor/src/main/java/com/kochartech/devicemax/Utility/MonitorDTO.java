package com.kochartech.devicemax.Utility;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * "SessionId":92233, "MessageId":9223372, "Accelerometer":"1",
 * "Bluetooth":"-1", "Camera":"-1", "FlashLight":"-1", "Gps":"-1",
 * "LongPress":"-1", "Proximity":"-1", "Touch":"-1", "Vibration":"-1",
 * "Wifi":"-1"
 *
 * @author aman.arora
 */
public class MonitorDTO {
    private long sessionId = 0;
    private long messageId = 0;
    private int vibrateResponse = -1;
    private int touchResponse = -1;
    private int longpressResponse = -1;
    private int acceleResponse = -1;
    private int proximityResponse = -1;
    private int flashlightResponse = -1;
    private int wifiResponse = -1;
    private int gpsResponse = -1;
    private int cameraResponse = -1;
    private int bluetoothResponse = -1;
    private int multiTouchResponse = -1;
    private int speakerTest = -1;
    private int micTest = -1;
    private int displayTest = -1;
    private int homeKeyTest = -1;
    private int powerKeyTest = -1;
    private int menuKeyTest = -1;
    private int backKeyTest = -1;
    private int volumeUpKeyTest = -1;
    private int volumeDownKeyTest = -1;

    public long getSessionId() {
        return sessionId;
    }

    public void setSessionId(long sessionId) {
        this.sessionId = sessionId;
    }

    public long getMessageId() {
        return messageId;
    }

    public void setMessageId(long messageId) {
        this.messageId = messageId;
    }

    public int getHomeKeyTest() {
        return homeKeyTest;
    }

    public void setHomeKeyTest(int homeKeyTest) {
        this.homeKeyTest = homeKeyTest;
    }

    public int getPowerKeyTest() {
        return powerKeyTest;
    }

    public void setPowerKeyTest(int powerKeyTest) {
        this.powerKeyTest = powerKeyTest;
    }

    public int getMenuKeyTest() {
        return menuKeyTest;
    }

    public void setMenuKeyTest(int menuKeyTest) {
        this.menuKeyTest = menuKeyTest;
    }

    public int getVolumeUpKeyTest() {
        return volumeUpKeyTest;
    }

    public void setVolumeUpKeyTest(int volumeUpKeyTest) {
        this.volumeUpKeyTest = volumeUpKeyTest;
    }

    public int getVolumeDownKeyTest() {
        return volumeDownKeyTest;
    }

    public void setVolumeDownKeyTest(int volumeDownKeyTest) {
        this.volumeDownKeyTest = volumeDownKeyTest;
    }

    public int getVibrateResponse() {
        return vibrateResponse;
    }

    public void setVibrateResponse(int vibrateResponse) {
        this.vibrateResponse = vibrateResponse;
    }

    public int getTouchResponse() {
        return touchResponse;
    }

    public void setTouchResponse(int touchResponse) {
        this.touchResponse = touchResponse;
    }

    public int getLongpressResponse() {
        return longpressResponse;
    }

    public void setLongpressResponse(int longpressResponse) {
        this.longpressResponse = longpressResponse;
    }

    public int getAcceleResponse() {
        return acceleResponse;
    }

    public void setAcceleResponse(int acceleResponse) {
        this.acceleResponse = acceleResponse;
    }

    public int getProximityResponse() {
        return proximityResponse;
    }

    public void setProximityResponse(int proximityResponse) {
        this.proximityResponse = proximityResponse;
    }

    public int getFlashlightResponse() {
        return flashlightResponse;
    }

    public void setFlashlightResponse(int flashlightResponse) {
        this.flashlightResponse = flashlightResponse;
    }

    public int getWifiResponse() {
        return wifiResponse;
    }

    public void setWifiResponse(int wifiResponse) {
        this.wifiResponse = wifiResponse;
    }

    public int getGpsResponse() {
        return gpsResponse;
    }

    public void setGpsResponse(int gpsResponse) {
        this.gpsResponse = gpsResponse;
    }

    public int getCameraResponse() {
        return cameraResponse;
    }

    public void setCameraResponse(int cameraResponse) {
        this.cameraResponse = cameraResponse;
    }

    public int getBluetoothResponse() {
        return bluetoothResponse;
    }

    public void setBluetoothResponse(int bluetoothResponse) {
        this.bluetoothResponse = bluetoothResponse;
    }

    public int getMultiTouchResponse() {
        return multiTouchResponse;
    }

    public void setMultiTouchResponse(int multiTouchResponse) {
        this.multiTouchResponse = multiTouchResponse;
    }

    public int getSpeakerTest() {
        return speakerTest;
    }

    public void setSpeakerTest(int speakerTest) {
        this.speakerTest = speakerTest;
    }

    public int getMicTest() {
        return micTest;
    }

    public void setMicTest(int micTest) {
        this.micTest = micTest;
    }

    public int getDisplayTest() {
        return displayTest;
    }

    public void setDisplayTest(int displayTest) {
        this.displayTest = displayTest;
    }

    public int getBackKeyTest() {
        return backKeyTest;
    }

    public void setBackKeyTest(int backKeyTest) {
        this.backKeyTest = backKeyTest;
    }

    // * "SessionId":92233, "MessageId":9223372, "Accelerometer":"1",
    // * "Bluetooth":"-1", "Camera":"-1", "FlashLight":"-1", "Gps":"-1",
    // * "LongPress":"-1", "Proximity":"-1", "Touch":"-1", "Vibration":"-1",
    // * "Wifi":"-1"
    public String toString() {
        String message = "";
        try {
            JSONObject object = new JSONObject();
//			object.put("SessionId", getSessionId());
//			object.put("MessageId", getMessageId());
            object.put("__type", "HardwareTestReceiveDTO:#Antitheft.CommandService.DTO.Commands.Receive");
            if (getAcceleResponse() != -1) {
//				object.put("Accelerometer", getAcceleResponse());
                object.put("HWTSTName", "Accelerometer");
                object.put("HWTSTResponse", getAcceleResponse() == 1);
            }
            if (getBluetoothResponse() != -1) {
//				object.put("Bluetooth", getBluetoothResponse());
                object.put("HWTSTName", "Bluetooth");
                object.put("HWTSTResponse", getBluetoothResponse() == 1);
            }
            if (getCameraResponse() != -1) {
                object.put("Camera", getCameraResponse());
                object.put("HWTSTName", "Accelerometer");
                object.put("HWTSTResponse", getAcceleResponse() == 1);
            }
            if (getFlashlightResponse() != -1) {
                object.put("HWTSTName", "FlashLight");
                object.put("HWTSTResponse", getFlashlightResponse() == 1);
//                object.put("FlashLight", getFlashlightResponse());
            }
            if (getGpsResponse() != -1) {
                object.put("HWTSTName", "Gps");
                object.put("HWTSTResponse", getGpsResponse() == 1);
//                object.put("Gps", getGpsResponse());
            }
            if (getLongpressResponse() != -1) {
                object.put("HWTSTName", "LongPress");
                object.put("HWTSTResponse", getLongpressResponse() == 1);
//                object.put("LongPress", getLongpressResponse());
            }
            if (getProximityResponse() != -1) {
                object.put("HWTSTName", "Proximity");
                object.put("HWTSTResponse", getProximityResponse() == 1);
//                object.put("Proximity", getProximityResponse());
            }
            if (getTouchResponse() != -1) {
                object.put("HWTSTName", "Touch");
                object.put("HWTSTResponse", getTouchResponse() == 1);
//                object.put("Touch", getTouchResponse());
            }
            if (getVibrateResponse() != -1) {
                object.put("HWTSTName", "Vibration");
                object.put("HWTSTResponse", getVibrateResponse() == 1);
//                object.put("Vibration", getVibrateResponse());
            }
            if (getWifiResponse() != -1) {
                object.put("HWTSTName", "Wifi");
                object.put("HWTSTResponse", getWifiResponse() == 1);
//                object.put("Wifi", getWifiResponse());
            }
            if (getMultiTouchResponse() != -1) {
                object.put("HWTSTName", "MultiTouch");
                object.put("HWTSTResponse", getMultiTouchResponse() == 1);
//                object.put("MultiTouch", getMultiTouchResponse());
            }
            if (getMicTest() != -1) {
                object.put("HWTSTName", "MIC");
                object.put("HWTSTResponse", getMicTest() == 1);
//                object.put("MIC", getMicTest());
            }
            if (getSpeakerTest() != -1) {
                object.put("HWTSTName", "Speaker");
                object.put("HWTSTResponse", getSpeakerTest() == 1);
//                object.put("Speaker", getSpeakerTest());
            }
            if (getDisplayTest() != -1) {
                object.put("HWTSTName", "Display");
                object.put("HWTSTResponse", getDisplayTest() == 1);
//                object.put("Display", getDisplayTest());
            }
            if (getPowerKeyTest() != -1) {
                object.put("HWTSTName", "PowerKey");
                object.put("HWTSTResponse", getPowerKeyTest() == 1);
//                object.put("PowerKey", getPowerKeyTest());
            }
            if (getMenuKeyTest() != -1) {
                object.put("HWTSTName", "MenuKey");
                object.put("HWTSTResponse", getMenuKeyTest() == 1);
//                object.put("MenuKey", getMenuKeyTest());
            }
            if (getBackKeyTest() != -1) {
                object.put("HWTSTName", "BackKey");
                object.put("HWTSTResponse", getBackKeyTest() == 1);
//                object.put("BackKey", getBackKeyTest());
            }
            if (getHomeKeyTest() != -1) {
                object.put("HWTSTName", "HomeKey");
                object.put("HWTSTResponse", getHomeKeyTest() == 1);
//                object.put("HomeKey", getHomeKeyTest());
            }
            if (getVolumeUpKeyTest() != -1) {
                object.put("HWTSTName", "VolumeUp");
                object.put("HWTSTResponse", getVolumeUpKeyTest() == 1);
//                object.put("VolumeUp", getVolumeUpKeyTest());
            }
            if (getVolumeDownKeyTest() != -1) {
                object.put("HWTSTName", "VolumeDown");
                object.put("HWTSTResponse", getVolumeDownKeyTest() == 1);
//                object.put("VolumeDown", getVolumeDownKeyTest());
            }
            message = object.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return message;
    }

}
