//package com.kochartech.gizmodoctor.Activity;
//
//import org.json.JSONException;
//import org.json.JSONObject;
//
//import android.app.Activity;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.os.AsyncTask;
//import android.os.Bundle;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.Window;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.CustomView.MyAlertDialog;
//import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
//import com.kochartech.gizmodoctor.HelperClass.AppConstants;
//import com.kochartech.gizmodoctor.HelperClass.ConnectionDetector;
//import com.kochartech.gizmodoctor.HelperClass.DeviceInformation;
//import com.kochartech.gizmodoctor.HelperClass.HttpPostConnection;
//
//public class GUIActivation extends Activity implements OnClickListener {
//	/*
//	 * if activation key Valid, then i get number of days left else i get the
//	 * message from = "ValidUpto"
//	 * 
//	 * For ForgetActivation Key if imei is valid then we get activation key as a
//	 * response message and also receive mail for this else null
//	 */
//	private String tag = "GUIActivation";
//	private TextView forgetSerialKeyTxtView;
//	private Button submitBt;
//	private EditText activiationKeyEditTxt;
//	private Context context;
//	private MyProgressDialog myProgressDialog;
//	private DeviceInformation deviceInformation;
//	private String imei;
//	private ConnectionDetector connDetector;
//	private AppConstants appConstants;
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		setContentView(R.layout.activity_activation);
//
//		context = this;
//		appConstants = new AppConstants();
//		connDetector = new ConnectionDetector(context);
//
//		activiationKeyEditTxt = (EditText) findViewById(R.id.activationKeyEditTxt);
//		activiationKeyEditTxt.setText(getActiviationKeyValue());
//
//		submitBt = (Button) findViewById(R.id.submitBt);
//		submitBt.setOnClickListener(this);
//
//		forgetSerialKeyTxtView = (TextView) findViewById(R.id.forgetSerialKeyTxtView);
//		forgetSerialKeyTxtView.setOnClickListener(this);
//
//		deviceInformation = new DeviceInformation(context);
//		imei = deviceInformation.getIMEI();
//
//		myProgressDialog = new MyProgressDialog(this);
//	}
//
//	public void onClick(View view) {
//
//		if (connDetector.isInternetAvailable()) {
//			if (view.getId() == R.id.submitBt)
//				registerActivationKey();
//			else if (view.getId() == R.id.forgetSerialKeyTxtView)
//				forgetActivationKey();
//		} else
//			MyAlertDialog.showAlertDialog(context,
//					R.string.InternetConnectionTxt,
//					R.string.InternetNotAvailableTxt);
//
//	}
//
//	public void forgetActivationKey() {
//
//		if (myProgressDialog != null)
//			if (!myProgressDialog.isShowing())
//				myProgressDialog.show();
//
//		new Thread(new Runnable() {
//
//			@Override
//			public void run() {
//
//				// TODO Auto-generated method stub
//				HttpPostConnection httConnection = new HttpPostConnection(
//						context, HttpPostConnection.methodGetApplicationKey);
//				httConnection.connect();
//				httConnection.writeToServer(createJsonForGetActivationKey());
//				String serverResponse = httConnection.readFromServer();
//
//				LogWrite.d(tag, "Server Response: " + serverResponse);
//				if (serverResponse != null) {
//					serverResponse = serverResponse.replace("\"", "").trim();
//					final String activationKey = serverResponse;
//					LogWrite.d(tag, "activationKey: " + activationKey);
//					if (activationKey.length() > 0
//							&& activationKey.toLowerCase().startsWith(
//									appConstants.getApplicationkeycode()
//											.toLowerCase())) {
//						runOnUiThread(new Runnable() {
//
//							@Override
//							public void run() {
//								// TODO Auto-generated method stub
//								activiationKeyEditTxt.setText(activationKey);
//								Toast.makeText(
//										context,
//										"Activation Key is also send to Register Email Account",
//										Toast.LENGTH_LONG).show();
//								LogWrite.d(tag, "Finish");
//							}
//						});
//					} else {
//						runOnUiThread(new Runnable() {
//							@Override
//							public void run() {
//								// TODO Auto-generated method stub
//								Toast.makeText(
//										context,
//										"Activation Key is not created for this Device.",
//										Toast.LENGTH_LONG).show();
//							}
//						});
//					}
//				}
//
//				runOnUiThread(new Runnable() {
//
//					@Override
//					public void run() {
//						// TODO Auto-generated method stub
//						if (myProgressDialog != null) {
//							if (myProgressDialog.isShowing())
//								myProgressDialog.dismiss();
//						}
//					}
//				});
//			}
//		}).start();
//
//	}
//
//	public String createJsonForGetActivationKey() {
//		JSONObject json = new JSONObject();
//		try {
//			json.put("imei", imei);
//			json.put("keycode", appConstants.getApplicationkeycode());
//
//		} catch (ExceptionDTO e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return json.toString();
//	}
//
//	public String getActiviationKeyValue() {
//		SharedPreferences preferences = context.getSharedPreferences(
//				"MyPreferences", 0);
//		return preferences.getString("activationkey", "");
//
//	}
//
//	public void registerActivationKey() {
//		String activationKey = activiationKeyEditTxt.getText().toString()
//				.trim();
//
//		if (activationKey.length() == 0) {
//			Toast.makeText(getApplicationContext(),
//					"Please enter Activation Key", Toast.LENGTH_LONG).show();
//		} else {
//
//			JSONObject jsonActivationInfo = new JSONObject();
//
//			try {
//				jsonActivationInfo.put("appkey", activationKey);
//				jsonActivationInfo.put("imei", imei);
//			} catch (JSONException e) {
//
//			}
//			String mesgae = jsonActivationInfo.toString();
//
//			myProgressDialog.show();
//			new Async().execute(mesgae);
//
//		}
//	}
//
//	class Async extends AsyncTask<String, Boolean, String> {
//
//		private String serverResponse;
//
//		@Override
//		protected String doInBackground(String... params) {
//			// TODO Auto-generated method stub
//
//			String message = params[0];
//
//			HttpPostConnection httpConnection = new HttpPostConnection(context,
//					HttpPostConnection.methodValidateActivationKey);
//			httpConnection.connect();
//			LogWrite.d(tag, "Message To sever: " + message);
//			httpConnection.writeToServer(message);
//			serverResponse = httpConnection.readFromServer();
//
//			LogWrite.d(tag, "ServerMessage: " + serverResponse);
//
//			boolean isActivationKeyValid = false;
//			if (serverResponse != null) {
//				serverResponse = serverResponse.replace("\"", "").trim();
//				if (isActivationKeyValid(serverResponse)) {
//
//					int numOfDays = Integer.valueOf(serverResponse);
//					if (numOfDays > 0) { // Num of Days are not negative
//
//						LogWrite.d(tag, "NumOfDays: " + numOfDays);
//						long numOfDaysInMilliSeconds = convertDaysToMilliseconds(numOfDays);
//						LogWrite.d(tag, "NumOfDays in Milliseconds: "
//								+ numOfDaysInMilliSeconds);
//
//						SharedPreferences preferences = context
//								.getSharedPreferences("MyPreferences", 0);
//						Editor editor = preferences.edit();
//						editor.putLong("activation_time_left",
//								numOfDaysInMilliSeconds);
//						editor.putBoolean("activation_key_isActivated", true);
//						editor.commit();
//
//						// Yes activation is Valid because numofdays greater
//						// than 0
//						isActivationKeyValid = true;
//					}
//				}
//			}
//
//			publishProgress(isActivationKeyValid);
//			return null;
//		}
//
//		@Override
//		protected void onProgressUpdate(Boolean... values) {
//			// TODO Auto-generated method stub
//
//			super.onProgressUpdate(values);
//
//			if (values[0]) {
//				// Activation key is Valid
//				intentNavigationDrawer(true);
//			} else {
//				Toast.makeText(getApplicationContext(),
//						"Activation Key is not valid.", Toast.LENGTH_LONG)
//						.show();
//			}
//
//		}
//
//		@Override
//		protected void onPostExecute(String result) {
//			// TODO Auto-generated method stub
//			super.onPostExecute(result);
//			if (myProgressDialog != null) {
//				if (myProgressDialog.isShowing())
//					myProgressDialog.dismiss();
//
//			}
//		}
//	}
//
//	/*
//	 * if activation key is Valid then i get number of days left else message
//	 * "ValidUpto"
//	 */
//	public boolean isActivationKeyValid(String serverMessage) {
//		try {
//			Integer.parseInt(serverMessage);
//			return true;
//		} catch (NumberFormatException e) {
//		}
//		return false;
//	}
//
//	public long convertDaysToMilliseconds(int numOfDays) {
//		return numOfDays * 24 * 60 * 60 * 1000L;
//	}
//
//	public void intentNavigationDrawer(boolean isToFinish) {
//		Intent intent = new Intent(context, NavDrawerActivity.class);
//		startActivity(intent);
//		if (isToFinish) {
//			setResult(RESULT_OK);
//			finish();
//		}
//	}
//}