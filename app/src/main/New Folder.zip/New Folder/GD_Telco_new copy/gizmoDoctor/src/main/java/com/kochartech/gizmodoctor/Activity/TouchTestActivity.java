package com.kochartech.gizmodoctor.Activity;

import java.util.ArrayList;

import com.kochartech.gizmodoctor.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


@SuppressLint({ "InlinedApi", "ClickableViewAccessibility", "NewApi" })
public class TouchTestActivity extends Activity implements OnTouchListener {
	private String TAG = TouchTestActivity.class.getSimpleName();

	private int gridViewWidth;
	private int gridViewHeight;

	private int gridWidthCount = 5;
	private int gridHeightCount = 0;

	private GridView gridview;
	private TextView resultView;

	private ArrayList<GridItem> arrayList;

	// private LinearLayout touchScreen;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {
			View decorView = getWindow().getDecorView();
			// Hide both the navigation bar and the status bar.
			// SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and
			// higher, but as
			// a general rule, you should design your app to hide the status bar
			// whenever you
			// hide the navigation bar.
			int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
					| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			decorView.setSystemUiVisibility(uiOptions);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Display d = getWindowManager().getDefaultDisplay();

		DisplayMetrics realDisplayMetrics = new DisplayMetrics();
		d.getRealMetrics(realDisplayMetrics);

		int screenHeight = realDisplayMetrics.heightPixels;
		int screenWidth = realDisplayMetrics.widthPixels;

		// DisplayMetrics displaymetrics = new DisplayMetrics();
		// getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
		// int screenHeight = displaymetrics.heightPixels + 96;
		// int screenWidth = displaymetrics.widthPixels;

		Log.i(TAG, "ScreenWidth : " + screenWidth);
		Log.i(TAG, "ScreenHeight : " + screenHeight);

		setContentView(R.layout.activity_touch);

		// touchScreen = (LinearLayout) findViewById(R.id.touch_screen);
		gridview = (GridView) findViewById(R.id.gridview);
		resultView = (TextView) findViewById(R.id.resultView);
		resultView.setVisibility(View.GONE);
		gridViewWidth = screenWidth / gridWidthCount;
		Log.i(TAG, "gridViewWidth : " + gridViewWidth);
		gridview.setColumnWidth(gridViewWidth);

		gridHeightCount = screenHeight / (gridViewWidth / 2);
		Log.i(TAG, "gridHeightCount : " + gridHeightCount);

		gridViewHeight = screenHeight / gridHeightCount;
		Log.i(TAG, "gridViewHeight : " + gridViewHeight);
		arrayList = new ArrayList<GridItem>();
		for (int i = 0; i < (gridHeightCount * gridWidthCount); i++) {
			ImageView imageView = new ImageView(this);
			imageView.setLayoutParams(new GridView.LayoutParams(
					gridViewWidth / 2, gridViewHeight));
			imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
			imageView.setPadding(0, 8, 0, 8);
			GridItem gridItem = new GridItem();
			gridItem.setImageView(imageView);
			gridItem.setTouchStatus(false);
			arrayList.add(gridItem);
		}

		gridview.setAdapter(new ImageAdapter(this, arrayList));
		gridview.setOnTouchListener(this);
		
		LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, (ViewGroup) findViewById(R.id.custom_toast_layout));

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(toastLayout);
        for (int i = 0; i < 3; i++) {
        	toast.show();
		}
        
		

	}

	private class ImageAdapter extends BaseAdapter {
		private ArrayList<GridItem> arrayList;

		public ImageAdapter(Context c, ArrayList<GridItem> arrayList) {
			// mContext = c;
			this.arrayList = arrayList;
		}

		public int getCount() {
			return arrayList.size();
		}

		public ImageView getItem(int position) {
			return null;
		}

		public long getItemId(int position) {
			return 0;
		}

		// create a new ImageView for each item referenced by the Adapter
		public View getView(int position, View convertView, ViewGroup parent) {
			final ImageView imageView;
			if (convertView == null) {
				// if it's not recycled, initialize some attributes
				imageView = arrayList.get(position).getImageView();
			} else {
				imageView = (ImageView) convertView;
			}
			imageView.setImageResource(mThumbIds[1]);
			return imageView;
		}

		// references to our images

	}

	private class GridItem {
		private ImageView imageView;
		private boolean touchStatus;

		public ImageView getImageView() {
			return imageView;
		}

		public void setImageView(ImageView imageView) {
			this.imageView = imageView;
		}

		public boolean isTouchStatus() {
			return touchStatus;
		}

		public void setTouchStatus(boolean touchStatus) {
			this.touchStatus = touchStatus;
		}
	}

	private Integer[] mThumbIds = {0,
			R.drawable.sample_grid_color };
	float initialX, initialY;

	@Override
	public boolean onTouch(View view, MotionEvent event) {
		// int action = event.getActionMasked();
		int position = ((GridView) view).pointToPosition((int) event.getX(),
				(int) event.getY());
		Log.e(TAG, "Position ::: " + position);
		if (position != -1) {
			GridItem gridItem = arrayList.get(position);
			final ImageView imageView = gridItem.getImageView();
			gridItem.setTouchStatus(true);
			final Animation animation = AnimationUtils.loadAnimation(
					TouchTestActivity.this, R.anim.abc_slide_out_top);
			animation.setAnimationListener(new AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {
				}

				@Override
				public void onAnimationRepeat(Animation animation) {
				}

				@Override
				public void onAnimationEnd(Animation animation) {
					imageView.setImageResource(mThumbIds[0]);
				}
			});
			imageView.startAnimation(animation);
			if (isTouchTestSuccess()) {
				resultView.setVisibility(View.VISIBLE);
				gridview.setVisibility(View.GONE);
			}
		}
		return false;
	}

	private boolean isTouchTestSuccess() {
		for (int i = 0; i < arrayList.size(); i++) {
			GridItem item = arrayList.get(i);
			if (!item.isTouchStatus())
				return false;
		}
		return true;
	}
}
