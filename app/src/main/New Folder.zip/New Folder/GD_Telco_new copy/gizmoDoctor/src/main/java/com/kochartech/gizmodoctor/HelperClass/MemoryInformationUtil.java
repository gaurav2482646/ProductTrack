package com.kochartech.gizmodoctor.HelperClass;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.DecimalFormat;
import java.util.ArrayList;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.os.StatFs;
import android.preference.PreferenceManager;


public class MemoryInformationUtil 
{
	private static SharedPreferences preferences;
	private static int ramLimit,internalLimit, externalLimit;
	private static ArrayList<String> storeTextResult;
	private static ArrayList<Boolean> storeBooleanResult;
	private static Context context;
	public static void startDiagnose(Context context,ArrayList<String> storeTextResult,ArrayList<Boolean> storeBooleanResult)
	{
		MemoryInformationUtil.context = context;
		MemoryInformationUtil.storeTextResult    = storeTextResult;
		MemoryInformationUtil.storeBooleanResult = storeBooleanResult;
		
		setRAMDiagnoseResult(MemoryInformationUtil.context);
//		setMemoryDiagnoseResult(MemoryInformationUtil.context);
		
	}
	public static void  setRAMDiagnoseResult(Context context)
	{
		MemoryInfo mi = new MemoryInfo();
		ActivityManager activityManager = (ActivityManager)context.getSystemService(context.ACTIVITY_SERVICE);
		activityManager.getMemoryInfo(mi);
		float availableMegs = mi.availMem / 1048576F;
		float totalRamInMB = getTotalRam();
		int percent = (int) ((availableMegs * 100) / totalRamInMB);
		ramLimit = getRamLimit(context);
		
		//LogWrite.d("RAMCheck"," percent = "+percent);
		
		if(percent<=30)
		{
			
		}
		else
		{
			
		}
//		//LogWrite.d("RAMCheck"," availableMegs = "+availableMegs);
//		//LogWrite.d("RAMCheck"," totalRamInMB = "+totalRamInMB);
//		//LogWrite.d("RAMCheck"," percent = "+percent);
		
//		if (ramLimit > percent) {
////			Toast.makeText(context,"false",Toast.LENGTH_LONG).show();
//			storeBooleanResult.add(false);
////			return false;
////			Ram.setTextColor(Color.RED);
////			ramStatusIcon.setImageDrawable(getResources().getDrawable(R.drawable.no));
//		} else {
//			storeBooleanResult.add(true);
////			Toast.makeText(context,"true",Toast.LENGTH_LONG).show();
////			return true;
////			Ram.setTextColor(Color.parseColor("#3B3B3B"));
////			ramStatusIcon.setImageDrawable(getResources().getDrawable(R.drawable.yes));
//		
//			
//		}

//		Toast.makeText(context,"Total: " + new DecimalFormat("##.##").format(totalRamInMB)
//				+ "MB,\t\tFree: "
//				+ new DecimalFormat("##.##").format(availableMegs) + "MB",Toast.LENGTH_LONG).show();
		storeTextResult.add("Total: " + new DecimalFormat("##.##").format(totalRamInMB)
				+ "MB,\t\tFree: "
				+ new DecimalFormat("##.##").format(availableMegs) + "MB");
//		Ram.setText("Total: " + new DecimalFormat("##.##").format(totalRamInMB)
//				+ "MB,\t\tFree: "
//				+ new DecimalFormat("##.##").format(availableMegs) + "MB");

	}
	private static int getRamLimit(Context context)
	{
//		preferences = PreferenceManager.getDefaultSharedPreferences(context);
//		return Integer.parseInt((preferences.getString("ram_limit","75")));
		
		return 75;
	}
	public static long getTotalRam() {
		long finaltotalRam = 0;
		try {

			RandomAccessFile reader = new RandomAccessFile("/proc/meminfo", "r"); // TOTAL
			String load;
			while ((load = reader.readLine()) != null) {
				if (load.contains("MemTotal")) {
					break;
				}
			}
			// //LogWrite.d(tag, "FINAL:> " + string.toString());
			String totalRAM = load.trim().substring(9, load.indexOf("kB"));
			// //LogWrite.d(tag, "TOTAL RAM IS:> " + totalRAM);
			long total = Long.parseLong(totalRAM.trim());
			finaltotalRam = (long) ( total /  1024);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return finaltotalRam;
	}	
	
	/*
	 *  Setting internal+external memory
	 */
	
	private static void setMemoryDiagnoseResult(Context context)
	{
		try {
			StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
			StatFs statSD = new StatFs(Environment
					.getExternalStorageDirectory().getPath());
			long bytesAvailable = (long) stat.getFreeBlocks()
					* (long) stat.getBlockSize();
			long totalMemory = (long) stat.getBlockCount()
					* (long) stat.getBlockSize();
			long freeMemory = bytesAvailable / 1048576;
			long mbTotal = totalMemory / 1048576;
			long bytesAvailableSD = (long) statSD.getFreeBlocks()
					* (long) statSD.getBlockSize();
			long totalMemorySD = (long) statSD.getBlockCount()
					* (long) statSD.getBlockSize();
			long freeMemorySD = bytesAvailableSD / 1048576;
			long mbTotalSD = totalMemorySD / 1048576;
			int internal_percent = 0, external_percent = 0;
			if (mbTotal > 0) {
				internal_percent = (int) ((freeMemory * 100) / mbTotal);
			}

			if (mbTotalSD > 0) {
				external_percent = (int) ((freeMemorySD * 100) / mbTotalSD);
			}
			internal_percent = getInternalLimit(context);
			if (internal_percent < internalLimit) {
				storeBooleanResult.add(false);
//				internalMem.setTextColor(Color.RED);
//				internalStatusIcon.setImageDrawable(getResources().getDrawable(R.drawable.no));
			}
			else
			{
				storeBooleanResult.add(true);	
			}
			externalLimit  = getExternalLimit(context);
			if (external_percent < externalLimit) {
				storeBooleanResult.add(false);
//				externalMem.setTextColor(Color.RED);
//				externalStatusIcon.setImageDrawable(getResources().getDrawable(R.drawable.no));
			}
			else
			{
				storeBooleanResult.add(true);	
			}
			storeTextResult.add("Total: " + mbTotal + "MB,\t\tFree: "
					+ freeMemory + "MB");
			storeTextResult.add("Total: " + mbTotalSD + "MB,\t\tFree: "
					+ freeMemorySD + "MB");
					
//			internalMem.setText("Total: " + mbTotal + "MB,\t\tFree: "
//					+ freeMemory + "MB");
//			externalMem.setText("Total: " + mbTotalSD + "MB,\t\tFree: "
//					+ freeMemorySD + "MB");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private static int getInternalLimit(Context context)
	{
		preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return Integer.parseInt((preferences.getString("internal_mem_limit","10")));
		
	}
	private static int getExternalLimit(Context context)
	{
		preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return  Integer.parseInt((preferences.getString("external_mem_limit","10")));
	}

}
