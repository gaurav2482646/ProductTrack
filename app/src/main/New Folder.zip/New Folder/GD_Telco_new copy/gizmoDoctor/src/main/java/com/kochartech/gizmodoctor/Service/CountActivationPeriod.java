package com.kochartech.gizmodoctor.Service;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.HelperClass.BackgroundTaskManager;
import com.kochartech.gizmodoctor.HelperClass.NotificationCheckerManager;
import com.kochartech.gizmodoctor.Preferences.ActivationKeyPreference;

public class CountActivationPeriod extends Service {

	private final String TAG = CountActivationPeriod.class.getSimpleName();
	private static Context context;
	private final long delayTime = 1300L;// in milliseconds
	private Handler handler = new Handler();
	private boolean isServiceRunning = false;
	private ActivationKeyPreference activationKeyPreference;

	/*
	 * Use variable(isToStartService) to stop this Service, otherwise it will
	 * start from onDestroy Method.
	 */
	private boolean isToStartService = true;

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		context = this;
		activationKeyPreference = new ActivationKeyPreference(context);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		isServiceRunning = true;
		handler.removeCallbacks(sendUpdatesToUI);
		handler.postDelayed(sendUpdatesToUI, 0);
		return START_STICKY;
	}

	private Runnable sendUpdatesToUI = new Runnable() {

		public void run() {
			/*
			 * Do Your Task
			 */
			intervalTasks();
			checkActivationTime();

			LogWrite.d(TAG, "Service is Running");
			if (isServiceRunning)
				handler.postDelayed(this, delayTime);
		}
	};

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		isServiceRunning = false;
		handler.removeCallbacks(sendUpdatesToUI);
		if (isToStartService) {
			startService(new Intent(getApplicationContext(),
					CountActivationPeriod.class));
		}
	}

	private void checkActivationTime() {
		long decreaseLeftTime = activationKeyPreference.getLeftTime()
				- delayTime;
		activationKeyPreference.setLeftTime(decreaseLeftTime);
		activationKeyPreference.setLastScanTime(System.currentTimeMillis());
		LogWrite.d(
				TAG,
				"Activation Time Left: "
						+ activationKeyPreference.getLeftTime());
		LogWrite.d(
				TAG,
				"Time Left : "
						+ convertToTime(activationKeyPreference.getLeftTime()));
		if (activationKeyPreference.getLeftTime() <= 0) {
			isToStartService = false;
			stopService(new Intent(context, CountActivationPeriod.class));
			BackgroundTaskManager.stopTask(context);
			activationKeyPreference.resetAll();
		}
	}

	@SuppressLint("SimpleDateFormat")
	private String convertToTime(long milliseconds) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:ss");
		Date date = new Date(milliseconds);
		return simpleDateFormat.format(date);
	}

	private void intervalTasks() {
		NotificationCheckerManager notificationManager = new NotificationCheckerManager(
				getApplicationContext());
		notificationManager.checkNotifications();
	}

}
