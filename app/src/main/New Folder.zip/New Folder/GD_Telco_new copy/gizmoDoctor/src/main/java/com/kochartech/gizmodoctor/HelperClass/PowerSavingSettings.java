package com.kochartech.gizmodoctor.HelperClass;

import java.util.ArrayList;

import android.content.Context;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.POJO.PowerSavingSettingsDTO;
import com.kochartech.gizmodoctor.Preferences.PowerSavingSettingsPreference;

public class PowerSavingSettings extends PowerSavingSettingsPreference {

	private Context context;
	public static final String TURNOFF_WIFI 	 = "Turn off Wifi";
	public static final String TURNOFF_BT     	 = "Turn off Bluetooth";
	public static final String TURNOFF_GPS 		 = "Turn off GPS";
	public static final String TURNOFF_AUTO_SYNC = "Turn off Sync";
	public static final String BRIGHTNESS 		 = "Brightness";
	public static final String SCREENTIME_OUT 	 = "Screen timeout";
	public static final String KILL_BACKGROUNDAPPS = "Kill Background Apps";

	private final String[] settingsName = { TURNOFF_WIFI, TURNOFF_BT,
			 TURNOFF_GPS, TURNOFF_AUTO_SYNC, BRIGHTNESS,
			SCREENTIME_OUT,KILL_BACKGROUNDAPPS };
	
	
	public  final String DES_TURNOFF_WIFI = "";
	public  final String DES_TURNOFF_BT = "";
	public  final String DES_TURNOFF_DATACONNECTION = "";
	public  final String DES_TURNOFF_GPS = "";
	public  final String DES_TURNOFF_AUTO_SYNC = "";
	public  final String DES_BRIGHTNESS = "20%";
	public  final String DES_SCREENTIME_OUT = "15s";
	public  final String DES_KILL_BACKGROUNDAPPS = "Auto kill background apps";
	
	

	private String getDescriptionTxt(String settingName) {
		
		if(settingName.equalsIgnoreCase(TURNOFF_WIFI)) 
			return DES_TURNOFF_WIFI;	
		else if(settingName.equalsIgnoreCase(TURNOFF_BT)) 
			return DES_TURNOFF_BT;	
		else if(settingName.equalsIgnoreCase(TURNOFF_GPS)) 
			return DES_TURNOFF_GPS;	
		else if(settingName.equalsIgnoreCase(TURNOFF_AUTO_SYNC)) 
			return DES_TURNOFF_AUTO_SYNC;	
		else if(settingName.equalsIgnoreCase(BRIGHTNESS)) 
			return DES_BRIGHTNESS;	
		else if(settingName.equalsIgnoreCase(SCREENTIME_OUT)) 
			return DES_SCREENTIME_OUT;	
		else if(settingName.equalsIgnoreCase(KILL_BACKGROUNDAPPS)) 
			return DES_KILL_BACKGROUNDAPPS;	
		return null;
	}
	
	private int getIcon(String settingName) {
		
		if(settingName.equalsIgnoreCase(TURNOFF_WIFI)) 
			return R.drawable.wifi_img;	
		else if(settingName.equalsIgnoreCase(TURNOFF_BT)) 
			return R.drawable.bt_img;	
		else if(settingName.equalsIgnoreCase(TURNOFF_GPS)) 
			return R.drawable.gps_img;	
		else if(settingName.equalsIgnoreCase(TURNOFF_AUTO_SYNC)) 
			return R.drawable.settings_icon_autosync;	
		else if(settingName.equalsIgnoreCase(BRIGHTNESS)) 
			return R.drawable.settings_icon_brightness;	
		else if(settingName.equalsIgnoreCase(SCREENTIME_OUT)) 
			return R.drawable.settings_icon_timeout;	
		else if(settingName.equalsIgnoreCase(KILL_BACKGROUNDAPPS)) 
			return R.drawable.settings_icon_killbackgroundapp;	
		return 0;
	}
	private ArrayList<PowerSavingSettingsDTO> powerSavingSettigsList = new ArrayList<PowerSavingSettingsDTO>();
	private PowerSavingSettingsPreference powerSavingSettingsPreference;

	public PowerSavingSettings(Context context) {
		super(context);
		this.context = context;
		powerSavingSettingsPreference = new PowerSavingSettingsPreference(
				context);
	}

	private int getCount() {
		return settingsName.length;
	}

	public ArrayList<PowerSavingSettingsDTO> getSettings() {
		int numOfSetting = getCount();
		for (int i = 0; i < numOfSetting; i++) {
			boolean settingState = powerSavingSettingsPreference.getPreference(i);
			PowerSavingSettingsDTO powerSavingSettingDTO = new PowerSavingSettingsDTO(
					settingsName[i], settingState, getDescriptionTxt(settingsName[i]));
			
			powerSavingSettingDTO.setIcon(getIcon(settingsName[i]));			
			powerSavingSettigsList.add(powerSavingSettingDTO);
		}
		return powerSavingSettigsList;
	}

	public void updateSettingInPreference(
			PowerSavingSettingsDTO powerSavingSettingDTO) {
		int preferenceIndex = getPreferenceIndex(powerSavingSettingDTO
				.getName());
		powerSavingSettingsPreference.setPreference(preferenceIndex,
				powerSavingSettingDTO.getState());
	}

	public int getPreferenceIndex(String settingName) {
		int numOfSetting = getCount();
		for (int i = 0; i < numOfSetting; i++) {
			if (settingsName[i].equals(settingName))
				return i;
		}
		return -1;
	}
}
