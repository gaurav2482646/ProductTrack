package com.kochartech.gizmodoctor.MonitorInBackground;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.Receiver.StatisticsReceiver;

public class StatisticsAlarmManager {
	private final String TAG = StatisticsAlarmManager.class.getSimpleName();
	// private Context context;
	private final int requestCode = 101010;
	private Intent receiverIntent;
	private AlarmManager alarmManager;
	private PendingIntent pendingIntent;
	private final long interval = 2 * 60 * 1000;
	
	// private final long interval = 10000;
	public StatisticsAlarmManager(Context context) {
		// this.context = context;
		receiverIntent = new Intent(context.getApplicationContext(),
				StatisticsReceiver.class);
		alarmManager = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
		pendingIntent = PendingIntent.getBroadcast(context, requestCode,
				receiverIntent, 0);
	}

	public void start() {
		try {
			alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
					System.currentTimeMillis() + 20000, (interval),
					pendingIntent);
		} catch (Exception e) {
			LogWrite.e(
					TAG,
					"StatisticsAlarmManagerStartException :---> "
							+ e.toString());
		}
	}

	public void stop() {
		try {
			alarmManager.cancel(pendingIntent);
		} catch (Exception e) {
			LogWrite.e(TAG,
					"StatisticsAlarmManagerStopException :---> " + e.toString());
		}
	}

}
