package com.kochartech.gizmodoctor.DataBase;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.POJO.MonitorAppDTO;
import com.kochartech.gizmodoctor.POJO.MonitoringDTO;

public class DataSource_Monitoring {
	private String tag = DataSource_Monitoring.class.getSimpleName();
	private static DataSource_Monitoring classInstance = null;
	private MySQLiteOpenHelper mySQLiteOpenHelper;
	private SQLiteDatabase db;
	private static Context appContext;

	public static DataSource_Monitoring getInstance(Context context) {
		appContext = context;
		if (classInstance == null)
			classInstance = new DataSource_Monitoring(context);
		return classInstance;
	}

	private DataSource_Monitoring(Context context) {
		LogWrite.d(tag, "constructor");
		// this.context = context;
		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
	}

	private void open() {
		LogWrite.d(tag, "open");
		db = mySQLiteOpenHelper.getWritableDatabase();
	}

	private void close() {
		LogWrite.d(tag, "close");
		db.close();
	}

	public void delete() {
		LogWrite.d(tag, "delete");
		open();
		try {
			db.execSQL("DELETE FROM " + MySQLiteOpenHelper.MONITOR_TABLE);
		} catch (Exception e) {
			LogWrite.e(tag, "ExceptionDTO : " + e.toString());
		}
		close();
	}

	public synchronized void insertRecord(MonitoringDTO monitoringDTO) {
		LogWrite.d(tag, "RowId : " + monitoringDTO.getRecord_id());
		LogWrite.d(tag, "AppName : " + monitoringDTO.getApp_name());
		LogWrite.d(tag, "ProcessName : " + monitoringDTO.getProcess_name());
		LogWrite.d(tag, "Cpu Usage : " + monitoringDTO.getCpu_usage());
		LogWrite.d(tag, "Battery Usage : " + monitoringDTO.getDischarge_rate());
		LogWrite.d(tag, "RAM Usage : " + monitoringDTO.getRam_usage());
		LogWrite.d(tag, "BatteryLevel: " + monitoringDTO.getBattery_level());
		LogWrite.d(tag, "DeviceHealth: " + monitoringDTO.getDevice_health());
		LogWrite.d(tag,
				"BatteryTemperature: " + monitoringDTO.getBattery_temp());
		LogWrite.d(tag, "ChargingState: " + monitoringDTO.getCharging_state());
		LogWrite.d(tag, "Date: " + monitoringDTO.getTime_stamp());
		open();
		ContentValues values = new ContentValues();
		values.put(MySQLiteOpenHelper.MONITOR_RECORD_ID,
				monitoringDTO.getRecord_id());
		values.put(MySQLiteOpenHelper.MONITOR_APPNAME,
				monitoringDTO.getApp_name());
		values.put(MySQLiteOpenHelper.MONITOR_PROCESSNAME,
				monitoringDTO.getProcess_name());
		values.put(MySQLiteOpenHelper.MONITOR_CPUUSAGE,
				monitoringDTO.getCpu_usage());
		values.put(MySQLiteOpenHelper.MONITOR_RAMUSAGE,
				monitoringDTO.getRam_usage());
		values.put(MySQLiteOpenHelper.MONITOR_DISCHARGE_RATE,
				monitoringDTO.getDischarge_rate());
		values.put(MySQLiteOpenHelper.MONITOR_BATTERY_TEMP,
				monitoringDTO.getBattery_temp());
		values.put(MySQLiteOpenHelper.MONITOR_BATTERY_LEVEL,
				monitoringDTO.getBattery_level());
		values.put(MySQLiteOpenHelper.MONITOR_BATTERY_STATE,
				monitoringDTO.getCharging_state());
		values.put(MySQLiteOpenHelper.MONITOR_DEVICE_HEALTH,
				monitoringDTO.getDevice_health());
		values.put(MySQLiteOpenHelper.MONITOR_WIFI,
				monitoringDTO.getWifi_time());
		values.put(MySQLiteOpenHelper.MONITOR_GPS, monitoringDTO.getGps_time());
		values.put(MySQLiteOpenHelper.MONITOR_BLUETOOTH,
				monitoringDTO.getBluetooth_time());
		values.put(MySQLiteOpenHelper.MONITOR_HOTSPOT,
				monitoringDTO.getHotspot_time());

		values.put(MySQLiteOpenHelper.MONITOR_APP_TYPE,
				monitoringDTO.getApp_type());
		values.put(MySQLiteOpenHelper.MONITOR_LAST_TIME,
				monitoringDTO.getLast_update_time());
		values.put(MySQLiteOpenHelper.MONITOR_TOTAL_CPU,
				monitoringDTO.getTotal_cpu());
		values.put(MySQLiteOpenHelper.MONITOR_TOTAL_RAM,
				monitoringDTO.getTotal_ram());
		values.put(MySQLiteOpenHelper.MONITOR_TOTAL_DISCHARGE,
				monitoringDTO.getTotal_discharge());
		values.put(MySQLiteOpenHelper.MONITOR_SIGNAL_STRENGTH,
				monitoringDTO.getSignal_strength());
		values.put(MySQLiteOpenHelper.MONITOR_BEARER_TYPE,
				monitoringDTO.getBearer_type());

		values.put(MySQLiteOpenHelper.MONITOR_TIME_STAMP,
				monitoringDTO.getTime_stamp());

		long id = db.insert(MySQLiteOpenHelper.MONITOR_TABLE, null, values);
		LogWrite.d(tag, "DataSource_MonitorUsage insert id : " + id);

		close();
		// LogWrite.d(tag, "insertRecord: recordId: " + id);

	}

	// public static final String MONITOR_BATTERY_TEMP =
	// "monitor_battery_temperature";
	// public static final String MONITOR_BATTERY_LEVEL =
	// "monitor_battery_level";
	// public static final String MONITOR_BATTERY_STATE =
	// "monitor_battery_state";
	// public static final String MONITOR_DEVICE_HEALTH =
	// "monitor_device_health";
	// public static final String MONITOR_WIFI = "monitor_wifi_time";
	// public static final String MONITOR_BLUETOOTH = "monitor_bluetooth_time";
	// public static final String MONITOR_GPS = "monitor_gps_time";
	// public static final String MONITOR_HOTSPOT = "monitor_hotspot_time";
	// public static final String MONITOR_TOTAL_CPU = "monitor_total_cpu";
	// public static final String MONITOR_TOTAL_RAM = "monitor_total_ram";
	// public static final String MONITOR_TOTAL_DISCHARGE =
	// "monitor_total_discharge_rate";
	// public static final String MONITOR_SIGNAL_STRENGTH =
	// "monitor_signal_strength";
	// public static final String MONITOR_BEARER_TYPE = "monitor_bearer_type";
	// public static final String MONITOR_TIME_STAMP = "monitor_time_stamp";

	private MonitoringDTO querySelectedDeviceRecords(int selectionArgs) {

		String[] columns = new String[] {
				MySQLiteOpenHelper.MONITOR_BATTERY_LEVEL,
				MySQLiteOpenHelper.MONITOR_BATTERY_TEMP,
				MySQLiteOpenHelper.MONITOR_BATTERY_STATE,
				MySQLiteOpenHelper.MONITOR_DEVICE_HEALTH,
				MySQLiteOpenHelper.MONITOR_WIFI,
				MySQLiteOpenHelper.MONITOR_BLUETOOTH,
				MySQLiteOpenHelper.MONITOR_GPS,
				MySQLiteOpenHelper.MONITOR_HOTSPOT,
				MySQLiteOpenHelper.MONITOR_TOTAL_CPU,
				MySQLiteOpenHelper.MONITOR_TOTAL_RAM,
				MySQLiteOpenHelper.MONITOR_TOTAL_DISCHARGE,
				MySQLiteOpenHelper.MONITOR_SIGNAL_STRENGTH,
				MySQLiteOpenHelper.MONITOR_BEARER_TYPE,
				MySQLiteOpenHelper.MONITOR_TIME_STAMP };

		String selection = MySQLiteOpenHelper.MONITOR_RECORD_ID + "=?";

		Cursor cursor = db.query(MySQLiteOpenHelper.MONITOR_TABLE, columns,
				selection, new String[] { selectionArgs + "" }, null, null,
				null);
		cursor.moveToFirst();
		MonitoringDTO monitoringDTO = new MonitoringDTO(appContext);
		monitoringDTO.setBattery_level(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_LEVEL)));
		monitoringDTO.setBattery_temp(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_TEMP)));
		monitoringDTO.setCharging_state(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_STATE)));
		monitoringDTO.setDevice_health(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_DEVICE_HEALTH)));
		monitoringDTO.setWifi_time(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_WIFI)));
		monitoringDTO.setBluetooth_time(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_BLUETOOTH)));
		monitoringDTO.setGps_time(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_GPS)));
		monitoringDTO.setHotspot_time(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_HOTSPOT)));
		monitoringDTO.setTotal_cpu(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_TOTAL_CPU)));
		monitoringDTO.setTotal_ram(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_TOTAL_RAM)));
		monitoringDTO.setTotal_discharge(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_TOTAL_DISCHARGE)));
		monitoringDTO.setSignal_strength(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_SIGNAL_STRENGTH)));
		monitoringDTO.setBearer_type(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_BEARER_TYPE)));
		monitoringDTO.setTime_stamp(cursor.getString(cursor
				.getColumnIndex(MySQLiteOpenHelper.MONITOR_TIME_STAMP)));
		cursor.close();
		return monitoringDTO;
	}

	private ArrayList<MonitorAppDTO> querySelectedAppRecords(int selectionArgs) {

		String[] columns = new String[] { MySQLiteOpenHelper.MONITOR_APPNAME,
				MySQLiteOpenHelper.MONITOR_PROCESSNAME,
				MySQLiteOpenHelper.MONITOR_APP_TYPE,
				MySQLiteOpenHelper.MONITOR_CPUUSAGE,
				MySQLiteOpenHelper.MONITOR_RAMUSAGE,
				MySQLiteOpenHelper.MONITOR_DISCHARGE_RATE,
				MySQLiteOpenHelper.MONITOR_LAST_TIME };
		String selection = MySQLiteOpenHelper.MONITOR_RECORD_ID + "=?";

		Cursor cursor = db.query(MySQLiteOpenHelper.MONITOR_TABLE, columns,
				selection, new String[] { selectionArgs + "" }, null, null,
				null);
		ArrayList<MonitorAppDTO> arrayList = new ArrayList<MonitorAppDTO>();
		while (cursor.moveToNext()) {
			MonitorAppDTO appDTO = new MonitorAppDTO();
			appDTO.setApp_name(cursor.getString(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_APPNAME)));
			appDTO.setApp_type(cursor.getString(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_APP_TYPE)));
			appDTO.setProcess_name(cursor.getString(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_PROCESSNAME)));
			appDTO.setCpu_usage(cursor.getString(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_CPUUSAGE)));
			appDTO.setRam_usage(cursor.getString(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_RAMUSAGE)));
			appDTO.setDischarge_rate(cursor.getString(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_DISCHARGE_RATE)));
			appDTO.setLast_update_time(cursor.getString(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_LAST_TIME)));
			arrayList.add(appDTO);
		}
		return arrayList;
	}

	public synchronized ArrayList<MonitoringDTO> queryTableRecId() {
		// open the database
		open();
		ArrayList<MonitoringDTO> arrayList = new ArrayList<MonitoringDTO>();
		String[] columns = new String[] { MySQLiteOpenHelper.MONITOR_RECORD_ID

		};
		Cursor cursor = db.query(true, MySQLiteOpenHelper.MONITOR_TABLE,
				columns, null, null, null, null, null, null);

		while (cursor.moveToNext()) {
			int recId = cursor.getInt(cursor
					.getColumnIndex(MySQLiteOpenHelper.MONITOR_RECORD_ID));
			LogWrite.i(tag, "----------------------------");
			LogWrite.i(tag, "Record Id :::: " + recId);
			try {
				MonitoringDTO monitorDTO = querySelectedDeviceRecords(recId);
				monitorDTO.setArrayList(querySelectedAppRecords(recId));
				arrayList.add(monitorDTO);
			} catch (Exception e) {
				LogWrite.e(tag, "ExceptionDTO ::::: " + e.toString());
			}
		}
		close();
		return arrayList;
	}

	// public synchronized List<MonitoringDTO> queryAllRecord() {
	// // open the database
	// open();
	//
	// List<MonitoringDTO> appsInfoList = new ArrayList<MonitoringDTO>();
	//
	// Cursor cursor = db.query(MySQLiteOpenHelper.MONITOR_TABLE, null, null,
	// null, null, null, null);
	//
	// int count = 0;
	// int total_row_count = 0;
	// int current_row_count = 0;
	// if (cursor.getCount() > 0) {
	// if (cursor.moveToFirst()) {
	// int index_record_id = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_RECORD_ID);
	// int index_App_Name = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_APPNAME);
	// int index_Process_Name = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_PROCESSNAME);
	// int index_Cpu_Usage = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_CPUUSAGE);
	// int index_Ram_Usage = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_RAMUSAGE);
	// int index_Discharge_Rate = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_DISCHARGE_RATE);
	// int index_Battery_Temp = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_TEMP);
	// int index_Battery_Level = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_LEVEL);
	// int index_Battery_State = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_STATE);
	// int index_Device_Health = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_DEVICE_HEALTH);
	// int index_Wifi = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_WIFI);
	// int index_Bluetooth = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_BLUETOOTH);
	// int index_Gps = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_GPS);
	// int index_Hotspot = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_HOTSPOT);
	// int index_App_Type = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_APP_TYPE);
	// int index_Last_Time = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_LAST_TIME);
	// int index_Total_Cpu = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_TOTAL_CPU);
	// int index_Total_Ram = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_TOTAL_RAM);
	// int index_Total_Discharge = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_TOTAL_DISCHARGE);
	// int index_Signal = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_SIGNAL_STRENGTH);
	// int index_Bearer = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_BEARER_TYPE);
	//
	// int index_Time_Stamp = cursor
	// .getColumnIndex(MySQLiteOpenHelper.MONITOR_TIME_STAMP);
	//
	// count = cursor.getInt(index_record_id); // 0
	// total_row_count = cursor.getCount(); // 10
	// ArrayList<MonitorAppDTO> arrayList = new ArrayList<MonitorAppDTO>();
	// do {
	// current_row_count++;
	// LogWrite.i("Aman", "TestRowCount : Total "
	// + total_row_count + " : Current "
	// + current_row_count);
	// LogWrite.i(tag,
	// "Record Id : " + cursor.getInt(index_record_id));
	// LogWrite.i("Aman", "Count : " + count);
	// MonitoringDTO monitoringDTO = new MonitoringDTO(appContext);
	// if (cursor.getInt(index_record_id) == count) {
	// LogWrite.e(tag, "Matches..............");
	// MonitorAppDTO appDTO = new MonitorAppDTO();
	// appDTO.setApp_name(cursor.getString(index_App_Name));
	// appDTO.setProcess_name(cursor
	// .getString(index_Process_Name));
	// appDTO.setCpu_usage(cursor.getString(index_Cpu_Usage));
	// appDTO.setRam_usage(cursor.getString(index_Ram_Usage));
	// appDTO.setDischarge_rate(cursor
	// .getString(index_Discharge_Rate));
	// appDTO.setApp_type(cursor.getString(index_App_Type));
	// appDTO.setLast_update_time(cursor
	// .getString(index_Last_Time));
	// arrayList.add(appDTO);
	//
	// monitoringDTO.setRecord_id(cursor
	// .getInt(index_record_id));
	// monitoringDTO.setArrayList(arrayList);
	// monitoringDTO.setBattery_temp(cursor
	// .getString(index_Battery_Temp));
	// monitoringDTO.setBattery_level(cursor
	// .getString(index_Battery_Level));
	// monitoringDTO.setCharging_state(cursor
	// .getString(index_Battery_State));
	// monitoringDTO.setDevice_health(cursor
	// .getString(index_Device_Health));
	// monitoringDTO
	// .setWifi_time(cursor.getString(index_Wifi));
	// monitoringDTO.setGps_time(cursor.getString(index_Gps));
	// monitoringDTO.setBluetooth_time(cursor
	// .getString(index_Bluetooth));
	// monitoringDTO.setHotspot_time(cursor
	// .getString(index_Hotspot));
	// monitoringDTO.setTotal_cpu(cursor
	// .getString(index_Total_Cpu));
	// monitoringDTO.setTotal_ram(cursor
	// .getString(index_Total_Ram));
	// monitoringDTO.setTotal_discharge(cursor
	// .getString(index_Total_Discharge));
	// monitoringDTO.setSignal_strength(cursor
	// .getString(index_Signal));
	// monitoringDTO.setBearer_type(cursor
	// .getString(index_Bearer));
	// monitoringDTO.setTime_stamp(cursor
	// .getString(index_Time_Stamp));
	// if (current_row_count == total_row_count) {
	// LogWrite.e("Aman", "Last Row...........");
	// LogWrite.e("Aman", "Saving Values in list");
	// appsInfoList.add(monitoringDTO);
	// LogWrite.i(
	// "Aman",
	// "TimeStamp : "
	// + monitoringDTO.getTime_stamp());
	// }
	//
	// } else {
	// LogWrite.e("Aman", "Row Changes...........");
	// LogWrite.i("Aman",
	// "TimeStamp : " + monitoringDTO.getTime_stamp());
	// appsInfoList.add(monitoringDTO);
	// // MonitoringDTO monitoringDTO = new MonitoringDTO(
	// // appContext);
	// // monitoringDTO.setRecord_id(cursor
	// // .getInt(index_record_id));
	// // monitoringDTO.setArrayList(arrayList);
	// // arrayList.clear();
	// // monitoringDTO.setBattery_temp(cursor
	// // .getString(index_Battery_Temp));
	// // monitoringDTO.setBattery_level(cursor
	// // .getString(index_Battery_Level));
	// // monitoringDTO.setCharging_state(cursor
	// // .getString(index_Battery_State));
	// // monitoringDTO.setDevice_health(cursor
	// // .getString(index_Device_Health));
	// // monitoringDTO
	// // .setWifi_time(cursor.getString(index_Wifi));
	// // monitoringDTO.setGps_time(cursor.getString(index_Gps));
	// // monitoringDTO.setBluetooth_time(cursor
	// // .getString(index_Bluetooth));
	// // monitoringDTO.setHotspot_time(cursor
	// // .getString(index_Hotspot));
	// // monitoringDTO.setTotal_cpu(cursor
	// // .getString(index_Total_Cpu));
	// // monitoringDTO.setTotal_ram(cursor
	// // .getString(index_Total_Ram));
	// // monitoringDTO.setTotal_discharge(cursor
	// // .getString(index_Total_Discharge));
	// // monitoringDTO.setSignal_strength(cursor
	// // .getString(index_Signal));
	// // monitoringDTO.setBearer_type(cursor
	// // .getString(index_Bearer));
	// // monitoringDTO.setTime_stamp(cursor
	// // .getString(index_Time_Stamp));
	// // appsInfoList.add(monitoringDTO);
	// count++;
	// MonitorAppDTO appDTO = new MonitorAppDTO();
	// appDTO.setApp_name(cursor.getString(index_App_Name));
	// appDTO.setProcess_name(cursor
	// .getString(index_Process_Name));
	// appDTO.setCpu_usage(cursor.getString(index_Cpu_Usage));
	// appDTO.setRam_usage(cursor.getString(index_Ram_Usage));
	// appDTO.setDischarge_rate(cursor
	// .getString(index_Discharge_Rate));
	// appDTO.setApp_type(cursor.getString(index_App_Type));
	// appDTO.setLast_update_time(cursor
	// .getString(index_Last_Time));
	// arrayList.add(appDTO);
	// }
	// } while (cursor.moveToNext());
	//
	// }
	// LogWrite.e(tag, "JSON LIST  2: " + appsInfoList.size());
	// }
	// LogWrite.e(tag, "JSON LIST  3: " + appsInfoList.size());
	// // close the database
	// close();
	// return appsInfoList;
	// }

	public synchronized MonitoringDTO getRecord(String process_name) {
		MonitoringDTO monitoringDTO = new MonitoringDTO(appContext);
		open();
		LogWrite.d(tag, "----");
		Cursor cursor = db.query(MySQLiteOpenHelper.MONITOR_TABLE, null,
				MySQLiteOpenHelper.MONITOR_PROCESSNAME + " =?",
				new String[] { process_name }, null, null, null);
		LogWrite.d(tag, "Cursor Size= " + cursor.getCount());
		if (cursor.getCount() > 0) {
			if (cursor.moveToNext()) {
				int index_record_id = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_RECORD_ID);
				int index_App_Name = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_APPNAME);
				int index_Process_Name = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_PROCESSNAME);
				int index_Cpu_Usage = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_CPUUSAGE);
				int index_Ram_Usage = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_RAMUSAGE);
				int index_Discharge_Rate = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_DISCHARGE_RATE);
				int index_Battery_Temp = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_TEMP);
				int index_Battery_Level = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_LEVEL);
				int index_Battery_State = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_BATTERY_STATE);
				int index_Device_Health = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_DEVICE_HEALTH);
				int index_Wifi = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_WIFI);
				int index_Bluetooth = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_BLUETOOTH);
				int index_Gps = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_GPS);
				int index_Hotspot = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_HOTSPOT);
				int index_Time_Stamp = cursor
						.getColumnIndex(MySQLiteOpenHelper.MONITOR_TIME_STAMP);

				do {
					monitoringDTO.setRecord_id(cursor.getInt(index_record_id));
					monitoringDTO.setApp_name(cursor.getString(index_App_Name));
					monitoringDTO.setProcess_name(cursor
							.getString(index_Process_Name));
					monitoringDTO.setCpu_usage(cursor
							.getString(index_Cpu_Usage));
					monitoringDTO.setRam_usage(cursor
							.getString(index_Ram_Usage));
					monitoringDTO.setDischarge_rate(cursor
							.getString(index_Discharge_Rate));
					monitoringDTO.setBattery_temp(cursor
							.getString(index_Battery_Temp));
					monitoringDTO.setBattery_level(cursor
							.getString(index_Battery_Level));
					monitoringDTO.setCharging_state(cursor
							.getString(index_Battery_State));
					monitoringDTO.setDevice_health(cursor
							.getString(index_Device_Health));
					monitoringDTO.setWifi_time(cursor.getString(index_Wifi));
					monitoringDTO.setGps_time(cursor.getString(index_Gps));
					monitoringDTO.setBluetooth_time(cursor
							.getString(index_Bluetooth));
					monitoringDTO.setHotspot_time(cursor
							.getString(index_Hotspot));
					monitoringDTO.setHotspot_time(cursor
							.getString(index_Time_Stamp));
					// String appName id = cursor.getInt(index_Id);
					// String usage = cursor.getString(index_Usage);
					// long time = cursor.getLong(index_Time);
					// LogWrite.d(tag, "id= " + id);
					// LogWrite.d(tag, "Usage= " + usage);
					// LogWrite.d(tag, "Time= " + time);
				} while (cursor.moveToNext());
			}
		}
		close();
		return monitoringDTO;
	}

	// public synchronized AppUsageInfo queryAppDetail(int appId) {
	// open();
	// long queryTime = System.currentTimeMillis() - 60 * 60 * 1000;
	// AppUsageInfo appinfo = new AppUsageInfo();
	// appinfo.setAppId(appId);
	//
	// Cursor cursor = db
	// .query(MySQLiteOpenHelper.BATTERY_TABLE, null,
	// MySQLiteOpenHelper.BATTERY_ColumnID + " =? AND "
	// + MySQLiteOpenHelper.BATTERY_ColumnTime
	// + " >=?", new String[] { String.valueOf(appId),
	// String.valueOf(queryTime) }, null, null,
	// MySQLiteOpenHelper.BATTERY_ColumnTime + " DESC");
	//
	// ArrayList<AppUsageDTO> appUsageDTOList = new ArrayList<AppUsageDTO>();
	//
	// LogWrite.d(tag, "Cursor Size= " + cursor.getCount());
	// if (cursor.getCount() > 0) {
	// if (cursor.moveToNext()) {
	// int index_Id = cursor
	// .getColumnIndex(MySQLiteOpenHelper.BATTERY_ColumnID);
	// int index_Usage = cursor
	// .getColumnIndex(MySQLiteOpenHelper.BATTERY_ColumnUsage);
	// int index_Time = cursor
	// .getColumnIndex(MySQLiteOpenHelper.BATTERY_ColumnTime);
	//
	// do {
	// int id = cursor.getInt(index_Id);
	// int usage = cursor.getInt(index_Usage);
	// long time = cursor.getLong(index_Time);
	// LogWrite.d(tag, "Query DataSource_BATTERYUsage id : " + id);
	// AppUsageDTO appUsageDTO = new AppUsageDTO(usage, time);
	// appUsageDTOList.add(appUsageDTO);
	// } while (cursor.moveToNext());
	// }
	// }
	// appinfo.setAppUsage(appUsageDTOList);
	// close();
	// return appinfo;
	// }

}
