package com.kochartech.gizmodoctor.HelperClass;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;

public class ServiceToast extends Service{

	private String TAG = "AshishSharma";
	private WindowManager  windowManager;
	private LayoutInflater inflater;
	private LinearLayout   toastLayout;
	private WindowManager.LayoutParams params;
	private TextView textview;
	private Typeface typeFace ;
	public static final String KEY_MESSAGETODISAPLY = "ServiceToast.MessageToDisplay";
	public static final String KEY_Gravity = "ServiceToast.Gravity";
	public static final String KEY_YCoordinate = "ServiceToast.YCoorrdinate";
	
	@Override
	public IBinder onBind(Intent intent) {
	    // Not used
	    return null;
	  }

	  @Override public void onCreate() {
	    super.onCreate();
//	    isToastDestory = false;
	    
	    Log.d(TAG, "onCreate Work");
	    typeFace = Typeface.createFromAsset(getApplicationContext().getAssets(),"fonts/fonnt.ttf");
	    windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
	    inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
	    toastLayout = (LinearLayout) inflater.inflate(R.layout.settings_toast_arrow_up,null);
	    LinearLayout linearLayout = (LinearLayout) toastLayout.findViewById(R.id.main);
	    linearLayout.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				stopSelf();
			}
		});
	    
	    textview = (TextView) toastLayout.findViewById(R.id.settingstoast_textview);
	
		
	  }

	  
	  @Override
	  public int onStartCommand(Intent intent, int flags, int startId) {
		  
		 Log.d(TAG, "on StartCommand is workings"); 
		 String messageToDisplay = (String) intent.getExtras().get(KEY_MESSAGETODISAPLY); 
		 textview.setText(messageToDisplay);
		 textview.setTypeface(typeFace);
		 textview.setTextColor(Color.BLACK);
		 
		 
		 params = new WindowManager.LayoutParams(
			        WindowManager.LayoutParams.WRAP_CONTENT,
			        WindowManager.LayoutParams.WRAP_CONTENT,
			        WindowManager.LayoutParams.TYPE_PHONE,
			        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			        PixelFormat.TRANSLUCENT);

			    params.gravity = Gravity.CENTER | Gravity.LEFT;
			    params.x = 0;
			    params.y = intent.getExtras().getInt(KEY_YCoordinate);
			    

	     windowManager.addView(toastLayout, params);
			    
		 return super.onStartCommand(intent, flags, startId);
	  }
	  @Override
	  public void onDestroy() {
	    super.onDestroy();
//	    isToastDestory = true;
	    if (toastLayout != null) windowManager.removeView(toastLayout);
	  }	
}
