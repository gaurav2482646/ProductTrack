package com.kochartech.devicemax.dto;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by gauravjeetsingh on 23/3/18.
 */

public class SendResponseDTO {
    private JSONObject Response;
    private String CommandKey;
    private String MAC;
    private String MessageCommandId;

    public SendResponseDTO(JSONObject response, String commandKey, String MAC, String messageCommandId) {
        this.Response = response;
        this.CommandKey = commandKey;
        this.MAC = MAC;
        this.MessageCommandId = messageCommandId;
    }
    public JSONObject toJSON(){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("MessageCommandId",MessageCommandId);
            jsonObject.put("MAC",MAC);
            jsonObject.put("CommandKey",CommandKey);
            jsonObject.put("Response",Response);
            return jsonObject;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
    public SendResponseDTO() {
    }

    public JSONObject getResponse() {

        return Response;
    }

    public void setResponse(JSONObject response) {
        Response = response;
    }

    public String getCommandKey() {
        return CommandKey;
    }

    public void setCommandKey(String commandKey) {
        CommandKey = commandKey;
    }

    public String getMAC() {
        return MAC;
    }

    public void setMAC(String MAC) {
        this.MAC = MAC;
    }

    public String getMessageCommandId() {
        return MessageCommandId;
    }

    public void setMessageCommandId(String messageCommandId) {
        MessageCommandId = messageCommandId;
    }


}
