package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewDebug.FlagToString;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Utility.CameraDTO;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.ShowHardwareResultActivity;
import com.kochartech.gizmodoctor.Activity.DisplayTestActivity;
import com.kochartech.gizmodoctor.Activity.FragmentListener;
import com.kochartech.gizmodoctor.Activity.TouchTestActivity;
import com.kochartech.gizmodoctor.CustomView.CustomGridAdapter;
import com.kochartech.gizmodoctor.HelperClass.FragmentTitles;
import com.kochartech.gizmodoctor.HelperClass.HardwareUtility;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;
import com.kochartech.gizmodoctor.POJO.SoftKey;

public class HardwareTestFragment extends Fragment implements
		OnItemClickListener, MyFragment, OnClickListener,
		OnAutoHardwareTestListener {
	private final static String TAG = HardwareTestFragment.class
			.getSimpleName();
	private Context context;
	private View rootView;
	private FragmentListener fragmentListener;

	private HardwareUtility utility;

	// private LinearLayout flashButton;

	private String[] hardwareTitles;
	private String[] hardwareDescription;
	private TypedArray hardwareIcons;
	private ArrayList<SoftKey> arrayList;
	private GridView gridView;

	private Button buttonAutoStart;

	private ProximitySensorTestFragment proximitySensorTestFragment;
	private AccelerometerBallTestFragment accelerometerBallTestFragment;
	private TouchTestFragment simpleTouchFragment;
	private TouchTestFragment longPressFragment;
	private MultiTouchTestFragment multiTouchTestFragment;
	private CameraTestFragment backCameraTestFragment;
	private CameraTestFragment frontCameraTestFragment;

	public static boolean isAutoStartClicked = false;

	@Override
	public String getTitle() {
		return FragmentTitles.HARDWARE_TEST;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	@Override
	public void onResume() {
		try {
			getActivity().setTitle(FragmentTitles.HARDWARE_TEST);
		} catch (Exception e) {
			Log.e(TAG, "onResumeException : " + e.toString());
		}
		super.onResume();
	}

	private void initDataSet() {

		proximitySensorTestFragment = new ProximitySensorTestFragment(null);
		accelerometerBallTestFragment = new AccelerometerBallTestFragment(null);
		simpleTouchFragment = new TouchTestFragment(
				TouchTestFragment.FRAGMENT_TYPE_SIMPLE_TOUCH, null);
		longPressFragment = new TouchTestFragment(
				TouchTestFragment.FRAGMENT_TYPE_LONG_TOUCH, null);
		multiTouchTestFragment = new MultiTouchTestFragment(null);
		CameraDTO cameraDTO = new CameraDTO();
		cameraDTO.setType(HardwareUtility.KEY_BACK_CAMERA_HARDWARE);
		backCameraTestFragment = new CameraTestFragment(cameraDTO);
		CameraDTO frontCameraDTO = new CameraDTO();
		frontCameraDTO.setType(HardwareUtility.KEY_FRONT_CAMERA_HARDWARE);
		frontCameraTestFragment = new CameraTestFragment(frontCameraDTO);
		hashMapHardwareResult = new HashMap<String, Boolean>();

		arrayList = new ArrayList<SoftKey>();
		hardwareTitles = getResources().getStringArray(R.array.hardware_titles);
		hardwareDescription = getResources().getStringArray(
				R.array.hardware_descrip);
		hardwareIcons = getResources().obtainTypedArray(R.array.hardware_icons);

		for (int i = 0; i < hardwareTitles.length; i++) {
			LogWrite.d(TAG, "MenuItems  =====> " + hardwareTitles[i]);
			SoftKey softKey = new SoftKey();
			softKey.setName(hardwareTitles[i]);
			softKey.setDescription(hardwareDescription[i]);
			softKey.setIcon(hardwareIcons.getResourceId(i, -1));
			arrayList.add(softKey);
			// SoftKey items = new RowItem(menutitles[i],
			// menuIcons.getResourceId(
			// i, -1));
			// rowItems.add(items);
		}
	}

	private void initUi(LayoutInflater inflater, ViewGroup container) {
		context = getActivity().getApplicationContext();
		fragmentListener = (FragmentListener) getActivity();

		rootView = inflater.inflate(R.layout.fragment_softwarekey_test,
				container, false);
		rootView.findViewById(R.id.headerTest).setVisibility(View.VISIBLE);
		buttonAutoStart = (Button) rootView.findViewById(R.id.btAutoStart);

		gridView = (GridView) rootView.findViewById(R.id.gridview);
		gridView.setAdapter(new CustomGridAdapter(context, arrayList));

		utility = new HardwareUtility(getActivity());

		gridView.setOnItemClickListener(this);
		// flashButton = (LinearLayout) rootView.findViewById(R.id.flashLight);
		//
		// // registerOnClick(rootView.findViewById(R.id.wifi));
		// // registerOnClick(rootView.findViewById(R.id.bluetooth));
		// // registerOnClick(rootView.findViewById(R.id.gps));
		// // registerOnClick(rootView.findViewById(R.id.mic_test));
		// registerOnClick(rootView.findViewById(R.id.vibrate));
		// registerOnClick(rootView.findViewById(R.id.flashLight));
		// registerOnClick(rootView.findViewById(R.id.touch));
		// registerOnClick(rootView.findViewById(R.id.proximity_sensor));
		// registerOnClick(rootView.findViewById(R.id.accelerometer));
		// registerOnClick(rootView.findViewById(R.id.longPress));
		// registerOnClick(rootView.findViewById(R.id.multi_touch));
		// registerOnClick(rootView.findViewById(R.id.mic));
		// // registerOnClick(rootView.findViewById(R.id.speaker));
		//
		// utility = new HardwareUtility(getActivity());
		// hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH,
		// rootView.findViewById(R.id.flashLight));
		// hasSystemFeature(PackageManager.FEATURE_SENSOR_PROXIMITY,
		// rootView.findViewById(R.id.proximity_sensor));
		// hasSystemFeature(PackageManager.FEATURE_SENSOR_ACCELEROMETER,
		// rootView.findViewById(R.id.accelerometer));

		buttonAutoStart.setOnClickListener(this);
	}

	// public void registerOnClick(View view) {
	// view.seton(this);
	// }

	// @Override
	// public void onClick(View v) {
	// /*
	// * HardwareTestAsync async = null; if (v.getId() == R.id.wifi) {
	// * LogWrite.i(TAG, "Wifi Hardware going to test"); async = new
	// * HardwareTestAsync(context, HardwareUtility.KEY_WIFI_HARDWARE);
	// * async.execute(""); } else if (v.getId() == R.id.bluetooth) {
	// * LogWrite.i(TAG, "Bluetooth Hardware going to test"); async = new
	// * HardwareTestAsync(context, HardwareUtility.KEY_BLUETOOTH_HARDWARE);
	// * async.execute(""); } else if (v.getId() == R.id.gps) {
	// * LogWrite.i(TAG, "GPS Hardware going to test"); async = new
	// * HardwareTestAsync(context, HardwareUtility.KEY_GPS_HARDWARE);
	// * async.execute(""); } else if (v.getId() == R.id.mic_test) {
	// * utility.vibrate(); } else
	// */
	// if (v.getId() == R.id.vibrate) {
	// utility.vibrate();
	// } else if (v.getId() == R.id.flashLight) {
	// flashButton.setEnabled(false);
	// utility.ledon();
	// new Timer().schedule(new TimerTask() {
	// @Override
	// public void run() {
	// try {
	// utility.ledoff();
	// getActivity().runOnUiThread(new Runnable() {
	// @Override
	// public void run() {
	// flashButton.setEnabled(true);
	// }
	// });
	//
	// } catch (ExceptionDTO e) {
	// LogWrite.e(TAG, "ExceptionDTO: " + e);
	// }
	// }
	// }, 2000);
	// } else if (v.getId() == R.id.longPress) {
	// fragmentListener.onItemClicked(FragmentListener.actionAdd,
	// new TouchTestFragment(
	// TouchTestFragment.FRAGMENT_TYPE_LONG_TOUCH, null));
	// } else if (v.getId() == R.id.accelerometer) {
	// fragmentListener.onItemClicked(FragmentListener.actionAdd,
	// new AccelerometerBallTestFragment(null));
	// } else if (v.getId() == R.id.touch) {
	// fragmentListener
	// .onItemClicked(
	// FragmentListener.actionAdd,
	// new TouchTestFragment(
	// TouchTestFragment.FRAGMENT_TYPE_SIMPLE_TOUCH,
	// null));
	// } else if (v.getId() == R.id.proximity_sensor) {
	// fragmentListener.onItemClicked(FragmentListener.actionAdd,
	// new ProximitySensorTestFragment(null));
	// } else if (v.getId() == R.id.multi_touch) {
	// fragmentListener.onItemClicked(FragmentListener.actionAdd,
	// new MultiTouchTestFragment(null));
	// } else if (v.getId() == R.id.mic) {
	// fragmentListener.onItemClicked(FragmentListener.actionAdd,
	// new MicTestFragment(null));
	// }
	//
	// }

	/***
	 * This method is used to check hardware is supported or not on device.
	 */
	private void hasSystemFeature(String featureName, View view) {
		PackageManager pm = context.getPackageManager();
		boolean flag;
		if (view.getId() == R.id.flashLight) {
			flag = utility.hasFlash();
		} else {
			flag = pm.hasSystemFeature(featureName);
		}
		if (!flag)
			view.setVisibility(View.GONE);
	}

	// <item>Vibration</item>
	// <item>Flash Light</item>
	// <item>Proximity</item>
	// <item>Accelerometer</item>
	// <item>Touch</item>
	// <item>Long Press</item>
	// <item>MultiTouch</item>
	// <item>Mic</item>
	// <item>Speaker</item>

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		String text = ((TextView) view.findViewById(R.id.grid_field_title))
				.getText().toString();
		LogWrite.d(TAG, "TextString : " + text);
		if (text.equals("Vibration")) {
			LogWrite.d(TAG, "Vibration going to check");
			utility.vibrate();
		} else if (text.equals("Flash Light")) {
			LogWrite.d(TAG, "FlashLight going to check");
			// flashButton.setEnabled(false);
			utility.ledon();
			new Timer().schedule(new TimerTask() {
				@Override
				public void run() {
					getActivity().runOnUiThread(new Runnable() {

						@Override
						public void run() {
							try {
								utility.ledoff();
								// getActivity().runOnUiThread(new Runnable() {
								// @Override
								// public void run() {
								// flashButton.setEnabled(true);
								// }
								// });

							} catch (Exception e) {
								LogWrite.e(TAG, "FlashLightException: " + e);
								if (isAutoStartClicked)
									HardwareTestFragment.this
											.onHardwareTestFinish(1,
													"Flash Light", false);
							}
						}
					});
				}
			}, 2000);
		} else if (text.equals("Proximity")) {
			// Proximity
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					proximitySensorTestFragment);
		} else if (text.equals("Accelerometer")) {
			if (accelerometerBallTestFragment.isAdded()) {
				return; // or return false/true, based on where you are calling
						// from
			}
			// Accelerometer
			try {
				fragmentListener.onItemClicked(FragmentListener.actionAdd,
						accelerometerBallTestFragment);
			} catch (Exception e) {
				Log.e(TAG, "AccelerometerException : " + e.toString());
			}

			// getActivity().getSupportFragmentManager().beginTransaction().add(accelerometerBallTestFragment,
			// "abc").commit();
		} else if (text.equals("Touch")) {
			// Touch
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					simpleTouchFragment);
		} else if (text.equals("Long Press")) {
			// Long Press
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					longPressFragment);
		} else if (text.equals("MultiTouch")) {
			// MultiTouch
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					multiTouchTestFragment);
		} else if (text.equals("Mic")) {
			// Mic
			MicTestActivity.startActivity(context, "Microphone", false, null,
					HardwareTestFragment.this);
			// fragmentListener.onItemClicked(FragmentListener.actionAdd,
			// new MicTestFragment(null));
		} else if (text.equals("Pixel")) {
			// Pixel Test
			fragmentListener.onItemClicked(FragmentListener.actionAdd,
					new DisplayFragment(null));
		} else if (text.equals("Display")) {
			// Display
			Intent intent = new Intent(getActivity(), TouchTestActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			getActivity().startActivity(intent);
		} else if (text.equals("Speaker")) {
			// Speaker
			SoundTestActivity.startActivity(context, "Sound Test", false, null,
					HardwareTestFragment.this);
			// fragmentListener.onItemClicked(FragmentListener.actionAdd,
			// new SoundTestFragment(null));
		} else if (text.equals("Camera")) {
			// Camera
			if (!isBackCameraAccessed) {
				fragmentListener.onItemClicked(FragmentListener.actionAdd,
						backCameraTestFragment);
				isBackCameraAccessed = true;
			} else {
				fragmentListener.onItemClicked(FragmentListener.actionAdd,
						frontCameraTestFragment);
			}
		}

	}

	// private class HardwareTestAsync extends AsyncTask<String, String, String>
	// {
	// // private Context context;
	// private String hardware_name = "";
	// private KTDeviceInfo deviceInfo;
	// private boolean wifiFlag = false, bluetoothFlag = false,
	// gpsFlag = false;
	// private int COUNT = 2;
	// private int SECONDS = 1000;
	// private int TOTAL = 0;
	// private int ONE_MINUTE = 1 * 60 * 1000;
	//
	// public HardwareTestAsync(Context context, String hardware_name) {
	// // this.context = context;
	// this.hardware_name = hardware_name;
	// deviceInfo = new KTDeviceInfo(context);
	// }
	//
	// @Override
	// protected synchronized String doInBackground(String... params) {
	//
	// if (hardware_name.equals(HardwareUtility.KEY_WIFI_HARDWARE)) {
	// wifiFlag = deviceInfo.isWifiEnabled();
	// while (!wifiFlag) {
	// LogWrite.e(TAG, "Wifi is OFF");
	// deviceInfo.setWifiEnabled(true);
	// wifiFlag = deviceInfo.isWifiEnabled();
	// sleep(COUNT * SECONDS);
	// TOTAL += (COUNT * SECONDS);
	// LogWrite.e(TAG, "Total Time Till now : " + TOTAL);
	// if (TOTAL >= ONE_MINUTE) {
	// break;
	// }
	// }
	// LogWrite.i(TAG, "Wifi is ON");
	// } else if (hardware_name
	// .equals(HardwareUtility.KEY_BLUETOOTH_HARDWARE)) {
	// bluetoothFlag = deviceInfo.isBluetoothEnabled();
	// while (!bluetoothFlag) {
	// LogWrite.e(TAG, "Bluetooth is OFF");
	// deviceInfo.setBluetoothEnabled(true);
	// bluetoothFlag = deviceInfo.isBluetoothEnabled();
	// sleep(COUNT * SECONDS);
	// TOTAL += (COUNT * SECONDS);
	// LogWrite.e(TAG, "Total Time Till now : " + TOTAL);
	// if (TOTAL >= ONE_MINUTE) {
	// break;
	// }
	// }
	// LogWrite.i(TAG, "Bluetooth is ON");
	// } else if (hardware_name.equals(HardwareUtility.KEY_GPS_HARDWARE)) {
	// gpsFlag = deviceInfo.isGPSEnabled();
	// while (!gpsFlag) {
	// LogWrite.e(TAG, "GPS is OFF");
	// deviceInfo.setGPSEnabled(true);
	// gpsFlag = deviceInfo.isGPSEnabled();
	// sleep(COUNT * SECONDS);
	// TOTAL += (COUNT * SECONDS);
	// LogWrite.e(TAG, "Total Time Till now : " + TOTAL);
	// if (TOTAL >= ONE_MINUTE) {
	// LogWrite.i(TAG, "Time Greater then 1Min");
	// break;
	// }
	// }
	// LogWrite.i(TAG, "GPS is ON");
	// }
	// publishProgress("");
	// return null;
	// }
	//
	// @Override
	// protected void onProgressUpdate(String... values) {
	// if (hardware_name.equals(HardwareUtility.KEY_WIFI_HARDWARE)) {
	// if (!wifiFlag)
	// Toast.makeText(context, "Wifi Hardware Failure!",
	// Toast.LENGTH_SHORT).show();
	// } else if (hardware_name
	// .equals(HardwareUtility.KEY_BLUETOOTH_HARDWARE)) {
	// if (!bluetoothFlag)
	// Toast.makeText(context, "Bluetooth Hardware Failure!",
	// Toast.LENGTH_SHORT).show();
	// } else if (hardware_name.equals(HardwareUtility.KEY_GPS_HARDWARE)) {
	// if (!gpsFlag)
	// Toast.makeText(context, "GPS Hardware Failure!",
	// Toast.LENGTH_SHORT).show();
	// }
	// super.onProgressUpdate(values);
	// }
	//
	// private void sleep(long time) {
	// try {
	// Thread.sleep(time);
	// } catch (InterruptedException e) {
	// e.printStackTrace();
	// }
	// }
	// }

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btAutoStart:
			if (!isAutoStartClicked) {
				isAutoStartClicked = true;

				proximitySensorTestFragment = new ProximitySensorTestFragment(
						null);
				accelerometerBallTestFragment = new AccelerometerBallTestFragment(
						null);
				simpleTouchFragment = new TouchTestFragment(
						TouchTestFragment.FRAGMENT_TYPE_SIMPLE_TOUCH, null);
				longPressFragment = new TouchTestFragment(
						TouchTestFragment.FRAGMENT_TYPE_LONG_TOUCH, null);
				multiTouchTestFragment = new MultiTouchTestFragment(null);
				CameraDTO cameraDTO = new CameraDTO();
				cameraDTO.setType(HardwareUtility.KEY_BACK_CAMERA_HARDWARE);
				backCameraTestFragment = new CameraTestFragment(cameraDTO);
				CameraDTO frontCameraDTO = new CameraDTO();
				frontCameraDTO
						.setType(HardwareUtility.KEY_FRONT_CAMERA_HARDWARE);
				frontCameraTestFragment = new CameraTestFragment(frontCameraDTO);
				hashMapHardwareResult = new HashMap<String, Boolean>();

				utility.setOnAutoHardwareTestListener(this);
				proximitySensorTestFragment.setOnAutoHardwareTestListener(this);
				accelerometerBallTestFragment
						.setOnAutoHardwareTestListener(this);
				simpleTouchFragment.setOnAutoHardwareTestListener(this);
				longPressFragment.setOnAutoHardwareTestListener(this);
				multiTouchTestFragment.setOnAutoHardwareTestListener(this);
				frontCameraTestFragment.setOnAutoHardwareTestListener(this);
				backCameraTestFragment.setOnAutoHardwareTestListener(this);
				gridView.performItemClick(
						gridView.getAdapter().getView(0, null, null), 0,
						gridView.getAdapter().getItemId(0));
			}
			break;

		default:
			break;
		}

	}

	private static boolean isBackCameraAccessed = false;

	@Override
	public void onHardwareTestFinish(final int position, final String testName,
			final boolean result) {
		new AsyncTask<String, String, String>() {
			int value = 0;

			@Override
			protected String doInBackground(String... params) {
				hashMapHardwareResult.put(testName, result);
				value = position;

				if (value <= 10)
					value++;
				// if (value == 11)
				// value = 10;
				if (value == 8)
					value++;

				Log.d(TAG, "TestName : " + testName);
				Log.d(TAG, "Result : " + result);
				Log.d(TAG, "Position : " + value);
				// isAutoStartClicked = false;
				if (value < hardwareTitles.length - 1) {
					try {
						Thread.sleep(2000);
					} catch (Exception e) {

					}
				}
				return "";
			}

			@Override
			protected void onPostExecute(String result) {
				if (value < hardwareTitles.length - 1) {

					gridView.performItemClick(
							gridView.getAdapter().getView(value, null, null),
							value, gridView.getAdapter().getItemId(value));
					isAutoStartClicked = true;
				} else {
					isAutoStartClicked = false;
					Iterator<String> iterator = hashMapHardwareResult.keySet()
							.iterator();
					while (iterator.hasNext()) {
						String key = (String) iterator.next();
						boolean value = (Boolean) hashMapHardwareResult
								.get(key);
						Log.e(TAG, key + " : " + value);
					}

					String jsonString = new JSONObject(hashMapHardwareResult)
							.toString();
					getActivity().startActivity(
							new Intent(getActivity(),
									ShowHardwareResultActivity.class).putExtra(
									"result_array", jsonString).addFlags(
									Intent.FLAG_ACTIVITY_NEW_TASK));
				}
				super.onPostExecute(result);
			}
		}.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "");

	}

	private HashMap<String, Boolean> hashMapHardwareResult;
}

// /**
// * This method is used to check vibration.
// */
// private void vibrate() {
// LogWrite.d(TAG, "Vibrate Method Enters.....");
// try {
// Vibrator vibrator = (Vibrator) context
// .getSystemService(Context.VIBRATOR_SERVICE);
// vibrator.vibrate(3000);
// } catch (ExceptionDTO e) {
// LogWrite.e(TAG, "VibrateException :---> " + e.toString());
// }
// }
/**
 * This method is used to check flash-light.
 */
// void ledon() {
// LogWrite.d(TAG, "FlashLight Check.....");
// final LinearLayout layout = (LinearLayout) rootView
// .findViewById(R.id.flashLight);
// layout.setEnabled(false);
// cam = Camera.open();
// Parameters params = cam.getParameters();
// params.setFlashMode(Parameters.FLASH_MODE_TORCH);
// cam.setParameters(params);
// cam.startPreview();
// cam.autoFocus(new AutoFocusCallback() {
// public void onAutoFocus(boolean success, Camera camera) {
// }
// });
//
// new Timer().schedule(new TimerTask() {
// @Override
// public void run() {
// try {
//
// cam.stopPreview();
// cam.release();
// getActivity().runOnUiThread(new Runnable() {
// @Override
// public void run() {
// layout.setEnabled(true);
// }
// });
//
// } catch (ExceptionDTO e) {
// Log.d("MainActivity", "ExceptionDTO: " + e);
// }
// }
// }, 2000);
// }

