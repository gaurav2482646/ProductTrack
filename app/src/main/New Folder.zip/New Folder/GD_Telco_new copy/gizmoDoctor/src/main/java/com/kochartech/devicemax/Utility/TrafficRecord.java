package com.kochartech.devicemax.Utility;

import android.net.TrafficStats;

import com.kochartech.devicemax.Activities.LogWrite;

public class TrafficRecord {
	long tx=0;
	long rx=0;
	String tag=null;
long stats=0;
	TrafficRecord() {
		tx=TrafficStats.getTotalTxBytes();
		rx=TrafficStats.getTotalRxBytes();
	}

//	public int returnTrafficStats(int uid){
//		
//			
//			
//			
//		}
//		  
//	}

	TrafficRecord(int uid, String tag) {
		tx=TrafficStats.getUidTxBytes(uid);
		rx=TrafficStats.getUidRxBytes(uid);
		this.tag=tag;
		LogWrite.d("tag",tag);
		LogWrite.d("uid is"+uid,"received bytes"+ rx);
		LogWrite.d("uid is"+uid,"transmitted bytes"+ tx);
		
	}
}