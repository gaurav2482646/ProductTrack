package com.kochartech.gizmodoctor.DataBase;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import android.os.Environment;

import com.kochartech.devicemax.Activities.LogWrite;

public class WriteToFile {
	private static final String tag = "WriteToFile";
	private static boolean debug = false;

	public static synchronized void write(String fileName, String msg) {
		if (debug) {
			try {
				String path = Environment.getExternalStorageDirectory()
						+ File.separator + fileName;
				File file = new File(path);
				boolean isFilExsits = file.exists();
				if (!isFilExsits) {
					try {
						isFilExsits = file.createNewFile();
					} catch (IOException e) {
						LogWrite.d(tag, "Unable to create File.");
					}
				}

				if (isFilExsits) {
					try {
						FileWriter fileWriter = new FileWriter(file, true);
						fileWriter.write(msg + " : " + "\n");
						fileWriter.flush();
						fileWriter.close();
					} catch (IOException e) {
						LogWrite.d(tag, "ExceptionDTO while file creation: " + e);
					}
				}
			} catch (Exception e) {
				LogWrite.d(tag, "ExceptionDTO while file creation: " + e);
			}
		}
	}
}
