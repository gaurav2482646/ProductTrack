package com.kochartech.gizmodoctor.Receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.kochartech.gizmodoctor.HelperClass.BackgroundTaskManager;
import com.kochartech.gizmodoctor.HelperClass.Config;
import com.kochartech.gizmodoctor.HelperClass.Config.AppTye;
import com.kochartech.gizmodoctor.Preferences.ActivationKeyPreference;
import com.kochartech.gizmodoctor.library.settingslistener.DeviceSettingsService;

public class BootReceiver extends BroadcastReceiver {

	// private String tag = BootReceiver.class.getSimpleName();
	// private Context context = null;
	// private SharedPreferences preferences;
	// private SharedPreferences.Editor editor;
	private ActivationKeyPreference activationKeyPreference;
	private AppTye applicationType;

	// private String fileName = "BootReceiver.txt";
	@Override
	public void onReceive(Context context, Intent intent) {

		// Toast.makeText(context, "Receiver !", Toast.LENGTH_LONG).show();
		// TODO Auto-generated method stub

		// WriteToFile.write(fileName, "BootReceiver");
		// this.context = context;
		if (intent.getAction().toString()
				.equals("com.android.kochar.servicestop")) {
			DeviceSettingsService.start(context);
		} else {
			activationKeyPreference = new ActivationKeyPreference(context);
			if (activationKeyPreference.isActivationKeyRegister()
					|| applicationType == Config.AppTye.WITHOUT_REGISTRATION) {
				// WriteToFile.write(fileName, "Device is Register");

				long systemCurrentTime = System.currentTimeMillis();

				if (activationKeyPreference.getLastScanTime() < systemCurrentTime) {

					// WriteToFile.write(fileName, "LastTime is Less");
					long diff = systemCurrentTime
							- activationKeyPreference.getLastScanTime();
					long lastTime = activationKeyPreference.getLeftTime()
							- diff;
					activationKeyPreference.setLeftTime(lastTime);
					activationKeyPreference.setLastScanTime(System
							.currentTimeMillis());
				} else {
					// WriteToFile.write(fileName, "LastTime is not less");
					activationKeyPreference.setLastScanTime(System
							.currentTimeMillis());
				}

				if (activationKeyPreference.getLeftTime() <= 0) {
					// WriteToFile.write(fileName,
					// "Activation Time is Expired");
					activationKeyPreference.resetAll();
					return;
				}

				BackgroundTaskManager.startTask(context);
				DeviceSettingsService.setRunning(context, false);
				DeviceSettingsService.start(context);
			}
		}

	}
}
