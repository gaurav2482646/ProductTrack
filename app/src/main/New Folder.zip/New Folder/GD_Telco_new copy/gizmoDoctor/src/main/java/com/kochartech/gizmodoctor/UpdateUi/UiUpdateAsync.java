package com.kochartech.gizmodoctor.UpdateUi;

import android.os.AsyncTask;

import com.kochartech.devicemax.Activities.LogWrite;
public class UiUpdateAsync extends AsyncTask<String, String, String> {
	private static String tag = "UiUpdateAsync";
	private boolean isRunnning = false;
	private static UiUpdateAsync classInstance;
	private UiRequireUpdate uiRequireUpdate;

	public static UiUpdateAsync getInstance() {
		if (classInstance == null)
			classInstance = new UiUpdateAsync();	
		
		return classInstance;
	}
	
	//private constuctor
	public  UiUpdateAsync() {
		
	}

	public boolean isRunning() {
		return isRunnning;
	}

	public UiUpdateAsync start(UiRequireUpdate uiRequireUpdate) {		
		LogWrite.d(tag,"is Running.....:"+isRunnning);
		if (!isRunnning) {			
			classInstance = new UiUpdateAsync();
			classInstance.setFragmentToUpdate(uiRequireUpdate);
			classInstance.setRunningState(true);			
			classInstance.execute("");
//			classInstance.executeOnExecutor(this.THREAD_POOL_EXECUTOR,"");
		}
		return classInstance;
	}

	public void stop() {
		isRunnning = false;
		
		LogWrite.d(tag,"is Stop :"+isRunnning);
	}

	private void setRunningState(boolean state) {
		isRunnning = state;
	}

	private void setFragmentToUpdate(UiRequireUpdate uiRequireUpdate) {
		this.uiRequireUpdate = uiRequireUpdate;
	}

	@Override
	protected String doInBackground(String... params) 
	{
		while (isRunnning) 
		{
			LogWrite.d(tag, "Running....");
			uiRequireUpdate.runInBackGround();
			LogWrite.d(tag, "Background Run Complete....");
			publishProgress("");

//			try {
//				Thread.sleep(10000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			isRunnning = false;
		}
		return null;
	}
	@Override
	protected void onProgressUpdate(String... values) {
		// TODO Auto-generated method stub
		super.onProgressUpdate(values);
		LogWrite.d(tag, "onProgress Update");
		uiRequireUpdate.updateUI();
	}
}
