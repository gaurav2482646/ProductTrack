package com.kochartech.gizmodoctor.POJO;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;

import com.kochartech.devicemax.Activities.LogWrite;

public class MonitoringDTO {
	private String TAG = MonitoringDTO.class.getSimpleName();
	// private Context context;
	private int record_id = 0;
	private String app_name = "";
	private String process_name = "";
	private String cpu_usage = "0";
	private String ram_usage = "0";
	private String discharge_rate = "0";
	private String battery_temp = "";
	private String battery_level = "";
	private String charging_state = "";
	private String device_health = "";
	private String wifi_time = "0:0";
	private String bluetooth_time = "0:0";
	private String gps_time = "0:0";
	private String hotspot_time = "0:0";
	private String time_stamp = "";
	private String total_cpu = "0";
	private String total_ram = "0";
	private String total_discharge = "0";
	private String signal_strength = "0";
	private String bearer_type = "";
	private String last_update_time = "0";
	private String app_type = "0";

	private ArrayList<MonitorAppDTO> arrayList;

	public MonitoringDTO(Context context) {
		// this.context = context;
	}

	public int getRecord_id() {
		return record_id;
	}

	public void setRecord_id(int record_id) {
		this.record_id = record_id;
	}

	public String getApp_name() {
		return app_name;
	}

	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}

	public String getProcess_name() {
		return process_name;
	}

	public void setProcess_name(String process_name) {
		this.process_name = process_name;
	}

	public String getCpu_usage() {
		return cpu_usage;
	}

	public void setCpu_usage(String cpu_usage) {
		this.cpu_usage = cpu_usage;
	}

	public String getRam_usage() {
		return ram_usage;
	}

	public void setRam_usage(String ram_usage) {
		this.ram_usage = ram_usage;
	}

	public String getDischarge_rate() {
		return discharge_rate;
	}

	public void setDischarge_rate(String discharge_rate) {
		this.discharge_rate = discharge_rate;
	}

	public String getLast_update_time() {
		return last_update_time;
	}

	public void setLast_update_time(String last_update_time) {
		this.last_update_time = last_update_time;
	}

	public String getApp_type() {
		return app_type;
	}

	public void setApp_type(String app_type) {
		this.app_type = app_type;
	}

	public String getTotal_cpu() {
		return total_cpu;
	}

	public void setTotal_cpu(String total_cpu) {
		this.total_cpu = total_cpu;
	}

	public String getTotal_ram() {
		return total_ram;
	}

	public void setTotal_ram(String total_ram) {
		this.total_ram = total_ram;
	}

	public String getTotal_discharge() {
		return total_discharge;
	}

	public void setTotal_discharge(String total_discharge) {
		this.total_discharge = total_discharge;
	}

	public String getSignal_strength() {
		return signal_strength;
	}

	public void setSignal_strength(String signal_strength) {
		this.signal_strength = signal_strength;
	}

	public String getBearer_type() {
		return bearer_type;
	}

	public void setBearer_type(String bearer_type) {
		this.bearer_type = bearer_type;
	}

	public String getBattery_temp() {
		return battery_temp;
	}

	public void setBattery_temp(String battery_temp) {
		this.battery_temp = battery_temp;
	}

	public String getCharging_state() {
		return charging_state;
	}

	public void setCharging_state(String charging_state) {
		this.charging_state = charging_state;
	}

	public String getBattery_level() {
		return battery_level;
	}

	public void setBattery_level(String battery_level) {
		this.battery_level = battery_level;
	}

	public String getDevice_health() {
		return device_health;
	}

	public void setDevice_health(String device_health) {
		this.device_health = device_health;
	}

	public String getWifi_time() {
		return wifi_time;
	}

	public void setWifi_time(String wifi_time) {
		this.wifi_time = wifi_time;
	}

	public String getBluetooth_time() {
		return bluetooth_time;
	}

	public void setBluetooth_time(String bluetooth_time) {
		this.bluetooth_time = bluetooth_time;
	}

	public String getGps_time() {
		return gps_time;
	}

	public void setGps_time(String gps_time) {
		this.gps_time = gps_time;
	}

	public String getHotspot_time() {
		return hotspot_time;
	}

	public void setHotspot_time(String hotspot_time) {
		this.hotspot_time = hotspot_time;
	}

	public String getTime_stamp() {
		return time_stamp;
	}

	public void setTime_stamp(String time_stamp) {
		this.time_stamp = time_stamp;
	}

	public ArrayList<MonitorAppDTO> getArrayList() {
		return arrayList;
	}

	public void setArrayList(ArrayList<MonitorAppDTO> arrayList) {
		this.arrayList = arrayList;
	}

	// "IMEI":"123123123123",
	// "AppNameMonitor":"12",
	// "ProcessName":"12",
	// "CPUUsage":"12",
	// "RAMUsage":"12",
	// "BatteryUsage":"12",
	// "BatteryTemp":"12",
	// "ChargingState":"12",
	// "BatteryLevel":"12",
	// "DeviceHealth":"12",
	// "WifiTime":"12"
	// "BluetoothTime":"12",
	// "HotspotTime":"12",
	// "GpsTime":"12",
	// "TimeStamp":"12",
	public JSONObject toJsonString() {

		String message = "";
		JSONObject object = new JSONObject();
		try {
			// DeviceInformation information = new
			// DeviceInformation(context);
			// object.put("IMEI", information.getIMEI());

			object.put("BatteryTemp", getBattery_temp());
			object.put("ChargingState", getCharging_state());
			object.put("BatteryLevel", getBattery_level());
			object.put("DeviceHealth", getDevice_health());
			object.put("WifiTime", getWifi_time());
			object.put("HotspotTime", getHotspot_time());
			object.put("BluetoothTime", getBluetooth_time());
			object.put("GpsTime", getGps_time());
			object.put("DeviceTotalCPU", getTotal_cpu());
			object.put("DeviceTotalRAM", getTotal_ram());
			object.put("DeviceTotalBatteryDischarge", getTotal_discharge());
			object.put("SignalStrength", getSignal_strength());
			object.put("BearerType", getBearer_type());
			object.put("TimeStamp", getTime_stamp());

			JSONArray array = new JSONArray();
			for (MonitorAppDTO appDTO : getArrayList()) {
				array.put(appDTO.toJsonString());
			}
			object.put("AppInfo", array);
			message = object.toString();
			LogWrite.d(TAG, "Message: " + message);
		} catch (JSONException e) {
			LogWrite.e(TAG, "JSONException : " + e.toString());
		}
		// } else
		// return null;
		return object;
	}
}
