package com.kochartech.gizmodoctor.POJO;

public class PowerSavingSettingsDTO {

	private String name;
	private String description;
	private boolean state;
	private int icon;
	public PowerSavingSettingsDTO(String name, boolean state, String description) {
		this.name = name;
		this.state = state;
		this.description = description;
	}
	
	public PowerSavingSettingsDTO(String name, String description, boolean state) {
		this.name = name;
		this.description = description;
		this.state = state;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	
	public boolean getState() {
		return state;
	}
	public void setState(boolean state) {
		this.state = state;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public int getIcon() {
		return icon;
	}

	public void setIcon(int icon) {
		this.icon = icon;
	}
	
	
	public boolean equals(Object o){
	    if(o == null)                return false;
	    if(! (o instanceof PowerSavingSettingsDTO)) return false;

	    PowerSavingSettingsDTO other = (PowerSavingSettingsDTO) o;
	    return this.name == other.name;
	  }
}
