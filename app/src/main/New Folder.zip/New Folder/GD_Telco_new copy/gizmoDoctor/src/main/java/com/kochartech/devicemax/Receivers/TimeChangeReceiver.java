package com.kochartech.devicemax.Receivers;
//package com.kochar.MDMS.Recievers;
//
//import com.kochar.AsyncTask.ApplicationUpdatehandler;
//import com.kochar.MDMS.Activities.LogWrite;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.util.Log;
//
//public class TimeChangeReceiver extends BroadcastReceiver
//{
////	private String tag = "TimeChangeReceiver";
//	public void onReceive(Context context, Intent intent) {
//		// TODO Auto-generated method stub
//		ApplicationUpdatehandler.startAlarm(context.getApplicationContext());
//		LogWrite.d("TimeChangeReceiver","TimeChangeReceiver  Work");
//	}
//
//}
