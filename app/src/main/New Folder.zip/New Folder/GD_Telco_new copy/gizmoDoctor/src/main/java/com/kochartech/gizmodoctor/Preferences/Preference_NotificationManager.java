package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class Preference_NotificationManager {

	private String tag = "NotificationManagerPreference";
	
	private final String PREFERENCE_NAME = "gizmodoctor";
	private final int    PREFERENCE_MODE = 0;
	
	
	private String notificationCount = "notificationCount";
	private String DiagnoseTime 	 = "diagnose_time";
	
	public  final int DEFAULTVALUE_NotificationCount = 0;
	public  final long DEFAULTVALUE_DiagnoseTime = System.currentTimeMillis();
	
	private Context context;
	private SharedPreferences myPreference;
	private Editor editor;
	
	public Preference_NotificationManager(Context context) {
		this.context = context;
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();		
	}
	
	public int getCount() {
		return myPreference.getInt(notificationCount, DEFAULTVALUE_NotificationCount);
	}
	
	public void setCount(int value) {
		editor.putInt(notificationCount,value).commit();
	}
	
	
	public long getDiagnoseTime() {
		return myPreference.getLong(DiagnoseTime, DEFAULTVALUE_DiagnoseTime);
	}
	
	public void setDiagnoseTime(long value) {
		editor.putLong(DiagnoseTime,value).commit();
	}
	
	
}
