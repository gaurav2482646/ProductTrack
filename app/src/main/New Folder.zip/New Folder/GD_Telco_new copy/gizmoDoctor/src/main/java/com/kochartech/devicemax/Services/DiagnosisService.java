package com.kochartech.devicemax.Services;

import java.util.ArrayList;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import com.kochartech.devicemax.Activities.APNCorrectDialog;
import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Utility.APNDataEnabledClass;
import com.kochartech.devicemax.Utility.APNProfileManipulator;

public class DiagnosisService extends BroadcastReceiver {
	private String currentOperatorName = "";
	private String tag = "DiagnosisService";
	private String defaultApnName;
	private String mobileNumber = "+919888919119";
	private String message;
	private static boolean smsFlag = false;
	private static boolean apnSMSFlag = false;

	// private static boolean apnFlag = false;
	@Override
	public void onReceive(Context context, Intent intent) {
		new DiagnosisAsyncTask(context).execute();
	}

	class DiagnosisAsyncTask extends AsyncTask<Object, String, String> {
		Context context;

		public DiagnosisAsyncTask(Context context) {
			this.context = context;
			// TODO Auto-generated constructor stub
		}

		@Override
		protected String doInBackground(Object... params) {
			diagnosisTask(context);
			return "";
		}

		@Override
		protected void onProgressUpdate(String... values) {
			Intent intent = new Intent(context, APNCorrectDialog.class);
			intent.putExtra("APN", values[0]);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
			super.onProgressUpdate(values);
		}

		public void diagnosisTask(Context context) {
			Boolean mobileDataStatus = APNDataEnabledClass
					.checkforMobileData(context);
			LogWrite.d(tag, "Mobile Data Status ======= " + mobileDataStatus);
			if (!mobileDataStatus) {
				APNDataEnabledClass.setMobileDataEnabled(context, true);
			} else {
				APNDataEnabledClass.setMobileDataEnabled(context, true);
			}
			Boolean mobileDataStatus1 = APNDataEnabledClass
					.checkforMobileData(context);
			if (mobileDataStatus1) {
				TelephonyManager telephonyManager = (TelephonyManager) context
						.getSystemService(Context.TELEPHONY_SERVICE);
				if (telephonyManager.getDataState() != TelephonyManager.DATA_CONNECTED) {
					message = "Mobile Data not working on your device";
					if (!smsFlag) {
						sendTextSMS(mobileNumber, message);
					}
					currentOperatorName = ((android.telephony.TelephonyManager) context
							.getSystemService(Context.TELEPHONY_SERVICE))
							.getNetworkOperatorName();
					LogWrite.d(tag, "Current Operator Name : "
							+ currentOperatorName);
					if (currentOperatorName.equalsIgnoreCase("reliance")) {
						String apnName = checkDefaultApn(context);
						LogWrite.d(apnName, "Apn Name : " + apnName);
						if (apnName.equals("")) {
							int id;
							try {
								id = APNProfileManipulator.GetInstance(context)
										.InsertAPN("Reliance", "rcomnet", "",
												"");
								APNProfileManipulator.GetInstance(context)
										.SetDefaultAPN(id);
							} catch (Exception e) {
								publishProgress("rcomnet");
							}
						} else if (!apnName.equals("rcomnet")) {
							LogWrite.d(tag,
									"*****************************Wrong APN");
							try {
								int id = APNProfileManipulator.GetInstance(
										context).updateAPN(defaultApnName,
										"rcomnet", true, "", "");
								LogWrite.d(tag, "APN ID = " + id);
							} catch (Exception e) {
								smsFlag = false;
								if (!smsFlag) {
									publishProgress("rcomnet");
									if (!apnSMSFlag) {
										sendTextSMS(mobileNumber,
												"APN is Incorrect");
										apnSMSFlag = true;
									}
								}
							}
						}
					}
					if (currentOperatorName.equalsIgnoreCase("airtel")) {
						String apnName = checkDefaultApn(context);
						LogWrite.d(tag, "Apn Name : " + apnName);
						if (apnName.equals("")) {
							int id;
							try {
								id = APNProfileManipulator.GetInstance(context)
										.InsertAPN("Airtel", "airtelgprs.com",
												"", "");
								APNProfileManipulator.GetInstance(context)
										.SetDefaultAPN(id);
							} catch (Exception e) {
								publishProgress("airtelgprs.com");
							}
						} else if (!apnName.equals("airtelgprs")
								&& !apnName.equals("airtelgprs.com")) {
							LogWrite.d(tag,
									"*****************************Wrong APN");
							try {
								int id = APNProfileManipulator.GetInstance(
										context).updateAPN(defaultApnName,
										"airtelgprs.com", true, "", "");
								LogWrite.d(tag, "APN ID = " + id);
							} catch (Exception e) {
								smsFlag = false;
								if (!smsFlag) {
									publishProgress("airtelgprs.com");
									if (!apnSMSFlag) {
										sendTextSMS(mobileNumber,
												"APN is Incorrect");
										apnSMSFlag = true;
									}
								}

							}

						}
					}
					if (currentOperatorName.contains("odafone")) {
						String apnName = checkDefaultApn(context);
						LogWrite.d(apnName, "Apn Name : " + apnName);
						if (apnName.equals("")) {
							int id;
							try {
								id = APNProfileManipulator.GetInstance(context)
										.InsertAPN("Vodafone", "www", "", "");
								APNProfileManipulator.GetInstance(context)
										.SetDefaultAPN(id);
							} catch (Exception e) {
								publishProgress("www");

							}

							// if(id == -1)
							// {
							// publishProgress("www");
							// }
							// else
							// {
							// APNProfileManipulator.GetInstance(context).SetDefaultAPN(id);
							// }
						}
						if (!apnName.equals("www")) {
							LogWrite.d(tag,
									"*****************************Wrong APN");
							try {
								int id = APNProfileManipulator.GetInstance(
										context).updateAPN(defaultApnName,
										"www", true, "", "");
								LogWrite.d(tag, "APN ID = " + id);
							} catch (Exception e) {
								smsFlag = false;
								if (!smsFlag) {
									publishProgress("www");
									if (!apnSMSFlag) {
										sendTextSMS(mobileNumber,
												"APN is Incorrect");
										apnSMSFlag = true;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public void sendTextSMS(String number, String message) {
		try {
			SmsManager smsManager = SmsManager.getDefault();
			ArrayList<String> parts = smsManager.divideMessage(message);
			smsManager
					.sendMultipartTextMessage(number, null, parts, null, null);
			smsFlag = true;
		} catch (Exception e) {
			LogWrite.d("Send SMS", "SMS ExceptionDTO ---> " + e.toString());
		}
	}

	private String checkDefaultApn(Context context) {
		String apnName = "";
		LogWrite.d(tag, "Default Apn Going to be checked");
		String ids = APNProfileManipulator.GetInstance(context).getIDS();
		LogWrite.d(tag, "APN IDS ---> " + ids);
		if (ids.length() != 0) {
			LogWrite.d(tag, "ids not zero");
			// LogWrite.d(tag, "ids > 0 ");
			// here i have : seperated id's of apn's whose mnc equals the
			// default apn's mnc
			ids = ids.substring(0, ids.length() - 1);
			LogWrite.d(tag, " ....................... 1");
			String idArray[] = ids.split(":");
			LogWrite.d(tag, " ....................... 2");
			// splitted ids on : and nwo i have String array of ids of
			// Access Points
			// now i will get array size and loop until i get names and apns
			// of all profiles of current operator
			int idArraySize = idArray.length;
			LogWrite.d(tag, " ....................... 3");
			defaultApnName = APNProfileManipulator.GetInstance(context)
					.APNFetcher();
			LogWrite.d(tag, "Default APN Name : " + defaultApnName);
			for (int i = 0; i < idArraySize; i++) {
				LogWrite.d(tag, "loop enter");
				String strNameApnCurrent = APNProfileManipulator.GetInstance(
						context).getNameApnCurrentFromId(idArray[i]);
				LogWrite.d(tag, " ....................... 20");
				strNameApnCurrent = strNameApnCurrent.substring(0,
						strNameApnCurrent.length() - 1);
				LogWrite.d(tag, " ....................... 21");
				String apnData[] = strNameApnCurrent.split("~");
				LogWrite.d(tag, " ....................... 22");
				String name = apnData[0];
				LogWrite.d(tag, " Name  :  " + name);
				String apn = apnData[1];
				LogWrite.d(tag, " APN   : " + apn);
				apnName = apn;
			}
		}
		LogWrite.d(tag, "APN Name ======= " + apnName);
		return apnName;
	}
}

// private final Handler handler = new Handler()
// {
// @Override
// public void handleMessage(android.os.Message msg)
// {
// timer = new Timer();
// timer.schedule(new TimerTask()
// {
// @Override
// public void run()
// {
// Boolean mobileDataStatus = APNDataEnabledClass.checkforMobileData(context);
// LogWrite.d(tag, "Mobile Data Status ======= " + mobileDataStatus);
// if(!mobileDataStatus)
// {
// APNDataEnabledClass.setMobileDataEnabled(context, true);
// }
// else
// {
// APNDataEnabledClass.setMobileDataEnabled(context, true);
// }
// Boolean mobileDataStatus1 = APNDataEnabledClass.checkforMobileData(context);
// if(mobileDataStatus1)
// {
// TelephonyManager telephonyManager = (TelephonyManager)
// context.getSystemService(Context.TELEPHONY_SERVICE);
// if(telephonyManager.getDataState() != TelephonyManager.DATA_CONNECTED)
// {
// message = "Mobile Data not working on your device";
// sendTextSMS(mobileNumber, message);
// }
// currentOperatorName = ((android.telephony.TelephonyManager)
// context.getSystemService(TELEPHONY_SERVICE)).getNetworkOperatorName();
// LogWrite.d(tag, "Current Operator Name : " + currentOperatorName);
// if(currentOperatorName.equalsIgnoreCase("reliance"))
// {
// String apnName = checkDefaultApn(context);
// if(!apnName.equals("rcomnet"))
// {
// LogWrite.d(tag, "*****************************Wrong APN");
// try
// {
// int id = APNProfileManipulator.GetInstance(context).updateAPN(defaultApnName,
// "rcomnet", true,"", "");
// LogWrite.d(tag, "APN ID = " + id);
// }
// catch (ExceptionDTO e)
// {
// smsFlag = false;
// sendTextSMS(mobileNumber, "APN is Incorrect");
// // handler.post(new Runnable()
// // {
// // @Override
// // public void run()
// // {
// // openDialogeForAPNCorrect("rcomnet");
// // }
// // });
// }
// }
// }
// if(currentOperatorName.equalsIgnoreCase("airtel"))
// {
// String apnName = checkDefaultApn(context);
// if(!apnName.equals("airtelgprs") || !apnName.equals("airtelgprs.com"))
// {
// LogWrite.d(tag, "*****************************Wrong APN");
// try
// {
// int id = APNProfileManipulator.GetInstance(context).updateAPN(defaultApnName,
// "airtelgprs.com", true,"", "");
// LogWrite.d(tag, "APN ID = " + id);
// }
// catch (ExceptionDTO e)
// {
// smsFlag = false;
// sendTextSMS(mobileNumber, "APN is Incorrect");
// // handler.post(new Runnable()
// // {
// // @Override
// // public void run()
// // {
// // openDialogeForAPNCorrect("airtelgprs.com");
// // }
// // });
// }
//
// }
// }
// if(currentOperatorName.contains("odafone"))
// {
// String apnName = checkDefaultApn(context);
// if(!apnName.equals("www"))
// {
// LogWrite.d(tag, "*****************************Wrong APN");
// try
// {
// int id = APNProfileManipulator.GetInstance(context).updateAPN(defaultApnName,
// "www", true,"", "");
// LogWrite.d(tag, "APN ID = " + id);
// }
// catch (ExceptionDTO e)
// {
// smsFlag = false;
// sendTextSMS(mobileNumber, "APN is Incorrect");
// // handler.post(new Runnable()
// // {
// // @Override
// // public void run()
// // {
// // openDialogeForAPNCorrect("www");
// // }
// // });
// }
// }
// }
// }
// }
// }, 100, 60*1000);
// }
// };
//
//
// public void onDestroy()
// {
// LogWrite.d(tag, "On Destroy Method call upon");
// timer.cancel();
// }

//
//
// public IBinder onBind(Intent intent)
// {
// return null;
// }
// private String checkDefaultApn(Context context)
// {
// String apnName = "";
// LogWrite.d(tag,"Default Apn Going to be checked");
// String ids = APNProfileManipulator.GetInstance(context).getIDS();
// LogWrite.d(tag,"APN IDS ---> " + ids);
// if (ids.length() != 0)
// {
// LogWrite.d(tag,"ids not zero");
// // LogWrite.d(tag, "ids > 0 ");
// // here i have : seperated id's of apn's whose mnc equals the
// // default apn's mnc
// ids = ids.substring(0, ids.length() - 1);
// LogWrite.d(tag, " ....................... 1");
// String idArray[] = ids.split(":");
// LogWrite.d(tag, " ....................... 2");
// // splitted ids on : and nwo i have String array of ids of
// // Access Points
// // now i will get array size and loop until i get names and apns
// // of all profiles of current operator
// int idArraySize = idArray.length;
// LogWrite.d(tag, " ....................... 3");
// defaultApnName = APNProfileManipulator.GetInstance(context).APNFetcher();
// LogWrite.d(tag, "Default APN Name : " + defaultApnName);
// for (int i = 0; i < idArraySize; i++)
// {
// LogWrite.d(tag, "loop enter");
// String strNameApnCurrent =
// APNProfileManipulator.GetInstance(context).getNameApnCurrentFromId(idArray[i]);
// LogWrite.d(tag, " ....................... 20");
// strNameApnCurrent = strNameApnCurrent.substring(0,strNameApnCurrent.length()
// - 1);
// LogWrite.d(tag, " ....................... 21");
// String apnData[] = strNameApnCurrent.split("~");
// LogWrite.d(tag, " ....................... 22");
// String name = apnData[0];
// LogWrite.d(tag, " Name  :  " + name);
// String apn = apnData[1];
// LogWrite.d(tag, " APN   : " + apn);
// apnName = apn;
// }
// }
// return apnName;
// }

// @Override
// public void onReceive(Context arg0, Intent arg1) {
// // TODO Auto-generated method stub
//
// }
//
// }
