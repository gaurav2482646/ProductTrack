package com.kochartech.gizmodoctor.Activity;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.kochartech.MyLibs.MyBluetoothManager;
import com.kochartech.MyLibs.MyWifiManager;
import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.HelperClass.PowerSavingSettings;
import com.kochartech.gizmodoctor.HelperClass.ServiceToastManager;
import com.kochartech.gizmodoctor.POJO.PowerSavingSettingsDTO;
import com.kochartech.library.Device.KTDeviceInfo;

public class PowerSavingNotificationActivity extends Activity implements
		OnItemClickListener {

	private String TAG = PowerSavingNotificationActivity.class.getSimpleName();
	private ListView listView;
	private ServiceToastManager serviceToastManager;
	private TextView numOfHoursLeftTxtView;
	private ArrayList<PowerSavingSettingsDTO> arrayList = new ArrayList<PowerSavingSettingsDTO>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_powersaving_notification);

		PowerSavingSettings settings = new PowerSavingSettings(this);

		arrayList = settings.getSettings();
		arrayList.remove(new PowerSavingSettingsDTO(
				PowerSavingSettings.TURNOFF_AUTO_SYNC, false, null));
		arrayList.remove(new PowerSavingSettingsDTO(
				PowerSavingSettings.KILL_BACKGROUNDAPPS, false, null));

		for (PowerSavingSettingsDTO powerSavingSettingDTO : arrayList) {
			Log.d(TAG, "name: " + powerSavingSettingDTO.getName());
			Log.d(TAG, "isSettingEnable: "
					+ isSettingEnable(powerSavingSettingDTO.getName()));
			powerSavingSettingDTO
					.setState(!isSettingEnable(powerSavingSettingDTO.getName()));
			Log.d(TAG, "currentState: " + powerSavingSettingDTO.getState());
		}

		initUi();
	}

	public void remove(String name) {

		arrayList.remove(arrayList.indexOf(name));
	}

	public void initUi() {

		listView = (ListView) findViewById(R.id.listView);
		numOfHoursLeftTxtView = (TextView) findViewById(R.id.numOfHoursLeftTxtView);

		MyAdapter adpeter = new MyAdapter();
		listView.setAdapter(adpeter);
		listView.setOnItemClickListener(this);
	}

	class MyAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arrayList.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return arrayList.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			if (convertView == null) {
				LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = layoutInflater
						.inflate(
								R.layout.listview_item_powersavingnotification_activity,
								null);
			}
			((TextView) convertView.findViewById(R.id.itemName))
					.setText(arrayList.get(position).getName());

			ImageView imageView = ((ImageView) convertView
					.findViewById(R.id.icon));

			if (arrayList.get(position).getState()) {
				imageView.setImageResource(R.drawable.tick);

			} else {
				imageView.setImageResource(R.drawable.cross);
			}

			return convertView;
		}

	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		// Toast.makeText(getApplicationContext(), "position: "+position,
		// Toast.LENGTH_LONG).show();

		String settingName = arrayList.get(position).getName();
		openSettingPage(settingName);
		pushToastMessage(settingName);

	}

	public void pushToastMessage(String settingName) {
		serviceToastManager = new ServiceToastManager(this,
				getToastMessage(settingName));
		serviceToastManager.showToast();
	}

	public boolean isSettingEnable(String name) {

		if (name.equals(PowerSavingSettings.TURNOFF_WIFI)) {
			return MyWifiManager.isWifiEnabled(this);
		} else if (name.equals(PowerSavingSettings.TURNOFF_BT)) {
			return new MyBluetoothManager().isBluetoothEnable();
		} else if (name.equals(PowerSavingSettings.TURNOFF_GPS)) {
			KTDeviceInfo ktDeviceInfo = new KTDeviceInfo(this);
			return ktDeviceInfo.isGPSEnabled();
		} else if (name.equals(PowerSavingSettings.TURNOFF_AUTO_SYNC)) {
			KTDeviceInfo ktDeviceInfo = new KTDeviceInfo(this);
			return ktDeviceInfo.isAutoSyncEnabled();
		} else if (name.equals(PowerSavingSettings.SCREENTIME_OUT)) {
			long timeout = Settings.System.getLong(getContentResolver(),
					Settings.System.SCREEN_OFF_TIMEOUT, -1);
			long sec = timeout / 1000;
			return sec == 15 ? true : false;
		}
		return false;

	}

	public void openSettingPage(String name) {
		Intent intent = new Intent();
		if (name.equals(PowerSavingSettings.TURNOFF_WIFI)) {
			intent.setAction(Settings.ACTION_WIFI_SETTINGS);
		} else if (name.equals(PowerSavingSettings.TURNOFF_BT)) {
			intent.setAction(Settings.ACTION_BLUETOOTH_SETTINGS);
		} else if (name.equals(PowerSavingSettings.TURNOFF_GPS)) {
			intent.setAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
		} else if (name.equals(PowerSavingSettings.SCREENTIME_OUT)
				|| name.equals(PowerSavingSettings.BRIGHTNESS)) {
			intent.setAction(Settings.ACTION_DISPLAY_SETTINGS);
		}
		startActivity(intent);
	}

	private String getToastMessage(String name) {

		if (name.equals(PowerSavingSettings.TURNOFF_WIFI)) {
			return "Turn off WiFi, to save power.";
		} else if (name.equals(PowerSavingSettings.TURNOFF_BT)) {
			return "Turn off Bluetooth, to save power.";
		} else if (name.equals(PowerSavingSettings.TURNOFF_GPS)) {
			return "Turn off GPS, to save power.";
		} else if (name.equals(PowerSavingSettings.SCREENTIME_OUT)) {
			return "Set screen timeout value to 15s, to save power.";
		} else if (name.equals(PowerSavingSettings.BRIGHTNESS)) {
			return "Reduce screen brightness, to save power.";
		} else {
			return null;
		}

	}

	protected void onResume() {
		super.onResume();
		setToastVisibilty(false);
		LogWrite.d(TAG, "onResume");
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		setToastVisibilty(true);
		LogWrite.d(TAG, "onPause");
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		setToastVisibilty(false);
		LogWrite.d(TAG, "onDestroy");
	}

	private void setToastVisibilty(boolean flag) {
		if (serviceToastManager != null) {
			serviceToastManager.setToastVisibility(flag);
		}
	}

}
