package com.kochartech.MyLibs;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Map;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;

import com.kochartech.devicemax.Activities.LogWrite;

@SuppressWarnings("deprecation")
public class InternalMemory {
	private static String tag = InternalMemory.class.getSimpleName();

	public static String getExtraPath1() {
		Map<String, File> externalLocations = ExternalStorage
				.getAllStorageLocations();
		File sdCard = externalLocations.get(ExternalStorage.SD_CARD);
		return sdCard.getPath();
	}

	public static String getExtraPath2() {
		Map<String, File> externalLocations = ExternalStorage
				.getAllStorageLocations();
		File externalSdCard = externalLocations
				.get(ExternalStorage.EXTERNAL_SD_CARD);
		return externalSdCard.getPath();

	}

	private static String getInternalStoragePath() {
		String responsePath = null;

		ArrayList<File> selected_ExternalStorages = new ArrayList<File>();
		File externalStorage = Environment.getExternalStorageDirectory();

		File rootOf_externalStorage = externalStorage.getParentFile();
		File[] listOf_externalStorages = rootOf_externalStorage.listFiles();

		// Log.d(tag, "External Storage = " + listOf_externalStorages.length);
		/*
		 * 
		 * we select the storages that has writable permission.
		 */
		for (File storage : listOf_externalStorages) {

			// Log.d(tag, "storage = " + storage.getPath());
			// Log.d(tag, "storage can write= " + storage.canWrite());
			if (storage.canWrite()) {
				selected_ExternalStorages.add(storage);
				LogWrite.d(tag, "Selected Path= " + storage.getPath());
			}
		}

		/*
		 * 
		 * from selected_ExternalStorages select phones inbuild storage.
		 */

		int countExternalStorage = selected_ExternalStorages.size();
		// Log.d(tag, "countExternalStorage =" + countExternalStorage);

		boolean isExternalStorageRemovable = false;
		if (android.os.Build.VERSION.SDK_INT >= 9) {
			isExternalStorageRemovable = Environment
					.isExternalStorageRemovable();
			// Log.d(tag, "isExternalStorageRemovable =" +
			// isExternalStorageRemovable);
		}
		// //Log.d(tag,"isExternalStorageEmulated ="+Environment.isExternalStorageEmulated());
		// if(countExternalStorage == 0)
		// {
		// // return "";
		// }
		if (countExternalStorage == 1) {
			// if(isExternalStorageRemovable)
			// return "";
			// else
			// return selected_ExternalStorages.get(0).getPath();

			if (!isExternalStorageRemovable)
				responsePath = Environment.getExternalStorageDirectory()
						.getPath();

		} else if (selected_ExternalStorages.size() == 2) {

			if (isExternalStorageRemovable) {
				String sdCardPath = Environment.getExternalStorageDirectory()
						.getPath();
				for (File storage : selected_ExternalStorages) {
					if (!storage.getPath().equalsIgnoreCase(sdCardPath)) {
						responsePath = storage.getPath();
					}
				}
			} else {
				/*
				 * Means External Storage is Not removeable.
				 */
				responsePath = Environment.getExternalStorageDirectory()
						.getPath();
			}
		}
		// Log.d(tag, "responsePath = " + responsePath);
		return responsePath;
	}

	public static String getExternalStoragePath() {
		// String tag = "getExternalStoragePath";
		String responsePath = null;

		ArrayList<File> selected_ExternalStorages = new ArrayList<File>();
		File externalStorage = Environment.getExternalStorageDirectory();
		File rootOf_externalStorage = externalStorage.getParentFile();
		File[] listOf_externalStorages = rootOf_externalStorage.listFiles();

		/*
		 * 
		 * we select the storages that has writable permission.
		 */
		for (File storage : listOf_externalStorages) {
			if (storage.canWrite()) {
				selected_ExternalStorages.add(storage);
			}
		}

		/*
		 * 
		 * from selected_ExternalStorages select phones inbuild storage.
		 */

		int countExternalStorage = selected_ExternalStorages.size();
		// Log.d(tag, "countExternalStorage =" + countExternalStorage);

		boolean isExternalStorageRemovable = false;
		if (android.os.Build.VERSION.SDK_INT >= 9) {
			isExternalStorageRemovable = Environment
					.isExternalStorageRemovable();
			// Log.d(tag, "isExternalStorageRemovable ="+
			// isExternalStorageRemovable);
		}

		// if(countExternalStorage == 0)
		// {
		// // return "";
		// }
		if (countExternalStorage == 1) {
			// if(isExternalStorageRemovable)
			// return "";
			// else
			// return selected_ExternalStorages.get(0).getPath();

			if (isExternalStorageRemovable)
				responsePath = Environment.getExternalStorageDirectory()
						.getPath();

		} else if (selected_ExternalStorages.size() == 2) {

			if (!isExternalStorageRemovable) {
				String sdCardPath = Environment.getExternalStorageDirectory()
						.getPath();
				for (File storage : selected_ExternalStorages) {
					if (!storage.getPath().equalsIgnoreCase(sdCardPath)) {
						responsePath = storage.getPath();
					}
				}
			} else {
				responsePath = Environment.getExternalStorageDirectory()
						.getPath();
			}
		}
		// Log.d(tag, "responsePath = " + responsePath);
		return responsePath;
	}
	
	
	
	

	public static String getTotalStorageCapacity(Context context) {
		float totalCapacity = 0;
		float internalCapacity = 0;
		float externalCapacity = 0;
		float totalInternal = 0, totalexternal = 0, freeInternal = 0, freeExternal = 0;
		LogWrite.d(tag, "-------------------------1");
		String interStoragePath = null;
		try {
			interStoragePath = getInternalStoragePath();
		} catch (Exception e) {
			LogWrite.e(tag, "InternalPathException : " + e.toString());
			e.printStackTrace();
		}
		LogWrite.d(tag, "-------------------------2");
		String externalStoragePath = null;
		try {
			externalStoragePath = getExternalStoragePath();
		} catch (Exception e) {
			LogWrite.e(tag, "ExternalPathException : " + e.toString());
			e.printStackTrace();
		}
		String extraPath1 = null, extraPath2 = null;
		if (interStoragePath == null) {
			try {
				extraPath1 = getExtraPath1();
				interStoragePath = extraPath1;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (externalStoragePath == null) {
			try {
				extraPath2 = getExtraPath2();
				externalStoragePath = extraPath2;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		LogWrite.d(tag, "InternalStroragePath = " + interStoragePath);
		LogWrite.d(tag, "ExternalStroragePath = " + externalStoragePath);
		LogWrite.d(tag, "ExtraStroragePath = " + extraPath1);
		LogWrite.d(tag, "ExtraStroragePath1 = " + extraPath2);

		if (interStoragePath != null) {
			StatFs internalStorageFs = new StatFs(interStoragePath);

			freeInternal = (long) internalStorageFs.getFreeBlocks()
					* (long) internalStorageFs.getBlockSize();
			totalInternal = (long) internalStorageFs.getBlockCount()
					* (long) internalStorageFs.getBlockSize();

			internalCapacity = totalInternal / 1048576;

			LogWrite.d(tag, "internalCapacity = " + internalCapacity);
			// Log.d(tag, "internalCapacity =" + internalCapacity);
		}
		if (externalStoragePath != null) {
			StatFs internalStorageFs = new StatFs(externalStoragePath);
			freeExternal = (long) internalStorageFs.getFreeBlocks()
					* (long) internalStorageFs.getBlockSize();
			totalexternal = (long) internalStorageFs.getBlockCount()
					* (long) internalStorageFs.getBlockSize();

			externalCapacity = totalexternal / 1048576;

			LogWrite.d(tag, "externalCapacity = " + externalCapacity);
			// Log.d(tag, "externalCapacity =" + externalCapacity);
		}
		if (totalInternal == totalexternal & freeInternal == freeExternal) {
			totalCapacity = (float) internalCapacity;
		} else {
			totalCapacity = (float) internalCapacity + externalCapacity;
		}
		LogWrite.d(tag, "totalCapacity = " + totalCapacity);
		totalCapacity = totalCapacity / 1024;
		LogWrite.d(tag, "totalCapacity = " + totalCapacity);
		return new DecimalFormat("##.##").format(totalCapacity);
	}
}
