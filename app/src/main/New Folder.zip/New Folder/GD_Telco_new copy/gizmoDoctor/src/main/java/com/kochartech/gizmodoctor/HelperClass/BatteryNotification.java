//package com.kochartech.gizmodoctor.HelperClass;
//
//import com.kochartech.library.Battery.KTBatteryInfo;
//
//import android.content.Context;
//
//public class BatteryNotification 
//{
//	private Context context;
//	private int temperature = 0;
//	private KTBatteryInfo ktBatteryInfo ;
//	public BatteryNotification(Context context) {
//		// TODO Auto-generated constructor stub		
//		this.context = context;	
//		ktBatteryInfo = KTBatteryInfo.getInstance();
//	}
//	
////	public void getTemperature
//
//}
