package com.kochartech.gizmodoctor.Activity;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Utility.Response;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.HelperClass.BackgroundRegistration;
import com.kochartech.gizmodoctor.HelperClass.BackgroundTaskManager;
import com.kochartech.gizmodoctor.HelperClass.Config;
import com.kochartech.gizmodoctor.HelperClass.Config.AppTye;
import com.kochartech.gizmodoctor.HelperClass.DeviceInformation;
import com.kochartech.gizmodoctor.Preferences.ActivationKeyPreference;
import com.kochartech.library.Device.KTDeviceInfo;

public class GUIDecisionMaking extends Activity {
	private String TAG = GUIDecisionMaking.class.getSimpleName();
	private AppTye applicationType;

	// private static MyProgressDialog myprogressDialog;

	// 353508079857913 : 862893008947934
//	 private static final String FIXED_IMEI = "861638030035286";
	//
	// private static final String FIXED_IMEI2 = "356906071187577";

	// private static final String FIXED_IMEI = "355427060959315";

	// private static final String FIXED_IMEI3 = "353508079857913";

	// 353490060024565
	// private static final String FIXED_IMEI3 = "352861070265664";
	// private static final String FIXED_IMEI4 = "355814070001156";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_decision_making);
		applicationType = Config.getApplicationType();
		if (applicationType == Config.AppTye.BACKGROUND_REGISTER) {
			BackgroundRegistration backgroundRegistration = new BackgroundRegistration(
					getApplicationContext());
			if (backgroundRegistration.hasActivationTime()) {
				Intent intent = new Intent(this, NavDrawerActivity.class);
				startActivity(intent);
				BackgroundTaskManager.startTask(this);
				backgroundRegistration.registerInBackground();
			} else {
				Intent intent = new Intent(this,
						Activity_LicenceKeyExpire.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
				BackgroundTaskManager.stopTask(this);
			}
			finish();
		} else if (applicationType == Config.AppTye.FOREGROUND_REGISTER) {
			ActivationKeyPreference activationKeyPreference = new ActivationKeyPreference(
					getApplicationContext());
			if (activationKeyPreference.isActivationKeyRegister()) {
				Intent intent = new Intent(this, NavDrawerActivity.class);
				startActivity(intent);
				BackgroundTaskManager.startTask(this);
			} else {
				Intent intent = new Intent(this, GUIRegistration.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
				BackgroundTaskManager.stopTask(this);
			}
			finish();
		} else if (applicationType == Config.AppTye.WITHOUT_REGISTRATION) {
//			 KTDeviceInfo deviceInfo = new KTDeviceInfo(this);
//			 if (deviceInfo.getDeviceId().equals(FIXED_IMEI)){
			// || deviceInfo.getDeviceId().equals(FIXED_IMEI2)) {
			// LogWrite.d(TAG, "Imei matches : " + deviceInfo.getDeviceId());
			startAnimations();
			SendingInstallLogAsync sendingInstallLogAsync = new SendingInstallLogAsync(
					this);
			sendingInstallLogAsync.execute("");
//			 } else {
//			 LogWrite.e(TAG,
//			 "Imei not matches : " + deviceInfo.getDeviceId());
//			 Intent intent = new Intent(this,
//			 Activity_LicenceKeyExpire.class);
//			 intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//			 startActivity(intent);
//			 BackgroundTaskManager.stopTask(this);
//			 finish();
//			 }
		}
		// finish();
	}

	private void startAnimations() {
		Animation anim = AnimationUtils.loadAnimation(this, R.anim.alpha);
		anim.reset();
		LinearLayout l = (LinearLayout) findViewById(R.id.lin_lay);
		l.clearAnimation();
		l.startAnimation(anim);

		anim = AnimationUtils.loadAnimation(this, R.anim.translate);
		anim.reset();
		ImageView iv = (ImageView) findViewById(R.id.logo);
		iv.clearAnimation();
		iv.startAnimation(anim);
	}

	private class SendingInstallLogAsync extends
			AsyncTask<String, String, String> {
		private Activity context;
		private String installUrl;
		private DeviceInformation deviceInfo;

		public SendingInstallLogAsync(Activity context) {
			this.context = context;
			installUrl = context.getString(R.string.InstallAppUrl);
			deviceInfo = new DeviceInformation(context);
			// myprogressDialog = new MyProgressDialog(GUIDecisionMaking.this);
			// if (!myprogressDialog.isShowing())
			// myprogressDialog.show();
		}

		// {
		// "IMEI": "54545424242424",
		// "IMSI": "5454445",
		// "Brand": "Apple",
		// "Model": "iphon7",
		// "DeviceOS": "Android lollipop 5.0",
		// "AppInstalledVersion": "3.16"
		// }
		@Override
		protected String doInBackground(String... params) {
			try {
				InstallPrefrences installPrefrences = new InstallPrefrences(
						context);
				if (!installPrefrences.getLogStatus()) {
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("IMEI", deviceInfo.getIMEI());
					jsonObject.put("IMSI", deviceInfo.getIMSI());
					jsonObject.put("Brand", deviceInfo.getBrand());
					jsonObject.put("Model", deviceInfo.getModel());
					jsonObject.put("DeviceOS", deviceInfo.getOSVersion());
					jsonObject.put("AppInsatalledVersion",
							getApplicationVersionName(context));
					Response response = new Response();
					boolean flag = response.send(context, installUrl,
							jsonObject.toString());
					if (flag) {
						LogWrite.d(TAG, "Sending Success!");
						installPrefrences.setLogStatus(true);
					} else {
						LogWrite.e(TAG, "Sending Failed!");
						installPrefrences.setLogStatus(false);
					}
				}
			} catch (JSONException e) {
				LogWrite.e(TAG, "JSONException : " + e.toString());
			}
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return "";
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			Intent intent = new Intent(context, NavDrawerActivity.class);
			context.startActivity(intent);
			overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
			BackgroundTaskManager.startTask(context);

			// if (myprogressDialog.isShowing())
			// myprogressDialog.dismiss();
			context.finish();

		}

		private String getApplicationVersionName(Context context) {
			try {
				PackageInfo pInfo = context.getPackageManager().getPackageInfo(
						context.getPackageName(), PackageManager.GET_META_DATA);
				return String.valueOf(pInfo.versionName);
			} catch (Exception e) {
				return "NA";
			}
		}
	}

	private class InstallPrefrences {
		private String KEY_INSTALL_LOG_STATUS = "install_log_status";
		private SharedPreferences preferences;
		private Editor editor;

		public InstallPrefrences(Context context) {
			preferences = context.getSharedPreferences(
					InstallPrefrences.class.getSimpleName(),
					Context.MODE_PRIVATE);
			editor = preferences.edit();
		}

		public boolean getLogStatus() {
			return preferences.getBoolean(KEY_INSTALL_LOG_STATUS, false);
		}

		public void setLogStatus(boolean flag) {
			editor.putBoolean(KEY_INSTALL_LOG_STATUS, flag).commit();
		}
	}

}