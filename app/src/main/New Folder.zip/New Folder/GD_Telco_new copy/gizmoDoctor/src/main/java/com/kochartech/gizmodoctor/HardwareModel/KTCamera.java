package com.kochartech.gizmodoctor.HardwareModel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.media.AudioManager;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.homehelper.HomeKeyWatcher;
import com.kochartech.gizmodoctor.homehelper.OnHomePressedListener;

@SuppressWarnings("deprecation")
public class KTCamera {

	private static final String TAG = KTCamera.class.getSimpleName();
	private Activity context;
	private PackageManager packageManager;
	private boolean pictureFlag = false;
	private File mediaFile;

	public ImageCaptureListener imageCaptureListener;

	private boolean homePressedFlag = false;
	private HomeKeyWatcher mHomeWatcher;

	public void setOnImageCapture(ImageCaptureListener imageCaptureListener) {
		this.imageCaptureListener = imageCaptureListener;
	}

	public KTCamera(Activity context) {
		this.context = context;
		packageManager = context.getPackageManager();
	}

	public boolean hasCamera() {
		return packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA) ? true
				: false;
	}

	public boolean hasFrontCamera() {
		return packageManager
				.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT) ? true
				: false;
	}

	public boolean hasAutoFlash(Camera mCamera) {
		Parameters params = mCamera.getParameters();
		List<String> flashModes = params.getSupportedFlashModes();
		if (flashModes == null) {
			return false;
		}

		for (String flashMode : flashModes) {
			if (Parameters.FLASH_MODE_AUTO.equals(flashMode)) {
				return true;
			}
		}
		return false;
	}

	public boolean hasFlash(Camera mCamera) {
		Parameters params = mCamera.getParameters();
		List<String> flashModes = params.getSupportedFlashModes();
		if (flashModes == null) {
			return false;
		}

		for (String flashMode : flashModes) {
			if (Parameters.FLASH_MODE_ON.equals(flashMode)) {
				return true;
			}
		}

		return false;
	}

	public boolean hasAutoFocus(Camera mCamera) {
		List<String> supportedFocusModes = mCamera.getParameters()
				.getSupportedFocusModes();
		boolean hasAutoFocus = supportedFocusModes != null
				&& supportedFocusModes
						.contains(Camera.Parameters.FOCUS_MODE_AUTO);
		return hasAutoFocus;
	}

	public Camera getBackCameraInstance() {
		Camera camera = null;
		try {
			camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_BACK);
		} catch (Exception e) {
			// cannot get camera or does not exist
		}
		return camera;
	}

	public Camera getFrontCameraInstance() {
		Camera camera = null;
		try {
			camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
		} catch (Exception e) {
			// cannot get camera or does not exist
			LogWrite.e(TAG, "Unable to open front camera");
		}
		return camera;
	}

	public Camera flipcamera(Camera mCamera, SurfaceView surfaceView,
			boolean flipFlag) {
		// boolean flipFlag = false;
		if (mCamera != null) {
			mCamera.stopPreview();
			mCamera.release();
			mCamera = null;
		}

		if (flipFlag) {
			mCamera = getFrontCameraInstance();
		} else {
			mCamera = getBackCameraInstance();
		}

		Parameters params = mCamera.getParameters();

		Display display = ((WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		// Toast.makeText(context,
		// "DeviceRotation : " + display.getRotation(),
		// Toast.LENGTH_SHORT).show();
		if (display.getRotation() == Surface.ROTATION_0) {
			mCamera.setDisplayOrientation(90);
		}

		if (display.getRotation() == Surface.ROTATION_180) {
			mCamera.setDisplayOrientation(270);
		}
		if (display.getRotation() == Surface.ROTATION_270) {
			mCamera.setDisplayOrientation(180);
		}

		// if (context.getResources().getConfiguration().orientation !=
		// Configuration.ORIENTATION_LANDSCAPE) {
		// params.set("orientation", "portrait");
		// mCamera.setDisplayOrientation(90);
		// }
		if (mCamera != null) {
			try {
				mCamera.setPreviewDisplay(surfaceView.getHolder());
				mCamera.startPreview();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mCamera;
	}

	public void showFlashButton(Parameters params, View view) {
		boolean showFlash = (context.getPackageManager().hasSystemFeature(
				PackageManager.FEATURE_CAMERA_FLASH) && params.getFlashMode() != null)
				&& params.getSupportedFlashModes() != null
				&& params.getSupportedFocusModes().size() > 1;

		view.setVisibility(showFlash ? View.VISIBLE : View.INVISIBLE);

	}

	public boolean takePicture(final Camera mCamera,
			final String directoryName, final boolean shutterSound,
			final boolean flashState, boolean flipFlag) {
		mHomeWatcher = new HomeKeyWatcher(context, false);
		mHomeWatcher.setOnHomePressedListener(new OnHomePressedListener() {
			@Override
			public void onHomePressed() {
				LogWrite.d(TAG, "Home Key Press..........");
				homePressedFlag = true;
			}

			@Override
			public void onHomeLongPressed() {
				LogWrite.d(TAG, "Home Key Long Press..........");
				homePressedFlag = true;
			}
		});
		mHomeWatcher.startWatch();
		try {
			setQualityImage(mCamera, flashState);
		} catch (Exception e) {
			LogWrite.e(TAG, "SetQualityImage ExceptionDTO :: " + e.toString());
		}
		if (hasAutoFocus(mCamera)) {
			mCamera.autoFocus(new Camera.AutoFocusCallback() {
				@Override
				public void onAutoFocus(boolean success, Camera camera) {
					LogWrite.e(TAG, "AutoFocus Success: " + success);
					if (success)
						picture(mCamera, directoryName, shutterSound,
								flashState);
					else {
						LogWrite.e(TAG, "AutoFocus Fails!");
						picture(mCamera, directoryName, shutterSound,
								flashState);
					}
				}
			});
		} else {
			picture(mCamera, directoryName, shutterSound, flashState);
		}

		return pictureFlag;
	}

	public void releaseCamera(Camera mCamera) {
		try {
			if (mCamera != null) {
				mCamera.setPreviewCallback(null);
				mCamera.setErrorCallback(null);
				mCamera.stopPreview();
				mCamera.release();
				mCamera = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogWrite.e(TAG, e.toString());
			mCamera = null;
		}
	}

	public void refreshCamera(Camera mCamera, SurfaceView su) {
		if (su.getHolder() == null) {
			// preview surface does not exist
			return;
		}
		// stop preview before making changes
		try {
			mCamera.stopPreview();
		} catch (Exception e) {
			// ignore: tried to stop a non-existent preview
		}
		// set preview size and make any resize, rotate or
		// reformatting changes here
		// start preview with new settings
		try {
			mCamera.setPreviewDisplay(su.getHolder());
			mCamera.startPreview();
		} catch (Exception e) {
			Log.d(TAG, "Error starting camera preview: " + e.getMessage());
		}
	}

	private void picture(final Camera mCamera, final String directoryName,
			final boolean shutterSound, final boolean flashState) {
		PictureCallback mPicture = new PictureCallback() {
			@Override
			public void onPictureTaken(byte[] data, Camera camera) {
				LogWrite.i(TAG, "On picture taken");
				// String value = new String(data);
				File pictureFile = getOutputMediaFile(directoryName);
				if (pictureFile == null) {
					imageCaptureListener.onImageCapture(null, "File is null");
					try {
						mHomeWatcher.stopWatch();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return;
				}
				try {
					FileOutputStream fos = new FileOutputStream(pictureFile);
					fos.write(data);
					fos.close();
					imageCaptureListener.onImageCapture(pictureFile, "success");
					try {
						mHomeWatcher.stopWatch();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (FileNotFoundException e) {
					imageCaptureListener.onImageCapture(null,
							"due to file not found");
					try {
						mHomeWatcher.stopWatch();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (IOException e) {
					imageCaptureListener.onImageCapture(null,
							"due to input/output error");
					try {
						mHomeWatcher.stopWatch();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} finally {
					Parameters params = mCamera.getParameters();
					if (flashState)
						params.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
					mCamera.setParameters(params);
					try {
						mCamera.startPreview();
					} catch (Exception e) {
						LogWrite.e(TAG,
								"StartPreviewException : " + e.toString());
					}
				}
			}

		};
		if (!homePressedFlag) {
			if (shutterSound) {
				LogWrite.i(TAG, "Shutter sound required!");
				// mCamera.takePicture(null, null, mPicture);

				try {
					mCamera.takePicture(new ShutterCallback() {
						@Override
						public void onShutter() {
							LogWrite.i(TAG, "On Shutter!!!!!!");
							AudioManager mgr = (AudioManager) context
									.getSystemService(Context.AUDIO_SERVICE);
							mgr.playSoundEffect(AudioManager.FLAG_PLAY_SOUND);
						}
					}, null, mPicture);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				LogWrite.i(TAG, "Shutter sound not required!");
				mCamera.takePicture(null, null, mPicture);
			}
		} else {
			imageCaptureListener.onImageCapture(null, "due to back press.");
			try {
				mHomeWatcher.stopWatch();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@SuppressLint("SimpleDateFormat")
	private File getOutputMediaFile(String directory_name) {
		if (directory_name.equals("") || directory_name == null) {
			directory_name = "CameraDemo";
		}
		File mediaStorageDir = new File(
				Environment
						.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
				directory_name);
		if (!mediaStorageDir.exists()) {
			if (!mediaStorageDir.mkdirs()) {
				LogWrite.i(TAG, "failed to create directory");
				return null;
			}
		}
		// Create a media file name
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
				.format(new Date());
		File mediaFile;
		mediaFile = new File(mediaStorageDir.getPath() + File.separator
				+ "IMG_" + timeStamp + ".jpg");
		setSaveFile(mediaFile);
		return mediaFile;
	}

	private void setSaveFile(File file) {
		mediaFile = file;
	}

	public File getSaveFile() {
		return mediaFile;
	}

	private void setQualityImage(Camera mCamera, boolean flashState)
			throws Exception {
		Parameters params = mCamera.getParameters();
		LogWrite.e(TAG, "------------2");
		if (flashState)
			params.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
		LogWrite.e(TAG, "------------3");
		params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
		LogWrite.e(TAG, "------------4");
		List<Camera.Size> sizes = params.getSupportedPictureSizes();
		LogWrite.e(TAG, "------------5");
		int w = 0, h = 0;
		for (Size size : sizes) {
			if (size.width > w || size.height > h) {
				w = size.width;
				h = size.height;
			}

		}
		LogWrite.e(TAG, "------------6");
		params.setPictureSize(w, h);
		LogWrite.e(TAG, "------------7");
		mCamera.setParameters(params);
	}

	public String getImageSize(Camera mCamera) {
		Parameters params = mCamera.getParameters();
		List sizes = params.getSupportedPictureSizes();
		Camera.Size result = null;

		ArrayList<Integer> arrayListForWidth = new ArrayList<Integer>();
		ArrayList<Integer> arrayListForHeight = new ArrayList<Integer>();

		for (int i = 0; i < sizes.size(); i++) {
			result = (Size) sizes.get(i);
			arrayListForWidth.add(result.width);
			arrayListForHeight.add(result.height);
			LogWrite.d(TAG, "Supported Size: " + result.width + "height : "
					+ result.height);
		}
		if (arrayListForWidth.size() != 0 && arrayListForHeight.size() != 0) {
			System.out.println("Back max W :"
					+ Collections.max(arrayListForWidth)); // Gives Maximum
															// Width
			System.out.println("Back max H :"
					+ Collections.max(arrayListForHeight)); // Gives Maximum
															// Height
			System.out.println("Back Megapixel :"
					+ (((Collections.max(arrayListForWidth)) * (Collections
							.max(arrayListForHeight))) / 1024000));
			return (Collections.max(arrayListForWidth) + "X" + Collections
					.max(arrayListForHeight));
		}
		return "";
	}

	public double getImagePixel(Camera mCamera) {
		Parameters params = mCamera.getParameters();
		List sizes = params.getSupportedPictureSizes();
		Camera.Size result = null;

		ArrayList<Integer> arrayListForWidth = new ArrayList<Integer>();
		ArrayList<Integer> arrayListForHeight = new ArrayList<Integer>();

		for (int i = 0; i < sizes.size(); i++) {
			result = (Size) sizes.get(i);
			arrayListForWidth.add(result.width);
			arrayListForHeight.add(result.height);
			LogWrite.d(TAG, "Supported Size: " + result.width + "height : "
					+ result.height);
		}
		if (arrayListForWidth.size() != 0 && arrayListForHeight.size() != 0) {
			System.out.println("Back max W :"
					+ Collections.max(arrayListForWidth)); // Gives Maximum
															// Width
			System.out.println("Back max H :"
					+ Collections.max(arrayListForHeight)); // Gives Maximum
															// Height
			System.out.println("Back Megapixel :"
					+ (((Collections.max(arrayListForWidth)) * (Collections
							.max(arrayListForHeight))) / 1024000));
			LogWrite.d(
					TAG,
					""
							+ ((double) ((Collections.max(arrayListForWidth)) * (Collections
									.max(arrayListForHeight))) / 1024000));
			return roundOneDecimals(((double) ((Collections
					.max(arrayListForWidth)) * (Collections
					.max(arrayListForHeight))) / 1000000));
		}
		return 0;
	}

	private double roundOneDecimals(double d) {
		DecimalFormat twoDForm = new DecimalFormat("#.#");
		return Double.valueOf(twoDForm.format(d));
	}

}