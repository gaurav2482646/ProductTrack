package com.kochartech.gizmodoctor.HelperClass;

import android.content.Context;
import android.content.Intent;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.HelperClass.Config.AppTye;
import com.kochartech.gizmodoctor.MonitorInBackground.StatisticsAlarmManager;
import com.kochartech.gizmodoctor.Receiver.BatteryChangeService;
import com.kochartech.gizmodoctor.Service.CountActivationPeriod;

public class BackgroundTaskManager {
	private static String TAG = BackgroundTaskManager.class.getSimpleName();

	// private static Context context;
	// public BackgroundTaskManager(Context context) {
	// // TODO Auto-generated constructor stub
	// this.context = context;
	// }
	public static void startTask(Context context) {

		try {
			LogWrite.d(TAG, "Start Work");
			/*
			 * Start Service for Battery Discharge rate
			 */
			if (!Util.isMyServiceRunning(context, BatteryChangeService.class))
				context.startService(new Intent(context,
						BatteryChangeService.class));
			/*
			 * It Calculate Background Monitoring
			 */
			new StatisticsAlarmManager(context).start();

			/*
			 * Start CountActivationPeriod if it is stop.
			 */

			AppTye applicationType = Config.getApplicationType();
			if (applicationType != Config.AppTye.WITHOUT_REGISTRATION) {
				if (!Util.isMyServiceRunning(context,
						CountActivationPeriod.class))
					context.startService(new Intent(context,
							CountActivationPeriod.class));
			}

			LogWrite.d(TAG, "Finish Work");
		} catch (Exception e) {
			LogWrite.e(TAG,
					"BackgroundTaskManagerStartTaskException : " + e.toString());
		}
	}

	public static void stopTask(Context context) {
		try {
			new StatisticsAlarmManager(context).stop();
			if (Util.isMyServiceRunning(context, BatteryChangeService.class)) {
				context.stopService(new Intent(context,
						BatteryChangeService.class));
			}
		} catch (Exception e) {
			LogWrite.e(TAG,
					"BackgroundTaskManagerStopTaskException : " + e.toString());
		}
	}
}
