package com.kochartech.gizmodoctor.HelperClass;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.BatteryManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;

public class DeviceInformation {
	private String TAG = DeviceInformation.class.getSimpleName();
	private Context context;
	private TelephonyManager telephonyManager;

	public DeviceInformation(Context context) {
		this.context = context;
		telephonyManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
	}

	public String getBrand() {
		return android.os.Build.BRAND.trim();
	}

	public String getModel() {
		return android.os.Build.MODEL.trim();
	}

	public String getOSVersion() {
		return android.os.Build.VERSION.RELEASE;
	}

	public String getCarrierName() {
		String carrierName = "NA";
		carrierName = telephonyManager.getSimOperatorName();
		if (carrierName.trim().length() == 0)
			carrierName = "NA";
		return carrierName;
	}

	// public String getNetworktype()
	// {
	// String bearerInfo = "NA";
	// int networkType = telephonyManager.getNetworkType();
	//
	// Toast.makeText(context,"Network Type :"+networkType,
	// Toast.LENGTH_LONG).show();
	// switch (networkType)
	// {
	// case TelephonyManager.NETWORK_TYPE_1xRTT:
	// bearerInfo = "1xRTT";
	// break;
	// case TelephonyManager.NETWORK_TYPE_CDMA:
	// bearerInfo = "CDMA";
	// break;
	// case TelephonyManager.NETWORK_TYPE_EDGE:
	// bearerInfo = "EDGE";
	// break;
	// case TelephonyManager.NETWORK_TYPE_EHRPD:
	// bearerInfo = "eHRPD";
	// break;
	// case TelephonyManager.NETWORK_TYPE_EVDO_0:
	// bearerInfo = "EVDO rev. 0";
	// break;
	// case TelephonyManager.NETWORK_TYPE_EVDO_A:
	// bearerInfo = "EVDO rev. A";
	// break;
	// case TelephonyManager.NETWORK_TYPE_EVDO_B:
	// bearerInfo = "EVDO rev. B";
	// break;
	// case TelephonyManager.NETWORK_TYPE_GPRS:
	// bearerInfo = "GPRS";
	// break;
	// case TelephonyManager.NETWORK_TYPE_HSDPA:
	// bearerInfo = "HSDPA";
	// break;
	// case TelephonyManager.NETWORK_TYPE_HSPA:
	// bearerInfo = "HSPA";
	// break;
	// case TelephonyManager.NETWORK_TYPE_HSPAP:
	// bearerInfo = "HSPA+";
	// break;
	// case TelephonyManager.NETWORK_TYPE_HSUPA:
	// bearerInfo = "HSUPA";
	// break;
	// case TelephonyManager.NETWORK_TYPE_IDEN:
	// bearerInfo = "iDen";
	// break;
	// case TelephonyManager.NETWORK_TYPE_LTE:
	// bearerInfo = "LTE";
	// break;
	// case TelephonyManager.NETWORK_TYPE_UMTS:
	// bearerInfo = "UMTS";
	// break;
	// case TelephonyManager.NETWORK_TYPE_UNKNOWN:
	// bearerInfo = "NA";
	// break;
	// }
	// return bearerInfo;
	// }

	public String getNetworktype() {
		String bearerInfo = "";

		TelephonyManager teleMan = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);

		if (teleMan.getSimState() == TelephonyManager.SIM_STATE_ABSENT)
			return "Unknown";

		int networkType = teleMan.getNetworkType();
		switch (networkType) {
		case TelephonyManager.NETWORK_TYPE_1xRTT:
			bearerInfo = "1xRTT";
			break;
		case TelephonyManager.NETWORK_TYPE_CDMA:
			bearerInfo = "CDMA";
			break;
		case TelephonyManager.NETWORK_TYPE_EDGE:
			bearerInfo = "EDGE";
			break;
		case TelephonyManager.NETWORK_TYPE_EHRPD:
			bearerInfo = "eHRPD";
			break;
		case TelephonyManager.NETWORK_TYPE_EVDO_0:
			bearerInfo = "EVDO rev. 0";
			break;
		case TelephonyManager.NETWORK_TYPE_EVDO_A:
			bearerInfo = "EVDO rev. A";
			break;
		case TelephonyManager.NETWORK_TYPE_EVDO_B:
			bearerInfo = "EVDO rev. B";
			break;
		case TelephonyManager.NETWORK_TYPE_GPRS:
			bearerInfo = "GPRS";
			break;
		case TelephonyManager.NETWORK_TYPE_HSDPA:
			bearerInfo = "HSDPA";
			break;
		case TelephonyManager.NETWORK_TYPE_HSPA:
			bearerInfo = "HSPA";
			break;
		case TelephonyManager.NETWORK_TYPE_HSPAP:
			bearerInfo = "HSPA+";
			break;
		case TelephonyManager.NETWORK_TYPE_HSUPA:
			bearerInfo = "HSUPA";
			break;
		case TelephonyManager.NETWORK_TYPE_IDEN:
			bearerInfo = "iDen";
			break;
		case TelephonyManager.NETWORK_TYPE_LTE:
			bearerInfo = "LTE";
			break;
		case TelephonyManager.NETWORK_TYPE_UMTS:
			bearerInfo = "UMTS";
			break;
		case TelephonyManager.NETWORK_TYPE_UNKNOWN:
			bearerInfo = "Unknown";
			break;

		}
		// }
		// }
		return bearerInfo;
	}

	private boolean isWifiNetwork(Context context) {
		ConnectivityManager connectivityManager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
				.isConnected()) {
			return true;
		}
		return false;
	}

	public String getTotalRAM() {
		return String.valueOf(MemoryInformationUtil.getTotalRam()) + " MB";
	}

	public String getTotalStorageCapacity() {
		return com.kochartech.MyLibs.InternalMemory
				.getTotalStorageCapacity(context) + " GB";
	}

	public String getIMEI() {
		return telephonyManager.getDeviceId().trim();
	}

	public String getIMSI() {
		String IMSI = telephonyManager.getSubscriberId();
		if (IMSI == null)
			IMSI = "NA";
		return IMSI;
	}

	public String getBatteryLevel() {
		Intent batteryIntent = context.registerReceiver(null, new IntentFilter(
				Intent.ACTION_BATTERY_CHANGED));
		int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
		return String.valueOf(level) + "%";
	}

	public int getDeviceBrightness() {
		return Settings.System.getInt(context.getContentResolver(),
				android.provider.Settings.System.SCREEN_BRIGHTNESS, -1);
	}

	public String getCellId() {
		String responseCellId = "NA";
		try {
			final TelephonyManager telephony = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
			if (telephony.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) {
				final GsmCellLocation location = (GsmCellLocation) telephony
						.getCellLocation();
				if (location != null) {
					int cellId = location.getCid();
					if (cellId != -1)
						responseCellId = String.valueOf(cellId);
				}

			} else {

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responseCellId;
	}
}
