package com.kochartech.gizmodoctor.HelperClass;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {

	// public static String getBatteryTemperature(Context context) {
	//
	//
	// KTBatteryInfo ktInformation = KTBatteryInfo.getInstance();
	// ktInformation.calculate(context);
	// float currentTemp = ktInformation.getTemperature();
	//
	// AppSettingsPreference appSetting = new AppSettingsPreference(context);
	// int tempUnits = appSetting.getTemperatureUnitToShow();
	//
	// if(KTEnum.TEMPERATURE_UNIT.CELSIUS.getValue() == tempUnits)
	// return currentTemp+" "+CELCIUS_UNICODE;
	// else
	// return currentTemp+" "+FARENHEIT_UNICODE;
	// }

	// public static String unitsAsName(int unit) {
	// return "";
	//
	// }
	public static String tempWithUnits(float temperatureInCelcius, int unit) {
		if (unit == KTEnum.TEMPERATURE_UNIT.CELSIUS.getValue()) // Celsius
			return temperatureInCelcius + " " + CELCIUS_UNICODE;
		else
			// Fahrenheit
			return convertCelsiusToFahrenheit(temperatureInCelcius) + " "
					+ FARENHEIT_UNICODE;
	}
	
	public static String tempWithUnits(int temperatureInCelcius, int unit) {
		if (unit == KTEnum.TEMPERATURE_UNIT.CELSIUS.getValue()) // Celsius
			return temperatureInCelcius + " " + CELCIUS_UNICODE;
		else
			// Fahrenheit
			return convertCelsiusToFahrenheit(temperatureInCelcius) + " "
					+ FARENHEIT_UNICODE;
	}
	

	// Converts to Celsius
	public static float convertFahrenheitToCelsius(float fahrenheit) {
		return ((fahrenheit - 32) * 5 / 9);
	}

	// Converts to Fahrenheit
	public static float convertCelsiusToFahrenheit(float celsius) {
		return ((celsius * 9) / 5) + 32;
	}

	public static String getCurrentDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return (String) sdf.format(new Date(System.currentTimeMillis()));

	}

	public final static String CELCIUS_UNICODE = "\u2103";
	public final static String FARENHEIT_UNICODE = "\u2109";
}
