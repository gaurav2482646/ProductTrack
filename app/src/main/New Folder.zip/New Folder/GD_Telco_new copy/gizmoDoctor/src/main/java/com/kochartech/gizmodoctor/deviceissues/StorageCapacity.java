package com.kochartech.gizmodoctor.deviceissues;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;

import com.kochartech.devicemax.Activities.LogWrite;

import android.content.Context;
import android.os.Environment;
import android.os.StatFs;

@SuppressWarnings("deprecation")
public class StorageCapacity {
	private String TAG = StorageCapacity.class.getSimpleName();

	public static final String SD_CARD = "sdCard";
	public static final String EXTERNAL_SD_CARD = "externalSdCard";

	// private Context context;

	public StorageCapacity(Context context) {
		// this.context = context;
	}

	public long getAvailableCapacity(String path) {
		StatFs stat = new StatFs(path);
		long blockSize = (long) stat.getBlockSize();
		LogWrite.i(TAG, "blockSize : " + blockSize);
		long availableBlocks = (long) stat.getAvailableBlocks();
		LogWrite.i(TAG, "availableBlocks : " + availableBlocks);
		return (long) (availableBlocks * blockSize);
	}

	public long getTotalCapacity(String path) {
		StatFs stat = new StatFs(path);
		long blockSize = (long) stat.getBlockSize();
		LogWrite.i(TAG, "blockSize : " + blockSize);
		long totalBlocks = (long) stat.getBlockCount();
		LogWrite.i(TAG, "totalBlocks : " + totalBlocks);
		return (long) totalBlocks * blockSize;
	}

	/**
	 * This method returns the list of removable storage and sdcard paths. I
	 * havnot. Assume 0th index will be removable sdcard path if size is e no
	 * USB OTG so can not test it. Is anybody can test it, please let me know if
	 * working or greater than 0.
	 * 
	 * @return the list of removable storage paths.
	 */
	public HashSet<String> getExternalPaths() {
		final HashSet<String> out = new HashSet<String>();
		String reg = "(?i).*vold.*(vfat|ntfs|exfat|fat32|ext3|ext4).*rw.*";
		String s = "";
		try {
			final Process process = new ProcessBuilder().command("mount")
					.redirectErrorStream(true).start();
			process.waitFor();
			final InputStream is = process.getInputStream();
			final byte[] buffer = new byte[1024];
			while (is.read(buffer) != -1) {
				s = s + new String(buffer);
			}
			is.close();
		} catch (final Exception e) {
			e.printStackTrace();
		}

		// parse output
		final String[] lines = s.split("\n");
		for (String line : lines) {
			if (!line.toLowerCase(Locale.US).contains("asec")) {
				if (line.matches(reg)) {
					String[] parts = line.split(" ");
					for (String part : parts) {
						if (part.startsWith("/")) {
							if (!part.toLowerCase(Locale.US).contains("vold")) {
								out.add(part.replace("/media_rw", "").replace(
										"mnt", "storage"));
							}
						}
					}
				}
			}
		}
		// Phone's external storage path (Not removal SDCard path)
		String phoneExternalPath = Environment.getExternalStorageDirectory()
				.getPath();

		// Remove it if already exist to filter all the paths of external
		// removable storage devices
		// like removable sdcard, USB OTG etc..
		// When I tested it in ICE Tab(4.4.2), Swipe Tab(4.0.1) with removable
		// sdcard, this method includes
		// phone's external storage path, but when i test it in Moto X Play
		// (6.0) with removable sdcard,
		// this method does not include phone's external storage path. So I am
		// going to remvoe the phone's
		// external storage path to make behavior consistent in all the phone.
		// Ans we already know and it easy
		// to find out the phone's external storage path.
		out.remove(phoneExternalPath);

		return out;
	}

	public String[] getDirectories() {
		LogWrite.d(TAG, "getStorageDirectories");
		File tempFile;
		String[] directories = null;
		String[] splits;
		ArrayList<String> arrayList = new ArrayList<String>();
		BufferedReader bufferedReader = null;
		String lineRead;

		try {
			arrayList.clear(); // redundant, but what the hey
			bufferedReader = new BufferedReader(new FileReader("/proc/mounts"));

			while ((lineRead = bufferedReader.readLine()) != null) {
				LogWrite.d(TAG, "lineRead: " + lineRead);
				splits = lineRead.split(" ");

				// System external storage
				if (splits[1].equals(Environment.getExternalStorageDirectory()
						.getPath())) {
					arrayList.add(splits[1]);
					LogWrite.d(TAG, "gesd split 1: " + splits[1]);
					continue;
				}

				// skip if not external storage device
				if (!splits[0].contains("/dev/block/")) {
					continue;
				}

				// skip if mtdblock device

				if (splits[0].contains("/dev/block/mtdblock")) {
					continue;
				}

				// skip if not in /mnt node

				if (!splits[1].contains("/mnt")) {
					continue;
				}

				// skip these names

				if (splits[1].contains("/secure")) {
					continue;
				}

				if (splits[1].contains("/mnt/asec")) {
					continue;
				}

				// Eliminate if not a directory or fully accessible
				tempFile = new File(splits[1]);
				if (!tempFile.exists()) {
					continue;
				}
				if (!tempFile.isDirectory()) {
					continue;
				}
				if (!tempFile.canRead()) {
					continue;
				}
				if (!tempFile.canWrite()) {
					continue;
				}

				// Met all the criteria, assume sdcard
				arrayList.add(splits[1]);
			}

		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException e) {
				}
			}
		}

		// Send list back to caller

		if (arrayList.size() == 0) {
			try {
				arrayList.add(getExtraPath1());
			} catch (Exception e) {
				arrayList.add("");
				e.printStackTrace();
			}
		}

		if (arrayList.size() == 0) {
			arrayList.add("");
		}
		directories = new String[arrayList.size()];
		for (int i = 0; i < arrayList.size(); i++) {
			directories[i] = arrayList.get(i);
		}
		return directories;
	}

	private static String getExtraPath1() {
		Map<String, File> externalLocations = getAllStorageLocations();
		File sdCard = externalLocations.get(SD_CARD);
		return sdCard.getPath();
	}

	/**
	 * @return A map of all storage locations available
	 */
	@SuppressWarnings("resource")
	public static Map<String, File> getAllStorageLocations() {
		Map<String, File> map = new HashMap<String, File>(10);

		List<String> mMounts = new ArrayList<String>(10);
		List<String> mVold = new ArrayList<String>(10);
		mMounts.add("/mnt/sdcard");
		mVold.add("/mnt/sdcard");

		try {
			File mountFile = new File("/proc/mounts");
			if (mountFile.exists()) {

				Scanner scanner = new Scanner(mountFile);
				while (scanner.hasNext()) {
					String line = scanner.nextLine();
					if (line.startsWith("/dev/block/vold/")) {
						String[] lineElements = line.split(" ");
						String element = lineElements[1];

						// don't add the default mount path
						// it's already in the list.
						if (!element.equals("/mnt/sdcard"))
							mMounts.add(element);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			File voldFile = new File("/system/etc/vold.fstab");
			if (voldFile.exists()) {
				Scanner scanner = new Scanner(voldFile);
				while (scanner.hasNext()) {
					String line = scanner.nextLine();
					if (line.startsWith("dev_mount")) {
						String[] lineElements = line.split(" ");
						String element = lineElements[2];

						if (element.contains(":"))
							element = element
									.substring(0, element.indexOf(":"));
						if (!element.equals("/mnt/sdcard"))
							mVold.add(element);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int i = 0; i < mMounts.size(); i++) {
			String mount = mMounts.get(i);
			if (!mVold.contains(mount))
				mMounts.remove(i--);
		}
		mVold.clear();

		List<String> mountHash = new ArrayList<String>(10);

		for (String mount : mMounts) {
			File root = new File(mount);
			if (root.exists() && root.isDirectory() && root.canWrite()) {
				File[] list = root.listFiles();
				String hash = "[";
				if (list != null) {
					for (File f : list) {
						hash += f.getName().hashCode() + ":" + f.length()
								+ ", ";
					}
				}
				hash += "]";
				if (!mountHash.contains(hash)) {
					String key = SD_CARD + "_" + map.size();
					if (map.size() == 0) {
						key = SD_CARD;
					} else if (map.size() == 1) {
						key = EXTERNAL_SD_CARD;
					}
					mountHash.add(hash);
					map.put(key, root);
				}
			}
		}

		mMounts.clear();

		if (map.isEmpty()) {
			map.put(SD_CARD, Environment.getExternalStorageDirectory());
		}
		return map;
	}

}
