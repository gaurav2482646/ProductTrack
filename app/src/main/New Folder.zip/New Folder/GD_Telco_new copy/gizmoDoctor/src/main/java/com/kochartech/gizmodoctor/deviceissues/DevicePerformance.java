//package com.kochartech.gizmodoctor.deviceissues;
//
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//
//import android.content.Context;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//import com.kochartech.gizmodoctor.HelperClass.NotificationHelper;
//import com.kochartech.library.Battery.KTBatteryInfo;
//import com.kochartech.library.CPU.KTApplicationInfo;
//import com.kochartech.library.CPU.KTUsageCPU;
//import com.kochartech.library.Memory.KTUsageRAM;
//
//public class DevicePerformance {
//	private String TAG = DevicePerformance.class.getSimpleName();
//	private Context context;
//
//	private CpuTemp cpuTemp;
//	private KTUsageCPU usageCpu;
//	private KTUsageRAM usageRam;
//	private KTBatteryInfo batteryInfo;
//	private StorageCapacity storageCapacity;
//
//	private NotificationHelper notificationHelper;
//
//	public DevicePerformance(Context context) {
//		this.context = context;
//		cpuTemp = new CpuTemp(context);
//		usageCpu = new KTUsageCPU(context);
//		usageRam = new KTUsageRAM(context);
//		batteryInfo = KTBatteryInfo.getInstance();
//		storageCapacity = new StorageCapacity(context);
//		notificationHelper = NotificationHelper.getInstance(context);
//	}
//
//	public void check() {
//		boolean isRamAboveThresholdFlag = false;
//		boolean isStorageAboveThresholdFlag = false;
//		batteryInfo.calculate(context);
//		usageCpu.refresh(25);
//		int batteryTemp = (int) batteryInfo.getTemperature();
//		LogWrite.i(TAG, "Battery Temp : " + batteryTemp);
//
//		int cpuTemp = getCpuTemp();
//		LogWrite.i(TAG, "CPU Temp : " + cpuTemp);
//
//		int cpuCurrentUsage = usageCpu.getTotalCPUUsage();
//		LogWrite.i(TAG, "CPU Usage : " + cpuCurrentUsage);
//
//		int ramCurrentUsage = usageRam.getMeoryInfo().getUsedInPercentage();
//		LogWrite.i(TAG, "RAM Usage : " + ramCurrentUsage);
//		if (ramCurrentUsage >= 85) {
//			isRamAboveThresholdFlag = true;
//		}
//
//		String[] dirs = storageCapacity.getDirectories();
//		ArrayList<String> directories = new ArrayList<String>();
//		for (String directory : dirs) {
//			if (!directory.contains("."))
//				directories.add(directory);
//		}
//		String externalStorage = "";
//		String internalStorage = "";
//		if (directories.size() >= 2) {
//			internalStorage = directories.get(0).toString();
//			externalStorage = directories.get(1).toString();
//		} else if (directories.size() < 2) {
//			internalStorage = directories.get(0).toString();
//			externalStorage = null;
//		}
//		if (externalStorage == null) {
//			HashSet<String> hashset = storageCapacity.getExternalPaths();
//			for (String string : hashset) {
//				// LogWrite.e(TAG, "External Path : " + string);
//				externalStorage = string;
//			}
//		}
//		if (!internalStorage.equals("")) {
//			// LogWrite.e(TAG, "Internal Storage : " + internalStorage);
//			long availableCapacity = storageCapacity
//					.getAvailableCapacity(internalStorage);
//			// LogWrite.e(TAG, "availableCapacity : " + availableCapacity);
//			long totalCapacity = storageCapacity
//					.getTotalCapacity(internalStorage);
//			// LogWrite.e(TAG, "totalCapacity : " + totalCapacity);
//			int usedInternalStorage = (int) (((float) (totalCapacity - availableCapacity) / totalCapacity) * 100);
//			LogWrite.i(TAG, "InternalStorageUsage : " + usedInternalStorage);
//			if (usedInternalStorage > 75) {
//				isStorageAboveThresholdFlag = true;
//			}
//		}
//		if (externalStorage != null) {
//			// LogWrite.e(TAG, "External Storage : " + externalStorage);
//			long availableCapacity = storageCapacity
//					.getAvailableCapacity(externalStorage);
//			// LogWrite.e(TAG, "availableCapacity : " + availableCapacity);
//			long totalCapacity = storageCapacity
//					.getTotalCapacity(externalStorage);
//			// LogWrite.e(TAG, "totalCapacity : " + totalCapacity);
//			int usedExternalStorage = (int) (((float) (totalCapacity - availableCapacity) / totalCapacity) * 100);
//			LogWrite.i(TAG, "ExternalStorageUsage : " + usedExternalStorage);
//		}
//
//		if (batteryTemp >= 40) {
//			LogWrite.e(TAG, "Device is getting hot!");
//		}
//		if (cpuTemp >= 50) {
//			LogWrite.e(TAG, "CPU is overheating!");
//		}
//
//		if (isRamAboveThresholdFlag && isStorageAboveThresholdFlag)
//			LogWrite.e(TAG, "Device is slow or hanging!");
//
//		List<KTApplicationInfo> cpuList = usageCpu.getPerAppUsage(5);
//		for (KTApplicationInfo ktApplicationInfo : cpuList) {
//			String[] arrayString = ktApplicationInfo.getUsage().split("%");
//			if (Integer.parseInt(arrayString[0]) > 20) {
//				LogWrite.e(TAG, "App Name : " + ktApplicationInfo.getAppName());
//				LogWrite.e(TAG,
//						"Process Name : " + ktApplicationInfo.getProcessName());
//				LogWrite.e(TAG, "Cpu Usage : " + ktApplicationInfo.getUsage());
//			}
//		}
//
//	}
//
//	private int getCpuTemp() {
//		int temp = (int) cpuTemp.getCpuTemp();
//		String str = "" + temp;
//		String first2char = str.substring(0, 2);
//		int currentTemp = Integer.parseInt(first2char);
//		return currentTemp;
//	}
//}