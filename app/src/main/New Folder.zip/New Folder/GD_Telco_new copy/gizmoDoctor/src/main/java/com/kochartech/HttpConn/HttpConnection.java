//package com.kochartech.HttpConn;
//
//import android.app.Activity;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.Toast;
//
//public abstract class HttpConnection extends Activity {
//	
//	
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//		
//		IntentFilter filter = new IntentFilter(HttpAsync.BROADCAST_ACTION);
//		if(receiver!= null)
//			registerReceiver(receiver, filter);
//	}
//	
//	@Override
//	protected void onDestroy() {
//		// TODO Auto-generated method stub
//		super.onDestroy();
//		
//		if(receiver!= null)
//		 unregisterReceiver(receiver);		
//	}
//	
//	private BroadcastReceiver receiver = new BroadcastReceiver() {		
//		@Override
//		public void onReceive(Context context, Intent intent) {
////			String serverMessage = (String) intent.getExtras().get("serverResponse");
//			
//			handleServerResponse(intent);
//		}
//	};
//	
//	public abstract void  handleServerResponse(Intent intent);
//	
//}
