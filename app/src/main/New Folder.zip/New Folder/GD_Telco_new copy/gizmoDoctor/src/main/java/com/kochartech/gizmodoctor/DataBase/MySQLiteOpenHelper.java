package com.kochartech.gizmodoctor.DataBase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.kochartech.devicemax.Activities.LogWrite;

public class MySQLiteOpenHelper extends SQLiteOpenHelper {

	/**
	 * Variables
	 */
	private static String tag = MySQLiteOpenHelper.class.getSimpleName();
	private Context context;
	private static final String DATABASE_NAME = "gizmodoctor";
	private static final int DATABASE_VERSION = 37;

	/**
	 * Settings Table
	 */
	public static final String SettingToMonitor_TableName = "setting_to_monitor";
	public static final String SettingToMonitor_Columnid = "_id";
	public static final String SettingToMonitor_ColumnSettingName = "setting_name";
	public static final String SettingToMonitor_ColumnIsToMonitor = "is_to_monitor";
	public static final String SettingToMonitor_ColumnLastState = "last_onoff_state";

	public static final String CREATE_TABLE_SettingToMonitor = "CREATE TABLE "
			+ SettingToMonitor_TableName + " (" + SettingToMonitor_Columnid
			+ " INTEGER PRIMARY KEY AUTOINCREMENT,"
			+ SettingToMonitor_ColumnSettingName + " TEXT,"
			+ SettingToMonitor_ColumnIsToMonitor + " INTEGER,"
			+ SettingToMonitor_ColumnLastState + " INTEGER " + ")";

	/**
	 * Settings Background Monitoring Data
	 */
	public static final String Data_SettingsToMonitring_TableName = "date_setting_to_monitor";
	public static final String Data_SettingsToMonitring_ColumnSettingName = "setting_name";
	public static final String Data_SettingsToMonitring_ColumnoOnTime = "on_time";
	public static final String Data_SettingsToMonitring_ColumnOffTime = "off_time";
	public static final String Data_SettingsToMonitring_ColumnIsToUpdate = "istoupdate";

	public static final String CREATE_TABLE_Data_SettingsToMonitring = "CREATE TABLE "
			+ Data_SettingsToMonitring_TableName
			+ "("
			+ Data_SettingsToMonitring_ColumnSettingName
			+ " TEXT,"
			+ Data_SettingsToMonitring_ColumnoOnTime
			+ " INTEGER, "
			+ Data_SettingsToMonitring_ColumnOffTime
			+ " INTEGER, "
			+ Data_SettingsToMonitring_ColumnIsToUpdate + " INTEGER " + ")";

	/**
	 * Table BatteryDiSChargeRate
	 */
	public static final String DischargeRate_TableName = "battery_discharge_rate";
	public static final String DischargeRate_ColumnID = "_id";
	public static final String DischargeRate_ColumnDecreaseLevel = "level";
	public static final String DischargeRate_ColumnTimeInterval = "time";

	public static final String CREATE_TABLE_DischargeRate = "CREATE TABLE "
			+ DischargeRate_TableName + "(" + DischargeRate_ColumnID
			+ " INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ DischargeRate_ColumnDecreaseLevel + " INTEGER, "
			+ DischargeRate_ColumnTimeInterval + " INTEGER " + ")";

	/**
	 * Table Apps
	 */
	public static final String APPS_TABLE = "apps";
	public static final String APPS_ColumnID = "_id";
	public static final String APPS_ColumnName = "name";
	public static final String APPS_ColumnPkgName = "pkg";

	public static final String CREATE_TABLE_APPS = "CREATE TABLE " + APPS_TABLE
			+ "(" + APPS_ColumnID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ APPS_ColumnName + " TEXT, " + APPS_ColumnPkgName + " TEXT" + ")";

	/**
	 * Table CPU Usage
	 */
	public static final String CPUUSAGE_TABLE = "cpuusage";
	public static final String CPUUSAGE_ColumnID = "_id";
	public static final String CPUUSAGE_ColumnUsage = "usage";
	public static final String CPUUSAGE_ColumnTime = "time";

	public static final String CREATE_TABLE_CPUUSAGE = "CREATE TABLE "
			+ CPUUSAGE_TABLE + "(" + CPUUSAGE_ColumnID + " INTEGER, "
			+ CPUUSAGE_ColumnUsage + " INTEGER, " + CPUUSAGE_ColumnTime
			+ " INTEGER" + ")";

	/**
	 * Table RAM Usage
	 */
	public static final String RAMUSAGE_TABLE = "ramusage";
	public static final String RAMUSAGE_ColumnID = "_id";
	public static final String RAMUSAGE_ColumnUsage = "usage";
	public static final String RAMUSAGE_ColumnTime = "time";

	public static final String CREATE_TABLE_RAMUSAGE = "CREATE TABLE "
			+ RAMUSAGE_TABLE + "(" + RAMUSAGE_ColumnID + " INTEGER, "
			+ RAMUSAGE_ColumnUsage + " INTEGER, " + RAMUSAGE_ColumnTime
			+ " INTEGER" + ")";

	/**
	 * Table Battery Discharge Usage
	 */
	public static final String BATTERY_TABLE = "batteryusage";
	public static final String BATTERY_ColumnID = "_id";
	public static final String BATTERY_ColumnUsage = "usage";
	public static final String BATTERY_ColumnTime = "time";

	public static final String CREATE_TABLE_BATTERY = "CREATE TABLE "
			+ BATTERY_TABLE + "(" + BATTERY_ColumnID + " INTEGER, "
			+ BATTERY_ColumnUsage + " TEXT, " + BATTERY_ColumnTime + " INTEGER"
			+ ")";
	/**
	 * Table for Monitoring
	 */
	public static final String MONITOR_TABLE = "monitor";
	public static final String MONITOR_RECORD_ID = "monitor_record_id";
	public static final String MONITOR_APPNAME = "monitor_app_name";
	public static final String MONITOR_PROCESSNAME = "monitor_process_name";
	public static final String MONITOR_CPUUSAGE = "monitor_cpu_usage";
	public static final String MONITOR_RAMUSAGE = "monitor_ram_usage";
	public static final String MONITOR_DISCHARGE_RATE = "monitor_discharge_rate";
	public static final String MONITOR_APP_TYPE = "monitor_app_type";
	public static final String MONITOR_LAST_TIME = "monitor_last_update_time";
	public static final String MONITOR_BATTERY_TEMP = "monitor_battery_temperature";
	public static final String MONITOR_BATTERY_LEVEL = "monitor_battery_level";
	public static final String MONITOR_BATTERY_STATE = "monitor_battery_state";
	public static final String MONITOR_DEVICE_HEALTH = "monitor_device_health";
	public static final String MONITOR_WIFI = "monitor_wifi_time";
	public static final String MONITOR_BLUETOOTH = "monitor_bluetooth_time";
	public static final String MONITOR_GPS = "monitor_gps_time";
	public static final String MONITOR_HOTSPOT = "monitor_hotspot_time";
	public static final String MONITOR_TOTAL_CPU = "monitor_total_cpu";
	public static final String MONITOR_TOTAL_RAM = "monitor_total_ram";
	public static final String MONITOR_TOTAL_DISCHARGE = "monitor_total_discharge_rate";
	public static final String MONITOR_SIGNAL_STRENGTH = "monitor_signal_strength";
	public static final String MONITOR_BEARER_TYPE = "monitor_bearer_type";
	public static final String MONITOR_TIME_STAMP = "monitor_time_stamp";

	public static final String CREATE_TABLE_MONITOR = "CREATE TABLE "
			+ MONITOR_TABLE + "(" + MONITOR_RECORD_ID + " INTEGER, "
			+ MONITOR_APPNAME + " TEXT, " + MONITOR_PROCESSNAME + " TEXT, "
			+ MONITOR_CPUUSAGE + " TEXT, " + MONITOR_RAMUSAGE + " TEXT, "
			+ MONITOR_DISCHARGE_RATE + " TEXT, " + MONITOR_BATTERY_TEMP
			+ " TEXT, " + MONITOR_BATTERY_LEVEL + " TEXT, "
			+ MONITOR_BATTERY_STATE + " TEXT, " + MONITOR_DEVICE_HEALTH
			+ " TEXT, " + MONITOR_WIFI + " TEXT, " + MONITOR_BLUETOOTH
			+ " TEXT, " + MONITOR_GPS + " TEXT, " + MONITOR_HOTSPOT + " TEXT, "
			+ MONITOR_APP_TYPE + " TEXT, " + MONITOR_LAST_TIME + " TEXT, "
			+ MONITOR_TOTAL_CPU + " TEXT, " + MONITOR_TOTAL_RAM + " TEXT, "
			+ MONITOR_TOTAL_DISCHARGE + " TEXT, " + MONITOR_SIGNAL_STRENGTH
			+ " TEXT, " + MONITOR_BEARER_TYPE + " TEXT, " + MONITOR_TIME_STAMP
			+ " TEXT" + ")"; // " TIMESTAMP DEFAULT CURRENT_TIMESTAMP"

	public MySQLiteOpenHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		this.context = context;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {

		LogWrite.d(tag, "onCreate: ");
		db.execSQL(CREATE_TABLE_SettingToMonitor);
		db.execSQL(CREATE_TABLE_Data_SettingsToMonitring);
		db.execSQL(CREATE_TABLE_DischargeRate);
		db.execSQL(CREATE_TABLE_APPS);
		db.execSQL(CREATE_TABLE_CPUUSAGE);
		db.execSQL(CREATE_TABLE_RAMUSAGE);
		db.execSQL(CREATE_TABLE_BATTERY);
		db.execSQL(CREATE_TABLE_MONITOR);
		initializeTables(db);
		// new InitTableInBackground(context, db).execute("");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXISTS " + SettingToMonitor_TableName);
		db.execSQL("DROP TABLE IF EXISTS " + Data_SettingsToMonitring_TableName);
		db.execSQL("DROP TABLE IF EXISTS " + DischargeRate_TableName);
		db.execSQL("DROP TABLE IF EXISTS " + APPS_TABLE);
		db.execSQL("DROP TABLE IF EXISTS " + CPUUSAGE_TABLE);
		db.execSQL("DROP TABLE IF EXISTS " + RAMUSAGE_TABLE);
		db.execSQL("DROP TABLE IF EXISTS " + BATTERY_TABLE);
		db.execSQL("DROP TABLE IF EXISTS " + MONITOR_TABLE);

		onCreate(db);
	}

	/*
	 * Method initialize tables
	 */
	private void initializeTables(SQLiteDatabase sqliteDataBase) {

		DataSource_Settings dsSetting = DataSource_Settings
				.getInstance(context);
		DataSource_AppsInfo dsApps = DataSource_AppsInfo.getInstance(context);

		dsSetting.init(sqliteDataBase);
		dsApps.init(sqliteDataBase);

	}
	/*
	 * It initialize table with default values
	 */
	// class InitTableInBackground extends AsyncTask<String, String, String> {
	//
	// private SQLiteDatabase db;
	// private SettingToMonitor_DS settingToMonitor;
	// // private DBHelper_PerAppCPU cpuUsagePerAppDBHelper;
	// // private DBHelper_TotalCPU cpuUsageTotalDBHelper;
	// private DataSource_AppsInfo dsApps;
	//
	// public InitTableInBackground(Context context, SQLiteDatabase db) {
	//
	// settingToMonitor = SettingToMonitor_DS.getInstance(context);
	// dsApps = DataSource_AppsInfo.getInstance(context);
	// this.db = db;
	// }
	// @Override
	// protected String doInBackground(String... params) {
	//
	// LogWrite.d(tag, "Async ");
	// settingToMonitor.init(db);
	// dsApps.init(db);
	// return null;
	// }
	// }

}
