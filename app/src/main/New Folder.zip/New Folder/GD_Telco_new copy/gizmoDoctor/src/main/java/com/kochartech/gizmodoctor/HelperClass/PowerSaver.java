package com.kochartech.gizmodoctor.HelperClass;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;

import com.kochartech.MyLibs.MemoryCleaner;
import com.kochartech.MyLibs.MyBluetoothManager;
import com.kochartech.MyLibs.MyWifiManager;
import com.kochartech.gizmodoctor.Activity.ReduceBrightnessScreen;
import com.kochartech.gizmodoctor.POJO.PowerSavingSettingsDTO;
import com.kochartech.gizmodoctor.Preferences.MyEnum;
import com.kochartech.gizmodoctor.Preferences.MyPreference;
import com.kochartech.library.Device.KTDeviceInfo;

public class PowerSaver {

//	private String TAG = PowerSaver.class.getSimpleName();
	private Context context;
	private PowerSavingSettings powerSavingSetting;

	public PowerSaver(Context context) {
		this.context = context;
		powerSavingSetting = new PowerSavingSettings(context);
	}

	public void savePower(Integer crntLevel, boolean isScrrenOn) {

		SharedPreferences sharePreference = context.getSharedPreferences(MyPreference.PREFERENCE_NAME, MyPreference.PREFERENCE_MODE);
		isScrrenOn = sharePreference.getBoolean(MyEnum.PREFERENCES_KEYS.DEVICE_ONOFF.getValue(), false);
		
		if (crntLevel == null) {
			Intent batteryIntent = context.registerReceiver(null,
					new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
			crntLevel = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL,
					-1);
		}
		boolean isCompletePowerSavingProfileOn = powerSavingSetting.getToggleStateCompletePowerSaving();
		boolean isCompleteCustomSavingProfileOn = powerSavingSetting.getToggleStateCustomPowerSaving();

		int completePowerSavingProfileThreashold = powerSavingSetting.getBatteryLimitCompletePowerSaving();
		int customPowerSavingProfileThreashold = powerSavingSetting.getBatteryLimitCustomPowerSaving();
		if (isCompletePowerSavingProfileOn	&& crntLevel < completePowerSavingProfileThreashold) 
		{
			ArrayList<PowerSavingSettingsDTO> powerSettingDTOList = powerSavingSetting.getSettings();
			for (PowerSavingSettingsDTO powerSettingDTO : powerSettingDTOList) 
			{
				performAction(powerSettingDTO.getName(), isScrrenOn);
			}
		} 
		else if (isCompleteCustomSavingProfileOn && crntLevel < customPowerSavingProfileThreashold) 
		{
			ArrayList<PowerSavingSettingsDTO> powerSettingDTOList = powerSavingSetting.getSettings();
			for (PowerSavingSettingsDTO powerSettingDTO : powerSettingDTOList) 
			{
				if (powerSettingDTO.getState()) 
				{
					performAction(powerSettingDTO.getName(), isScrrenOn);
				}
			}
		}

	}

	public void performAction(String actionName, boolean isScreenOn) {

		if (actionName.equalsIgnoreCase(PowerSavingSettings.TURNOFF_WIFI)) {
			
			if (MyWifiManager.isWifiEnabled(context)) {
				if (!MyWifiManager.isWifiConnected(context) || !isScreenOn) {
					MyWifiManager.setWifiState(context, false);
				}
			}
		}
		else if (actionName.equalsIgnoreCase(PowerSavingSettings.TURNOFF_BT)) {
			
			MyBluetoothManager blueToothManager = new MyBluetoothManager();
			if (blueToothManager.isBluetoothEnable()) {
				blueToothManager.setBluetoothState(false);
			}
		} 
		else if (actionName.equalsIgnoreCase(PowerSavingSettings.TURNOFF_GPS)) {
			KTDeviceInfo ktDeviceInfo = new KTDeviceInfo(context);
			if (ktDeviceInfo.isGPSEnabled()) {
				ktDeviceInfo.setGPSEnabled(false);
			}
		}
		else if (actionName.equalsIgnoreCase(PowerSavingSettings.BRIGHTNESS)) {
					Intent intent = new Intent(context, ReduceBrightnessScreen.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					context.startActivity(intent);
		}
		else if (actionName.equalsIgnoreCase(PowerSavingSettings.SCREENTIME_OUT)) {
			KTDeviceInfo ktDeviceInfo = new KTDeviceInfo(context);
			try 
			{
				ktDeviceInfo.setScreenOffTimeout(0);
			}
			catch (Exception e) { }
		}
		else if (actionName.equalsIgnoreCase(PowerSavingSettings.TURNOFF_AUTO_SYNC)) {
			KTDeviceInfo ktDeviceInfo = new KTDeviceInfo(context);
			if (ktDeviceInfo.isAutoSyncEnabled())
				ktDeviceInfo.setAutoSyncEnabled(false);
		}
		else if (actionName.equalsIgnoreCase(PowerSavingSettings.KILL_BACKGROUNDAPPS)) {
			new MemoryCleaner(context).clean();
		}
	}

}
