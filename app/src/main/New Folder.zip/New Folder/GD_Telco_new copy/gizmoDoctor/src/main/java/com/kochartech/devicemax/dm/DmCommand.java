package com.kochartech.devicemax.dm;

import java.util.Hashtable;

import com.kochartech.devicemax.Activities.LogWrite;

public class DmCommand {
	/**
	 * This is the parent command DM Command
	 */
	public static Hashtable<String, String> hashTable = new Hashtable<String, String>();
	String dm = "DM";
	String uId = "UID";
	String mn = "MN";
	String cNo = "CN0";
	String kill = "q1";

	String strToParse;
	String dt = "DT";
	String key = "", value = "";
	int seqNo = 0, msgParts = 0;

	private String remainingMessage = "";

	public DmCommand() {
	}

	public void AccumulateMessage(String messagePart) {
		String[] arrayMessagepart = new String[100];
		if (messagePart.contains("of")) {
			String[] msgPart = messagePart.split("of");
			seqNo = Integer.parseInt(msgPart[0]);
			msgParts = Integer.parseInt(msgPart[1]);

		}

		if (seqNo == 1) {
			arrayMessagepart[seqNo] = messagePart.substring(0,
					messagePart.length() - 2);
			// remainingMessage=messagePart.substring(0,messagePart.length()-2
			// );
		} else {
			arrayMessagepart[seqNo] = messagePart.substring(62,
					messagePart.length() - 2);
		}

		for (int i = 0; i < 100; i++) {
			remainingMessage += arrayMessagepart[i];
		}

	}

	public void parseDtCommand(String strToParse) {
		/**
		 * Data part of command is received here
		 */

		// System.out.println("Entered into parse DT Command");
		// System.out.println("String received :  " + strToParse);
		String dataKey = "", dataValue = "";
		String mn = "MN";
		// String startSesssion = "STRTSESS";
		String cNo = "CNo";
		// String ht = "HT", nw = "NW", pr = "PR", em = "EM";

		// String dataString=strToParse.substring(i,
		// strToParse.lastIndexOf('>'));

		char[] dataCharArray = strToParse.toCharArray();

		int dataCharArrayLength = dataCharArray.length;

		for (int j = 0; j < dataCharArrayLength; j++) {
			if (dataCharArray[j] == ':') {
				if (dataKey.equals(mn)) {
					j++;
					while (dataCharArray[j] != ';') {
						dataValue += dataCharArray[j];
						j++;
					}
					hashTable.put(dataKey, dataValue);
					// System.out.println("Hashtable Contents"+
					// hashTable.toString());

					// System.out.println(dataKey + dataValue);
					dataKey = "";
					dataValue = "";
				}

				else if (dataKey.equals(cNo)) {

					j++;
					while (dataCharArray[j] != ';') {
						dataValue += dataCharArray[j];
						j++;
					}
					hashTable.put(dataKey, dataValue);
					// System.out.println(dataKey + dataValue);
					// hashTable.put(dataKey,dataValue);
					// System.out.println("Hashtable Contents"+
					// hashTable.toString());

					dataKey = "";
					dataValue = "";
					String commandinfo = strToParse.substring(j + 1,
							strToParse.length());
					new ParseCommands(commandinfo);
					System.out.println(hashTable.toString());
				}

			} else {
				dataKey += dataCharArray[j];
			}
		}

	}

	public Hashtable<String, String> parseCompleteMessage(String strToParse) {

		hashTable.clear();
		if (strToParse.contains("KOCHAR-DM")) {
			strToParse = strToParse.substring(10, strToParse.length());
		}
		// this.strToParse = strToParse1.substring(10, strToParse1.length());
		char[] charArray = strToParse.toCharArray();
		int arrayLength = charArray.length;

		for (int i = 0; i < arrayLength; i++) {
			if (charArray[i] == ':') {
				if (key.equals(dm)) {
					i++;
					while (charArray[i] != ';') {
						value += charArray[i];
						i++;
					}
					hashTable.put(key, value);
					// DM=value;
					// System.out.println(key + value);
					String seqPrst[] = value.split("of");
					seqNo = Integer.parseInt(seqPrst[0]);
					msgParts = Integer.parseInt(seqPrst[1]);
					hashTable.put("sequenceNo", seqNo + "");
					hashTable.put("totalMsgs", msgParts + "");
					key = "";
					value = "";
				} else if (key.equals(uId)) {
					i++;
					while (charArray[i] != ';') {
						value += charArray[i];
						i++;
					}
					// UID=value;
					hashTable.put(key, value);

					// System.out.println(key + value);
					key = "";
					value = "";
				} else if (key.equals(dt)) {
					// System.out.println( key + strToParse.substring(i+1,
					// strToParse.lastIndexOf('>')));
					// System.out.println( key + strToParse.substring(i,
					// strToParse.length()));
					// String dataString=strToParse.substring(i,
					// strToParse.length());

					// KOCHAR-DM
					// DM:1of1;UID:23245_187112;DT:<MN:9958112020;CNo:1;CMD-1:STRTSESS;CMDINF-1:<>;>;
					// MessageID:634989496124810034Content-Length:0

					String dataString = strToParse.substring(i + 2,
							strToParse.lastIndexOf('>'));
					// System.out.println(dataString);
					parseDtCommand(dataString);
					// parseDataCommand(dataString);

					// System.out.println("Data : " + strToParse.substring(i,
					// strToParse.length()));
				}
			} else {
				key += charArray[i];
			}
			// DT<MN9958112020;CNo1;CMD-1KILLAPP;CMDINF-1<KILLAPP-1<Q1ALL;>;>;>;

			if (i == arrayLength - 1) {
				LogWrite.i("Aman", "Key :----> " + key);
				if (key.contains("KILLAPP")) {
					if (key.contains("<")) {
						String[] keys = key.split("<");
						for (String keyQ1 : keys) {
							if (keyQ1.startsWith("Q1")) {
								String[] splitStrings = keyQ1.split(";>");
								String string = splitStrings[0];
								String newKey = string.substring(0, 2);
								String newvalue = string.substring(2);
								hashTable.put(newKey, newvalue);
							}
						}
					}
				} else if (key.contains("HWTEST")) {
					if (key.contains("<")) {
						String[] keys = key.split("<");
						for (String keyQ1 : keys) {
							if (keyQ1.startsWith("A1")) {
								String[] splitStrings = keyQ1.split(";>");
								String string = splitStrings[0];
								String newKey = string.substring(0, 2);
								String newvalue = string.substring(2);
								hashTable.put(newKey, newvalue);
							}
						}
					}
				}
			}

		}
		return hashTable;
	}

	void process(String command) {
		if (command.equals("STRTSESS")) {

		} else if (command.equals("CRTPRF")) {

		}
		if (command.equals("EDTPRF")) {

		}

	}

	// public static void main(String args[])
	// {
	//
	// // String
	// strToParse="DM:1of1;UID:1234_996;DT:<MN:32434;CNo:1;CMD-1:DELPRF;CMDINF-1:<PR-1:<A1:Mobile Office;>;>;";
	// String
	// strToParse="DM:1of1;UID:1123_876;DT:<MN:324784625234;CNo:1;CMD-1:STRTSESS;CMDINF-1:<STRTSESS>;>;";
	// //
	// strToParse="DM:1of1;UID:1234_996;DT:<MN:32434;CNo:1;CMD-1:EDTPRF;CMDINF-1:<PR-1:<A1:Mobile Office;C1:airtelgprs.com;K1:Y;>;>;";
	// //
	// strToParse="DM:1of1;UID:1234_996;DT:<MN:32434;CNo:1;CMD-1:CRTPRF;CMDINF-1:<PR-2:<A1:Mobile Office;B1:PACKET DATA;C1:airtelgprs.com;K1:Y;A2:Airtel Live!;B2:PACKET DATA;C2:airtelfun.com;D2:100.1.200.99;E2:8080;K2:N;>;>;>;";
	// //
	// strToParse="DM:1of1;UID:1234_996;DT:<MN:32434;CNo:1;CMD-1:DELPRF;CMDINF-1:<PR-1:<A1:Mobile Office;>;>;";
	// new DmCommand().parseCompleteMessage(strToParse);
	// }

}
// ********************************************************//**************************************************

// ***************************************************************************************************************

// //////////////

