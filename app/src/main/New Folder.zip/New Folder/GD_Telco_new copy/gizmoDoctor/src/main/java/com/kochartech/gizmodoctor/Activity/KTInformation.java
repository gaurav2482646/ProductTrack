package com.kochartech.gizmodoctor.Activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

import com.kochartech.devicemax.Activities.LogWrite;

public class KTInformation
{
	private KTInformation information = null;
	private float currentBatteryLevel;
	public KTInformation getInstance()
	{
		if(information == null)
			information = new KTInformation();
		return information;
	}
	
	public void register(Context context)
	{
		context.registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
	}
	
	public void unRegister(Context context)
	{
		context.unregisterReceiver(batteryReceiver);
		information = null;
	}
	
	BroadcastReceiver batteryReceiver = new BroadcastReceiver() 
	{	
		@Override
		public void onReceive(Context context, Intent intent) 
		{
			int level 					= intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
			LogWrite.d("BatteryActivity", "Battery level: " + level + "%");
			
			int scale	 				= intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
			LogWrite.d("BatteryActivity", "Battery Scale: " + scale);
			
			if (level != -1 && scale != -1)
				currentBatteryLevel 	= 100 * level / (float) scale;
			LogWrite.d("BatteryActivity", "Current Battery Level : " + currentBatteryLevel);
			
			// Are we charging / charged?
			int status 			= intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
			boolean isCharging  = status == BatteryManager.BATTERY_STATUS_CHARGING ||
								  status == BatteryManager.BATTERY_STATUS_FULL;
	         LogWrite.d("BatteryActivity", "Charging State : " + isCharging);
	         
	         // How are we charging?
	         int chargePlug 			= intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
	         boolean usbCharge 			= chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
	         boolean acCharge 			= chargePlug == BatteryManager.BATTERY_PLUGGED_AC;
	         if(usbCharge)
	        	 LogWrite.d("BatteryActivity", "USB Charging");
	         if(acCharge)
	        	 LogWrite.d("BatteryActivity", "AC Charging");
	         
	         String technology			= intent.getExtras().getString(BatteryManager.EXTRA_TECHNOLOGY);
	         LogWrite.d("BatteryActivity", "Technology : " + technology);
	         
	         int temperature			= intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
	         LogWrite.d("BatteryActivity", "Temperature : " + ((float) (temperature/10)) + " C");
	        
	         int voltage				= intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
	         LogWrite.d("BatteryActivity", "Voltage : " + voltage);
	         
	         boolean  present			= intent.getExtras().getBoolean(BatteryManager.EXTRA_PRESENT);
	         LogWrite.d("BatteryActivity", "Battery Present : " + present);
	         
	         int  health				= intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
	         LogWrite.d("BatteryActivity", "Battery Health : " + health);
	         
		}
	};
}
