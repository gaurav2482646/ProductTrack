package com.kochartech.gizmodoctor.Activity;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.deviceissues.AccessibilityHelper;
import com.kochartech.gizmodoctor.deviceissues.ActionPerformPrefrence;
import com.kochartech.gizmodoctor.deviceissues.CleanAppAdapter;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager;
import com.kochartech.gizmodoctor.deviceissues.ProcessManager.Process;
import com.kochartech.gizmodoctor.deviceissues.RunningAppDTO;

@SuppressLint("InflateParams")
public class GUICleanActivity extends ActionBarActivity implements OnClickListener {
	private String TAG = GUICleanActivity.class.getSimpleName();
	private Context context;
	private Button cleanButton;
	private ListView appListView;
	private CleanAppAdapter adapter;
	private ArrayList<RunningAppDTO> arrayAppList;

	// private boolean isWorking = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_clean);
		getSupportActionBar().setTitle("GizmoDoctor");
		context = this;

		arrayAppList = new ArrayList<RunningAppDTO>();

		adapter = new CleanAppAdapter(getApplicationContext(),
				R.layout.clean_app_view, arrayAppList);

		cleanButton = (Button) findViewById(R.id.btClean);

		appListView = (ListView) findViewById(R.id.running_app_list);
		appListView.setAdapter(adapter);

		BackgroundAsyncTask asyncTask = new BackgroundAsyncTask(context);
		asyncTask.execute("");

		cleanButton.setOnClickListener(this);
	}

	@Override
	public void onClick(View view) {
		ArrayList<RunningAppDTO> newAppList = CleanAppAdapter.newAppList;
		CleanAppAsyncTask cleanAppAsyncTask = new CleanAppAsyncTask(context,
				newAppList);
		cleanAppAsyncTask.execute("");

		// ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
		// context);
		// try {
		// LogWrite.d(TAG, "------------------------------------1");
		// ArrayList<RunningAppDTO> newAppList = CleanAppAdapter.newAppList;
		// LogWrite.i(TAG, "NewAppListSize : " + newAppList.size());
		// for (RunningAppDTO runningAppDTO : newAppList) {
		// LogWrite.d(TAG, "------------------------------------For Loop");
		// if (runningAppDTO.isSelected()) {
		// actionPrefrence
		// .setActionToPerform(ActionPerformPrefrence.ACTION_FORCE_CLOSE);
		// LogWrite.i(TAG,
		// "APP Name : " + runningAppDTO.getPackageName());
		// performAction(getApplicationContext(),
		// runningAppDTO.getPackageName());
		// isWorking = true;
		// while (isWorking) {
		// LogWrite.d(TAG, "Is working flag : " + isWorking);
		// Thread.sleep(5000);
		// }
		// LogWrite.e(TAG, "Is working flag : " + isWorking);
		// } else {
		// LogWrite.e(TAG,
		// "APP Name : " + runningAppDTO.getPackageName());
		// }
		// }
		// LogWrite.d(TAG, "------------------------------------2");
		// } catch (ExceptionDTO e) {
		// LogWrite.e(TAG, "ActionPerformException : " + e.toString());
		// actionPrefrence
		// .setActionToPerform(ActionPerformPrefrence.ACTION_NO);
		// }
	}

	private class CleanAppAsyncTask extends AsyncTask<String, Object, String> {
		private Context context;
		private ArrayList<RunningAppDTO> newAppList;

		private final String PUBLISH_ENABLE_ACCESSIBILITY = "enable_accessibility";
		// private final String PUBLISH_MANAGE_SETTINGS = "manage_settings";
		private final String PUBLISH_REMOVE_VIEW = "remove_view";

		private final String PUBLISH_TEST_START = "test_start";
		private final String PUBLISH_TEST_FINISH = "test_finish";

		public CleanAppAsyncTask(Context context,
				ArrayList<RunningAppDTO> newAppList) {
			this.context = context;
			this.newAppList = newAppList;
		}

		@Override
		protected String doInBackground(String... params) {
			AccessibilityHelper helper = new AccessibilityHelper(context);

			if (helper.isAccessibilityEnabled()) {
				ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
						context);
				publishProgress(PUBLISH_TEST_START);
				for (RunningAppDTO runningAppDTO : newAppList) {
					if (runningAppDTO.isSelected()) {
						actionPrefrence
								.setActionToPerform(ActionPerformPrefrence.ACTION_FORCE_CLOSE);
						LogWrite.i(
								TAG,
								"PackageName : "
										+ runningAppDTO.getPackageName());
						// publishProgress(PUBLISH_MANAGE_SETTINGS + "::"
						// + runningAppDTO.getPackageName());
						publishProgress(runningAppDTO);
						sleep(3);

						publishProgress(PUBLISH_REMOVE_VIEW);
						// performAction(context,
						// runningAppDTO.getPackageName());
					} else {
						actionPrefrence
								.setActionToPerform(ActionPerformPrefrence.ACTION_NO);
						LogWrite.e(TAG,
								"APP Name : " + runningAppDTO.getPackageName());
					}
				}
				publishProgress(PUBLISH_TEST_FINISH);
			} else {
				publishProgress(PUBLISH_ENABLE_ACCESSIBILITY);
			}
			return "";
		}

		WindowManager windowManager = null;
		View overlayView = null;

		@Override
		protected void onProgressUpdate(Object... values) {

			if (values[0] instanceof RunningAppDTO) {
				RunningAppDTO runningAppDTO = (RunningAppDTO) values[0];

				ImageView imageView = (ImageView) overlayView
						.findViewById(R.id.app_icon);
				TextView messageView = (TextView) overlayView
						.findViewById(R.id.app_message);
				imageView.setImageDrawable(runningAppDTO.getIcon());
				messageView.setText("Stop " + runningAppDTO.getAppName()
						+ " from running");
				fadeOutAndHideImage(imageView);

				// ActivityOverlay.start(context);
				// if (actionPrefrence.getActionToPerform() ==
				// ActionPerformPrefrence.ACTION_GPS) {
				// Intent i = new Intent(
				// android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				// i.addCategory(Intent.CATEGORY_DEFAULT);
				// i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
				// startActivity(i);
				// } else {
				Intent i = new Intent(
						android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
				i.addCategory(Intent.CATEGORY_DEFAULT);
				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
						| Intent.FLAG_ACTIVITY_CLEAR_TASK
						| Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
				i.setData(Uri.parse("package:" + runningAppDTO.getPackageName()));
				context.startActivity(i);
			} else {
				LogWrite.e(TAG, "----------onProgressUpdate");
				LogWrite.e(TAG, "----------Value : " + values[0].toString());
				if (values[0].equals(PUBLISH_ENABLE_ACCESSIBILITY)) {
					Intent intent = new Intent(
							Settings.ACTION_ACCESSIBILITY_SETTINGS);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
							| Intent.FLAG_ACTIVITY_CLEAR_TASK);
					context.startActivity(intent);
					// isWorking = false;
					final ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
							context);
					actionPrefrence.clear();
				} else if (values[0].equals(PUBLISH_REMOVE_VIEW)) {

					// ActivityOverlay.stop();
				} else if (values[0].equals(PUBLISH_TEST_START)) {
					if (windowManager == null)
						windowManager = getWindowMnagerNew();
					if (overlayView == null)
						overlayView = getOverlayView();
					WindowManager.LayoutParams params = new WindowManager.LayoutParams(
							WindowManager.LayoutParams.MATCH_PARENT,
							WindowManager.LayoutParams.MATCH_PARENT,
							WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
							WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
									| WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
									| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
							PixelFormat.TRANSLUCENT);
					windowManager.addView(overlayView, params);
					LogWrite.e(TAG, "-------------------------------------A");
					overlayView.setKeepScreenOn(true);
				} else if (values[0].equals(PUBLISH_TEST_FINISH)) {
					windowManager.removeView(overlayView);
					windowManager = null;
					overlayView = null;
					final ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
							context);
					actionPrefrence
							.setActionToPerform(ActionPerformPrefrence.ACTION_NO);
					GUICleanActivity.this.finish();
					GUICleanActivityFinish.launch(context);
					overridePendingTransition(R.anim.fade_in, R.anim.fade_out);

				}
			}
			super.onProgressUpdate(values);
		}

		private void fadeOutAndHideImage(final ImageView img) {
			Animation fadeOut = new AlphaAnimation(1, 0);
			fadeOut.setInterpolator(new AccelerateInterpolator());
			fadeOut.setDuration(2000);

			fadeOut.setAnimationListener(new AnimationListener() {
				public void onAnimationEnd(Animation animation) {
					img.setVisibility(View.GONE);
				}

				public void onAnimationRepeat(Animation animation) {

				}

				public void onAnimationStart(Animation animation) {
				}
			});

			img.startAnimation(fadeOut);
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			// GUICleanActivity.this.finish();
		}

		private View getOverlayView() {
			LayoutInflater layoutInflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			final View overlayView = layoutInflater.inflate(R.layout.overlay,
					null);
			return overlayView;
		}

		private WindowManager getWindowMnagerNew() {
			return (WindowManager) context
					.getSystemService(Context.WINDOW_SERVICE);
		}

		private void sleep(long sec) {
			try {
				Thread.sleep(sec * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// private void performAction(final Context context,
	// final String packageName) {
	// AccessibilityHelper topApplication = new AccessibilityHelper(
	// context);
	// if (topApplication.isAccessibilityEnabled()) {
	// LogWrite.d(TAG, "Inside the start application");
	//
	// // Snackbar.make(view, "Replace with your own action",
	// // Snackbar.LENGTH_LONG)
	// // .setAction("Action", null).show();
	//
	// // LayoutInflater layoutInflater = (LayoutInflater) context
	// // .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	// // final WindowManager windowManager = (WindowManager) context
	// // .getSystemService(Context.WINDOW_SERVICE);
	// // final View overlayView = layoutInflater.inflate(
	// // R.layout.overlay, null);
	// //
	// // WindowManager.LayoutParams params = new
	// // WindowManager.LayoutParams(
	// // WindowManager.LayoutParams.MATCH_PARENT, // |
	// // // WindowManager.LayoutParams.FLAG_FULLSCREEN,
	// // WindowManager.LayoutParams.MATCH_PARENT,// |
	// // // WindowManager.LayoutParams.FLAG_FULLSCREEN,
	// // WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
	// // WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
	// // | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
	// // PixelFormat.TRANSLUCENT);
	//
	// final ActionPerformPrefrence actionPrefrence = new
	// ActionPerformPrefrence(
	// context);
	// if (actionPrefrence.getActionToPerform() ==
	// ActionPerformPrefrence.ACTION_GPS) {
	// Intent i = new Intent(
	// android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
	// i.addCategory(Intent.CATEGORY_DEFAULT);
	// i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
	// | Intent.FLAG_ACTIVITY_CLEAR_TASK
	// | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
	// context.startActivity(i);
	// } else {
	// String[] arrayString = {};
	// arrayString[0] = PUBLISH_MANAGE_SETTINGS;
	// arrayString[1] = packageName;
	// publishProgress(arrayString);
	// // windowManager.addView(overlayView, params);
	// // LogWrite.e(TAG,
	// // "-------------------------------------A");
	// // // if (actionPrefrence.getActionToPerform() ==
	// // // ActionPerformPrefrence.ACTION_GPS) {
	// // // Intent i = new Intent(
	// // //
	// // android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
	// // // i.addCategory(Intent.CATEGORY_DEFAULT);
	// // // i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
	// // // startActivity(i);
	// // // } else {
	// // Intent i = new Intent(
	// // android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
	// // i.addCategory(Intent.CATEGORY_DEFAULT);
	// // i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
	// // | Intent.FLAG_ACTIVITY_CLEAR_TASK
	// // | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
	// // i.setData(Uri.parse("package:" + packageName));
	// // context.startActivity(i);
	// // }
	// sleep(1);
	// }
	//
	// if (actionPrefrence.getActionToPerform() ==
	// ActionPerformPrefrence.ACTION_GPS) {
	// actionPrefrence.clear();
	// sleep(3);
	// } else {
	// publishProgress(PUBLISH_REMOVE_VIEW);
	// // windowManager.removeView(overlayView);
	// // Intent i = context.getPackageManager()
	// // .getLaunchIntentForPackage(
	// // context.getPackageName());
	// // i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	// // context.startActivity(i);
	// // actionPrefrence.clear();
	// sleep(5);
	// }
	//
	// // TopPackageService.showInstalledAppDetails(getApplicationContext(),
	// // "com.kochartech.gizmodoctor");
	// // topApplication.setPackageChangeListener(this);
	// } else {
	// LogWrite.d(TAG, "In else access");
	//
	// publishProgress(PUBLISH_ENABLE_ACCESSIBILITY);
	//
	// // Intent intent = new Intent(
	// // Settings.ACTION_ACCESSIBILITY_SETTINGS);
	// // intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
	// // | Intent.FLAG_ACTIVITY_CLEAR_TASK);
	// // context.startActivity(intent);
	// // // isWorking = false;
	// // final ActionPerformPrefrence actionPrefrence = new
	// // ActionPerformPrefrence(
	// // context);
	// // actionPrefrence.clear();
	// }
	// }
	//
	// }

	private class BackgroundAsyncTask extends AsyncTask<String, String, String> {
		private Context context;
		private List<Process> appList;

		public BackgroundAsyncTask(Context context) {
			this.context = context;
		}

		@Override
		protected String doInBackground(String... params) {
			arrayAppList = new ArrayList<RunningAppDTO>();
			appList = ProcessManager.getRunningApps();
			for (Process string : appList) {
				if (!isExist(string.getPackageName(), arrayAppList)) {
					if (!string.getPackageName().contains("com.kochar")) {
						String appName = getAppName(string.getPackageName());
						if (!appName.equals("")) {
							// LogWrite.d(TAG,
							// "ProcessName : " + string.getPackageName());
							// LogWrite.d(TAG, "AppName : " + appName);
							RunningAppDTO appDTO = new RunningAppDTO();
							appDTO.setPackageName(string.getPackageName());
							appDTO.setAppName(appName);
							appDTO.setIcon(getAppIcon(string.getPackageName()));
							appDTO.setSelected(true);
							arrayAppList.add(appDTO);
						}
					}
				}
			}
			return "";
		}

		@Override
		protected void onPostExecute(String result) {
			LogWrite.i(TAG, "AppListSize : " + arrayAppList.size());
			adapter = new CleanAppAdapter(context, R.layout.clean_app_view,
					arrayAppList);
			appListView.post(new Runnable() {
				public void run() {
					// mAdapter.notifyDataSetChanged();
					appListView.setAdapter(adapter);
				}
			});
			// adapter = new CleanAppAdapter(context, R.layout.clean_app_view,
			// arrayAppList);
			// adapter.notifyDataSetChanged();
			super.onPostExecute(result);
		}

		private Drawable getAppIcon(String packageName) {
			final PackageManager pm = getApplicationContext()
					.getPackageManager();
			ApplicationInfo ai;
			try {
				ai = pm.getApplicationInfo(packageName, 0);
			} catch (final NameNotFoundException e) {
				ai = null;
			}
			final Drawable appIcon = (ai != null ? pm.getApplicationIcon(ai)
					: null);
			return appIcon;
		}

		private String getAppName(String packageName) {
			final PackageManager pm = getApplicationContext()
					.getPackageManager();
			ApplicationInfo ai;
			try {
				ai = pm.getApplicationInfo(packageName, 0);
			} catch (final NameNotFoundException e) {
				ai = null;
			}
			final String applicationName = (String) (ai != null ? pm
					.getApplicationLabel(ai) : "");
			return applicationName;

		}

		private boolean isExist(String packageName,
				ArrayList<RunningAppDTO> arrayAppList) {
			for (RunningAppDTO runningAppDTO : arrayAppList) {
				if (runningAppDTO.getPackageName().equals(packageName))
					return true;
			}
			return false;
		}
	}

}