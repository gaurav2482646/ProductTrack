//package com.kochartech.gizmodoctor.HelperClass;
//
//import android.app.Activity;
//
//import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
//
//public class BackgroundHttpOperation implements Runnable {
//	private Thread thread;
//	private String methodName;
//	private Activity context;
//	private String messageToPost;
//	private boolean  isWrite,isRead;
//	public BackgroundHttpOperation(Activity context,String messageToPost,
//			boolean isWrite, boolean isRead) {
//		this.context = context;
//		this.thread = new Thread(this);
//		this.messageToPost = messageToPost;
//		this.isWrite = isWrite;
//		this.isRead = isRead;
//	}
//
//	public void start() {		
//		thread.start();
//	}
//
//	public void join() {
//		try {
//			thread.join();
//		} catch (InterruptedException e) {
//		}
//	}
//
//	@Override
//	public void run() {
//		// TODO Auto-generated method stub
//
//		HttpPostConnection httConnection = new HttpPostConnection(context,
//				HttpPostConnection.methodGetApplicationKey);
//		httConnection.connect();
//		httConnection.writeToServer(messageToPost);
//		responseMsg = httConnection.readFromServer();
//	}
//
//	public String getResponseMsg() {
//		return responseMsg;
//	}
//	private String responseMsg = "";
//}
