package com.kochartech.devicemax.Receivers;
//package com.kochar.MDMS.Recievers;
//
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.io.OutputStreamWriter;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.net.URLConnection;
//import java.util.Random;
//import com.kochar.MDM.Command.Manager.MDM_CommandHandler;
//import com.kochar.MDMS.Activities.ApplicationUpdate;
//import com.kochar.MDMS.Activities.LogWrite;
//import com.kochar.MDMS.Activities.R;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.content.pm.PackageManager.NameNotFoundException;
//import android.os.AsyncTask;
//import android.preference.PreferenceManager;
//import android.util.Log;
//
//public class ApplicationUpdateReceiver extends BroadcastReceiver
//{
//	private static String tag = "ApplicationUpdateReceiver";
//	Context context;
//	SharedPreferences sharePreference;
//	int count;
//	Editor editor;
//	String version="";
//	public void onReceive(Context arg0, Intent arg1)
//	{
//	
//		this.context = arg0;		
//		sharePreference = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
//		count = sharePreference.getInt("appupdatecount",0);
//		if(count<874)
//		{
//			count++;			
////			Intent intent = new Intent(context.getApplicationContext(),ApplicationUpdate.class); 
////			intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
////			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////			context.startActivity(intent);
//		
//			
//		}
//		else			
//		{	
//			count = 0;
////			new InnerAsync().execute("");	
////			Intent intent = new Intent(context,ApplicationUpdate.class); 
////			intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
////			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////			context.startActivity(intent);
//			new  checkUpdateAvailable().execute("");
//		}
//		editor = sharePreference.edit();
//		editor.putInt("appupdatecount",count);
//		editor.commit();
//		
//		LogWrite.d(tag,"Receiver Work Count= "+count);
//	}    
//	class checkUpdateAvailable extends AsyncTask<String, String, String>
//	{
//		private String tag="ApplicationUpdate";
//		final String SERVERURL;
//		checkUpdateAvailable()
//		{
//			SERVERURL = context.getString(R.string.ServerUrl);	
//			try 
//			{
//				version = new MDM_CommandHandler(context.getApplicationContext(),false).getAppNameVersion("com.kochar.MDMS.Activities");
//			}
//			catch (NameNotFoundException e) 
//			{
//				LogWrite.d(tag, "NameNotFoundException ---> "  + e.toString());
//			} 
//		}		
//		protected String doInBackground(String... params) 
//		{
//			LogWrite.d(tag,"doInBackGround Work");
//			try
//			{
//				URL url = new URL(SERVERURL);
//				URLConnection conn = url.openConnection();
//				HttpURLConnection httpConn = (HttpURLConnection) conn;
//				
//				httpConn.setConnectTimeout(9*1000);
//				httpConn.setReadTimeout(9*1000);
//				httpConn.setRequestMethod("POST");
//				
//				httpConn.setDoInput(true);
//				httpConn.setDoOutput(true);
////				httpConn.setAllowUserInteraction(true);
//				httpConn.setRequestProperty("Content-Type", "text/plain");
//				httpConn.setRequestMethod("POST");
//				OutputStreamWriter os = new OutputStreamWriter(
//						httpConn.getOutputStream());
//				httpConn.connect();
//				
//				os.write("MessageID:" + getRandomNumber()
//						+ "\nMessageClass:Event\nMessageType:HTTPToHSet\n"
//						+ "Event:GetAppVersion\nVersion:"
//						+version + "\nContent-Length:0\n");
//				os.close();
//				
//				BufferedReader br = new BufferedReader(
//						new InputStreamReader(httpConn.getInputStream()));
//				String data1="";
//				String data = "";
//				while ((data = br.readLine()) != null) {
//					data1 += data;
//				}
//				
//				LogWrite.d(tag,"version  ="+version);
//				LogWrite.d(tag,"Server Response ="+data1);
//				httpConn.disconnect();
//				String[] stausPlusURL = data1.split("~");
//				if(stausPlusURL[0].equalsIgnoreCase("true"))
//				{
//					LogWrite.d(tag,"status = true");
//					publishProgress(stausPlusURL[1]);					
//				}
//				else
//				{
//					LogWrite.d(tag,"status = false");
//				}
//				
//			}
//			catch (ExceptionDTO e)
//			{
//				LogWrite.d(tag,"ExceptionDTO ="+e);
//			}
//		
//				
//			return null;
//		}
//		
//		protected void onProgressUpdate(String... values)
//		{
////			super.onProgressUpdate(values);
//			LogWrite.d(tag,"PuslisProgress = Start");
//			Intent intent = new Intent(context.getApplicationContext(),ApplicationUpdate.class); 
//			intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
//			intent.putExtra("url",values[0]);
//			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//			context.startActivity(intent);
//			LogWrite.d(tag,"PuslisProgress = Finish");
//		}
//	}
//	
//	public String getRandomNumber() 
//	{
//		String finalRN = "";
//		Random rd = new Random(10000);
//		int randomNumber = rd.nextInt();
//		String rn = Integer.toString(randomNumber);
//
//		if (rn.startsWith("-")) {
//			int index = rn.indexOf("-");
//			finalRN = rn.substring(index + 1, rn.length());
//			LogWrite.d(tag, "getRandomNumber-> " + finalRN);
//			return finalRN;
//		} 
//		else 
//		{
//			return rn;
//		}
//
//		// return Integer.toString(randomNumber);
//	}
//
//}
