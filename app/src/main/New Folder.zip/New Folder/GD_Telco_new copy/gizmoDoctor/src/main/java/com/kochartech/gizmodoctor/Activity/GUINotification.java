package com.kochartech.gizmodoctor.Activity;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.HelperClass.SettingStateMonitor;
import com.kochartech.gizmodoctor.POJO.SettingStateDTO;
import com.kochartech.gizmodoctor.Preferences.GUISetNotificationPreference;
import com.kochartech.gizmodoctor.Preferences.NotificationAlertPreference;

public class GUINotification extends ActionBarActivity {

	private String tag = GUINotification.class.getSimpleName();

	private Context context;
	// private Preference_NotificationManager notificationManagerPreferece;
	private NotificationAlertPreference notificationsAlertPreference;
	private TextView batteryLevelTxtView, batteryTemperatureTxtView,
			cpuTemperatureTxtView, diagnoseTimeTxtView, settingTxtView; //
	private LinearLayout uiBatteryLevelNotification,
			uiBatteryTemperatureNotification, uiCpuTemperatureNotification,
			uiDataConnectionNotification, uiRAMNotification, uiCPUNotification,
			uiSettingNotification;
	private String batteryLevel, batteryTemp, cpuTemp;
	// private long diagnoseTime;

	private SettingStateMonitor monitor;
	private ArrayList<String> settingNameArrayList;
	private String settingString = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getSupportActionBar().setTitle("Notifications");
		LogWrite.d(tag, "onCreate");
		initDataSet();
		initUi();
	}

	public void initDataSet() {
		context = this;

		// notificationManagerPreferece = new Preference_NotificationManager(
		// context);
		notificationsAlertPreference = new NotificationAlertPreference(context);

		batteryLevel = notificationsAlertPreference
				.getBatteryLevel_WHILE_SCAN() + " %";
		batteryTemp = notificationsAlertPreference
				.getBatteryTemperature_WHILE_SCAN() + " \u2103";
		cpuTemp = notificationsAlertPreference.getCpuTemperature_WHILE_SCAN()
				+ " \u2103";

		// diagnoseTime = notificationManagerPreferece.getDiagnoseTime();

		guiNotificationPreference = new GUISetNotificationPreference(context);

		monitor = new SettingStateMonitor(context);
		settingNameArrayList = new ArrayList<String>();
		ArrayList<SettingStateDTO> arrayList = monitor.getSettingState();
		for (SettingStateDTO settingStateDTO : arrayList) {
			if (settingStateDTO.getOnTime().equals("Off"))
				continue;
			String[] setting_time = settingStateDTO.getOnTime().split(":");
			int current = Integer.parseInt(setting_time[0]);
			if (current != 0) {
				LogWrite.d(tag,
						"Setting Name : " + settingStateDTO.getSettingName());
				LogWrite.d(tag, "OnFrom : " + current);
				settingString += settingStateDTO.getSettingName() + " "
						+ current + " hours."
						+ System.getProperty("line.separator");
				settingNameArrayList.add(settingStateDTO.getSettingName()
						+ current + " hours.");
			}
		}

	}

	public void initUi() {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_notification);

		uiBatteryLevelNotification = (LinearLayout) findViewById(R.id.layoutBatteryLevel);
		uiBatteryTemperatureNotification = (LinearLayout) findViewById(R.id.layoutBatteryTemperature);
		uiCpuTemperatureNotification = (LinearLayout) findViewById(R.id.layoutCpuTemperature);
		uiDataConnectionNotification = (LinearLayout) findViewById(R.id.layoutDataConnection);
		uiRAMNotification = (LinearLayout) findViewById(R.id.ramNotificationUi);
		uiCPUNotification = (LinearLayout) findViewById(R.id.cpuNotificationUi);
		uiSettingNotification = (LinearLayout) findViewById(R.id.settingNotificationUi);

		batteryLevelTxtView = (TextView) findViewById(R.id.batteryLevelTxtView);
		batteryTemperatureTxtView = (TextView) findViewById(R.id.batteryTemperatureTxtView);
		cpuTemperatureTxtView = (TextView) findViewById(R.id.cpuTemperatureTxtView);
		diagnoseTimeTxtView = (TextView) findViewById(R.id.diagnoseTimeTxtView);
		settingTxtView = (TextView) findViewById(R.id.settingNotifyTxtView);

		diagnoseTimeTxtView.setText(getString(R.string.app_name));
		batteryLevelTxtView.setText(batteryLevel);
		batteryTemperatureTxtView.setText(batteryTemp);
		cpuTemperatureTxtView.setText(cpuTemp);

		settingTxtView.setText(settingString);
		isToShowView(uiBatteryLevelNotification,
				notificationsAlertPreference.getAlert_Battery_Level());
		isToShowView(uiBatteryTemperatureNotification,
				notificationsAlertPreference.getAlert_Battery_Temperature());

		isToShowView(uiCpuTemperatureNotification,
				notificationsAlertPreference.getAlert_CPU_Temperature());

		isToShowView(uiDataConnectionNotification,
				notificationsAlertPreference.isToAlertDataConnectionWorking());
		isToShowView(uiRAMNotification,
				notificationsAlertPreference.isToAlertRAMNotification());
		isToShowView(uiCPUNotification,
				notificationsAlertPreference.isToAlertCPUNotification());
		isToShowView(uiSettingNotification,
				notificationsAlertPreference.isToAlertSettingsNotification());

		if (isToFinish)
			finish();
	}

	public void isToShowView(View view, boolean flag) {
		LogWrite.d(tag, "Flag: " + flag);
		if (!flag) {
			view.setVisibility(View.GONE);
		} else {
			isToFinish = false;
		}
	}

	public void onClick(View view) {

		if (view.getId() == R.id.btBatteryLevel) {
			guiNotificationPreference.setBatteryLevel(false);
			isToShowView(uiBatteryLevelNotification, false);
			if (isToFinishUi())
				finish();
		} else if (view.getId() == R.id.btBatteryTemp) {
			guiNotificationPreference.setBatteryTemperature(false);
			isToShowView(uiBatteryTemperatureNotification, false);
			if (isToFinishUi())
				finish();
		} else if (view.getId() == R.id.btCpuTemp) {
			Intent intent = new Intent(context, GUICleanActivity.class);
			startActivity(intent);
			// guiNotificationPreference.setCPUTemperature(false);
			isToShowView(uiCpuTemperatureNotification, false);
			if (isToFinishUi())
				finish();
		} else if (view.getId() == R.id.btDataConnection) {
			guiNotificationPreference.setDataConnection(false);
			isToShowView(uiDataConnectionNotification, false);
			if (isToFinishUi())
				finish();
		} else if (view.getId() == R.id.disableRAMMonitoring) {
			guiNotificationPreference.setRAMUsageNotification(false);
			isToShowView(uiRAMNotification, false);
			if (isToFinishUi())
				finish();
		} else if (view.getId() == R.id.disableCPUMonitoring) {
			guiNotificationPreference.setCPUUsageNotification(false);
			isToShowView(uiCPUNotification, false);
			if (isToFinishUi())
				finish();
		} else if (view.getId() == R.id.disableSettingMonitoring) {
			guiNotificationPreference.setSettingNotification(false);
			isToShowView(uiSettingNotification, false);
			if (isToFinishUi())
				finish();
		}

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		LogWrite.d(tag, "onDestroy");

	}

	private boolean isToFinishUi() {
		if (uiBatteryLevelNotification.getVisibility() == View.VISIBLE) {
			return false;
		} else if (uiBatteryTemperatureNotification.getVisibility() == View.VISIBLE) {
			return false;
		} else if (uiCpuTemperatureNotification.getVisibility() == View.VISIBLE) {
			return false;
		} else if (uiDataConnectionNotification.getVisibility() == View.VISIBLE) {
			return false;
		} else if (uiRAMNotification.getVisibility() == View.VISIBLE) {
			return false;
		} else if (uiCPUNotification.getVisibility() == View.VISIBLE) {
			return false;
		} else if (uiSettingNotification.getVisibility() == View.VISIBLE) {
			return false;
		} else
			return true;
	}

	private boolean isToFinish = true;
	private GUISetNotificationPreference guiNotificationPreference;

}
