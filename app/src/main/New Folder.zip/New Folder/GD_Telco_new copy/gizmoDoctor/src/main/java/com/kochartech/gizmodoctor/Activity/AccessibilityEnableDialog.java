package com.kochartech.gizmodoctor.Activity;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.deviceissues.AccessibilityHelper;
import com.kochartech.gizmodoctor.deviceissues.ActionPerformPrefrence;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class AccessibilityEnableDialog extends Dialog implements
		android.view.View.OnClickListener {

	public Activity activity;
	public Dialog dialog;
	public Button ok;

	public AccessibilityEnableDialog(Activity a) {
		super(a);
		// TODO Auto-generated constructor stub
		this.activity = a;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.accessibility_dialog);
		ok = (Button) findViewById(R.id.btn_ok);
		ok.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_ok:
			AccessibilityHelper accessibilityHelper = new AccessibilityHelper(
					activity);
			if (!accessibilityHelper.isAccessibilityEnabled()) {
				Intent intent = new Intent(
						Settings.ACTION_ACCESSIBILITY_SETTINGS);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
						| Intent.FLAG_ACTIVITY_CLEAR_TASK);
				activity.startActivity(intent);
				final ActionPerformPrefrence actionPrefrence = new ActionPerformPrefrence(
						activity);
				actionPrefrence.clear();
			}
			break;
		default:
			break;
		}
		dismiss();
	}
}
