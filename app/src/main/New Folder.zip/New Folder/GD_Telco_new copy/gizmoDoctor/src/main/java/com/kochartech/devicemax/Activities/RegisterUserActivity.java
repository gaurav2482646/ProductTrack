package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kochartech.devicemax.AsyncTask.CreateTableAsync;
import com.kochartech.devicemax.Receivers.AppUpdateReceiver;
import com.kochartech.devicemax.Receivers.DeviceAdminSamplee;
import com.kochartech.devicemax.Services.DataChangeListener;
import com.kochartech.gizmodoctor.R;

/**
 * Activity Started On Start of the Application.
 */

public class RegisterUserActivity extends Activity {
	EditText editTextMobileNo = null;
	final String tag = "RegisterUserActivity";
	String fixedPhoneNumber = "5500669977";
	static int imsiCount = 0;

	SharedPreferences.Editor editor;
	SharedPreferences sharedPreferences = null;
	Button btnStart, extBtn;
	// public BatteryChangeReceiver batteryChangeReceiver = null;
	public static RegisterUserActivity promptNumberActivity = null;

	/**
	 * Returns instance for the Activity PromptNumberActivity.
	 * 
	 * @return {@link RegisterUserActivity}
	 */
	public static RegisterUserActivity GetInstance() {
		if (promptNumberActivity == null) {
			promptNumberActivity = new RegisterUserActivity();
		}
		return promptNumberActivity;
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		// if(batteryChangeReceiver!=null)
		// {
		// unregisterReceiver(batteryChangeReceiver);
		// }

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.registerphone);
		// Admin screen for the user to Enable device admin
		Intent in = new Intent(this, DeviceAdminSamplee.Controller.class);
		in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(in);

		btnStart = (Button) findViewById(R.id.btnStartApplication);
		extBtn = (Button) findViewById(R.id.btnExitApplication);
		LogWrite.d(tag, "PromptNumberActivity Starts..");

		AppUpdateReceiver receiver = new AppUpdateReceiver(
				getApplicationContext());
		receiver.execute("");

		// DataChangeListener dataChangeListener = new DataChangeListener();
		// startService(new Intent(getApplicationContext(),
		// DataChangeListener.class));

		// /*
		// * Logging Service
		// */
		// startServiceAlarm(getApplicationContext(), 10);
		// /*
		// * Starting Diagnosis service
		// */
		// startAlarmDiagnosis(getApplicationContext(), 1);
		// /*
		// * FTP Service
		// */
		// startBackUpAlarm(getApplicationContext(), 30);
		// try
		// {
		// batteryChangeReceiver = new BatteryChangeReceiver();
		// registerReceiver(batteryChangeReceiver,new
		// IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		//
		// }
		// catch (ExceptionDTO e1)
		// {
		// e1.printStackTrace();
		// }
		/*
		 * GPS Location service
		 */
		// Intent intent1 = new Intent(this, GpsProviderService.class);
		// startService(intent1);

		TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		if (telephonyManager != null) {
			boolean flagImsiCmp = false;
			String IMEI = "";
			promptNumberActivity = this;

			sharedPreferences = PreferenceManager
					.getDefaultSharedPreferences(getApplicationContext());
			editor = sharedPreferences.edit();
			IMEI = telephonyManager.getDeviceId();

			boolean flagFreshApp = sharedPreferences.getBoolean("freshApp",
					false);
			editor.putString("phoneNumber", fixedPhoneNumber);
			editor.putString("imei", IMEI);
			editor.commit();
			if (!flagFreshApp) {
				editor.putBoolean("freshApp", true);
				editor.commit();
			}
			LogWrite.d(tag,
					"*************** PERFORMING DATABASE FUNCTIONS ********************");
			new CreateTableAsync().execute(getApplicationContext());
			this.startService(new Intent(this, DataChangeListener.class));
			editor.putString("SimSerialNumber",
					getSimSerialNumber(getApplicationContext()));
			editor.commit();
			editTextMobileNo = (EditText) findViewById(R.id.editMobileNo);
			// {
			// LogWrite.d(tag, "Service is started here.....");
			// LogWrite.d(tag,
			// "*******************************************************************");
			// boolean flag = iSR(promptNumberActivity);
			// LogWrite.d(tag, "flag-->" + flag);
			//
			// // if (!flag)
			// // startService(new Intent(this, ServiceEg.class));
			// LogWrite.d(tag,
			// "*******************************************************************");
			// }

			// for fetching IMSI as it would be checked whether a new sim
			// has
			// been inserted

			// imsi fetched from mobile using telephony manager
			String imsi = telephonyManager.getSimSerialNumber();

			String serialNoFromShared = sharedPreferences.getString("IMSI",
					"imsi");
			if (serialNoFromShared.equals("imsi")) {
				LogWrite.d(tag, "imsi is not set " + imsi);
				SharedPreferences.Editor editor = sharedPreferences.edit();
				editor.putString("IMSI", imsi);
				editor.commit();
				flagImsiCmp = true;
			} else if (serialNoFromShared.equals(imsi)) {
				LogWrite.d(tag, "cmp success " + imsi + "  "
						+ serialNoFromShared);
				flagImsiCmp = true;
			} else {
				LogWrite.d(tag, "else cmp fails  " + imsi + "  "
						+ serialNoFromShared);
				SharedPreferences.Editor editor = sharedPreferences.edit();
				editor.putString("IMSI", imsi);
				editor.putString("phoneNumber", "phoneNumber");
				editor.commit();
				editTextMobileNo.setEnabled(true);
				editTextMobileNo.setText("");
				flagImsiCmp = false;
			}
			// Intent in = new Intent(this,DeviceAdminSamplee.Controller.class);
			// in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			// btnStart = (Button) findViewById(R.id.btnStartApplication);
			// extBtn = (Button) findViewById(R.id.btnExitApplication);
			btnStart.setOnClickListener(new OnClickListener() {
				public void onClick(View arg0) {
					String mobileNUmber = ((EditText) findViewById(R.id.editMobileNo))
							.getText() + "";
					if (!(mobileNUmber.length() >= 10 && mobileNUmber.length() <= 12)) {
						Toast.makeText(getApplicationContext(),
								"Invalid number. Please enter valid number",
								Toast.LENGTH_SHORT).show();
						return;
					}
					Intent intent = new Intent(getApplicationContext(),
							MDMMainActivity.class);
					intent.putExtra("phoneNumber", mobileNUmber);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					PreferenceManager
							.getDefaultSharedPreferences(
									getApplicationContext()).edit()
							.putString("ph", mobileNUmber).commit();
					startActivity(intent);
					DecisionMakerActivity.activityStatusFlag = true;
					RegisterUserActivity.GetInstance().finish();
				}
			});

			extBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View arg0) {
					LogWrite.d(tag, "Exit Button Clickd");
					try {
						// stopServiceAlarm(getApplicationContext());
						LogWrite.d(tag,
								"Exit Button Clickd  -----------------1");
						// Intent intent1 = new Intent(getApplicationContext(),
						// GpsProviderService.class);
						// stopService(intent1);
						DecisionMakerActivity.activityStatusFlag = false;

						// stopAlarmDiagnosis(getApplicationContext());
						LogWrite.d(tag,
								"Exit Button Clickd  -----------------2");
						// stopServiceAlarm(getApplicationContext());
						LogWrite.d(tag,
								"Exit Button Clickd  -----------------3");
						// stopBackUpAlarm(getApplicationContext());
						LogWrite.d(tag,
								"Exit Button Clickd  -----------------4");
						// if(batteryChangeReceiver!=null)
						// {
						// LogWrite.d(tag,
						// "Exit Button Clickd  -----------------5");
						// unregisterReceiver(batteryChangeReceiver);
						// batteryChangeReceiver = null;
						// LogWrite.d(tag,
						// "Exit Button Clickd  -----------------6");
						// }
						LogWrite.d(tag,
								"Exit Button Clickd  -----------------7");
						finish();
						LogWrite.d(tag,
								"Exit Button Clickd  -----------------8");
					} catch (Exception e) {
						LogWrite.d(tag,
								"Exit Button ExceptionDTO ----> " + e.toString());
					}
				}
			});
		} // end if(telephonyManager!=null)
	}// end oncreate
		// public void startBackUpAlarm(Context context, int TimeInterval)
		// {
		// Intent ftpIntent=new Intent(context,FtpUploadReceiver.class);
		// ftpIntent.putExtra("Destination" ,
		// FTPDetails.DESTINATION.toString());
		// ftpIntent.putExtra("ExternalPath",
		// FTPDetails.EXTERNALSOURCE.toString());
		// ftpIntent.putExtra("Password" , FTPDetails.PASSWORD.toString());
		// ftpIntent.putExtra("UserName" , FTPDetails.USERNAME.toString());
		// AlarmManager alarmManager=(AlarmManager)
		// context.getSystemService(Context.ALARM_SERVICE);
		// PendingIntent pendingFtpIntent=PendingIntent.getBroadcast(context,
		// 232024, ftpIntent, 0);
		// alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
		// System.currentTimeMillis()+(5*1000), (TimeInterval*60*1000L),
		// pendingFtpIntent);
		// }
		// public void stopBackUpAlarm(Context context)
		// {
		// Intent ftpIntent=new Intent(context,FtpUploadReceiver.class);
		// AlarmManager alarmManager=(AlarmManager)
		// context.getSystemService(Context.ALARM_SERVICE);
		// PendingIntent pendingFtpIntent=PendingIntent.getBroadcast(context,
		// 232024, ftpIntent, 0);
		// alarmManager.cancel(pendingFtpIntent);
		// }
		// public void startAlarmDiagnosis(Context context, int TimeInterval)
		// {
		// LogWrite.d(tag, "Start Service Method enters");
		// try
		// {
		// Intent intent=new Intent(context, DiagnosisService.class);
		// AlarmManager alarmManager=(AlarmManager)
		// getSystemService(Context.ALARM_SERVICE);
		// PendingIntent pendingIntent=PendingIntent.getBroadcast(context,
		// 10102,
		// intent, 0);
		// alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,(System.currentTimeMillis()+5*1000),
		// TimeInterval*60*1000, pendingIntent);
		// }
		// catch (ExceptionDTO e)
		// {
		// LogWrite.d(tag, "------"+e);
		// }
		// }
		//
		// public void stopAlarmDiagnosis(Context context)
		// {
		// LogWrite.d(tag, "Stop Service Method enters");
		// try
		// {
		// Intent intent=new Intent(context, DiagnosisService.class);
		// AlarmManager alarmManager=(AlarmManager)
		// getSystemService(Context.ALARM_SERVICE);
		// PendingIntent pendingIntent=PendingIntent.getBroadcast(context,
		// 10102,
		// intent, 0);
		// alarmManager.cancel(pendingIntent);
		// }
		// catch (ExceptionDTO e)
		// {
		// LogWrite.d(tag, "------"+e);
		// }
		// }
		// public void startServiceAlarm(Context context, int TimeInterval)
		// {
		// LogWrite.d(tag, "Start Service Method enters");
		// try
		// {
		// Intent intent=new Intent(context, ServiceReceiver.class);
		// AlarmManager alarmManager=(AlarmManager)
		// getSystemService(Context.ALARM_SERVICE);
		// PendingIntent pendingIntent=PendingIntent.getBroadcast(context,
		// 10101,
		// intent, 0);
		// alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,(System.currentTimeMillis()+5*1000),
		// TimeInterval*60*1000, pendingIntent);
		// }
		// catch (ExceptionDTO e)
		// {
		// LogWrite.d(tag, "------"+e);
		// }
		// }
		//
		// public void stopServiceAlarm(Context context)
		// {
		// LogWrite.d(tag, "Stop Service Method enters");
		// try
		// {
		// Intent intent=new Intent(context, ServiceReceiver.class);
		// AlarmManager alarmManager=(AlarmManager)
		// getSystemService(Context.ALARM_SERVICE);
		// PendingIntent pendingIntent=PendingIntent.getBroadcast(context,
		// 10101,
		// intent, 0);
		// alarmManager.cancel(pendingIntent);
		// }
		// catch (ExceptionDTO e)
		// {
		// LogWrite.d(tag, "------"+e);
		// }
		// }

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == 1) {
			// unregisterReceiver(batteryChangeReceiver);
			finish();
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		LogWrite.d("Test back", "not back" + event);
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			LogWrite.d("Test back", "back");
			return false;
		}
		LogWrite.d("Test back", "not back");
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * Retrieves Serial Number (IMSI) of SIM.
	 * 
	 * @return {@link String}
	 */
	public String getSimSerialNumber(Context context) {
		TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		return tm.getSimSerialNumber();
	}

	/**
	 * Checks for the Services, whether running or not.
	 * 
	 * @param context
	 * @return {@link Boolean}
	 */
	// private boolean iSR(Context context)
	// {
	// String sClassName;
	// ActivityManager manager = (ActivityManager) context
	// .getSystemService(Context.ACTIVITY_SERVICE);
	// for (RunningServiceInfo service : manager
	// .getRunningServices(Integer.MAX_VALUE)) {
	// sClassName = service.service.getClassName();
	//
	// // if (sClassName.contains(ServiceEg.class.getName())) {
	// // return true;
	// // }
	// }
	// return false;
	// }

	/**
	 * Installs <b>BUSYBOX</b>.
	 * 
	 */
	// public void InstallBusybox() {
	// Process process;
	// try {
	// process = Runtime.getRuntime().exec("su");
	// DataOutputStream os = new DataOutputStream(
	// process.getOutputStream());
	// os.writeBytes("mount -o remount,rw -t yaffs2 /dev/block/mtdblock3 /system; \n");
	// os.writeBytes("mkdir /system/xbin; \n");
	// String path = Environment.getExternalStorageDirectory()
	// + "/busybox";
	// LogWrite.d(tag, "Tpath===" + path);
	// os.writeBytes("cat " + path + " > /system/xbin/busybox; \n");
	// os.writeBytes("chmod 777 /system/xbin/busybox; \n");
	// os.writeBytes("chmod 777 /data/app; \n");
	// os.writeBytes("busybox --install /system/xbin; \n");
	// os.writeBytes("sync; \n");
	// os.writeBytes("reboot; \n");
	//
	// } catch (IOException e) {
	// e.printStackTrace();
	// } catch (ExceptionDTO e) {
	// e.printStackTrace();
	// }
	// }
}
