package com.kochartech.gizmodoctor.deviceissues;

import com.kochartech.gizmodoctor.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class ActivityOverlay extends Activity {
	private static Activity activity;

	public static void start(Context context) {
		Intent intent = new Intent(context, ActivityOverlay.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
				| Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
		context.startActivity(intent);
	}

	public static void stop() {
		if (ActivityOverlay.activity != null)
			ActivityOverlay.activity.finish();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.overlay);
		activity = this;
	}

}
