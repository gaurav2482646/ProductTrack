package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Adapter.BatteryAdapter;
import com.kochartech.gizmodoctor.CustomView.MyProgressDialog;
import com.kochartech.gizmodoctor.HelperClass.Utility;
import com.kochartech.gizmodoctor.Preferences.AppSettingsPreference;
import com.kochartech.gizmodoctor.UpdateUi.UiRequireUpdate;
import com.kochartech.library.Battery.KTApplicationDTO;
import com.kochartech.library.Battery.KTBatteryApps;
import com.kochartech.library.Battery.KTBatteryInfo;

public class GUIBattery extends Fragment implements MyFragment, UiRequireUpdate {
	private String tag = "GUIBattery";
	private Context context;
	private View rootView;
	private ListView apps_ListView;
	private TextView temperatureTextView, voltageTextView, healthTextView,
			technologyTextView;
	private ImageView batteryInPercentage;
	private KTBatteryInfo ktBatteryInfo;
	private KTBatteryApps ktBatteryApps;
	private ArrayList<KTApplicationDTO> batteryAppsList;
	private MyProgressDialog myProgressDialog;
	private BatteryAdapter listViewAdapter;
	private int[] batteryImage = { R.drawable.battery_10,
			R.drawable.battery_10, R.drawable.battery_20,
			R.drawable.battery_30, R.drawable.battery_40,
			R.drawable.battery_50, R.drawable.battery_60,
			R.drawable.battery_70, R.drawable.battery_80,
			R.drawable.battery_90, R.drawable.battery_100 };

	private boolean isToShowProgressDialog = false;
	private int count = 0;
	private int temperatureUnits;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		initData();
		initUi(inflater, container);

		if (savedInstanceState == null) {

			myProgressDialog = new MyProgressDialog(getActivity());
			myProgressDialog.show();
		} else {
			isToShowProgressDialog = true;
		}

		return rootView;
	}

	private void initData() {
		context = getActivity().getApplicationContext();

		AppSettingsPreference appSettingPreference = new AppSettingsPreference(
				context);
		temperatureUnits = appSettingPreference.getTemperatureUnitToShow();

		ktBatteryInfo = KTBatteryInfo.getInstance();
		ktBatteryInfo.calculate(context);
		ktBatteryApps = new KTBatteryApps(getActivity());
		batteryAppsList = ktBatteryApps.refreshView();
		LogWrite.d(tag,
				"batteryConsumingAppsList Size: " + batteryAppsList.size());
		listViewAdapter = new BatteryAdapter(context, batteryAppsList);

	}

	private void initUi(LayoutInflater inflater, ViewGroup container) {

		rootView = inflater.inflate(R.layout.fragment_batterydetail1,
				container, false);
		apps_ListView = (ListView) rootView.findViewById(R.id.listView_Apps);

		temperatureTextView = (TextView) rootView
				.findViewById(R.id.temperature);

		voltageTextView = (TextView) rootView.findViewById(R.id.voltage);
		healthTextView = (TextView) rootView.findViewById(R.id.health);
		technologyTextView = (TextView) rootView.findViewById(R.id.technology);
		batteryInPercentage = (ImageView) rootView
				.findViewById(R.id.batteryInPercentage);

		int batteryImageIndex = getIndexForBatteryImage((int) ktBatteryInfo
				.getBatteryLevel());
		batteryInPercentage
				.setBackgroundResource(batteryImage[batteryImageIndex]);

		temperatureTextView.setText(Utility.tempWithUnits(
				ktBatteryInfo.getTemperature(), temperatureUnits));
		voltageTextView.setText("" + ktBatteryInfo.getVoltage() + " mV");
		healthTextView.setText("" + ktBatteryInfo.getHealth());
		technologyTextView.setText(ktBatteryInfo.getTechnology());

		apps_ListView.setAdapter(listViewAdapter);

	}

	@Override
	public String getTitle() {
		return "Battery Diagnosis";
	}

	@Override
	public void runInBackGround() {

		if (isToShowProgressDialog) {
			isToShowProgressDialog = false;

			getActivity().runOnUiThread(new Runnable() {

				@Override
				public void run() {
					myProgressDialog = new MyProgressDialog(getActivity());
					myProgressDialog.show();
				}
			});

		}

		// TODO Auto-generated method stub
		ArrayList<KTApplicationDTO> arrayList = ktBatteryApps.refreshView();

		batteryAppsList.clear();

		batteryAppsList.addAll(arrayList);

		LogWrite.d(tag, "List Size:" + batteryAppsList);
		LogWrite.d(tag, "List Size:" + batteryAppsList.size());
	}

	@Override
	public void updateUI() {
		// TODO Auto-generated method stub

		if (count <= 6)
			count++;

		LogWrite.d(tag, "count: " + count);
		if (batteryAppsList.size() > 0 || count > 6) {
			if (myProgressDialog.isShowing())
				myProgressDialog.dismiss();
		}
		listViewAdapter.notifyDataSetChanged();
	}

	private int getIndexForBatteryImage(int batteryPercentage) {
		return batteryPercentage / 10;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		 ktBatteryApps.stopBackgroundWorking();
	}
	// @Override
	// public boolean isToUpdateUi() {
	// // TODO Auto-generated method stub
	// return false;
	// }
}
