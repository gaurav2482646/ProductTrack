package com.kochartech.devicemax.dto;

import java.util.List;

/**
 * Created by gauravjeetsingh on 22/3/18.
 */
public class AppDTO
{
    private List<Apps> Apps;

    public List<Apps> getApps ()
    {
        return Apps;
    }

    public void setApps (List<Apps> Apps)
    {
        this.Apps = Apps;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Apps = "+Apps+"]";
    }
}
