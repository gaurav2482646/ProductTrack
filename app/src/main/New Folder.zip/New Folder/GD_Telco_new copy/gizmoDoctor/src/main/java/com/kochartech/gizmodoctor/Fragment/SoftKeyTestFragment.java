package com.kochartech.gizmodoctor.Fragment;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.CustomView.CustomGridAdapter;
import com.kochartech.gizmodoctor.HelperClass.FragmentTitles;
import com.kochartech.gizmodoctor.POJO.SoftKey;

public class SoftKeyTestFragment extends Fragment implements
		OnItemClickListener, MyFragment {
	private String TAG = SoftKeyTestFragment.class.getSimpleName();
	private Context context;
	private View rootView;
	private GridView gridView;
	// private FragmentListener fragmentListener;

	private String[] softKeyTitles;
	private String[] softKeyDescription;
	private TypedArray softKeyIcons;

	// static final String[] GRID_DATA = new String[] { "PowerKey", "HomeKey",
	// "MenuKey", "VolumeUpKey", "VolumeDownKey" };

	private ArrayList<SoftKey> arrayList;

	@Override
	public String getTitle() {
		return FragmentTitles.SOFTWARE_KEY_TEST;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		initDataSet();
		initUi(inflater, container);
		return rootView;
	}

	private void initDataSet() {
		arrayList = new ArrayList<SoftKey>();
		softKeyTitles = getResources().getStringArray(R.array.soft_key_titles);
		softKeyDescription = getResources().getStringArray(
				R.array.soft_key_descrip);
		softKeyIcons = getResources().obtainTypedArray(R.array.soft_key_icons);

		for (int i = 0; i < softKeyTitles.length; i++) {
			LogWrite.d(TAG, "MenuItems  =====> " + softKeyTitles[i]);
			SoftKey softKey = new SoftKey();
			softKey.setName(softKeyTitles[i]);
			softKey.setDescription(softKeyDescription[i]);
			softKey.setIcon(softKeyIcons.getResourceId(i, -1));
			arrayList.add(softKey);
			// SoftKey items = new RowItem(menutitles[i],
			// menuIcons.getResourceId(
			// i, -1));
			// rowItems.add(items);
		}
	}

	private void initUi(LayoutInflater inflater, ViewGroup container) {
		context = getActivity().getApplicationContext();
		// fragmentListener = (FragmentListener) getActivity();
		rootView = inflater.inflate(R.layout.fragment_softwarekey_test,
				container, false);
		rootView.findViewById(R.id.headerTest).setVisibility(View.GONE);

		gridView = (GridView) rootView.findViewById(R.id.gridview);
		gridView.setAdapter(new CustomGridAdapter(context, arrayList));
		gridView.setOnItemClickListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		String text = ((TextView) view.findViewById(R.id.grid_field_title))
				.getText().toString();

		Intent keyScreenIntent = new Intent(context, KeysTestFragment.class);
		keyScreenIntent.putExtra("SoftKeyTest", text);
		startActivity(keyScreenIntent);

		// if (text.equals(softKeyTitles[0])) {
		// // Power Key Press
		// // fragmentListener.onItemClicked(FragmentListener.actionAdd,
		// // new KeysTestFragment("POWER", null));
		// } else if (text.equals(softKeyTitles[1])) {
		// // Home Key Press
		// fragmentListener.onItemClicked(FragmentListener.actionAdd,
		// new KeysTestFragment("HOME", null));
		// } else if (text.equals(softKeyTitles[2])) {
		// // Menu Key Press
		// fragmentListener.onItemClicked(FragmentListener.actionAdd,
		// new KeysTestFragment("MENU", null));
		// } else if (text.equals(softKeyTitles[3])) {
		// // Volume Up Key press
		// fragmentListener.onItemClicked(FragmentListener.actionAdd,
		// new KeysTestFragment("VOLUMEUP", null));
		// } else if (text.equals(softKeyTitles[4])) {
		// // Volume Down Key press
		// fragmentListener.onItemClicked(FragmentListener.actionAdd,
		// new KeysTestFragment("VOLUMEDOWN", null));
		// }
		//
		// Toast.makeText(context, "Text : " + text, Toast.LENGTH_SHORT).show();
	}

}
