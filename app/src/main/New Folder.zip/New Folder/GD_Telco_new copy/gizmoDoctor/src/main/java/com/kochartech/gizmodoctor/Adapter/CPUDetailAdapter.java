package com.kochartech.gizmodoctor.Adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.library.CPU.KTApplicationInfo;

public class CPUDetailAdapter extends BaseAdapter {
	private String tag = "CPUDetailAdapter";
	private Context context;
	private List<KTApplicationInfo> runningAppProcess;
	private LayoutInflater inflator;

	public CPUDetailAdapter(Context context,
			List<KTApplicationInfo> runningAppProcess) {
		this.context = context;
		this.runningAppProcess = runningAppProcess;

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LogWrite.d(tag, "position :" + position);
		try {
			if (convertView == null) {
				LayoutInflater inflator = LayoutInflater.from(context);
				convertView = inflator
						.inflate(R.layout.rowview_cpudetail, null);
			}

			KTApplicationInfo ktAppInfo = runningAppProcess.get(position);

			LogWrite.d(tag, "AppName" + ktAppInfo.getAppName());

			ImageView appIcon = (ImageView) convertView.findViewById(R.id.icon);
			TextView appName = (TextView) convertView
					.findViewById(R.id.appname);
			TextView appInfo = (TextView) convertView
					.findViewById(R.id.appinfo);

			appIcon.setBackgroundDrawable(ktAppInfo.getIcon());
			appName.setText(ktAppInfo.getAppName());
			LogWrite.d(tag, "AppName" + ktAppInfo.getAppName());
			appInfo.setText(ktAppInfo.getUsage());
			LogWrite.d(tag, "Usage :" + ktAppInfo.getUsage());
		} catch (Exception e) {
			LogWrite.d(tag, "ExceptionDTO..." + e);
		}

		return convertView;

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return runningAppProcess.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return runningAppProcess.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODOAuto-generated method stub
		return position;
	}

}
