package com.kochartech.gizmodoctor.HelperClass;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.Preferences.AndroidOsPreference;

import android.content.Context;
import android.os.Build;

public class CheckOsUpdate {
	private String TAG = CheckOsUpdate.class.getSimpleName();
	private AndroidOsPreference osPreference;

	public CheckOsUpdate(Context context) {
		osPreference = new AndroidOsPreference(context);
	}

	public boolean check() {
		String release = "";
		try {
			release = Build.VERSION.RELEASE;
			LogWrite.d(TAG, "Android OS Version :::: " + release);
		} catch (Exception e) {
			LogWrite.e(TAG, "VerisonException :> " + e.toString());
		}
		if (osPreference.getLastOsVerison().equals("")) {
			LogWrite.d(TAG, "Prefrence is empty, need to set os version");
			osPreference.setOsVersion(release);
			return false;
		} else {
			LogWrite.d(TAG, "Prefrence is not empty, need to check update");
			if (osPreference.getLastOsVerison().equals(release)) {
				LogWrite.d(TAG, "OS not update");
				return false;
			} else {
				LogWrite.i(TAG, "OS update, Need to inform");
				osPreference.setOsVersion(release);
				return true;
			}
		}

	}
}
