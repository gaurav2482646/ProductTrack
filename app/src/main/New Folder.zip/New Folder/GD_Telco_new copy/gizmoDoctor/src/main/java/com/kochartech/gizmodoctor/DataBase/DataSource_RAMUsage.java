package com.kochartech.gizmodoctor.DataBase;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.POJO.AppUsageDTO;

public class DataSource_RAMUsage {
	private String tag = "DataSource_RAMUsage";
	private Context context;
	private static DataSource_RAMUsage classInstance = null;
	private MySQLiteOpenHelper mySQLiteOpenHelper;
	private SQLiteDatabase db;

	public static DataSource_RAMUsage getInstance(Context context) {
		if (classInstance == null)
			classInstance = new DataSource_RAMUsage(context);
		return classInstance;
	}

	private DataSource_RAMUsage(Context context) {
		LogWrite.d(tag, "constructor");
		this.context = context;
		mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
	}

	private void open() {
		LogWrite.d(tag, "open");
		db = mySQLiteOpenHelper.getWritableDatabase();
	}

	private void close() {
		LogWrite.d(tag, "close");
		db.close();
	}

	public synchronized void insertRecord(int appId, int ramUsage, long time) {

		open();
		ContentValues values = new ContentValues();
		values.put(MySQLiteOpenHelper.RAMUSAGE_ColumnID, appId);
		values.put(MySQLiteOpenHelper.RAMUSAGE_ColumnUsage, ramUsage);
		values.put(MySQLiteOpenHelper.RAMUSAGE_ColumnTime, time);

		long id = db.insert(MySQLiteOpenHelper.RAMUSAGE_TABLE, null, values);

		close();
		// LogWrite.d(tag, "insertRecord: recordId: " + id);

	}

	public synchronized AppUsageInfo queryAppDetail(int appId) {
		open();

		long queryTime = System.currentTimeMillis() - 60 * 60 * 1000;
		AppUsageInfo appinfo = new AppUsageInfo();
		appinfo.setAppId(appId);

		Cursor cursor = db
				.query(MySQLiteOpenHelper.RAMUSAGE_TABLE, null,
						MySQLiteOpenHelper.RAMUSAGE_ColumnID + " =? AND "
								+ MySQLiteOpenHelper.RAMUSAGE_ColumnTime
								+ " >=?", new String[] { String.valueOf(appId),
								String.valueOf(queryTime) }, null, null,
						MySQLiteOpenHelper.RAMUSAGE_ColumnTime + " DESC");

		ArrayList<AppUsageDTO> appUsageDTOList = new ArrayList<AppUsageDTO>();

		LogWrite.d(tag, "Cursor Size= " + cursor.getCount());
		if (cursor.getCount() > 0) {
			if (cursor.moveToNext()) {
				int index_Id = cursor
						.getColumnIndex(MySQLiteOpenHelper.RAMUSAGE_ColumnID);
				int index_Usage = cursor
						.getColumnIndex(MySQLiteOpenHelper.RAMUSAGE_ColumnUsage);
				int index_Time = cursor
						.getColumnIndex(MySQLiteOpenHelper.RAMUSAGE_ColumnTime);

				do {
					int id = cursor.getInt(index_Id);
					int usage = cursor.getInt(index_Usage);
					long time = cursor.getLong(index_Time);

					AppUsageDTO appUsageDTO = new AppUsageDTO(usage, time);

					appUsageDTOList.add(appUsageDTO);
				} while (cursor.moveToNext());
			}
		}

		appinfo.setAppUsage(appUsageDTOList);

		close();

		return appinfo;
	}

	public synchronized String getRecord(int recordId) {
		String ram_usage = "0";
		open();
		LogWrite.d(tag, "----");
		Cursor cursor = db.query(MySQLiteOpenHelper.RAMUSAGE_TABLE, null,
				MySQLiteOpenHelper.RAMUSAGE_ColumnID + " =?",
				new String[] { String.valueOf(recordId) }, null, null, null);

		LogWrite.d(tag, "Cursor Size= " + cursor.getCount());
		if (cursor.getCount() > 0) {
			if (cursor.moveToNext()) {
				int index_Id = cursor
						.getColumnIndex(MySQLiteOpenHelper.RAMUSAGE_ColumnID);
				int index_Usage = cursor
						.getColumnIndex(MySQLiteOpenHelper.RAMUSAGE_ColumnUsage);
				int index_Time = cursor
						.getColumnIndex(MySQLiteOpenHelper.RAMUSAGE_ColumnTime);

				do {
					int id = cursor.getInt(index_Id);
					int usage = cursor.getInt(index_Usage);
					long time = cursor.getLong(index_Time);

					LogWrite.d(tag, "id= " + id);
					LogWrite.d(tag, "Usage= " + usage);
					LogWrite.d(tag, "Time= " + time);
					ram_usage = "" + usage;
				} while (cursor.moveToNext());
			}
		}
		close();
		return ram_usage;
	}
}
