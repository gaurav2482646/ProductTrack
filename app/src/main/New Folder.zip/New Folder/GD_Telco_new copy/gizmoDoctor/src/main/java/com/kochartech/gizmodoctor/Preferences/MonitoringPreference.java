package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class MonitoringPreference {
	private String PREFERENCE_NAME = MonitoringPreference.class.getSimpleName();
	private final int PREFERENCE_MODE = 0;
	private Editor editor;
	private SharedPreferences myPreference;
	private String KEY_MONITOR_STATUS = "MonitoringStatus";
	private String KEY_MONITOR_COUNT = "MonitoringCount";
	private String KEY_MONITOR_START = "MonitoringStart";
	private String KEY_MONITOR_WIFI = "MonitoringWifi";
	private String KEY_MONITOR_GPS = "MonitoringGps";
	private String KEY_MONITOR_BLUETOOTH = "MonitoringBluetooth";
	private String KEY_MONITOR_HOTSPOT = "MonitoringHotspot";
	private String KEY_MONITOR_SEND_COUNT = "MonitoringSendCount";
	private boolean DEFAULT_VALUE_MONITOR_START = false;
	private int DEFAULT_INTEGER_VALUE = 0;

	/**
	 * Every 6 minute count increase
	 */
	// public static int ONE_DAY_COUNT = 240;
	public static int THREE_HOURS_COUNT = 30;

	public MonitoringPreference(Context context) {
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();
	}

	public boolean getMonitoringStartStatus() {
		return myPreference.getBoolean(KEY_MONITOR_START,
				DEFAULT_VALUE_MONITOR_START);
	}

	public void setMonitoringStartStatus(boolean monitor_start_status) {
		editor.putBoolean(KEY_MONITOR_START, monitor_start_status).commit();
	}

	public boolean deleteMonitoringStatus() {
		return editor.remove(KEY_MONITOR_START).commit();
	}

	public int getMonitoringValue() {
		return myPreference.getInt(KEY_MONITOR_STATUS, DEFAULT_INTEGER_VALUE);
	}

	public void setMonitoringValue(int monitor_value) {
		editor.putInt(KEY_MONITOR_STATUS, monitor_value).commit();
	}

	public boolean deleteMonitoringValue() {
		return editor.remove(KEY_MONITOR_STATUS).commit();
	}

	public int getCount() {
		return myPreference.getInt(KEY_MONITOR_COUNT, DEFAULT_INTEGER_VALUE);
	}

	public void setCount(int count) {
		editor.putInt(KEY_MONITOR_COUNT, count).commit();
	}

	public boolean deleteCount() {
		return editor.remove(KEY_MONITOR_COUNT).commit();
	}

	public int getSendCount() {
		return myPreference.getInt(KEY_MONITOR_SEND_COUNT, 1);
	}

	public void setSendCount(int count) {
		editor.putInt(KEY_MONITOR_SEND_COUNT, count).commit();
	}

	public boolean deleteSendCount() {
		return editor.remove(KEY_MONITOR_SEND_COUNT).commit();
	}

	// Wifi Monitoring Persistent
	public int getMonitoringWifiValue() {
		return myPreference.getInt(KEY_MONITOR_WIFI, DEFAULT_INTEGER_VALUE);
	}

	public void setMonitoringWifiValue(int count) {
		editor.putInt(KEY_MONITOR_WIFI, count).commit();
	}

	public boolean deleteMonitoringWifiValue() {
		return editor.remove(KEY_MONITOR_WIFI).commit();
	}

	// Wifi Monitoring Persistent
	// Bluetooth Monitoring Persistent
	public int getMonitoringBluetoothValue() {
		return myPreference
				.getInt(KEY_MONITOR_BLUETOOTH, DEFAULT_INTEGER_VALUE);
	}

	public void setMonitoringBluetoothValue(int count) {
		editor.putInt(KEY_MONITOR_BLUETOOTH, count).commit();
	}

	public boolean deleteMonitoringBluetoothValue() {
		return editor.remove(KEY_MONITOR_BLUETOOTH).commit();
	}

	// Bluetooth Monitoring Persistent
	// GPS Monitoring Persistent
	public int getMonitoringGpsValue() {
		return myPreference.getInt(KEY_MONITOR_GPS, DEFAULT_INTEGER_VALUE);
	}

	public void setMonitoringGpsValue(int count) {
		editor.putInt(KEY_MONITOR_GPS, count).commit();
	}

	public boolean deleteMonitoringGpsValue() {
		return editor.remove(KEY_MONITOR_GPS).commit();
	}

	// GPS Monitoring Persistent
	// Hotspot Monitoring Persistent
	public int getMonitoringHotspotValue() {
		return myPreference.getInt(KEY_MONITOR_HOTSPOT, DEFAULT_INTEGER_VALUE);
	}

	public void setMonitoringHotspotValue(int count) {
		editor.putInt(KEY_MONITOR_HOTSPOT, count).commit();
	}

	public boolean deleteMonitoringHotspotValue() {
		return editor.remove(KEY_MONITOR_HOTSPOT).commit();
	}

	// Hotspot Monitoring Persistent

	public void resetAll() {
		editor.clear().commit();
	}
}
