package com.kochartech.gizmodoctor.Activity;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.KeyEvent;
import android.view.Window;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.Fragment.GUIDiagnose;

public class FragmentActivity extends android.support.v4.app.FragmentActivity
{
	private String tag = "FragmentActivity";
//	private FrameLayout fragmentContainer;
	private FragmentManager fragmentManager;
	@Override
	protected void onCreate(Bundle arg0) 
	{
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.fragmentactivity);
		
		
//		fragmentContainer = (FrameLayout) findViewById(R.id.fragment_container);
		
		fragmentManager = getSupportFragmentManager();		
		
//		KTInformation ktInfo = new KTInformation();
//		ktInfo.
		try {
			fragmentManager.beginTransaction().add(R.id.fragment_container, new GUIDiagnose()).commit();
//			fragmentManager.beginTransaction().addToBackStack("1").commit();
		} catch (Exception e) {
			LogWrite.d(tag,"ExceptionDTO..."+e);
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		
		int backStackCount = fragmentManager.getBackStackEntryCount();
		
		LogWrite.d(tag,"BackStack Count :"+backStackCount);
//		int count = getSupportFragmentManager().getFragments().size();
//		Toast.makeText(getApplicationContext(), "Count:"+count, Toast.LENGTH_LONG).show();
		return super.onKeyDown(keyCode, event);
	}
}
