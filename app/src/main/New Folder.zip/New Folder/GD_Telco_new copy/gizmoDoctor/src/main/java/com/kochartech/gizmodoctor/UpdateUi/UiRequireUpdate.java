package com.kochartech.gizmodoctor.UpdateUi;

public interface UiRequireUpdate {
	public void runInBackGround();

	public void updateUI();
}
