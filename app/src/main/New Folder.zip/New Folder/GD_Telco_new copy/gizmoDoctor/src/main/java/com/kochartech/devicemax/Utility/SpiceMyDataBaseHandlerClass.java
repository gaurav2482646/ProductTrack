package com.kochartech.devicemax.Utility;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Activities.RegisterUserActivity;
import com.kochartech.gizmodoctor.R;

public class SpiceMyDataBaseHandlerClass extends SQLiteOpenHelper
{
	private String tag = "MyDataBaseHandlerClass"; 
	private SQLiteDatabase dba;
	public SpiceMyDataBaseHandlerClass(Context context, String name,	CursorFactory factory, int version) 
	{
		super(context, name, factory, version);
	}

	@Override
	public void onCreate(SQLiteDatabase arg0) {}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2){	}
	
	@Override
	public void onOpen(SQLiteDatabase db) 
	{
		dba= db;
		super.onOpen(db);
	}
	
	void createTable()
	{
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("email");
		arrayList.add("camera");
		arrayList.add("gmail");
		arrayList.add("google play store");
		arrayList.add("facebook");
		arrayList.add("browser");
		arrayList.add("internet");
		arrayList.add("youtube");
		arrayList.add("maps");
		arrayList.add("superuser");
//		arrayList.add("opera");
//		arrayList.add("firefox");
//		arrayList.add("chrome");
//		arrayList.add("messenger");
		
//		String[] strings = {"Gmail~com.google.android.gm~0~1",
//				"Browser~com.android.browser~0~1",
//				"Map~com.google.android.apps.maps~0~1",
//				"Market~com.google.android.finsky~0~1",
//				"Email~com.android.email~0~1",
//				"File manager~com.motorola.filemanager~0~1",
//				"YouTube~com.google.android.youtube~0~1",
//				"Inbuilt Camera app~com.sec.android.app.camera~0~1"};
		try
		{
//			dba.execSQL("CREATE TABLE IF NOT EXISTS AppsTable (AppName TEXT, AppPackageName TEXT PRIMARY KEY," +
//					" AppStatus INT, AppTimerStatus INT)");
			dba.execSQL("CREATE TABLE IF NOT EXISTS AppsTable (AppName TEXT, AppPackageName TEXT PRIMARY KEY," +
					" AppStatus INT, AppSize TEXT,thirdParty TEXT)");
			PackageManager pm = RegisterUserActivity.GetInstance().getPackageManager();
			List<ApplicationInfo> list =RegisterUserActivity.GetInstance().
			getPackageManager().getInstalledApplications(PackageManager.GET_UNINSTALLED_PACKAGES);
			LogWrite.d("Application Installed", "internal Apps ="+list.size());
//			Toast.makeText(, "Size ="+list.size(),Toast.LENGTH_LONG);
			for (int n = 0; n < list.size(); n++)
			{
				LogWrite.d("Application Installed", list.get(n).loadLabel(pm).toString());
				//
				if ((list.get(n).flags & ApplicationInfo.FLAG_SYSTEM) != 1)
				{
					// 1 to unblock apps  0 to block third party app
					if (!list.get(n).loadLabel(pm).toString().equalsIgnoreCase(RegisterUserActivity.GetInstance().getString(R.string.app_name)))
					{
						
						AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
								list.get(n).packageName,
								1,
								
								0,
								"E");
						
					}
					else if(arrayList.contains(list.get(n).loadLabel(pm).toString().toLowerCase()))
						{
							AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
								list.get(n).packageName,
								0,
								
								0,
								"E");
						}
				}
				//to block some apps given in the list
				else
				{
					if(arrayList.contains(list.get(n).loadLabel(pm).toString().toLowerCase()))
					{
						AddApplicationInfo(list.get(n).loadLabel(pm).toString(),
							list.get(n).packageName,
							0,
							0,
							
							"I");
					}
				}
			}
		}
		catch (Exception e) 
		{
			Log.e(tag,e+"");
		}
	}
	
	/* 
	 *   Insert Application in the DataBase
	 */
//	public void AddApplicationInfo(String AppName, String AppPackageName, int AppStatus, int AppTimerStatus)
	public void AddApplicationInfo(String AppName, String AppPackageName, int AppStatus, int previousDataUse,String internalExternal)
	{
		try
		{
//			dba.execSQL("INSERT INTO AppsTable values('"+AppName+"' , '"+AppPackageName+"' ,"+AppStatus+","+AppTimerStatus+" )");
			dba.execSQL("INSERT INTO AppsTable values('"+AppName+"' , '"+AppPackageName
					+"' ,"+AppStatus+" ,'"+previousDataUse+"' ,'"+internalExternal+"')");
			LogWrite.d(tag, "Insert Done----->"+AppPackageName+" status"+AppStatus);
			
			LogWrite.d("app name -------->",AppName);
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
	}
//	public long getLastUsage(String packageName){
//		Cursor c=dba.rawQuery("select previousDataUsed from AppsTable where AppPackageName = '"+packageName +"'",null);
//		c.moveToFirst();
//		if(c!=null)
//		return c.getInt(0);
//		return 0;
//	}
	
//public void updateAppDataUsage(String packageName , String appUsage){
//	try{		
////		long lastUsage=getLastUsage(packageName);
////		int currentUsage=Integer.parseInt(appUsage);
////		long usageNow=lastUsage+currentUsage;
//		//LogWrite.d(tag,"update AppsTable set presentDataUse ='" + appUsage +"' where AppPackageName like +'"+packageName+ "' ");
//			dba.execSQL("update AppsTable set PresentDataUsed ='" + appUsage +"' where AppPackageName like +'"+packageName+ "' " );
//			//LogWrite.d(tag,"query update done  ");
//	}catch(ExceptionDTO ex){
//		LogWrite.d(tag, ex.toString());
//	}	
//	}
// public void updatePreviousAppDataUsage(String packageName,String previousDataUsed)
// {
//	 try
//	 {
//		 dba.execSQL("update AppsTable set previousDataUsed ='" + previousDataUsed +"' where AppPackageName like +'"+packageName+ "' " );
//	 }
//	 catch(ExceptionDTO ex)
//	 {
//		 LogWrite.d("error during previous data updation", ex.toString());
//	 }
// }
// public Cursor getPreviousData(String packageName)
// {
//	 Cursor c=dba.rawQuery("SELECT PresentDataUsed FROM AppsTable WHERE AppPackageName='"+packageName+"'",null);
//	 return c;
// }
 public Cursor getAppPackage()
 {
	 Cursor c=dba.rawQuery("SELECT AppPackageName FROM AppsTable" ,null);
	 return c;
 }
	
	public String[] GetApplicationsFromDataBase()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.query("AppsTable",null , null, null, null, null,"AppName");
			string = new String[c.getCount()];
			c.moveToFirst();
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					LogWrite.d("in database class", c.getString(0)+"~"+c.getInt(2)+"~"+c.getInt(4)+"~"+c.getString(5));
//					if(c.getInt(4)>0)
//					{
					string[j] = c.getString(0)+"~"+c.getInt(2)+"~"+c.getInt(4)+"~"+c.getString(5);
					LogWrite.d(tag+"data usage greater than zero",string[j]);
				//	}
					//LogWrite.d("app status<<<<<<<<<",c.getString(0)+"  "+c.getString(3));
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	
//	public String[] GetApplicationsFromDataBaseInUnBlockedTime()
//	{
//		String[] string=null;
//		try
//		{
////			Cursor c=dba.query("AppsTable",null , null, null, null, null,"AppName");
//			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+" AND AppTimerStatus="+0+"", null);
//			string = new String[c.getCount()];
//			if(c.moveToFirst())
//			{
//				for (int j = 0; j < string.length; j++) 
//				{
//					string[j] = c.getString(1);
////					LogWrite.d(tag, "-->"+string[j]);
//					c.moveToNext();
//				}
//			}
//			c.close();
//		}
//		catch (ExceptionDTO e)
//		{
//			LogWrite.d(tag,e.toString());
//		}
//		return string;
//	}
	
	public String[] GetApplicationsFromDataBaseInBlockedTime()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+"", null);
			string = new String[c.getCount()];
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					string[j] = c.getString(1);
//					LogWrite.d(tag, "-->"+string[j]);
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	/**********************************************************/
	public String[] GetpackageFromDataBaseTime()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable ", null);
			string = new String[c.getCount()];
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					string[j] = c.getString(1);
//					LogWrite.d(tag, "-->"+string[j]);
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	
	public String[] GetApplicationFromDataBaseTime2()
	{
		String[] string=null;
		try
		{
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable ", null);
			string = new String[c.getCount()];
			if(c.moveToFirst())
			{
				for (int j = 0; j < string.length; j++) 
				{
					string[j] = c.getString(0);
//					LogWrite.d(tag, "-->"+string[j]);
					c.moveToNext();
				}
			}
			c.close();
		}
		catch (Exception e) 
		{
			LogWrite.d(tag,e.toString());
		}
		return string;
	}
	
	/*******************************************************************************/
	public void UpdateAppStatus(String app_name,int status)
	{
		try
		{
			LogWrite.d(tag, "UPDATE AppsTable SET AppStatus="+status+" WHERE AppName='"+app_name+"'");
			dba.execSQL("UPDATE AppsTable SET AppStatus="+status+" WHERE AppName='"+app_name+"'");
			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+"", null);
			if(c.moveToFirst())
			{
				for (int j = 0; j < c.getCount(); j++) 
				{
					LogWrite.d(tag, "-->"+c.getString(1)+ "   " +c.getString(2));
					c.moveToNext();
				}
			}	
			c.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void updatePresentDataCounter(String AppPackageName, long PresentDataUsed)
	{
		try
		{
//			LogWrite.d(tag, dba+"");
			
			Cursor c1=dba.rawQuery("SELECT previousDataUsed FROM AppsTable WHERE AppPackageName='"+AppPackageName+"'", null);
			long previousDataUse =0;
			if(c1!=null)
			{
				c1.moveToFirst();
				
				
				previousDataUse = Long.parseLong(c1.getString(0));
			}
//			int previousDataUse =0;
			
			LogWrite.d(tag, "UPDATE AppsTable SET PresentDataUsed='"+(PresentDataUsed+previousDataUse)+"' WHERE AppPackageName='"+AppPackageName+"'");
//			dba.execSQL("UPDATE AppsTable SET PresentDataUsed="+(PresentDataUsed+previousDataUse)+" WHERE AppPackageName='"+AppPackageName+"'");
//			Cursor c=dba.rawQuery("SELECT * FROM AppsTable WHERE AppStatus="+0+"", null);
//			c.close();
		}
		catch (Exception e) 
		{
			Log.e(tag, e.toString());
		}
	}
	
	public void DeleteApp(String appname)
	{
		try
		{
			LogWrite.d(tag, "Delete from AppsTable WHERE AppName='"+appname+"'");
			dba.execSQL("Delete from AppsTable WHERE AppName='"+appname+"'");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void DeleteAppbyPackage(String package_name)
	{
		try
		{
			LogWrite.d(tag, "Delete from AppsTable WHERE AppPackageName='"+package_name+"'");
			dba.execSQL("Delete from AppsTable WHERE AppPackageName='"+package_name+"'");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}