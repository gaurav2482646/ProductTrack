package com.kochartech.devicemax.Receivers;
//package com.kochar.MDMS;
//
//import java.util.Hashtable;
//
//import com.mdms.dm.ConvertHashTableToString;
//import com.mdms.dm.DmCommand;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.telephony.gsm.SmsMessage;
//import android.util.Log;
//import android.widget.Toast;
//
//public class SmsReceiver extends BroadcastReceiver {
//	String tag="SmsReceiver";
//	String message;
//	String str = "";
//	String key = "", value = "";
//	static String[] arrayMessagepart = new String[10];
//	int seqNo = 0, msgParts = 0;
//	int uidCounter = 0;
//	int seqCounter = 0;
//	int cNo = 0;
//	String uidComaparitive = "", masterUid = "";
//	String remainingMessage = "";
//	String command = "";
//	private Hashtable<String, String> htDMCommand;
//	@Override
//	public void onReceive(Context context, Intent intent) {
//		// TODO Auto-generated method stub
//		try 
//		{
//			Bundle bundle = intent.getExtras();
//			SmsMessage[] msgs = null;
//			
//			if (bundle != null) 
//			{
//				Object pdus[] = (Object[]) bundle.get("pdus");
//				msgs = new SmsMessage[pdus.length];
//				
//				for (int i = 0; i < pdus.length; i++) 
//				{
//					msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
//					str += msgs[i].getMessageBody().toString();
//				}
//				int index = str.indexOf("ChunkData");
//				int indexOfMessageId = str.indexOf("MessageID");
//				message = str.substring(index + 10, indexOfMessageId);
//				// LogWrite.d(tag, TagMakeDecision+ " Message-: " + message);
//				if (message.contains("KOCHAR-DM"))// Kochar-D
//				{
//					LogWrite.d(tag, tag + "contains kochar dm  ");
//					String messagePart = message;
//					String dm = "DM";
//					String uId = "UID";
//					messagePart = messagePart.substring(10, messagePart.length());
//					LogWrite.d(tag, tag + " messag part " + messagePart);
//					key = "";
//					char[] charArray = messagePart.toCharArray();
//					int arrayLength = charArray.length;
//				    
//					for (int i = 0; i < arrayLength; i++) {
//						if (charArray[i] == ':') // for-if 1
//						{
//							// LogWrite.d(tag, TagMakeDecision+ " : encountered " + key);
//							if (key.equals(dm)) {
//								// LogWrite.d(tag, TagMakeDecision+ " : key == dm ");
//								i++;
//								while (charArray[i] != ';') {
//									value += charArray[i];
//									i++;
//								}
//								String seqPrt[] = value.split("of");
//								seqNo = Integer.parseInt(seqPrt[0]);
//								msgParts = Integer.parseInt(seqPrt[1]);
//								key = "";
//								value = "";
//								// LogWrite.d(tag, TagMakeDecision+ "  seq :"+ seqNo +
//								// ", msgpart " + msgParts);
//							}// if
//						}// fro-if 1
//						else if (key.equals(uId)) {
//							i++;
//							while (charArray[i] != ';') {
//								value += charArray[i];
//								i++;
//							}
//							uidCounter++;
//							// LogWrite.d(tag,"uid counter " + i+ "****" + uidCounter);
//							if (uidCounter == 1) {
//								masterUid = value;
//								masterUid.split("_");
//							}
//							uidComaparitive = value;
//							// LogWrite.d(tag,"key+++value" + key + value);
//							key = "";
//							value = "";
//						} // end else if key.equals(uId))
//						else {
//							key += charArray[i];
//						}
//					}// end for
//					// LogWrite.d(tag, masterUid+"  "+uidComaparitive);
//					// comparison of uid with master uid
//					if (masterUid.equals(uidComaparitive)) {
//						// Toast.makeText(context1," uid comparison success ",
//						// 1000).show();
//						// LogWrite.d(tag, " Make decision. cmp success  ->" +msgParts);
//						if (msgParts != 1) {
//							// LogWrite.d(tag, TagMakeDecision+ " msg parts !=1  ");
//							// Toast.makeText(getApplicationContext()," msgparts!= 1",
//							// 1000).show();
//							seqCounter++;
//							AccumulateMessage(message.trim());
//						} else {
//							// LogWrite.d(tag, "msg parts equals 1  ");
//							seqCounter++;
//							arrayMessagepart[seqNo] = message;// messagePart.substring(0,messagePart.length()-2
//																// );
//							// remainingMessage=str;
//							// AccumulateMessage(message.trim());
//						}
//						if (seqCounter == msgParts) {
//							// LogWrite.d(tag, "seq == msg parts  ");
//							uidCounter = 0;
//							for (int i = 1; i <= msgParts; i++) {
//								remainingMessage += arrayMessagepart[i];
//							}
//							seqCounter = 0;
//							msgParts = 0;
//							seqNo = 0;
//							DmCommand formattedCommand = new DmCommand();
//
//							// LogWrite.d(tag, "remaining msg " + remainingMessage);
//							Hashtable<String, String> hashTableData = formattedCommand
//									.parseCompleteMessage(remainingMessage);
//							/**
//							 * fetching data part from the hashtable and removing it
//							 * from the same. so that it can be forwarded to
//							 * DMServer as an acknowledgement in case of commands
//							 * except startSession
//							 */
//							LogWrite.d(tag, "" + hashTableData.toString());
//							if (hashTableData.get("nothing") != null) {
//
//							} else {
//								ConvertHashTableToString ob1 = new ConvertHashTableToString();
//								String stringObtainedFromHashTable = ob1
//										.createMessageFromHashtable(hashTableData);
//								LogWrite.d(tag, "string from ht "
//										+ stringObtainedFromHashTable);
//								processCommand(stringObtainedFromHashTable,context);
//							}
//						}
//					}// end if master uid
//					else {
//						// LogWrite.d(TagMakeDecision, "cmp not success   ");
//						Toast.makeText(context,
//								"comparison not success ", 1000).show();
//						masterUid = "";
//						uidComaparitive = "";
//					}
//
//				}// if kocchar-DM
//					// }//while if check
//				else {
//					Toast.makeText(context,
//							"**Cant recieve String from server", 1000).show();
//					LogWrite.d(tag, "**Cant recieve String from server" + "#######");
//				}
//			
//				
//				
//				
//			}//end if
//			
//			}//end try
//		    catch(ExceptionDTO e)
//		    {
//		    	
//				LogWrite.d(tag, "exception:"+e);
//		    }		
//				
//				
//			
//	}//End onReceive
//	public void AccumulateMessage(String messagePart) {
//		try {
//			if (seqNo == 1) {
//				arrayMessagepart[seqNo] = messagePart.substring(0,
//						messagePart.length() - 2);
//				Log.i(tag, seqNo + " " + arrayMessagepart[seqNo]);
//				// Toast.makeText(getApplicationContext(),
//				// arrayMessagepart[seqNo] , Toast.LENGTH_SHORT).show();
//				// remainingMessage=messagePart.substring(0,messagePart.length()-2
//				// );
//			} else if (seqNo == msgParts) {
//				int index = messagePart.indexOf("<");
//				// Toast.makeText(context1, " Index of < ", 2000).show();
//				arrayMessagepart[seqNo] = messagePart.substring(index + 1,
//						messagePart.length());
//				Log.i(tag, seqNo + " " + arrayMessagepart[seqNo]);
//				// Toast.makeText(context1, "last part"+arrayMessagepart[seqNo]
//				// ,Toast.LENGTH_SHORT).show();
//			} else {
//				int index = messagePart.indexOf("<");
//				arrayMessagepart[seqNo] = messagePart.substring(index + 1,
//						messagePart.length() - 2);
//				Log.i(tag, seqNo + " " + arrayMessagepart[seqNo]);
//				// Toast.makeText(context1, arrayMessagepart[seqNo] ,
//				// Toast.LENGTH_SHORT).show();
//			}
//		} catch (ExceptionDTO ex) {
////			Toast.makeText(getApplicationContext(),
////					"accumulate " + ex.toString(), Toast.LENGTH_SHORT).show();
//			LogWrite.d(tag, "accumulate"+ex.toString());
//		}
//	}// Acumulate msg
//	
//	public void processCommand(String message,Context c) {
//
//		// final String TAG = "ProcessCommand";
//		// here we are putting the key value string received from Broadcast
//		// receiver into hashtable
//		htDMCommand = new ConvertHashTableToString().putInHashTable(message);
//		LogWrite.d(tag, "----------------------------------------------");
//		// get no of commandsgyui./tycD-1:STRTSESS;CMDINF-1:<>;
//		cNo = Integer.parseInt(htDMCommand.get("CNo"));
//		String messageInAction = "MN:" + htDMCommand.get("MN") + ";CNo:" + cNo
//				+ ";";
//
//		boolean flag = true; // this flag is to test whether acknowledgment will
//								// be sent or not
//		for (int i = 1; i <= cNo; i++) {
//			command = htDMCommand.get("CMD-" + i);
//			// Toast.makeText(getApplicationContext(), "command:->"+ command,
//			// 2000).show();
//			// Toast.makeText(getApplicationContext(),
//			// "HT Contents : "+htDMCommand.toString(), 2000).show();
//			
//			LogWrite.d(tag, "-----------------------" + command);
//			// Toast.makeText(getApplicationContext(), "MN : "+mobileNumber,
//			// 2000).show();
//
//			if (command.equals("STRTSESS")) {
//				
//				Intent intent=new Intent(c,PromptNumberActivity.class);
//				c.startActivity(intent);
//			}
//			else if (command.equals("ENDSESS")) {
//				
//			} 
//		}//End for
//	}//End processCommand
//			
//
//}
