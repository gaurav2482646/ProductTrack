//package com.kochartech.gizmodoctor.Activity;
//
//import android.app.Activity;
//import android.graphics.Color;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.LinearLayout;
//import android.widget.SeekBar;
//import android.widget.Toast;
//
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.HelperClass.LineGraph2;
//
//public class ActivityToTestUI extends Activity {
//	private SeekBar seekBar;
//	private LinearLayout containerLineGraph_CPUUsage,containerLineGraph_RAMUsage;
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		// TODO Auto-generated method stub
//		super.onCreate(savedInstanceState);
//
//		setContentView(R.layout.activitygraph_ui);
//		
//		
////		cpuLineGraph = new LineGraph2(this);
////		lineGraph2 = new LineGraph2(this);
////		
////		containerLineGraph_RAMUsage = (LinearLayout) findViewById(R.id.containerLineGraph_RAMUsage);
//		containerLineGraph_CPUUsage = (LinearLayout) findViewById(R.id.containerLineGraph_CPUUsage);
//		
////		containerLineGraph_CPUUsage.setBackgroundColor(Color.argb(0, 116, 120, 147));
////		containerLineGraph_CPUUsage.addView(cpuLineGraph.getView(),
////				new LinearLayout.LayoutParams(
////						LinearLayout.LayoutParams.FILL_PARENT,
////						LinearLayout.LayoutParams.FILL_PARENT, 1));
////		
////		containerLineGraph_RAMUsage.addView(lineGraph2.getView(),
////				new LinearLayout.LayoutParams(
////						LinearLayout.LayoutParams.FILL_PARENT,
////						LinearLayout.LayoutParams.FILL_PARENT, 1));
//		
//		
//		
//
//	}
//
//	public void onClick(View view) {
//
////		Toast.makeText(getApplicationContext(), "Click Work", Toast.LENGTH_LONG)
////				.show();
////
////		int[] xAxisPoints = new int[60];
////		int[] pointsToDraw = { 10, 20, 10, 3, 22, 10, 15, 30, 10, 30, 10, 20,
////				80, 30, 22, 100, 45, 30, 40, 30, 50, 20, 70, 3, 22, 10, 15, 30,
////				10, 30, 10, 20, 10, 3, 22, 10, 15, 80, 10, 30, 10, 20, 10, 3,
////				22, 10, 15, 30, 10, 30, 10, 20, 10, 80, 22, 10, 15, 30, 10, 30 };
////
////		for (int i = 0; i < 60; i++) {
////			xAxisPoints[i] = i;
////		}
////
////		cpuLineGraph.setAxsisPoint(pointsToDraw);
////		cpuLineGraph.refresh();
////		
////		
////		lineGraph2.setAxsisPoint(pointsToDraw);
////		lineGraph2.refresh();
//
//	}
//
////	private LineGraph2 cpuLineGraph,lineGraph2;
//
//}
