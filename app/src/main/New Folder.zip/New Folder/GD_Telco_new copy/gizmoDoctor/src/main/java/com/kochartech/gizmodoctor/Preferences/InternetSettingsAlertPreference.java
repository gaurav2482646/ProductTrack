//package com.kochartech.gizmodoctor.Preferences;
//
//import android.content.Context;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//
//public class InternetSettingsAlertPreference {
//	private final String PREFERENCE_NAME = "gizmodoctor";
//	private final int    PREFERENCE_MODE = 0;
//	
//	private final String ALERT_DATACONNECTION_OFF 	 = "dataConnection_isnot_working";
//	
//	public  final boolean DEFAULTVALUE_DATACONNECTION_OFF = false;
//	
//	private Context context;
//	private SharedPreferences myPreference;
//	private Editor editor;
//	
//	public InternetSettingsAlertPreference(Context context) {
//		this.context = context;
//		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
//				PREFERENCE_MODE);
//		editor = myPreference.edit();
//	}
//	
//	
//	public boolean isToAlertDataConnectionWorking() {
//		return myPreference.getBoolean(ALERT_DATACONNECTION_OFF, DEFAULTVALUE_DATACONNECTION_OFF);
//	}
//	
//	public void setDataConnectionAlert(boolean value) {
//		editor.putBoolean(ALERT_DATACONNECTION_OFF, value).commit();
//	}
//	
//	public void resetPreferences() {
//		setDataConnectionAlert(false);		
//	}
//}
