package com.kochartech.gizmodoctor.HelperClass;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint.Align;
import android.util.DisplayMetrics;
import android.util.TypedValue;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.POJO.AppUsageDTO;

public class LineGraph2 {

	private String TAG = "LineGraph2";

	private int lineWidthXYSeriesRenderer = 2;
	private int lineColorXYSeriesRenderer = Color.WHITE;
	private Context context;
	XYSeries xySeries;
	private XYSeriesRenderer xySeriesRenderer;
	XYMultipleSeriesRenderer mRenderer;
	XYMultipleSeriesDataset dataSet;
	int[] xAxisPoints = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };
	int[] pointsToDraw = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	SimpleDateFormat format = new SimpleDateFormat("hh:mm");
	ArrayList<Integer> xAxisPointsList = new ArrayList<Integer>();
	ArrayList<AppUsageDTO> pointsToDrawList = new ArrayList<AppUsageDTO>();
	GraphicalView chartView;

	public LineGraph2(Context context) {
		this.context = context;
		initXYSeriesObject();
		initXYSeriesRenderer();
		intiXYMultipleSeriesRenderer();
		initXYMultipleSeriesDataset();
		
	}

//	public LineGraph2(Context context, ArrayList<Integer> xAxisPointsList,
//			ArrayList<Integer> pointsToDrawList) {
//		this.context = context;
//		this.xAxisPointsList = xAxisPointsList;
//		this.pointsToDrawList = pointsToDrawList;
//
//		initXYSeriesObject();
//		initXYSeriesRenderer();
//		intiXYMultipleSeriesRenderer();
//		initXYMultipleSeriesDataset();
//	}

//	public void setDataSet(ArrayList<Integer> xAxisPointsList,
//			ArrayList<Integer> pointsToDrawList)
//	{
//		this.xAxisPointsList = xAxisPointsList;
//		this.pointsToDrawList = pointsToDrawList;
//	}

	
	private void initXYSeriesObject() {
		xySeries = new XYSeries("CPUUsage");
		for (int i = 0; i < xAxisPoints.length; i++)
			xySeries.add(xAxisPoints[i], pointsToDraw[i]);
	}

	private void initXYSeriesRenderer() {
		xySeriesRenderer = new XYSeriesRenderer();
		xySeriesRenderer.setLineWidth(lineWidthXYSeriesRenderer);
		xySeriesRenderer.setColor(lineColorXYSeriesRenderer);
//		xySeriesRenderer.setPointStrokeWidth(0);
//		xySeriesRenderer.setPointStyle(PointStyle.CIRCLE);
		xySeriesRenderer.setFillBelowLine(true);
		xySeriesRenderer.setFillBelowLineColor(Color.rgb(16,35,65));
//		xySeriesRenderer.setFillBelowLineColor(Color.argb(255,17, 133, 180));
//		xySeriesRenderer.setFillBelowLineColor(Color.parseColor("#111747"));
//		xySeriesRenderer.setFillBelowLineColor(R.drawable.gradient);
	}

//	public void setLineWidthXYSeriesRenderer(int lineWidthXYSeriesRenderer)
//	{
//		this.lineWidthXYSeriesRenderer = lineWidthXYSeriesRenderer;
//	}
//	public void setLineColorXYSeriesRenderer(int lineColorXYSeriesRenderer)
//	{
//		this.lineColorXYSeriesRenderer = lineColorXYSeriesRenderer;
//	}
	

	private void intiXYMultipleSeriesRenderer() {
		mRenderer = new XYMultipleSeriesRenderer();
		// To Disable ZOOm in out feature
		mRenderer.setPanEnabled(true, false);
		mRenderer.setZoomEnabled(false, false);

		// to Hide X axsis Labels
		// mRenderer.setXLabels(10);

		mRenderer.setShowLegend(false);
		// mRenderer.setLegendHeight(0);
		
		DisplayMetrics metrics1 = context.getResources().getDisplayMetrics();
		float left = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 20, metrics1);
		float right = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 30, metrics1);
		float top = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 30, metrics1);
		
		mRenderer.setMargins(new int[] { (int) left, (int) right, 0, (int) top });

		mRenderer.setYLabelsAlign(Align.RIGHT);
//		mRenderer.setMarginsColor(Color.BLACK);
		// mRenderer.
		// mRenderer.setXLabelsAlign();
		// mRenderer.setLegendHeight(0);
		mRenderer.addSeriesRenderer(xySeriesRenderer);
		// mRenderer.setZoomEnabled(false);
		// mRenderer.setXLabelsPadding(10);
		// mRenderer.setYLabelsPadding(10);
		mRenderer.setYLabels(4);
		mRenderer.addYTextLabel(100,"100%");
		mRenderer.addYTextLabel(50,"50%");
		mRenderer.addYTextLabel(25,"25%");
		mRenderer.addYTextLabel(75,"75%");

	
		
//		mRenderer.addXTextLabel(100, "100%");

		mRenderer.setXLabels(0);
		mRenderer.setXAxisMax(60);
		
//		long currentTime = System.currentTimeMillis();
//		long firstTime = currentTime - (30*60*1000);
//		long seconfTime = currentTime -(60*60*1000);
//		long thirdTime = currentTime - (90*60*1000);
//		long fourthTime = currentTime - (120*60*1000);
		
	
		
//		String currrentString = format.format(currentTime);
//		String firstString    = format.format(firstTime);
//		String secondString   = format.format(seconfTime);
//		String thirdString    = format.format(thirdTime);
//		String fourthString    = format.format(fourthTime);
		
		
//		LogWrite.d("ASHISH", "currrentString:"+currrentString);
//		LogWrite.d("ASHISH", "firstString:"+firstString);
//		LogWrite.d("ASHISH", "secondString:"+secondString);
//		LogWrite.d("ASHISH", "thirdString:"+thirdString);
		
//		mRenderer.addXTextLabel(0, currrentString);
//		mRenderer.addXTextLabel(30, firstString);
//		mRenderer.addXTextLabel(60, secondString);
//		mRenderer.addXTextLabel(90,thirdString);
//		mRenderer.addXTextLabel(120, fourthString);
		
		
		String[] xAxsisLabels = getXAxsisLabel();
		
		for(int i=0 ; i<xAxsisLabels.length ; i++)
		{
			if(i == 0)
				mRenderer.addXTextLabel(i, xAxsisLabels[i]);
			else
				mRenderer.addXTextLabel(i*diffXAxsisLabelsInMinutes, xAxsisLabels[i]);
		}
		
		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		float val = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 10, metrics);
		mRenderer.setLabelsTextSize(val);
		/*
		 * set Color of The Margins
		 */
//		mRenderer.setMarginsColor(Color.rgb(22, 57, 111));
		mRenderer.setMarginsColor(Color.parseColor("#00111747"));

		mRenderer.setAxesColor(Color.WHITE);
		mRenderer.setAxisTitleTextSize(val);
		/*
		 * User can not touch the Pan it helps Zoom in-out and also stop raphs
		 * moves forward and backward with swipe
		 */
		mRenderer.setPanEnabled(false, false);

		mRenderer.setYLabelsColor(0,Color.WHITE);
		mRenderer.setXLabelsColor(Color.WHITE);
		
		// Set Y axsis Min and Max value
		mRenderer.setYAxisMax(yAxisMax);
		mRenderer.setYAxisMin(yAxisMin);
		
		mRenderer.setShowGrid(false); // we show the grid
		mRenderer.setShowGridX(false); // we show the grid
		mRenderer.setShowGridY(true); // we show the grid
		mRenderer.setGridColor(Color.WHITE);
//		mRenderer.setGridColor(Color.rgb(30,66,113));
		// mRenderer.setInScroll(true);
		// mRenderer.setYLabelsAlign(Align.LEFT, 0);
		mRenderer.setApplyBackgroundColor(true);
//		mRenderer.setBackgroundColor(bgXYMultipleSeriesRenderer);
		mRenderer.setBackgroundColor(Color.parseColor("#001E2140"));
	}

	
	
//	private int 	bgXYMultipleSeriesRenderer  = Color.rgb(22, 57, 111);
//	private int 	bgXYMultipleSeriesRenderer  = Color.WHITE;
	private boolean isBackgroundGridVisible     = false;
//	private int     backgroundGridColor       = (Color.rgb(126,199,226));	
	private int yAxisMax=100,yAxisMin=0;
	
//	private void setYAxisMax(int yAxisMax)
//	{
//		this.yAxisMax = yAxisMax;
//	}
//	
//	private void setYAxisMin(int yAxisMin)
//	{
//		this.yAxisMin = yAxisMin;
//	}
//	public int getBgXYMultipleSeriesRenderer() {
//		return bgXYMultipleSeriesRenderer;
//	}
//
//	public void setBgXYMultipleSeriesRenderer(int bgXYMultipleSeriesRenderer) {
//		this.bgXYMultipleSeriesRenderer = bgXYMultipleSeriesRenderer;
//	}
//
//	public boolean isBackgroundGridVisible() {
//		return isBackgroundGridVisible;
//	}
//
//	public void setBackgroundGridVisible(boolean isBackgroundGridVisible) {
//		this.isBackgroundGridVisible = isBackgroundGridVisible;
//	}
//
//	public int getBackgroundGridColor() {
//		return backgroundGridColor;
//	}
//
//	public void setBackgroundGridColor(int backgroundGridColor) {
//		this.backgroundGridColor = backgroundGridColor;
//	}
	
	

	private void initXYMultipleSeriesDataset() {
		dataSet = new XYMultipleSeriesDataset();
		dataSet.addSeries(xySeries);
		chartView = ChartFactory.getLineChartView(context, dataSet, mRenderer);
		chartView.setPadding(0, 0, 0, 0);
	}

	public GraphicalView getView() {
		return chartView;
	}

	public void refresh(boolean isStatic) {

		
		// for(int i=xAxisPoints.length-2;i>=0;i--)
		// pointsToDraw[i+1] = pointsToDraw[i];
		// pointsToDraw[0] = newValue;
		// xySeries.clear();
		//
		// for(int i=0;i<xAxisPoints.length;i++) {
		// xySeries.add(xAxisPoints[i], pointsToDraw[i]);
		// }

//		LogWrite.d(TAG, "xAxisPoints: " + xAxisPoints.length);
//		LogWrite.d(TAG, "xAxisPoints: " + pointsToDraw.length);
		
//		int k = 120;
		
		xySeries.clear();
		for (int i = 0; i < pointsToDrawList.size() ; i++) {
			xySeries.add(i, pointsToDrawList.get(i).getAppUsage());
			
			LogWrite.d("KK",""+pointsToDrawList.get(i).getAppUsage());
		}

		chartView.repaint();
	}
		public void refresh() {

		
		// for(int i=xAxisPoints.length-2;i>=0;i--)
		// pointsToDraw[i+1] = pointsToDraw[i];
		// pointsToDraw[0] = newValue;
		// xySeries.clear();
		//
		// for(int i=0;i<xAxisPoints.length;i++) {
		// xySeries.add(xAxisPoints[i], pointsToDraw[i]);
		// }

//		LogWrite.d(TAG, "xAxisPoints: " + xAxisPoints.length);
//		LogWrite.d(TAG, "xAxisPoints: " + pointsToDraw.length);
		
//		int k = 120;
		
		xySeries.clear();
		for (int i = 0; i < pointsToDraw.length ; i++) {
			xySeries.add(i, pointsToDraw[i]);
			
//			LogWrite.d("KK",""+pointsToDrawList.get(i).getAppUsage());
		}

		chartView.repaint();
	}

//	public void setAxsisPoint(int[] xAxisPoints, int[] pointsToDraw) {
//		this.xAxisPoints = xAxisPoints;
//		this.pointsToDraw = pointsToDraw;
//	}
	public void setAxsisPoint(ArrayList<AppUsageDTO> pointsToDrawList) {
		this.pointsToDrawList = pointsToDrawList;
	}
	
	public void setAxsisPoint(int[] pointsToDraw) {
		this.pointsToDraw = pointsToDraw;
	}
	
	private  int numOfPoints = 60;
	private int diagnoseHours = 1;
	private int numOfXAxsisLabels = 3;
	long diffXAxsisLabelsInMinutes;
	public String[] getXAxsisLabel()
	{
		String[] xAxsisLabels = new String[4];
//		long diagnoseHoursInMinutes    = 1408512465518;
		long diagnoseHoursInMinutes    = diagnoseHours*60;
		diffXAxsisLabelsInMinutes = diagnoseHoursInMinutes / numOfXAxsisLabels;
		
		long currentTimeInMilliseconds = System.currentTimeMillis();
		xAxsisLabels[0] = format.format(currentTimeInMilliseconds);
		xAxsisLabels[1] = format.format(currentTimeInMilliseconds -(diffXAxsisLabelsInMinutes*60*1000));
		xAxsisLabels[2] = format.format(currentTimeInMilliseconds- (2*(diffXAxsisLabelsInMinutes*60*1000)));
		xAxsisLabels[3] = format.format(currentTimeInMilliseconds- (3*(diffXAxsisLabelsInMinutes*60*1000)));
		
		return xAxsisLabels;
	}
//	private ArrayList<Integer> pointsToDrawList;
}
