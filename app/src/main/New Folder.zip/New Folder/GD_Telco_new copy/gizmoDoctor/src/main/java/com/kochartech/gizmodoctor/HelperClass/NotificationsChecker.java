package com.kochartech.gizmodoctor.HelperClass;

import java.util.ArrayList;
import java.util.HashSet;

import android.content.Context;
import android.telephony.TelephonyManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.POJO.SettingStateDTO;
import com.kochartech.gizmodoctor.Preferences.GUISetNotificationPreference;
import com.kochartech.gizmodoctor.Preferences.NotificationAlertPreference;
import com.kochartech.gizmodoctor.deviceissues.CpuTemp;
import com.kochartech.gizmodoctor.deviceissues.StorageCapacity;
import com.kochartech.library.Battery.KTBatteryInfo;
import com.kochartech.library.CPU.KTUsageCPU;
import com.kochartech.library.Device.KTDeviceInfo;
import com.kochartech.library.Memory.KTMemoryInfo;
import com.kochartech.library.Memory.KTUsageRAM;

public class NotificationsChecker {

	private String TAG = NotificationsChecker.class.getSimpleName();

	private Context context;
	private KTBatteryInfo ktBatteryInfo;
	private NotificationAlertPreference notificationsAlertPreference;
	private GUISetNotificationPreference guiNotificationPreference;

	public NotificationsChecker(Context context) {

		this.context = context;
		ktBatteryInfo = KTBatteryInfo.getInstance();
		notificationsAlertPreference = new NotificationAlertPreference(context);
		guiNotificationPreference = new GUISetNotificationPreference(context);
	}

	public void check() {

		ktBatteryInfo.calculate(context);
		notificationsAlertPreference.resetPreferences();

		diagnoseTemperature();
		diagnoseLevel();
		diagnoseInternetConnection();
		// if (isRamMoreThen80perc() && isStorageMoreThen80perc()) {
		// LogWrite.e(TAG, "Device is getting slow!");
		// diagnoseDeviceSlowness();
		// } else
		diagnoseRAMLimit();

		diagnoseCPULimit();
		diagnoseSettingLimit();
		diagnoseCPUTemp();
	}

	private void diagnoseSettingLimit() {
		LogWrite.d(TAG, "In Setting Limit");
		boolean isToAlert = false;
		if (guiNotificationPreference.isSettingNotificationOn()) {
			SettingStateMonitor monitor = new SettingStateMonitor(context);
			ArrayList<SettingStateDTO> arrayList = monitor.getSettingState();
			for (SettingStateDTO settingStateDTO : arrayList) {
				LogWrite.d(TAG, settingStateDTO.getSettingName());
				if (settingStateDTO.getOnTime().equals("Off"))
					continue;
				String[] setting_time = settingStateDTO.getOnTime().split(":");
				int current = Integer.parseInt(setting_time[0]);
				int count = guiNotificationPreference.getSettingKeyToNotify();
				if (count < current) {
					isToAlert = true;
					notificationsAlertPreference
							.setSettingsNotificationAlert(true);

					NotificationHelper helper = NotificationHelper
							.getInstance(context);
					LogWrite.d(TAG, settingStateDTO.getSettingName() + current
							+ " hours.");
					helper.createNotification(settingStateDTO.getSettingName()
							+ " " + current + " hours.",
							NotificationHelper.ID_SETTINGS, true);
					guiNotificationPreference.setSettingKeyToNotify(current);
				}
			}
		}
		notificationsAlertPreference.setSettingsNotificationAlert(isToAlert);
	}

	private void diagnoseTemperature() {
		boolean isToAlert = false;
		if (guiNotificationPreference.getBatteryTemperature()) {
			int batteryTemperature = (int) ktBatteryInfo.getTemperature();
			LogWrite.d(TAG, "Battery Temperature: " + batteryTemperature);
			LogWrite.d(
					TAG,
					"Threshold Battery Temperature: "
							+ guiNotificationPreference
									.getBatteryTemperatureThresholdLimit());
			if (batteryTemperature >= guiNotificationPreference
					.getBatteryTemperatureThresholdLimit()) {
				LogWrite.d(TAG, "Battery Temperature: true");

				isToAlert = true;
				notificationsAlertPreference
						.setBatteryTemperature_WHILE_SCAN(batteryTemperature);

				NotificationHelper helper = NotificationHelper
						.getInstance(context);
				helper.createNotification(
						"Battery temperature is above than normal",
						NotificationHelper.ID_SETTINGS, true);
			}
		}
		notificationsAlertPreference.setAlert_Battery_Temperature(isToAlert);
	}

	private void diagnoseLevel() {
		boolean isToAlert = false;
		if (guiNotificationPreference.getBatteryLevel()) {
			int batteryLevel = (int) ktBatteryInfo.getBatteryLevel();
			if (batteryLevel < guiNotificationPreference
					.getBatteryLevelThresholdLimit()) {
				LogWrite.d(TAG, "Battery Level: true");
				isToAlert = true;
				notificationsAlertPreference
						.setBatteryLevel_WHILE_SCAN(batteryLevel);
				NotificationHelper helper = NotificationHelper
						.getInstance(context);
				helper.createNotification(
						"Battery level is less than "
								+ guiNotificationPreference
										.getBatteryLevelThresholdLimit() + "%",
						NotificationHelper.ID_SETTINGS, true);
			}
		}

		notificationsAlertPreference.setAlert_Battery_Level(isToAlert);
	}

	private void diagnoseInternetConnection() {
		boolean isToAlert = false;
		if (guiNotificationPreference.getDataConnection()) {

			KTDeviceInfo ktDeviceInfo = new KTDeviceInfo(context);
			if (!ktDeviceInfo.isWifiEnabled()) {
				TelephonyManager telephonyManagger = (TelephonyManager) context
						.getSystemService(Context.TELEPHONY_SERVICE);
				if (telephonyManagger.getDataState() == TelephonyManager.DATA_DISCONNECTED) {

					isToAlert = true;
					NotificationHelper helper = NotificationHelper
							.getInstance(context);
					helper.createNotification("Data connection is not working",
							NotificationHelper.ID_SETTINGS, true);
				}
			}
		}
		notificationsAlertPreference.setDataConnectionAlert(isToAlert);

	}

	private void diagnoseRAMLimit() {
		boolean isToAlert = false;
		LogWrite.d(TAG, "diagnoseRAMLimit: work");
		if (guiNotificationPreference.isRAMUsageNotificationOn()) {
			KTUsageRAM ktUsageRAM = new KTUsageRAM(context);
			KTMemoryInfo ktMemoryInfo = ktUsageRAM.getMeoryInfo();
			int currentRAMUsage = ktMemoryInfo.getUsedInPercentage();
			LogWrite.d(TAG, "currentRAMUsage: " + currentRAMUsage);
			if (currentRAMUsage > guiNotificationPreference
					.getRAMThreashHoldLimit()) {
				LogWrite.d(TAG, "Yes to Notify");
				isToAlert = true;
				NotificationHelper helper = NotificationHelper
						.getInstance(context);
				helper.createNotification("RAM Usage above than threshold",
						NotificationHelper.ID_SETTINGS, true);

			}
		}
		notificationsAlertPreference.setRAMNotificationAlert(isToAlert);
	}

	private void diagnoseCPULimit() {
		boolean isToAlert = false;
		LogWrite.d(TAG, "diagnoseCPULimit: work");

		if (guiNotificationPreference.isCPUUsageNotificationOn()) {
			KTUsageCPU ktUsageCPU = new KTUsageCPU(context);
			ktUsageCPU.refresh(5);
			int cpuUsage = ktUsageCPU.getTotalCPUUsage();
			LogWrite.d(TAG, "cpuUsage: " + cpuUsage);
			if (cpuUsage > guiNotificationPreference.getCPUThreashHoldLimit()) {
				LogWrite.d(TAG, "Yes to Notify");
				isToAlert = true;

				NotificationHelper helper = NotificationHelper
						.getInstance(context);
				helper.createNotification("CPU Usage above than threshold",
						NotificationHelper.ID_SETTINGS, true);
			}
		}
		notificationsAlertPreference.setCPUNotificationAlert(isToAlert);
	}

	private void diagnoseCPUTemp() {
		boolean isToAlert = false;
		LogWrite.d(TAG, "diagnoseCPULimit: work");
		if (guiNotificationPreference.getCPUTemperature()) {
			try {
				int cpuTemp = getCpuTemp();
				LogWrite.d(TAG, "CPU Temperature: " + cpuTemp);
				LogWrite.d(
						TAG,
						"Threshold CPU Temperature: "
								+ guiNotificationPreference
										.getCPUTemperatureThresholdLimit());
				if (cpuTemp > guiNotificationPreference
						.getCPUTemperatureThresholdLimit()) {
					LogWrite.d(TAG, "Yes to Notify");
					isToAlert = true;
					notificationsAlertPreference
							.setCpuTemperature_WHILE_SCAN(cpuTemp);
					NotificationHelper helper = NotificationHelper
							.getInstance(context);
					helper.createNotification("CPU is overheating",
							NotificationHelper.ID_SETTINGS, true);
				}
			} catch (Exception e) {
				LogWrite.e(TAG, "CpuTempException : " + e.toString());
			}
		}
		notificationsAlertPreference.setAlert_CPU_Temperature(isToAlert);
	}

	private int getCpuTemp() {
		CpuTemp cpuTemp = new CpuTemp(context);
		int temp = (int) cpuTemp.getCpuTemp();
		String str = "" + temp;
		String first2char = str.substring(0, 2);
		int currentTemp = Integer.parseInt(first2char);
		return currentTemp;
	}

	private void diagnoseDeviceSlowness() {
		NotificationHelper helper = NotificationHelper.getInstance(context);
		helper.createNotificationDialog("Device is getting slow",
				NotificationHelper.ID_DEVICE_SLOW, true);
	}

	private boolean isRamMoreThen80perc() {
		KTUsageRAM ktUsageRAM = new KTUsageRAM(context);
		KTMemoryInfo ktMemoryInfo = ktUsageRAM.getMeoryInfo();
		int currentRAMUsage = ktMemoryInfo.getUsedInPercentage();
		LogWrite.d(TAG, "currentRAMUsage: " + currentRAMUsage);
		if (currentRAMUsage > 70) {
			return true;
		}
		return false;
	}

	private boolean isStorageMoreThen80perc() {
		StorageCapacity storageCapacity = new StorageCapacity(context);
		String[] dirs = storageCapacity.getDirectories();
		ArrayList<String> directories = new ArrayList<String>();
		for (String directory : dirs) {
			if (!directory.contains("."))
				directories.add(directory);
		}
		String externalStorage = "";
		String internalStorage = "";
		if (directories.size() >= 2) {
			internalStorage = directories.get(0).toString();
			externalStorage = directories.get(1).toString();
		} else if (directories.size() < 2) {
			internalStorage = directories.get(0).toString();
			externalStorage = null;
		}
		if (externalStorage == null) {
			HashSet<String> hashset = storageCapacity.getExternalPaths();
			for (String string : hashset) {
				// LogWrite.e(TAG, "External Path : " + string);
				externalStorage = string;
			}
		}
		if (!internalStorage.equals("")) {
			// LogWrite.e(TAG, "Internal Storage : " + internalStorage);
			long availableCapacity = storageCapacity
					.getAvailableCapacity(internalStorage);
			// LogWrite.e(TAG, "availableCapacity : " + availableCapacity);
			long totalCapacity = storageCapacity
					.getTotalCapacity(internalStorage);
			// LogWrite.e(TAG, "totalCapacity : " + totalCapacity);
			int usedInternalStorage = (int) (((float) (totalCapacity - availableCapacity) / totalCapacity) * 100);
			LogWrite.i(TAG, "InternalStorageUsage : " + usedInternalStorage);
			if (usedInternalStorage > 75) {
				return true;
			}
		}
		if (externalStorage != null) {
			// LogWrite.e(TAG, "External Storage : " + externalStorage);
			long availableCapacity = storageCapacity
					.getAvailableCapacity(externalStorage);
			// LogWrite.e(TAG, "availableCapacity : " + availableCapacity);
			long totalCapacity = storageCapacity
					.getTotalCapacity(externalStorage);
			// LogWrite.e(TAG, "totalCapacity : " + totalCapacity);
			int usedExternalStorage = (int) (((float) (totalCapacity - availableCapacity) / totalCapacity) * 100);
			LogWrite.i(TAG, "ExternalStorageUsage : " + usedExternalStorage);
		}
		return false;
	}

}
