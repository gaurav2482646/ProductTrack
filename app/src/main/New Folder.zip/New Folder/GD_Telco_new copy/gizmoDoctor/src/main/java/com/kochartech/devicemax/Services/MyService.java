//package com.kochartech.devicemax.Services;
//
//import android.app.IntentService;
//import android.content.Intent;
//
//import com.kochartech.devicemax.Activities.*;
//
//public class MyService extends IntentService
//{
//	String TAG = "CheckLockScreenService";
//
//	public MyService()
//	{
//		super("MyService");
//	}
//
//	@Override
//	protected void onHandleIntent(Intent intent)
//	{
//		LogWrite.d("TAG", "started Service");
//		while (LockScreenActivity.stopServiceFlag)
//		{
//			LogWrite.d(TAG, "before toggling stop service flag "	+ LockScreenActivity.stopServiceFlag);
//			if (!LockScreenActivity.lockScreenFocus)
//			{
//				LogWrite.d(TAG, "before toggling flag "	+ LockScreenActivity.lockScreenFocus);
//				LockScreenActivity.lockScreenFocus = true;
//				LogWrite.d(TAG, "about to start activity "+ LockScreenActivity.lockScreenFocus);
//				Intent myIntent = new Intent(this, LockScreenActivity.class);
//				myIntent.setFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
//				startActivity(myIntent);
//			} 
//			else
//			{
//				LogWrite.d(TAG, "Value of boolean Var "	+ LockScreenActivity.lockScreenFocus);
//			}
//			try
//			{
//				Thread.sleep(3000);
//			} 
//			catch (InterruptedException e)
//			{
//				e.printStackTrace();
//			}
//		}
//
//	}
//
//}
