package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class ActivationKeyPreference
{
	private final String PREFERENCE_NAME = "gizmodoctor";
	private final int    PREFERENCE_MODE = 0;

	private final String KEY_ActivationKey  		 = "activation_key";
	private final String KEY_Timeleft 				 = "time_left";
	private final String KEY_LastScanTime 			 = "last_scan_time";
	private final String KEY_IsActivationKeyRegister = "is_activation_key_register";
	
	public  final String  DEFAULTVALUE_ActivationKey = "";
	public  final long    DEFAULTVALUE_timeleft      = 0;
	public  final long    DEFAULTVALUE_lastScanTime  = System.currentTimeMillis();
	private final boolean DEFAULTVALUE_isActivationKeyRegister = false;

	private Context context;
	private SharedPreferences myPreference;
	private Editor editor;

	public ActivationKeyPreference(Context context) {
		this.context = context;
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,PREFERENCE_MODE);
		editor = myPreference.edit();
	}

	public String getActivationKey() {
		return myPreference.getString(KEY_ActivationKey, DEFAULTVALUE_ActivationKey);
	}
	
	public void setActivationKey(String value) {
		editor.putString(KEY_ActivationKey, value).commit();
	}
	
	
	public long getLeftTime() {
		return myPreference.getLong(KEY_Timeleft, DEFAULTVALUE_timeleft);
	}
	
	public void setLeftTime(long value) {
		editor.putLong(KEY_Timeleft, value).commit();
	}
	
	
	
	public long getLastScanTime() {
		return myPreference.getLong(KEY_LastScanTime, DEFAULTVALUE_lastScanTime);
	}
	
	public void setLastScanTime(long value) {
		editor.putLong(KEY_LastScanTime, value).commit();
	}
	
	
	
	public boolean isActivationKeyRegister() {
		return myPreference.getBoolean(KEY_IsActivationKeyRegister, DEFAULTVALUE_isActivationKeyRegister);
	}
	
	public void setIsActivationKeyRegister(Boolean value) {
		editor.putBoolean(KEY_IsActivationKeyRegister, value).commit();
	}

	
	 
	public void resetAll() {
		
		setIsActivationKeyRegister(false);
		editor.clear().commit();
	
	}

	
}
