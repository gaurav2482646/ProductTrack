package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class AppFirstRunPreference {

	public final String PREFERENCE_NAME = "gizmodoctor_flipkart";
	public final int PREFERENCE_MODE = 0;
	
	public SharedPreferences myPreference;
	public Editor editor;
	
	public final String  IS_APPLICATION_FIRSTRUN = "is_application_firstrun";
	public final boolean DEFAULTVALUE_IS_APPLICATION_FIRSTRUN = true;
	
	public AppFirstRunPreference(Context context) {
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();
	}
	
	
	public void setApplicationFirstRun(boolean value) {
		editor.putBoolean(IS_APPLICATION_FIRSTRUN, value).commit();
	}
	
	public boolean isApplicationFirstRun() {
		return myPreference.getBoolean(IS_APPLICATION_FIRSTRUN, DEFAULTVALUE_IS_APPLICATION_FIRSTRUN);
	}	

}
