package com.kochartech.MyLibs;

import java.util.List;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

public class MyWifiManager
{
	private static WifiManager wifiManager = null;
	private static ConnectivityManager connManager;
	private static NetworkInfo mWifi ;
	private static WifiInfo wifiInfo;
	public static boolean isWifiEnabled(Context context)
	{
		if(wifiManager == null)
			wifiManager = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
		return wifiManager.isWifiEnabled();
	}
	public static boolean isWifiConnected(Context context)
	{
		connManager = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
		mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		return mWifi.isConnected();
	}
	public static boolean setWifiState(Context context,boolean flag)
	{
		if(wifiManager == null)
			wifiManager = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
		return wifiManager.setWifiEnabled(flag);
	}
	public static String getSSID(Context context)
	{
		if(wifiManager == null)
			wifiManager = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
		wifiInfo = wifiManager.getConnectionInfo();
		return wifiInfo.getSSID();
	}
	
	public static boolean hasSaveWifiProfile(Context context)
	{
		if(wifiManager == null)
			wifiManager = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
		
		List<WifiConfiguration> wifiConfiguration = wifiManager.getConfiguredNetworks();
//		Logger.d("WifiA","wifiConfiguration :"+wifiConfiguration.size());
		if(wifiConfiguration != null)
		{
			return (wifiConfiguration.size()>0)?true:false;
		}
		return false;
	}
}
