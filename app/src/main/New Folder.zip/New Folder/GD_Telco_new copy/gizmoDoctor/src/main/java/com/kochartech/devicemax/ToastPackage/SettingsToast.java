package com.kochartech.devicemax.ToastPackage;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.devicemax.Activities.MDMMainActivity;
import com.kochartech.gizmodoctor.R;

public class SettingsToast implements OnClickListener, SettingsToast_Messages {

	public static final int ARROW_UP = 0;
	public static final int ARROW_DOWN = 1;
	public static final int GRAVITY_Top = Gravity.TOP;
	public static final int GRAVITY_CENTER = Gravity.CENTER;
	public static final int GRAVITY_BOTTOM = Gravity.BOTTOM;

	private String tag = "SettingsToast";
	private Activity activityContext;
	private LayoutInflater inflater;
	private View layout;
	private TextView textview;
	private Toast toast;
	private Timer timer;
	private int timerCount = 0;
	private TimerTask timerTask;
	private static SettingsToast settingsToast = null;
	private boolean state = true;

	public static SettingsToast openSingleInstance() {
		if (settingsToast == null) {
			settingsToast = new SettingsToast();
		}
		return settingsToast;
	}

	public void setActivityActiveState(boolean state) {
		this.state = state;
		LogWrite.d(tag + "ashish", "....State ===" + state);
	}

	public void show(Context context, String message, int arrowDirection,
			int gravity) {
		LogWrite.d(tag, "Work...");
		LogWrite.d(tag, "Message..." + message);
		try {
			// this.activityContext = (Activity) context;
			this.activityContext = MDMMainActivity.mdmActivity;
			// typeFace =
			// Typeface.createFromAsset(activityContext.getAssets(),"fonts/fonnt.ttf");
			inflater = activityContext.getLayoutInflater();
			// inflater = (LayoutInflater)
			// context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			if (arrowDirection == ARROW_UP)
				layout = inflater.inflate(R.layout.settings_toast_arrow_up,
						null);
			else
				layout = inflater.inflate(R.layout.settings_toast_arrow_down,
						null);
			// layout.setOnClickListener(this);
			textview = (TextView) layout
					.findViewById(R.id.settingstoast_textview);
			textview.setText(message);
			// textview.setTypeface(typeFace);
			toast = new Toast(activityContext);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.setView(layout);
			timerCount = 0;
			timer = new Timer();
			timerTask = new TimerTask() {
				@Override
				public void run() {
					try {
						if (state == true) {
							toast.cancel();
							timer.cancel();
						} else {
							if (timerCount == 20) {
								toast.cancel();
								timer.cancel();
							} else {
								timerCount++;
								toast.show();
							}
						}
						LogWrite.d(tag, "State =" + state);
						LogWrite.d(tag, "Timer is Running");
					} catch (Exception e) {
						Log.e(tag, "ExceptionDTO....." + e.toString());
					}
				}
			};
			timer.schedule(timerTask, 3000, 500);
			LogWrite.d(tag, "Finsih Sucessfully");
		} catch (Exception e) {
			LogWrite.d(tag, "ExceptionDTO....." + e);
		}
	}

	public void cancel() {
		try {
			toast.cancel();
			timer.cancel();
			state = true;
		} catch (Exception e) {
			Log.e(tag, "ExceptionDTO...." + e.toString());
			// Toast.makeText(activityContext, ""+e, Toast.LENGTH_LONG).show();
		}
	}

	@Override
	public void onClick(View v) {
		cancel();
		// Toast.makeText(activityContext, ""+e, Toast.LENGTH_LONG).show();
	}

}
