package com.kochartech.gizmodoctor.Activity;

import android.app.Activity;
import android.os.Bundle;

import com.kochartech.gizmodoctor.R;

public class Activity_LicenceKeyExpire extends Activity {

//	private String TAG = Activity_LicenceKeyExpire.class.getSimpleName();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.licencekeyexpire_activity);
	}
}
