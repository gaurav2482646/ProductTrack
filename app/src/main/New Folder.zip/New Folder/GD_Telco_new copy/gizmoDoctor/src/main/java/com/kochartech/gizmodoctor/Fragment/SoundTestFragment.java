//package com.kochartech.gizmodoctor.Fragment;
//
//import android.app.Activity;
//import android.content.Context;
//import android.content.SharedPreferences;
//import android.content.SharedPreferences.Editor;
//import android.media.AudioManager;
//import android.media.MediaPlayer;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.PowerManager;
//import android.os.Vibrator;
//import android.support.v4.app.Fragment;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.ViewGroup;
//import android.view.WindowManager.LayoutParams;
//import android.widget.Button;
//import android.widget.TextView;
//
//import com.kochartech.devicemax.Activities.LogWrite;
//import com.kochartech.gizmodoctor.R;
//import com.kochartech.gizmodoctor.Activity.FragmentListener;
//import com.kochartech.gizmodoctor.Activity.OnCommandListener;
//import com.kochartech.gizmodoctor.CustomView.SoundLevelView;
//import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar;
//import com.kochartech.gizmodoctor.HardwareModel.CircularProgressBar.ProgressAnimationListener;
//import com.kochartech.gizmodoctor.HardwareModel.SoundMeter;
//
//public class SoundTestFragment extends Fragment implements OnClickListener {
//	private String TAG = SoundTestFragment.class.getSimpleName();
//
//	private static Activity activity;
//	private View rootView;
//	private TextView textView;
//	private Button button;
//	private boolean isFromCommand = false;
//	public static final String KEY_ISFROMCOMMAND = "isfromcommand";
//	private OnCommandListener onCommandListener = null;
//	private boolean isClickWork = false;
//
//	private boolean vibrate = false;
//
//	/* constants */
//	private static final int POLL_INTERVAL = 300;
//
//	/** running state **/
//	private boolean mRunning = false;
//
//	/** config state **/
//	private int mThreshold;
//
//	private PowerManager.WakeLock mWakeLock;
//
//	private Handler mHandler = new Handler();
//
//	private SoundLevelView mDisplay;
//
//	/* sound data source */
//	private SoundMeter mSensor;
//
//	private MediaPlayer player = null;
//
//	private CircularProgressBar timerProgress;
//
//	private boolean success = false;
//	private String FAILURE_MESSAGE = "Press OK if Sound test not working";
//	private Button okButton;
//
//	private static boolean appAlreadyWorkingFlag = false;
//
//	/****************** Define runnable thread again and again detect noise *********/
//
//	private Runnable mSleepTask = new Runnable() {
//		public void run() {
//			// Log.i("Noise", "runnable mSleepTask");
//			start();
//		}
//	};
//
//	// Create runnable thread to Monitor Voice
//	private Runnable mPollTask = new Runnable() {
//		public void run() {
//			double amp;
//			try {
//				amp = mSensor.getAmplitude();
//			} catch (ExceptionDTO e) {
//				e.printStackTrace();
//				amp = 0;
//			}
//			if (amp >= 8) {
//				if (!success) {
//					// Log.i("Noise", "runnable mPollTask");
//					success = true;
//					updateDisplay("Monitoring Voice...", amp);
//				}
//			}
//
//			// if ((amp > mThreshold)) {
//			// callForHelp();
//			// // Log.i("Noise", "==== onCreate ===");
//			//
//			// }
//
//			// Runnable(mPollTask) will again execute after POLL_INTERVAL
//			mHandler.postDelayed(mPollTask, POLL_INTERVAL);
//
//		}
//	};
//
//	public SoundTestFragment(OnCommandListener onCommandListener) {
//		this.onCommandListener = onCommandListener;
//	}
//
//	@Override
//	public View onCreateView(LayoutInflater inflater, ViewGroup container,
//			Bundle savedInstanceState) {
//		getActivity().getWindow()
//				.setFlags(
//						0xFFFFFFFF,
//						LayoutParams.FLAG_FULLSCREEN
//								| LayoutParams.FLAG_KEEP_SCREEN_ON);
//
//		initDataSet();
//		initUi(inflater, container);
//		return rootView;
//	}
//
//	private void initDataSet() {
//		Bundle bundle = getArguments();
//		if (bundle != null) {
//			if (bundle.containsKey(KEY_ISFROMCOMMAND)) {
//				isFromCommand = bundle.getBoolean(KEY_ISFROMCOMMAND);
//			}
//		}
//	}
//
//	@SuppressWarnings("deprecation")
//	private void initUi(LayoutInflater inflater, ViewGroup container) {
//		activity = getActivity();
//		rootView = inflater
//				.inflate(R.layout.fragment_speaker, container, false);
//		textView = (TextView) rootView.findViewById(R.id.textView);
//		textView.setText(R.string.speaker_screen);
//		button = (Button) rootView.findViewById(R.id.button_play);
//
//		// Used to record voice
//		mSensor = new SoundMeter();
//		mDisplay = (SoundLevelView) rootView.findViewById(R.id.volume);
//
//		PowerManager pm = (PowerManager) activity
//				.getSystemService(Context.POWER_SERVICE);
//		mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK,
//				"NoiseAlert");
//		button.setOnClickListener(this);
//
//		okButton = (Button) rootView.findViewById(R.id.ok_button);
//		okButton.setOnClickListener(this);
//
//		timerProgress = (CircularProgressBar) rootView
//				.findViewById(R.id.circularprogressbar2);
//		timerProgress.animateProgressTo(10, 0, new ProgressAnimationListener() {
//
//			@Override
//			public void onAnimationStart() {
//			}
//
//			@Override
//			public void onAnimationProgress(int progress) {
//				timerProgress.setTitle(progress + "");
//				timerProgress.setSubTitle("");
//			}
//
//			@Override
//			public void onAnimationFinish() {
//				if (!success) {
//					button.setVisibility(View.GONE);
//					textView.setText(FAILURE_MESSAGE);
//					textView.setTextAppearance(activity, R.style.textStyleRed);
//					okButton.setVisibility(View.VISIBLE);
//					timerProgress.setSubTitle("");
//					timerProgress.setVisibility(View.GONE);
//				}
//			}
//		});
//	}
//
//	@Override
//	public void onDestroy() {
//		super.onDestroy();
//		LogWrite.i(TAG, "OnDestroy Method Enters.............");
//		if (null != player) {
//			player.release();
//		}
//		stop();
//		// if (getToSendFlag()) {
//		// if (onCommandListener != null) {
//		// onCommandListener.onCommand(getToSendFlag());
//		// }
//		// }
//		appAlreadyWorkingFlag = false;
//		LogWrite.i(TAG, "GetToSendFlag : " + appAlreadyWorkingFlag);
//	}
//
//	@Override
//	public void onPause() {
//		super.onPause();
//		LogWrite.i(TAG, "OnPause Method Enters.............");
//		// if (player != null)
//		// player.stop();
//		// stop();
//		// if (getToSendFlag()) {
//		// if (onCommandListener != null) {
//		// onCommandListener.onCommand(getToSendFlag());
//		// }
//		// }
//	}
//
//	@Override
//	public void onResume() {
//		super.onResume();
//		LogWrite.i(TAG, "OnResume Method Enters.............");
//		LogWrite.i(TAG, "GetToSendFlag : " + appAlreadyWorkingFlag);
//		if (!appAlreadyWorkingFlag) {
//
//			initializeApplicationConstants();
//			mDisplay.setLevel(0, mThreshold);
//		} else {
//			// onCommandListener.onCommand(getToSendFlag());
//			FragmentListener fragmentListener = (FragmentListener) getActivity();
//			fragmentListener.onItemClicked(FragmentListener.actionRemove,
//					SoundTestFragment.this);
//			// fragmentListener.onItemClicked(FragmentListener.actionRemove,
//			// SoundTestFragment.this);
//		}
//		// playMusic(getActivity());
//	}
//
//	private void start() {
//		// Log.i("Noise", "==== start ===");
//
//		mSensor.start();
//		if (!mWakeLock.isHeld()) {
//			mWakeLock.acquire();
//		}
//
//		// Noise monitoring start
//		// Runnable(mPollTask) will execute after POLL_INTERVAL
//		mHandler.postDelayed(mPollTask, POLL_INTERVAL);
//	}
//
//	private void stop() {
//		Log.i("Noise", "==== Stop Noise Monitoring===");
//		if (mWakeLock.isHeld()) {
//			mWakeLock.release();
//		}
//		mHandler.removeCallbacks(mSleepTask);
//		mHandler.removeCallbacks(mPollTask);
//		mSensor.stop();
//		mDisplay.setLevel(0, 0);
//		updateDisplay("stopped...", 0.0);
//		mRunning = false;
//
//	}
//
//	private void initializeApplicationConstants() {
//		// Set Noise Threshold
//		mThreshold = 8;
//
//	}
//
//	private void updateDisplay(String status, double signalEMA) {
//		int signal = (int) signalEMA;
//		LogWrite.i(TAG, "Signal : " + signal);
//		if (signal >= mThreshold) {
//			if (!vibrate) {
//				textView.setText(R.string.speaker_is_working_fine);
//				textView.setTextAppearance(getActivity(),
//						R.style.textStyleGreen);
//
//				Vibrator vibrator = (Vibrator) activity
//						.getSystemService(Context.VIBRATOR_SERVICE);
//				vibrator.vibrate(500);
//				try {
//					Thread.sleep(2000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				vibrate = true;
//				stop();
//				player.stop();
//				player.release();
//				LogWrite.e("Aman", "IS FROM COMMMAND...... " + isFromCommand);
//				LogWrite.e("Aman", "After 2 Seconds....");
//				success = true;
//				timerProgress.setVisibility(View.GONE);
//				if (isFromCommand) {
//					onCommandListener.onCommand(true);
//					FragmentListener fragmentListener = (FragmentListener) getActivity();
//					fragmentListener.onItemClicked(
//							FragmentListener.actionRemove,
//							SoundTestFragment.this);
//					// fragmentListener.onItemClicked(
//					// FragmentListener.actionRemove,
//					// SoundTestFragment.this);
//					appAlreadyWorkingFlag = true;
//					setToSendFlag();
//				} else {
//					button.setClickable(true);
//					button.setBackgroundDrawable(getResources().getDrawable(
//							R.drawable.button_selector));
//				}
//				isClickWork = true;
//			}
//		} else {
//			vibrate = false;
//			if (success) {
//
//			}
//		}
//
//		mDisplay.setLevel(signal, mThreshold);
//	}
//
//	@Override
//	public void onClick(View v) {
//		if (v.getId() == R.id.ok_button) {
//			Vibrator vibrator = (Vibrator) activity
//					.getSystemService(Context.VIBRATOR_SERVICE);
//			vibrator.vibrate(500);
//			textView.setText("Speaker test fails.");
//			if (isFromCommand) {
//				onCommandListener.onCommand(false);
//				FragmentListener fragmentListener = (FragmentListener) getActivity();
//				fragmentListener.onItemClicked(FragmentListener.actionRemove,
//						this);
//				// FragmentListener fragmentListener = (FragmentListener)
//				// getActivity();
//				// fragmentListener.onItemClicked(FragmentListener.actionRemove,
//				// SoundTestFragment.this);
//			}
//			okButton.setVisibility(View.GONE);
//		} else {
//			success = false;
//			button.setClickable(false);
//			button.setBackgroundDrawable(getResources().getDrawable(
//					R.drawable.button_bg_pressed));
//			playMusic(getActivity().getApplicationContext());
//		}
//	}
//
//	private void playMusic(Context context) {
//		if (player != null)
//			player.release();
//
//		player = MediaPlayer.create(getActivity(), R.raw.siren);
//		player.setVolume(1f, 1f);
//		player.setLooping(false);
//		try {
//			AudioManager audioManager = (AudioManager) context
//					.getSystemService(Context.AUDIO_SERVICE);
//			audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 20, 0);
//			player.start();
//		} catch (ExceptionDTO e) {
//			e.printStackTrace();
//		}
//		// if (player.isPlaying()) {
//		if (!mRunning) {
//			mRunning = true;
//			start();
//		}
//		// }
//	}
//
//	//
//	private boolean getToSendFlag() {
//		SharedPreferences sharedPreferences = getActivity()
//				.getSharedPreferences("SoundTestFrtagment",
//						Context.MODE_PRIVATE);
//		return sharedPreferences.getBoolean("SENDFLAG", false);
//	}
//
//	private void setToSendFlag() {
//		SharedPreferences sharedPreferences = getActivity()
//				.getSharedPreferences("SoundTestFrtagment",
//						Context.MODE_PRIVATE);
//		Editor editor = sharedPreferences.edit();
//		editor.putBoolean("SENDFLAG", true);
//		editor.commit();
//
//	}
//
//	public static void clear() {
//		SharedPreferences sharedPreferences = activity.getSharedPreferences(
//				"SoundTestFrtagment", Context.MODE_PRIVATE);
//		Editor editor = sharedPreferences.edit();
//		editor.clear().commit();
//	}
//	// private float getVolume(Context context) {
//	// AudioManager audioManager =
//	// (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
//	// audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 20, 0);
//	// float currVolume=(float)audioManager.getInt("volume", 10);
//	// float maxVolume=15.0f;
//	// float result=currVolume/maxVolume;
//	// return result;
//	// }
//}
