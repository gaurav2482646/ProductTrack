package com.kochartech.devicemax.Receivers;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.R;

public class StartTestReceiver extends BroadcastReceiver {
	Context statsContext;
	String TAG = "StartTestReceiver";
	// private String VALUE = "http://192.165.0.15/1mb/1mb.zip";
	private String VALUE = "http://202.164.36.66/1mb/1mb.zip";
	private String SERVERURL = "";
	// private String SERVERURL
	// ="http://192.161.0.9/SpiceHandler/mdmshandler.ashx";
	// private String SERVERURL
	// ="http://192.161.0.9/HttpHandler/mdmshandler.ashx";
	long time1, time2;
	String downloadSpeed = "NA", imei = "NA", imsi = "NA",
			fileTransferStatus = "NA";
	String cellId = "NA";
	String lac = "NA";
	String latency = "Failure", packetloss = "0";;
	// String networkName="Unknown";
	int signalStrength = 0;
	String latitude = "", longitude = "";
	String bearerInfo = "";
	String url = "http://202.164.36.66/1mb/1mb.zip";
	String transferSize = "";
	String startDateTime = "NA", endDateTime = "NA";// stats start and end date
													// time
	String phoneNumber = "NA";

	@Override
	public void onReceive(Context context, Intent intent) {
		LogWrite.d(TAG, "Speed Test Called...");
		statsContext = context;
		/**
		 * Server URL
		 */
		SERVERURL = context.getString(R.string.ServerUrl).trim();
		LogWrite.d(TAG, "Server URL : " + SERVERURL);
		int count = PreferenceManager.getDefaultSharedPreferences(
				statsContext.getApplicationContext()).getInt("count", 0);
		LogWrite.d(TAG, "Count -----------> " + count);

		// if(count>=864)
		if (count >= 144) {
			Intent startTestIntent = new Intent(context,
					StartTestReceiver.class);
			AlarmManager alarmManager = (AlarmManager) context
					.getSystemService(context.ALARM_SERVICE);
			PendingIntent pendingstartTestIntent = PendingIntent
					.getBroadcast(context.getApplicationContext(), 232324,
							startTestIntent, 0);
			alarmManager.cancel(pendingstartTestIntent);
			LogWrite.d("Ashis1", "Receiver Stoped ");
			SharedPreferences sharePrefernce = PreferenceManager
					.getDefaultSharedPreferences(statsContext
							.getApplicationContext());
			Editor editor = sharePrefernce.edit();
			editor.putInt("count", 0);
			editor.commit();
		} else {
			LogWrite.d(TAG, "Speed Test going to be Start");
			count++;
			LogWrite.d(TAG, "Count =" + count);
			SharedPreferences sharePrefernce = PreferenceManager
					.getDefaultSharedPreferences(statsContext
							.getApplicationContext());
			Editor editor = sharePrefernce.edit();
			editor.putInt("count", count);
			editor.commit();
			new DownloadAsyncTask().execute(context);
		}

	}

	// ==================== WEB ASYNCTASK ========================
	public class DownloadAsyncTask extends AsyncTask<Context, Integer, Integer> {
		private String tag = "DownloadAsyncTask";
		String fileName = null;
		File filetoDelete;
		String networkName = "NA";

		/**
		 * Before starting background thread Show Progress Bar Dialog
		 * */

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			PhoneStateListener phonestate = new PhoneStateListener() {
				public void onSignalStrengthChanged(int asu) {
					signalStrength = asu;
					int dbm = -113 + (2 * asu); // Asu range to 0 to -113
												// Same is formula to calulate
												// signal strength
					dbm = dbm * (-1); // Make it positve
					if (dbm >= 60 && dbm < 70) {
						dbm = 95;
					} else if (dbm >= 70 && dbm < 87) {
						dbm = 85;
					} else if (dbm >= 87) {
						dbm = 60;
					}
					signalStrength = dbm;
				}
			};
			((android.telephony.TelephonyManager) statsContext
					.getSystemService(statsContext.TELEPHONY_SERVICE)).listen(
					phonestate, PhoneStateListener.LISTEN_SIGNAL_STRENGTH);
			setLatitudeAndLongitude();
		}

		// public void setDownloadSpeed(Context context)
		// {
		// fileTransferStatus = "Failure";
		// boolean timeoutStatus = false;
		// long startTime1,endTime1;
		// LogWrite.d(tag,"getDowanloadSpeed  Work");
		// SimpleDateFormat dateFormat = new
		// SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SS");
		// Calendar cl = Calendar.getInstance();
		// startDateTime = dateFormat.format(cl.getTime());
		// // startDateTime = startDateTime.replace(":","/");
		// LogWrite.d(tag,"startDateTime  ="+startDateTime);
		// final String filePath = url;
		// int fileSize ;
		// int timeOut = 15;
		// // String transferSize = "";
		// try
		// {
		// LogWrite.d(tag,"Downloading File Path = "+filePath);
		// startTime1 = System.currentTimeMillis();
		// long timeOutMinutes = timeOut*60*1000;
		// long totalTimetoBetaken = startTime1 + timeOutMinutes;
		// URL url = new URL(filePath);
		// URLConnection conection = url.openConnection();
		// HttpURLConnection httpConn = (HttpURLConnection) conection;
		// httpConn.setConnectTimeout(13*1000);
		// httpConn.setReadTimeout(3*60*1000);
		// LogWrite.d(tag,"Connection Status = "+httpConn.getResponseCode());
		// if(httpConn.getResponseCode() == 200)
		// {
		// int lengthOfFile = httpConn.getContentLength();
		// LogWrite.d(tag,"File Size = "+lengthOfFile);
		// fileSize = lengthOfFile / 1024;
		// LogWrite.d(tag,"File Size = "+fileSize);
		// // transferSize = "" + fileSize;
		// InputStream inputStream = httpConn.getInputStream();
		// DataInputStream dataInputStream = new DataInputStream(inputStream);
		// byte[] buffer = new byte[1024];
		// long total = 0;
		// int length = 0;
		// while ((length = dataInputStream.read(buffer)) > 0)
		// {
		// endTime1 = System.currentTimeMillis();
		// if(endTime1 <= totalTimetoBetaken)
		// {
		// LogWrite.d(tag, "Less then or equals"+ timeOut+" mins");
		// total += length;
		// LogWrite.d(tag, "Total ----> " + total);
		// }
		// else
		// {
		// LogWrite.d(tag, "Greater then 10 mins");
		// total += length;
		// timeoutStatus = true;
		// break;
		// }
		// }
		// int inKb = (int) (total/1024);
		// transferSize = "" + inKb;
		// LogWrite.d(tag, "Downloaded Size ----> " + transferSize);
		// if(!timeoutStatus)
		// {
		// endTime1 = System.currentTimeMillis();
		// long timeTaken = endTime1 - startTime1;
		//
		// long timeInSeconds = timeTaken / 1000;
		// LogWrite.d(tag,"Time Taken inSeconds = "+timeTaken);
		// LogWrite.d(tag,"File Size = "+fileSize);
		// if(fileSize > 0)
		// {
		// downloadSpeed = ""+fileSize / timeInSeconds;
		// fileTransferStatus = "Success";
		// }
		// }
		// else
		// {
		// fileTransferStatus = "Timeout";
		// }
		// dataInputStream.close();
		// httpConn.disconnect();
		// }
		// }
		// catch (ExceptionDTO e)
		// {
		// LogWrite.d("Ashis1","ExceptionDTO =DownloadSpeed = "+e);
		// // if(!isNetworkAvailable(context))
		// // {
		// // failureResult = "No Internet Connection";
		// // }
		// }
		// /*
		// * Setting End Time
		// */
		// cl.setTime(new Date());
		// endDateTime = dateFormat.format(cl.getTime());
		// LogWrite.d("Ashis1","endDateTime  ="+endDateTime);
		// }
		public void setDownloadSpeed() {
			fileTransferStatus = "Failure";
			long startTime1, endTime1;
			LogWrite.d("Ashis1", "getDowanloadSpeed  Work");
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cl = Calendar.getInstance();
			startDateTime = dateFormat.format(cl.getTime());
			startDateTime = startDateTime.replace(":", "/");
			LogWrite.d("Ashis1", "startDateTime  =" + startDateTime);
			final String filePath = "http://202.164.36.66/1mb/1mb.zip";
			int fileSize;
			try {
				startTime1 = System.currentTimeMillis();
				URL url = new URL(filePath);
				URLConnection conection = url.openConnection();
				HttpURLConnection httpConn = (HttpURLConnection) conection;
				httpConn.setConnectTimeout(13 * 1000);
				httpConn.setReadTimeout(3 * 60 * 1000);

				// httpConn.connect();
				LogWrite.d("Ashis1",
						"Connection Status = " + httpConn.getResponseCode());
				if (httpConn.getResponseCode() == 200) {
					int lengthOfFile = httpConn.getContentLength();
					fileSize = lengthOfFile / 1024;
					LogWrite.d("Ashis1", "File Size = " + fileSize);

					// if(conection instanceof HttpURLConnection)
					// {
					//
					// LogWrite.d("Ashis1","Connection Status = "+httpConn.getResponseCode());
					// }

					// InputStream inputStream = url.openStream();
					// DataInputStream dataInputStream = new
					// DataInputStream(inputStream);
					// byte[] buffer = new byte[1024];
					// long total = 0;
					// int length;
					// while ((length = dataInputStream.read(buffer)) > 0) {
					// total += length;
					// }
					InputStream inputStream = httpConn.getInputStream();
					DataInputStream dataInputStream = new DataInputStream(
							inputStream);
					byte[] buffer = new byte[1024];
					long total = 0;
					int length;
					while ((length = dataInputStream.read(buffer)) > 0) {
						LogWrite.d("Ashis1", "loop = " + total);
						total += length;
						transferSize = total + "";
					}
					transferSize = ((int) total) / 1024 + "";
					endTime1 = System.currentTimeMillis();
					long timeTaken = endTime1 - startTime1;
					long timeInSeconds = timeTaken / 1000;
					LogWrite.d("Ashis1", "Time Taken inSeconds = " + timeTaken);
					LogWrite.d("Ashis1", "File Size = " + fileSize);
					downloadSpeed = "" + fileSize / timeInSeconds + " kbps";
					fileTransferStatus = "Success";
					dataInputStream.close();
					httpConn.disconnect();
				}

			} catch (Exception e) {
				LogWrite.d("Ashis1", "ExceptionDTO =DownloadSpeed = " + e);
			}
			/*
			 * Setting End Time
			 */
			cl.setTime(new Date());
			endDateTime = dateFormat.format(cl.getTime());
			endDateTime = endDateTime.replace(":", "/");
			LogWrite.d("Ashis1", "endDateTime  =" + endDateTime);
		}

		public void setIMEI(Context context) {
			try {
				TelephonyManager telephonyManager = (TelephonyManager) context
						.getSystemService(Context.TELEPHONY_SERVICE);
				imei = telephonyManager.getDeviceId();
			} catch (Exception e) {
				LogWrite.d("Ashis1", "ExceptionDTO =setIMEI = " + e);
			}
		}

		public void setIMSI(Context context) {
			try {
				imsi = "NA";
				if (((android.telephony.TelephonyManager) context
						.getSystemService(context.TELEPHONY_SERVICE))
						.getSubscriberId() != null) {
					imsi = ((android.telephony.TelephonyManager) context
							.getSystemService(context.TELEPHONY_SERVICE))
							.getSubscriberId();
				}
			} catch (Exception e) {
				LogWrite.d("Ashis1", "ExceptionDTO =setIMSI = " + e);
			}
		}

		void setCellIdAndLoc(Context context) {
			try {
				final TelephonyManager telephony = (TelephonyManager) context
						.getSystemService(Context.TELEPHONY_SERVICE);
				if (telephony.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) {
					final GsmCellLocation location = (GsmCellLocation) telephony
							.getCellLocation();
					if (location != null) {
						lac = String.valueOf(location.getLac());
					}
					int cellID = location.getCid();
					cellID = cellID & 0xffff;
					cellId = String.valueOf(cellID);
				} else {
					// showToast("Not on GSM Network", 2000);
				}
			} catch (Exception e) {
				LogWrite.d("Ashis1", "ExceptionDTO =CellIdLoc = " + e);
			}
		}

		public void setLatency() {
			/*
			 * "ping -c 25 " + ip command ping specified url 25 times and result
			 * is of the form 64 bytes from 202.164.36.66: icmp_seq=15 ttl=125
			 * time=955 ms (25 times)
			 * 
			 * And at last it gives report of ping 1)packet report 25 packets
			 * transmitted, 22 received, 12% packet loss, time 24099ms
			 * 2)timebased report rtt min/avg/max/mdev =
			 * 14.770/732.416/2064.789/569.445 ms, pipe 3
			 */
			String Tag = "LatencyTest";
			String ip = "www.google.com";
			String pingCmd = "ping -c 5 " + ip;
			long startTime = System.currentTimeMillis();
			long timeOutMinutes = 2 * 60 * 1000;
			long totalTimetoBetaken = startTime + timeOutMinutes;
			boolean timeoutFlag = false;
			try {
				Runtime r = Runtime.getRuntime();
				LogWrite.d(Tag, "-----------------1");
				Process p = r.exec(pingCmd);
				LogWrite.d(Tag, "-----------------2");
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(p.getInputStream()));
				LogWrite.d(Tag, "-----------------3");
				String str;
				LogWrite.d(Tag, "-----------------4");
				while (!reader.ready()) {
					LogWrite.d(Tag, "-----------------5");
					long endTime = System.currentTimeMillis();
					if (endTime > totalTimetoBetaken) {
						LogWrite.d(Tag,
								"End Time is Greater then total time to be taken");
						timeoutFlag = true;
						break;
					}
					Thread.sleep(500);
				}
				LogWrite.d(Tag, "Time OuT flag = " + timeoutFlag);
				if (!timeoutFlag) {
					char[] buffer = new char[4096];
					int i;
					StringBuffer output = new StringBuffer();
					while ((i = reader.read(buffer)) > 0) {
						LogWrite.d(tag, "----------------- " + i);
						output.append(buffer, 0, i);
					}
					reader.close();
					str = output.toString();
					LogWrite.d(tag, "ping result " + str);
					int indexDash = str.lastIndexOf("---");
					String statStrings = str.substring(indexDash + 3,
							str.length());
					int indexMs = statStrings.indexOf("ms");
					String pingStats = statStrings.substring(0, indexMs);
					String[] pingStatsArr = pingStats.split(",");
					String dummy = "";
					dummy = pingStatsArr[1];
					dummy = dummy.substring(0, dummy.indexOf("received"));
					dummy = dummy.trim();
					if (dummy.equalsIgnoreCase("0")) {
						packetloss = "100";
						latency = "0";
					} else {
						dummy = pingStatsArr[2];
						dummy = dummy.substring(0, dummy.indexOf("%"));
						packetloss = "" + Integer.parseInt(dummy.trim());
						String minAvgMax = statStrings.substring(statStrings
								.indexOf("=") + 1);
						String[] minAvg = minAvgMax.split("/");
						float latFloat = Float.parseFloat(minAvg[1]);
						latency = "" + latFloat;
					}
				} else {
					latency = "0";
				}
			} catch (Exception e) {
				LogWrite.d(Tag, "ExceptionDTO..." + e.toString());
				latency = "0";
			}
		}

		// public void setLatency()
		// {
		// /*
		// * "ping -c 25 " + ip command ping specified url 25 times and result
		// is of the form
		// * 64 bytes from 202.164.36.66: icmp_seq=15 ttl=125 time=955 ms (25
		// times)
		// *
		// * And at last it gives report of ping
		// * 1)packet report
		// * 25 packets transmitted, 22 received, 12% packet loss, time 24099ms
		// 2)timebased report
		// rtt min/avg/max/mdev = 14.770/732.416/2064.789/569.445 ms, pipe 3
		// */
		// String TAG ="LatencyTest";
		// // ip = "74.125.236.66";
		// String ip = "202.164.36.66";
		// String pingCmd = "ping -c 25 " + ip;
		// try {
		// Runtime r = Runtime.getRuntime();
		// Process p = r.exec(pingCmd);
		// BufferedReader in = new BufferedReader(new
		// InputStreamReader(p.getInputStream()));
		// String inputLine;
		// String latencyResult = null;
		// while ((inputLine = in.readLine()) != null)
		// {
		// latencyResult = inputLine;
		// }
		// String[] keyValue = latencyResult.split("=");
		// String[] value = keyValue[1].split("/");
		// latency = value[1];
		// }
		// catch (ExceptionDTO e)
		// {
		// LogWrite.d(TAG, "ExceptionDTO..."+e);
		// }
		// }
		// private void setLatency()
		// {
		// // ip = "74.125.236.66";
		// final String ip = "202.164.36.66";
		// String pingResult = "";
		// String pingCmd = "ping -c 60 " + ip;
		// ArrayList<String> val=new ArrayList<String>();
		// String percenLoss = "100";
		// try {
		// Runtime r = Runtime.getRuntime();
		// Process p = r.exec(pingCmd);
		// BufferedReader in = new BufferedReader(new
		// InputStreamReader(p.getInputStream()));
		// String inputLine;
		// int sum=0;int k=0;
		// int count=0;
		// while ((inputLine = in.readLine()) != null)
		// {
		// int tend=inputLine.lastIndexOf(" ");
		// int time_index=inputLine.indexOf("time=");
		// if(time_index>0)
		// {
		// count++;
		// time_index=time_index+5;
		// String timezoneID=inputLine.substring(time_index, tend);
		// int add=Integer.parseInt(timezoneID);
		// sum=sum+add;
		// }
		// pingResult += inputLine;
		// k++;
		// if(inputLine.contains("packets"))
		// {
		// int startIndex=inputLine.indexOf("received")+10;
		// int endIndex=inputLine.indexOf("%");
		// percenLoss=inputLine.substring(startIndex, endIndex);
		// }
		// }
		// if(count>0)
		// {
		// latency=sum/count;
		// }
		// }
		// catch (ExceptionDTO e) {
		// LogWrite.d("Ashis1","ExceptionDTO =Latency = "+e);
		// }
		// }
		public void setNetworkName(Context context) {
			try {
				networkName = ((android.telephony.TelephonyManager) context
						.getApplicationContext().getSystemService(
								context.TELEPHONY_SERVICE))
						.getNetworkOperatorName();

			} catch (Exception e) {
				networkName = "NA";
				LogWrite.d("Ashis1", "ExceptionDTO =setNetworkName = " + e);
			}
		}

		public void setLatitudeAndLongitude() {
			LocationManager locationManager = (LocationManager) statsContext
					.getSystemService(statsContext.LOCATION_SERVICE);
			try {
				locationManager.requestLocationUpdates(
						LocationManager.NETWORK_PROVIDER, 1000, 1000,
						new LocationListener() {
							public void onStatusChanged(String provider,
									int status, Bundle extras) {
							}

							public void onProviderEnabled(String provider) {
							}

							public void onProviderDisabled(String provider) {
							}

							public void onLocationChanged(Location location) {
								// TODO Auto-generated method stub
								latitude = "" + location.getLatitude();
								longitude = "" + location.getLongitude();
							}
						});
			} catch (Exception e) {
				LogWrite.d("Ashis1", "ExceptionDTO =setLatitudeAndLongitude = "
						+ e);
			}

			LogWrite.d(tag, "2");
			LogWrite.d(tag, "outside of function...");
		}

		public void setBearerInfo() {
			TelephonyManager teleMan = (TelephonyManager) statsContext
					.getSystemService(statsContext.TELEPHONY_SERVICE);
			int networkType = teleMan.getNetworkType();
			switch (networkType) {
			case TelephonyManager.NETWORK_TYPE_CDMA:
				bearerInfo = "CDMA";
				break;
			case TelephonyManager.NETWORK_TYPE_EDGE:
				bearerInfo = "EDGE";
				break;
			case TelephonyManager.NETWORK_TYPE_GPRS:
				bearerInfo = "GPRS";
				break;
			case TelephonyManager.NETWORK_TYPE_IDEN:
				bearerInfo = "IDEN";
				break;
			case TelephonyManager.NETWORK_TYPE_LTE:
				bearerInfo = "LTE";
				break;
			case TelephonyManager.NETWORK_TYPE_UMTS:
				bearerInfo = "UMTS";
				break;
			default:
				bearerInfo = "NA";
				break;
			}
		}

		public void setUrl() {
			url = "202.164.36.66/1mb/1mb.zip";
		}

		public void setTransferSize() {
			transferSize = "1Mb";
		}

		public void setStartEndDateTimeAndPhoneNumber() {
			try {
				// startDateTime =
				// PreferenceManager.getDefaultSharedPreferences(statsContext.getApplicationContext()).getString("starttime","");
				// startDateTime = startDateTime.replace(":","/");
				// endDateTime =
				// PreferenceManager.getDefaultSharedPreferences(statsContext.getApplicationContext()).getString("endtime","");
				// endDateTime = endDateTime.replace(":","/");
				phoneNumber = PreferenceManager.getDefaultSharedPreferences(
						statsContext.getApplicationContext()).getString("imei",
						"");
			} catch (Exception e) {
				LogWrite.d("Ashis1", "ExceptionDTO =setStartEndDateTime = " + e);
			}
		}

		/**
		 * Downloading file in background thread
		 * */
		@Override
		protected Integer doInBackground(Context... params) {
			setIMEI(statsContext);
			LogWrite.d("Ashis1", "IMEI =" + imei);
			setUrl();
			LogWrite.d("Ashis1", "url =" + url);
			// setTransferSize();

			setStartEndDateTimeAndPhoneNumber();
			LogWrite.d("Ashis1", "startDateTime =" + startDateTime);
			LogWrite.d("Ashis1", "endDateTime =" + endDateTime);
			LogWrite.d("Ashis1", "phone Number =" + phoneNumber);
			setDownloadSpeed();// it set download speed and trnsfer status
			LogWrite.d("Ashis1", "transferSize =" + transferSize);
			LogWrite.d("Ashis1", "downloadSpeed =" + downloadSpeed);
			LogWrite.d("Ashis1", "fileTransferStatus =" + fileTransferStatus);
			setCellIdAndLoc(statsContext);
			LogWrite.d("Ashis1", "cellId =" + cellId);
			LogWrite.d("Ashis1", "lac =" + lac);
			setLatency();
			LogWrite.d("Ashis1", "letency =" + latency);
			setNetworkName(statsContext);
			LogWrite.d("Ashis1", "networkName =" + networkName);
			setBearerInfo();
			LogWrite.d("Ashis1", "bearerInfo =" + bearerInfo);
			LogWrite.d("Ashis1", "latitude =" + latitude);
			LogWrite.d("Ashis1", "latitude =" + latitude);

			String message = "<SPDTST-1:<A1:" + imei + ";";
			message += "B1:" + url + ";";
			message += "C1:" + transferSize + ";";
			message += "D1:" + startDateTime + ";";
			message += "E1:" + endDateTime + ";";
			message += "F1:" + fileTransferStatus + ";";
			message += "G1:" + latency + ";";
			message += "H1:" + latitude + ";";
			message += "I1:" + longitude + ";";
			message += "J1:" + cellId + ";";
			message += "K1:" + lac + ";";
			message += "L1:" + networkName + ";";
			message += "M1:" + signalStrength + ";";
			message += "N1:" + bearerInfo + ";";
			message += "O1:" + downloadSpeed + ";";
			message += ">;>";
			sendTextMessage("", message);
			//
			// public const string URL = "B";
			// public const string FILESIZE = "C";
			// public const string DOWNLOADSTARTTIME = "D";
			// public const string DOWNLOADENDTIME = "E";
			// public const string DOWNLOADSTATUS = "F";
			// public const string LATENCY = "G";
			// public const string LATITUDE = "H";
			// public const string LONGITUDE = "I";
			// public const string CELLID = "J";
			// public const string AREACODE = "K";
			// public const string NETWORKNAME = "L";
			// public const string SIGNALSTRENGTH = "M";
			// public const string BREARERINFO = "N";

			return 0;
			// String result = "";
			// int FileSize = 0;
			//
			// try {
			//
			// LogWrite.d(tag, "Inside doInBackground........");
			// try {
			// fileName = VALUE.substring(VALUE.lastIndexOf("/") + 1,
			// VALUE.length());
			//
			// LogWrite.d(tag, " File name is " + fileName);
			//
			// URL url = new URL(VALUE);
			// URLConnection conection = url.openConnection();
			// conection.connect();
			// // getting file length
			// int lengthOfFile = conection.getContentLength();
			// LogWrite.d(tag, "LENGTH OF FILE: " + lengthOfFile);
			// FileSize = lengthOfFile / 1024;
			// int length;
			//
			// InputStream inputStream = url.openStream();
			//
			// DataInputStream dataInputStream = new DataInputStream(
			// inputStream);
			//
			// byte[] buffer = new byte[1024];
			//
			// String destinationPath = params[0].getFilesDir() + "/";
			//
			// isDirectoryPresent(destinationPath);
			//
			// File file = new File(destinationPath + File.separator
			// + fileName);
			// filetoDelete = file;
			// isFilePresent(file);
			//
			// LogWrite.d(tag, "path " + file.getAbsolutePath());
			// FileOutputStream fileOutputStream = params[0]
			// .openFileOutput(fileName,
			// Context.MODE_WORLD_WRITEABLE
			// | Context.MODE_WORLD_READABLE);
			//
			// long total = 0;
			// while ((length = dataInputStream.read(buffer)) > 0) {
			// total += length;
			// // LogWrite.d(tag,"TOTAL:"+total+"   LENGTH:"+length);
			// // publishing the progress....
			// // After this onProgressUpdate will be called
			// publishProgress((int) ((total * 100) / lengthOfFile));
			// // LogWrite.d(tag, "PROGRESS>>>>>>"
			// // + (int) ((total * 100) / lengthOfFile));
			// fileOutputStream.write(buffer, 0, length);
			// }
			//
			// LogWrite.d(tag, "File downloaded at " + params[0].getFilesDir()
			// + "/" + fileName);
			//
			// fileOutputStream.close();
			//
			// } catch (ExceptionDTO ex) {
			// LogWrite.d(tag, "Download file " + ex.toString());
			//
			// }
			// // publishProgress(result);
			// } catch (ExceptionDTO e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// result = "ERROR:" + e.toString();
			// }
			//
			// return FileSize;

		}

		public String getRandomNumber() {
			String finalRN = "";
			Random rd = new Random(10000);
			int randomNumber = rd.nextInt();
			String rn = Integer.toString(randomNumber);

			if (rn.startsWith("-")) {
				int index = rn.indexOf("-");
				finalRN = rn.substring(index + 1, rn.length());
				LogWrite.d(tag, "getRandomNumber-> " + finalRN);
				return finalRN;
			} else {
				return rn;
			}

			// return Integer.toString(randomNumber);
		}

		public void sendTextMessage(String address, String message) {

			String tag = "statssendtextmessage";

			try {

				String messageToAppend, messageToSend = "";
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost(SERVERURL);
				String outerBody = PreferenceManager
						.getDefaultSharedPreferences(
								statsContext.getApplicationContext())
						.getString("outerbodystart", "");
				String innerBody = PreferenceManager
						.getDefaultSharedPreferences(
								statsContext.getApplicationContext())
						.getString("innerbodystart", "");
				String outerBodyEnd = PreferenceManager
						.getDefaultSharedPreferences(
								statsContext.getApplicationContext())
						.getString("outerbodyend", "");
				String innerBodyEnd = PreferenceManager
						.getDefaultSharedPreferences(
								statsContext.getApplicationContext())
						.getString("innerbodyend", "");

				LogWrite.d(tag, "Outer =" + outerBody);
				LogWrite.d(tag, "Inner =" + innerBody);
				LogWrite.d(tag, "Messagae =" + message);

				messageToSend = outerBody + innerBody + message + innerBodyEnd
						+ outerBodyEnd;
				// messageToSend += message + ">;";
				// messageToSend +=">;";

				LogWrite.d(tag, "sendresponse--" + "MessageID:"
						+ getRandomNumber()
						+ "MessageClass:EventMessageType:HSetToHTTPEvent:"
						+ "NewDMResponseChunkData:" + messageToSend + "Mobile:"
						+ phoneNumber + "Content-Length:0\n");
				httppost.setEntity(new StringEntity(
						"MessageID:"
								+ getRandomNumber()
								+ "\nMessageClass:Event\nMessageType:HSetToHTTP\nEvent:"
								+ "NewDMResponse\nChunkData:" + messageToSend
								+ "\nMobile:" + phoneNumber
								+ "\nContent-Length:0\n"));
				HttpResponse resp = httpclient.execute(httppost);
				HttpEntity ent = resp.getEntity();

				LogWrite.d(tag, "StatusCode ="
						+ resp.getStatusLine().getStatusCode());

				if (resp.getStatusLine().getStatusCode() == 200) {
					LogWrite.d(tag, "Stats Status ="
							+ resp.getStatusLine().getStatusCode());
				} else {
					// Thread.sleep(2000);
					// sendTextMessage(address,message);
				}

			} catch (Exception e) {
				LogWrite.d(tag, "ExceptionDTO =" + e);
				// try {
				// Thread.sleep(2000);
				// } catch (InterruptedException e1) {
				// // TODO Auto-generated catch block
				// e1.printStackTrace();
				// }
				// sendTextMessage(address,message);
			}
		}

		@Override
		protected void onProgressUpdate(Integer... progress) {
			LogWrite.d(tag, "PROGRESS UPDATE>>>>>>" + progress[0]);
		}

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			time2 = System.currentTimeMillis();
			long timeTaken = time2 - time1;
			long timeInSeconds = timeTaken / 1000;
			LogWrite.d(tag, "Total Time taken in seconds " + timeInSeconds);
			LogWrite.d(tag, "Download Speed in kbps is "
					+ (result / timeInSeconds) * 8);
			LogWrite.d(tag, "Download Speed in KB/s is "
					+ (result / timeInSeconds));
			// statusSpeed.setText("Download Speed \n kbps: "
			// + ((result / timeInSeconds) * 8) + "\n KB/s: "
			// + (result / timeInSeconds));
			isFilePresent(filetoDelete);
			new RunPingTestTask().execute("www.google.com");

		}

		@Override
		protected void onCancelled() {
			// TODO Auto-generated method stub
			super.onCancelled();

		}
	}

	void isDirectoryPresent(String directoryPath) {
		try {
			File file = new File(directoryPath);
			boolean flag = file.exists();
			LogWrite.d(TAG, directoryPath + " exist is  " + flag);

			if (!flag) {
				file.mkdirs();
			}
		} catch (Exception ex) {
			LogWrite.d(TAG, ex.toString());
		}
	}

	void isFilePresent(File _file) {
		try {
			boolean flag = _file.exists();
			LogWrite.d(TAG, "FILE>>> exist is  " + flag);

			if (flag) {
				LogWrite.d(TAG, "FILE ALREADY EXISTS...");
				if (_file.isFile()) {
					LogWrite.d(TAG, "YES IT IS A FILE...");
					LogWrite.d(TAG, "FILE DELETED:> " + _file.delete());
				} else {
					LogWrite.d(TAG, "NO FILE FOUND...");
				}

			}
		} catch (Exception ex) {
			LogWrite.d(TAG, ex.toString());
		}
	}

	public class RunPingTestTask extends AsyncTask<String, String, String> {

		@Override
		protected String doInBackground(String... params) {
			ping(params[0]);
			return null;
		}

	}

	/**
	 * Ping the Network for the stated URL.
	 * 
	 * @param url
	 * @return
	 */
	public String ping(String url) {
		String toSend = "";
		String str = "";
		// Hashtable<String, String> pingKeyValues=new Hashtable<String,
		// String>();
		String[] arr = new String[7];
		String[] arr1 = { "A1:", "B1:", "C1:", "D1:", "E1:", "F1:", "G1:" };

		int count = 0;
		try {
			LogWrite.d(TAG, "Before execute...");
			Process process = Runtime.getRuntime().exec(
					"/system/bin/ping -c 8 " + url);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					process.getInputStream()));
			int i;
			char[] buffer = new char[4096];
			StringBuffer output = new StringBuffer();
			while ((i = reader.read(buffer)) > 0)
				output.append(buffer, 0, i);
			reader.close();

			// body.append(output.toString()+"\n");
			str = output.toString();
			// LogWrite.d(TAG, str);
			int indexDash = str.lastIndexOf("---");
			// body.append(indexDash+""+str.length());

			String statStrings = str.substring(indexDash + 3, str.length());

			int indexMs = statStrings.indexOf("ms");
			LogWrite.d(TAG, "stat strings gaurav" + statStrings);
			String pingStats = statStrings.substring(0, indexMs);
			LogWrite.d("PING SATS:>>>> ", pingStats);
			String[] pingStatsArr = pingStats.split(",");

			arr[count] = url;
			count++;
			// LogWrite.d(TAG,"ji"+pingStatsArr[0]);
			String dummy = "";
			// dummy=dummy.substring(0,dummy.indexOf("packets"));

			// arr[count]="gaurav"+pingStatsArr[1];
			arr[count] = "8";

			count++;
			dummy = pingStatsArr[1];
			dummy = dummy.substring(0, dummy.indexOf("received"));
			arr[count] = dummy;
			count++;
			dummy = dummy.trim();
			if (dummy.equalsIgnoreCase("0")) {
				return "A1:" + url + ";B1:8;C1:0;D1:100;E1:N/A;F1:N/A;G1:N/A;";
			}

			dummy = pingStatsArr[2];
			dummy = dummy.substring(0, dummy.indexOf("%"));
			arr[count] = dummy;
			count++;

			LogWrite.d(TAG, "Value: " + pingStats);
			String minAvgMax = statStrings
					.substring(statStrings.indexOf("=") + 1);
			LogWrite.d(TAG, "min avg max: " + minAvgMax);

			String[] minAvg = minAvgMax.split("/");

			arr[count] = minAvg[2];
			count++;
			arr[count] = minAvg[0];
			count++;
			arr[count] = minAvg[1];
			count++;

			for (String stt : arr) {
				LogWrite.d(TAG, "stt " + stt);
			}

			for (int in = 0; in < 7; in++) {
				toSend += arr1[in] + arr[in] + ";";
			}

			LogWrite.d(TAG, "hello " + toSend);
			return toSend;

		} catch (IOException e) {
			// body.append("Error\n");
			e.printStackTrace();
		}
		return toSend;

	}

	public void getIMSI(Context context) {
		String IMSI = "";
		if (((android.telephony.TelephonyManager) context
				.getApplicationContext().getSystemService("TELEPHONY_SERVICE"))
				.getSubscriberId() != null) {
			IMSI = ((android.telephony.TelephonyManager) context
					.getSystemService("TELEPHONY_SERVICE")).getSubscriberId();
		} else {
			IMSI = "0";
		}
	}
}