package com.kochartech.gizmodoctor.Adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kochartech.gizmodoctor.R;
import com.kochartech.gizmodoctor.POJO.SettingStateDTO;

public class DiagnoseAdapter extends BaseAdapter {

	int[] hexColorCodes = { 0xff00aba5, 0xff63a9ff, 0xfffec262, 0xffff6364 };

	int[] drawable = { R.drawable.wifi_img, R.drawable.bt_img,
			R.drawable.gps_img, R.drawable.mobiledata_img };
	private Context context;
	private ArrayList<SettingStateDTO> arrayListSettingDTO;

	private int count = 0;

	public DiagnoseAdapter(Context context,
			ArrayList<SettingStateDTO> arrayListSettingDTO) {
		this.context = context;
		this.arrayListSettingDTO = arrayListSettingDTO;
	}

	@Override
	public int getCount() {
		return arrayListSettingDTO.size();
	}

	@Override
	public Object getItem(int position) {
		return arrayListSettingDTO.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		SettingStateDTO settingStateDTO = arrayListSettingDTO.get(position);
		if (convertView == null) {
			LayoutInflater inflator = LayoutInflater.from(context);
			convertView = inflator.inflate(R.layout.rowui_leftright_textview,
					parent, false);
		}
		if (position == 0) {

			convertView.setBackgroundResource(R.drawable.wifiwifi);
		}

		else if (position == 1) {
			LinearLayout ll = (LinearLayout) convertView
					.findViewById(R.id.temp);
			convertView.setBackgroundResource(R.drawable.btbt);

		} else if (position == 2) {
			LinearLayout ll = (LinearLayout) convertView
					.findViewById(R.id.temp);
			convertView.setBackgroundResource(R.drawable.round);
		} else if (position == 3) {
			LinearLayout ll = (LinearLayout) convertView
					.findViewById(R.id.temp);
			convertView.setBackgroundResource(R.drawable.mobiledata);
		}

		TextView settingName = (TextView) convertView
				.findViewById(R.id.left_TextView);
		settingName.setText(settingStateDTO.getSettingName());

		TextView settingState = (TextView) convertView
				.findViewById(R.id.right_TextView);
		settingState.setText(settingStateDTO.getOnTime());

		ImageView imageView = (ImageView) convertView.findViewById(R.id.image);
		imageView.setImageResource(drawable[position]);
		// if (GUIDiagnose.firstTimeFlag) {
		// Animation animation = AnimationUtils.loadAnimation(context,
		// R.anim.down_from_top);
		// convertView.startAnimation(animation);
		// if (count > arrayListSettingDTO.size())
		// GUIDiagnose.firstTimeFlag = false;
		// count++;
		// }
		return convertView;
	}
}
