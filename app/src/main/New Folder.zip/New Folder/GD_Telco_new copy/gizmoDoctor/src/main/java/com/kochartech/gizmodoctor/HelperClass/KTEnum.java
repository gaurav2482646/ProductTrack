package com.kochartech.gizmodoctor.HelperClass;

public class KTEnum {

	public enum TEMPERATURE_UNIT {
		CELSIUS  (0),
		FAHRENHEIT (1);
	    private final int unit;       
	    private TEMPERATURE_UNIT(int unit) {
	    	this.unit = unit;
	    }
	    public int getValue() {
	    	return unit;
	    }    	
	}
}
