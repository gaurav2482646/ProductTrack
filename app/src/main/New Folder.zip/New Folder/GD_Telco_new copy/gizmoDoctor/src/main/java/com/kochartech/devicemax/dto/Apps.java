package com.kochartech.devicemax.dto;

/**
 * Created by gauravjeetsingh on 22/3/18.
 */

public class Apps
{
    private String appName;

    private String appCpuUsage;

    private String processName;

    private String appBatteryUsage;

    private String appRamUsage;

    private String appType;

    public String getAppName ()
    {
        return appName;
    }

    public void setAppName (String appName)
    {
        this.appName = appName;
    }

    public String getAppCpuUsage ()
    {
        return appCpuUsage;
    }

    public void setAppCpuUsage (String appCpuUsage)
    {
        this.appCpuUsage = appCpuUsage;
    }

    public String getProcessName ()
    {
        return processName;
    }

    public void setProcessName (String processName)
    {
        this.processName = processName;
    }

    public String getAppBatteryUsage ()
    {
        return appBatteryUsage;
    }

    public void setAppBatteryUsage (String appBatteryUsage)
    {
        this.appBatteryUsage = appBatteryUsage;
    }

    public String getAppRamUsage ()
    {
        return appRamUsage;
    }

    public void setAppRamUsage (String appRamUsage)
    {
        this.appRamUsage = appRamUsage;
    }

    public String getAppType ()
    {
        return appType;
    }

    public void setAppType (String appType)
    {
        this.appType = appType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [appName = "+appName+", appCpuUsage = "+appCpuUsage+", processName = "+processName+", appBatteryUsage = "+appBatteryUsage+", appRamUsage = "+appRamUsage+", appType = "+appType+"]";
    }
}