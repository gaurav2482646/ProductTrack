package com.kochartech.devicemax.Receivers;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Example of a do-nothing admin class. When enabled, it lets you control some
 * of its policy and reports when there is interesting activity.
 */
public class DeviceAdminSamplee extends DeviceAdminReceiver 
{

	void showToast(Context context, CharSequence msg) 
	{
		Toast.makeText(context, "Sample Device Admin: " + msg,Toast.LENGTH_LONG).show();
	}

	@Override
	public void onEnabled(Context context, Intent intent) 
	{
		showToast(context, "enabled");
	}

	@Override
	public CharSequence onDisableRequested(Context context, Intent intent) 
	{
		return "This is an optional message to warn the user about disabling.";
	}

	@Override
	public void onDisabled(Context context, Intent intent) 
	{
		showToast(context, "disabled");
	}

	@Override
	public void onPasswordChanged(Context context, Intent intent) 
	{
		showToast(context, "pw changed");
	}

	@Override
	public void onPasswordFailed(Context context, Intent intent) 
	{
		showToast(context, "pw failed");
	}

	@Override
	public void onPasswordSucceeded(Context context, Intent intent) 
	{
		showToast(context, "pw succeeded");
	}

	public static class Controller extends Activity 
	{
		static final int REQUEST_CODE_ENABLE_ADMIN = 1;
		static final int REQUEST_CODE_START_ENCRYPTION = 2;

		DevicePolicyManager mDPM;
		ActivityManager mAM;
		ComponentName mDeviceAdminSample;

		@Override
		protected void onCreate(Bundle savedInstanceState) 
		{
			super.onCreate(savedInstanceState);
			mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
			mAM = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
			mDeviceAdminSample = new ComponentName(Controller.this,DeviceAdminSamplee.class);
			int value = this.getIntent().getIntExtra("value", 0);
			switch (value)
			{
				case 0:
					Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
					intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,	mDeviceAdminSample);
					intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"Additional text explaining why this needs to be added.");
					startActivityForResult(intent, REQUEST_CODE_ENABLE_ADMIN);
					finish();
					break;
				case 1:
					mDPM.wipeData(0);
					finish();
					break;
				default:
					break;
			}
		}
	}
}
