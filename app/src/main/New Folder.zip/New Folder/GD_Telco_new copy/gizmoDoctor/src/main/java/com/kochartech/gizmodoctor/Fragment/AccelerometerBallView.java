package com.kochartech.gizmodoctor.Fragment;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.view.View;

public class AccelerometerBallView extends View {

	public float mX;
	public float mY;
	private final int mR;
	private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

	// construct new ball object
	public AccelerometerBallView(Context context, float x, float y, int r) {
		super(context);

		// color hex is [transparency][red][green][blue]
		// mPaint.setColor(0xFF00FF00); // not transparent. color is green
		this.mX = x;
		this.mY = y;
		this.mR = r; // radius
	}

	// called by invalidate()
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		mPaint.setColor(0xFF00FF00);
		mPaint.setStyle(Style.FILL_AND_STROKE);
		mPaint.setAntiAlias(true);
		canvas.drawCircle(mX, mY, mR, mPaint);
		// Bitmap bmp = BitmapFactory.decodeResource(getResources(),
		// R.drawable.ball);
		// canvas.drawBitmap(bmp, mX, mY, null);
	}
}
