package com.kochartech.devicemax.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class DecisionMakerActivity extends Activity {
	public static boolean activityStatusFlag = false;
	private String TAG = "DecisionMakerActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (!activityStatusFlag) {
			LogWrite.d(TAG, "inside the registeruseracitvity");
			startActivity(RegisterUserActivity.class, getApplicationContext());
		} else {
			LogWrite.d(TAG, "inside MainAcitvity");
			startActivity(MDMMainActivity.class, getApplicationContext());
		}
	}

	private void startActivity(Class<?> classs, Context context) {
		context.startActivity(new Intent(context, classs)
				.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
		finish();
	}
}
