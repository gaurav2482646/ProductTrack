package com.kochartech.gizmodoctor.HelperClass;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import android.content.Context;
import android.net.wifi.WifiManager;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.DataBase.DBHelperDataSettingsToMonitor;
import com.kochartech.gizmodoctor.DataBase.DataSource_Settings;
import com.kochartech.gizmodoctor.POJO.DBSettingDTO;
import com.kochartech.gizmodoctor.POJO.SettingStateDTO;
import com.kochartech.library.Device.KTInformation;

public class SettingStateMonitor {

	private String tag = SettingStateMonitor.class.getName();
	// private int count = 0, countMax = 4;
	// private KTInformation ktInformation;
	private DBHelperDataSettingsToMonitor dbHelperDataSettingsToMonitor;
	private DataSource_Settings settingToMonitorDS;

	private Context context;

	public SettingStateMonitor(Context context) {
		this.context = context;
		settingToMonitorDS = DataSource_Settings.getInstance(context);
		dbHelperDataSettingsToMonitor = DBHelperDataSettingsToMonitor
				.getInstance(context);

		// ktInformation = new KTInformation(context);
	}

	public ArrayList<SettingStateDTO> getSettingState() {
		ArrayList<SettingStateDTO> arrayListSettingStateDTO = new ArrayList<SettingStateDTO>();
		ArrayList<DBSettingDTO> dbSettingDTOList = settingToMonitorDS
				.getAllColumns();
		if (dbSettingDTOList != null) {
			for (DBSettingDTO dbSettingDTO : dbSettingDTOList) {
				SettingStateDTO settingStateDTO = new SettingStateDTO();
				String name = dbSettingDTO.getName();
				LogWrite.d(tag, "Setting Name : " + name);
				if (dbSettingDTO.getLastState()) {
					if (getCurrentState(name)) {
						try {
							long startTime = dbHelperDataSettingsToMonitor
									.getSettingOnTime(dbSettingDTO.getName());

							LogWrite.i(tag, "StartTime : " + getDate(startTime));

							long currentTime = System.currentTimeMillis();
							LogWrite.i(tag, "currentTime : "
									+ getDate(currentTime));

							long timefromStart = currentTime - startTime;
							long timefromStartInMinutes = ((timefromStart / 1000) / 60);
							LogWrite.i(tag, "timefromStartInMinutes : "
									+ timefromStartInMinutes);

							String time = "";
							time += timefromStartInMinutes / 60 + ":"
									+ timefromStartInMinutes % 60;
							settingStateDTO.setOnTime(String.valueOf(time));
							name += " On from";

						} catch (Exception e) {
							LogWrite.e(
									tag,
									"getSettingStateException : "
											+ e.toString());
						}
					} else {
						settingStateDTO.setOnTime("Off");
						dbHelperDataSettingsToMonitor
								.setSettingMonitorningOff(name);
						settingToMonitorDS.updateTheLastState(name, 0);
//						dbHelperDataSettingsToMonitor
//								.updateSettingEndTime(dbSettingDTO.getName());
					}
				} else {
					if (getCurrentState(name)) {
						try {
							long startTime = System.currentTimeMillis();
							LogWrite.i(tag, "StartTime : " + getDate(startTime));

							long currentTime = System.currentTimeMillis();
							LogWrite.i(tag, "currentTime : "
									+ getDate(currentTime));

							long timefromStart = currentTime - startTime;
							long timefromStartInMinutes = ((timefromStart / 1000) / 60);
							LogWrite.i(tag, "timefromStartInMinutes : "
									+ timefromStartInMinutes);

							String time = "";
							time += timefromStartInMinutes / 60 + ":"
									+ timefromStartInMinutes % 60;
							settingStateDTO.setOnTime(String.valueOf(time));
							name += " On from";

						} catch (Exception e) {
							LogWrite.e(
									tag,
									"getSettingStateException : "
											+ e.toString());
						}
					} else {
						settingStateDTO.setOnTime("Off");
						dbHelperDataSettingsToMonitor
								.setSettingMonitorningOff(name);
						settingToMonitorDS.updateTheLastState(name, 0);
//						dbHelperDataSettingsToMonitor
//								.updateSettingEndTime(dbSettingDTO.getName());
					}
				}

				settingStateDTO.setSettingName(name);
				LogWrite.d(tag, settingStateDTO.getSettingName() + " : "
						+ settingStateDTO.getOnTime());
				arrayListSettingStateDTO.add(settingStateDTO);
			}
			LogWrite.d(tag, "List Size: " + arrayListSettingStateDTO.size());
		}
		return arrayListSettingStateDTO;
	}

	private boolean getCurrentState(String settingName) {
		KTInformation ktInformation = new KTInformation(context);
		if (settingName.equalsIgnoreCase("WiFi")) {
			return ktInformation.isWifiEnabled();
		} else if (settingName.equalsIgnoreCase("Bluetooth")) {
			return ktInformation.isBluetoothEnabled();
		} else if (settingName.equalsIgnoreCase("GPS")) {
			return ktInformation.isGPSEnabled();
		} else if (settingName.equalsIgnoreCase("WiFi hotspot")) {
			return isHotspotTetheringEnabled(context);
		}
		return false;
	}

	private boolean isHotspotTetheringEnabled(Context context) {
		boolean state = false;
		WifiManager wifi = (WifiManager) context
				.getSystemService(Context.WIFI_SERVICE);
		Method[] wmMethods = wifi.getClass().getDeclaredMethods();
		for (Method method : wmMethods) {
			if (method.getName().equals("isWifiApEnabled")) {
				try {
					state = (Boolean) method.invoke(wifi);
					return state;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
			}
		}
		return state;
	}

	/**
	 * Return date in specified format.
	 * 
	 * @param milliSeconds
	 *            Date in milliseconds
	 * @return String representing date in specified format
	 */
	private String getDate(long milliSeconds) {
		// Create a DateFormatter object for displaying date in specified
		// format.
		String dateFormat = "dd/MM/yyyy hh:mm:ss.SSS";
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

		// Create a calendar object that will convert the date and time value in
		// milliseconds to date.
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(milliSeconds);
		return formatter.format(calendar.getTime());
	}

}
