package com.kochartech.devicemax.DualSimPackage;

import java.lang.reflect.Method;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;

public class TelephonyInfo 
{
	private static String tag = "TelephonyInfo";
	private static TelephonyInfo telephonyInfo;
	private String imeiSIM1;
	private String imeiSIM2;
	private String imsi1;
	private String imsi2;
	private boolean isSIM1Ready;
	private boolean isSIM2Ready;
	private String isDataState;
	private String operator1;
	private String operator2;
	public String getIMSI1() 
	{
		return imsi1;
	}
	public String getIMSI2() 
	{
		return imsi2;
	}
	public String getOperator1() 
	{
		return operator1;
	}
	public String getOperator2() 
	{
		return operator2;
	}
	public String getImeiSIM1() 
	{
		return imeiSIM1;
	}
	public String getImeiSIM2() 
	{
		return imeiSIM2;
	}
	public boolean isSIM1Ready() 
	{
		return isSIM1Ready;
	}
	public boolean isSIM2Ready() 
	{
		return isSIM2Ready;
	}
	public String isDataReady() 
	{
		return isDataState;
	}
	public int isDualSIM() 
	{
		if(imeiSIM2 != null)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	private TelephonyInfo() 
	{
		
	}

	public static TelephonyInfo getInstance(Context context) 
	{
		if (telephonyInfo == null) 
		{
			telephonyInfo = new TelephonyInfo();
			TelephonyManager telephonyManager = ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE));
			telephonyInfo.imsi1 = telephonyManager.getSubscriberId();
			telephonyInfo.imsi2 = null;
			try 
			{
				telephonyInfo.imsi1 = getSIMSerialBySlot(context, "getSubscriberIdGemini", 0);
				telephonyInfo.imsi2 = getSIMSerialBySlot(context, "getSubscriberIdGemini", 1);
			}
			catch (GeminiMethodNotFoundException e) 
			{
				e.printStackTrace();
				try 
				{
					telephonyInfo.imsi1 = getDeviceIdBySlot(context,"getSubscriberId", 0);
					telephonyInfo.imsi2 = getDeviceIdBySlot(context,"getSubscriberId", 1);
				}
				catch (GeminiMethodNotFoundException e1) 
				{
					e1.printStackTrace();
				}
			}
			telephonyInfo.imeiSIM1 = telephonyManager.getDeviceId();
			telephonyInfo.imeiSIM2 = null;
			try 
			{
				telephonyInfo.imeiSIM1 = getDeviceIdBySlot(context, "getDeviceIdGemini", 0);
				telephonyInfo.imeiSIM2 = getDeviceIdBySlot(context, "getDeviceIdGemini", 1);
			}
			catch (GeminiMethodNotFoundException e) 
			{
				e.printStackTrace();
				try 
				{
					telephonyInfo.imeiSIM1 = getDeviceIdBySlot(context,"getDeviceId", 0);
					telephonyInfo.imeiSIM2 = getDeviceIdBySlot(context,"getDeviceId", 1);
				}
				catch (GeminiMethodNotFoundException e1) 
				{
					e1.printStackTrace();
				}
			}
			LogWrite.d(tag, "telephonyInfo.imeiSIM1 : " + telephonyInfo.imeiSIM1);
			LogWrite.d(tag, "telephonyInfo.imeiSIM2 : " + telephonyInfo.imeiSIM2);
			telephonyInfo.isSIM1Ready = telephonyManager.getSimState() == TelephonyManager.SIM_STATE_READY;
			telephonyInfo.isSIM2Ready = false;
			try
			{
				telephonyInfo.isSIM1Ready = getSIMStateBySlot(context, "getSimStateGemini", 0);
				telephonyInfo.isSIM2Ready = getSIMStateBySlot(context, "getSimStateGemini", 1);
			} 
			catch (GeminiMethodNotFoundException e) 
			{
				e.printStackTrace();
				try
				{
					telephonyInfo.isSIM1Ready = getSIMStateBySlot(context, "getSimState", 0);
					telephonyInfo.isSIM2Ready = getSIMStateBySlot(context, "getSimState", 1);
				}
				catch (GeminiMethodNotFoundException e1) 
				{
					e1.printStackTrace();
				}
			}
			LogWrite.d(tag, "telephonyInfo.isSIM1Ready : " + telephonyInfo.isSIM1Ready);
			LogWrite.d(tag, "telephonyInfo.isSIM2Ready : " + telephonyInfo.isSIM2Ready);
			
			
			
			telephonyInfo.operator1 = telephonyManager.getNetworkOperatorName() ;
			telephonyInfo.operator2 = "";
			try
			{
				telephonyInfo.operator1 = getSIMOperatorBySlot(context, "getNetworkOperatorNameGemini", 0);
				telephonyInfo.operator2 = getSIMOperatorBySlot(context, "getNetworkOperatorNameGemini", 1);
			} 
			catch (GeminiMethodNotFoundException e) 
			{
				e.printStackTrace();
				try
				{
					telephonyInfo.operator1 = getSIMOperatorBySlot(context, "getNetworkOperatorName", 0);
					telephonyInfo.operator2 = getSIMOperatorBySlot(context, "getNetworkOperatorName", 1);
				}
				catch (GeminiMethodNotFoundException e1) 
				{
					e1.printStackTrace();
				}
			}
			LogWrite.d(tag, "telephonyInfo.isSIM1Ready : " + telephonyInfo.isSIM1Ready);
			LogWrite.d(tag, "telephonyInfo.isSIM2Ready : " + telephonyInfo.isSIM2Ready);
			
			
			try
			{
				telephonyInfo.isDataState = getDataStateBySlot(context, "getPreferredDataSubscriptionGemini");
			}
			catch (GeminiMethodNotFoundException e) 
			{
				e.printStackTrace();
				try
				{
					telephonyInfo.isDataState = getDataStateBySlot(context, "getPreferredDataSubscription");
				}
				catch (GeminiMethodNotFoundException e1) 
				{
					e1.printStackTrace();
				}
			}
		}
		return telephonyInfo;
	}
	private static String getSIMOperatorBySlot(Context context, String predictedMethodName, int slotID) 
					throws GeminiMethodNotFoundException
	{
		String operatorName = "";
		TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		try 
		{
			Class<?> telephonyClass = Class.forName(telephony.getClass().getName());
			Class<?>[] parameter = new Class[1];
			parameter[0] = int.class;
			Method getSimID = telephonyClass.getMethod(predictedMethodName, parameter);
			Object[] obParameter = new Object[1];
			obParameter[0] = slotID;
			Object ob_phone = getSimID.invoke(telephony, obParameter);
			if (ob_phone != null) 
			{
				operatorName = ob_phone.toString();
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new GeminiMethodNotFoundException(predictedMethodName);
		}
		return operatorName;
	}
	private static String getSIMSerialBySlot(Context context, String predictedMethodName, int slotID) throws GeminiMethodNotFoundException 
	{
		String imsi = null;
		TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		try 
		{
			Class<?> telephonyClass = Class.forName(telephony.getClass().getName());
			Class<?>[] parameter = new Class[1];
			parameter[0] = int.class;
			Method getSimID = telephonyClass.getMethod(predictedMethodName, parameter);
			Object[] obParameter = new Object[1];
			obParameter[0] = slotID;
			Object ob_phone = getSimID.invoke(telephony, obParameter);
			if (ob_phone != null) 
			{
				imsi = ob_phone.toString();
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new GeminiMethodNotFoundException(predictedMethodName);
		}
		return imsi;
	}
	private static String getDeviceIdBySlot(Context context, String predictedMethodName, int slotID) throws GeminiMethodNotFoundException 
	{
		String imei = null;
		TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		try 
		{
			Class<?> telephonyClass = Class.forName(telephony.getClass().getName());
			Class<?>[] parameter = new Class[1];
			parameter[0] = int.class;
			Method getSimID = telephonyClass.getMethod(predictedMethodName, parameter);
			Object[] obParameter = new Object[1];
			obParameter[0] = slotID;
			Object ob_phone = getSimID.invoke(telephony, obParameter);
			if (ob_phone != null) 
			{
				imei = ob_phone.toString();
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new GeminiMethodNotFoundException(predictedMethodName);
		}
		return imei;
	}
	private static boolean getSIMStateBySlot(Context context, String predictedMethodName, int slotID)
			throws GeminiMethodNotFoundException 
	{
		boolean isReady = false;
		TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		try 
		{
			Class<?> telephonyClass = Class.forName(telephony.getClass().getName());
			Class<?>[] parameter = new Class[1];
			parameter[0] = int.class;
			Method getSimStateGemini = telephonyClass.getMethod(predictedMethodName, parameter);
			Object[] obParameter = new Object[1];
			obParameter[0] = slotID;
			Object ob_phone = getSimStateGemini.invoke(telephony, obParameter);
			if (ob_phone != null) 
			{
				int simState = Integer.parseInt(ob_phone.toString());
				if (simState == TelephonyManager.SIM_STATE_READY) 
				{
					isReady = true;
				}
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new GeminiMethodNotFoundException(predictedMethodName);
		}
		return isReady;
	}

	private static String getDataStateBySlot(Context context, String predictedMethodName)  
			throws GeminiMethodNotFoundException
	{
		try 
		{
			TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			Class<?> telephonyClass = Class.forName(telephony.getClass().getName());	
			Class<?>[] parameter = new Class[1];
			parameter[0] = int.class;
			Method getDataStateGemini = telephonyClass.getMethod(predictedMethodName);
			Object ob_phone = getDataStateGemini.invoke(telephony);
			LogWrite.d(tag, ">>>>>>" + ob_phone);
			int simDataState = Integer.parseInt(ob_phone.toString());
			LogWrite.d(tag, "SimDataState  : " + simDataState);
//			if(simDataState == null)
//			{
//				return "0";
//			}
			if(simDataState == 0)
			{
				return "0";
			}
			if(simDataState == 1)
			{
				return "1";
			}
		}
		catch (Exception exception) 
		{
			Log.i(tag, "ExceptionDTO in default " + exception.getMessage());
			throw new GeminiMethodNotFoundException(predictedMethodName);
		}

		return "0";
	}

	private static class GeminiMethodNotFoundException extends Exception
	{
		private static final long serialVersionUID = -996812356902545308L;
		public GeminiMethodNotFoundException(String info) 
		{
			super(info);
		}
	}
}
