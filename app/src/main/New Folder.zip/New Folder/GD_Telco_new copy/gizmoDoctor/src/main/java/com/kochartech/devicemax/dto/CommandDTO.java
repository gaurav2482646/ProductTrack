package com.kochartech.devicemax.dto;

/**
 * Created by gauravjeetsingh on 20/3/18.
 */

public class CommandDTO
{
    private ExceptionDTO Exception;

    private ResponseDTO[] Response;

    public ExceptionDTO getExceptionDTO()
    {
        return Exception;
    }

    public void setExceptionDTO(ExceptionDTO Exception)
    {
        this.Exception = Exception;
    }

    public ResponseDTO[] getResponseDTO()
    {
        return Response;
    }

    public void setResponseDTO(ResponseDTO[] Response)
    {
        this.Response = Response;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ExceptionDTO = "+ Exception +", ResponseDTO = "+ Response +"]";
    }
}