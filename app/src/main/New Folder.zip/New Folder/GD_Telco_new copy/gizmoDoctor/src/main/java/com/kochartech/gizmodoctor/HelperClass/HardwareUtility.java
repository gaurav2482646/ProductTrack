package com.kochartech.gizmodoctor.HelperClass;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Parameters;
import android.os.IBinder;
import android.os.Vibrator;
import android.util.Log;

import com.kochartech.devicemax.Activities.LogWrite;
import com.kochartech.gizmodoctor.Fragment.HardwareTestFragment;
import com.kochartech.gizmodoctor.Model.OnAutoHardwareTestListener;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

@SuppressWarnings("deprecation")
public class HardwareUtility {
    public static String KEY_HARDWARE = "HARDWARETEST";
    public static String KEY_TOUCH_HARDWARE = "TOUCH";
    public static String KEY_VIBRATION_HARDWARE = "VIBRATION";
    public static String KEY_FLASH_LIGHT_HARDWARE = "FLASHLIGHT";
    public static String KEY_PROXIMITY_HARDWARE = "PROXIMITY";
    public static String KEY_ACCELEROMETER_HARDWARE = "ACCELEROMETER";
    public static String KEY_LONG_PRESS_HARDWARE = "LONGPRESS";
    public static String KEY_WIFI_HARDWARE = "WIFI";
    public static String KEY_GPS_HARDWARE = "GPS";
    public static String KEY_BLUETOOTH_HARDWARE = "BLUETOOTH";
    public static String KEY_BACK_CAMERA_HARDWARE = "BACKCAMERA";
    public static String KEY_FRONT_CAMERA_HARDWARE = "FRONTCAMERA";
    public static String KEY_MULTI_TOUCH = "MULTITOUCH";
    public static String KEY_MIC_HARDWARE = "MIC";
    public static String KEY_SPEAKER_HARDWARE = "SPEAKER";
    public static String KEY_DISPLAY_HARDWARE = "DISPLAY";
    public static String KEY_VOLUME_UP_KEY = "VOLUMEUP";
    public static String KEY_VOLUME_DOWN_KEY = "VOLUMEDOWN";
    public static String KEY_POWER_KEY = "POWERKEY";
    public static String KEY_HOME_KEY = "HOMEKEY";
    public static String KEY_MENU_KEY = "MENUKEY";
    public static String KEY_BACK_KEY = "BACKKEY";
    private String TAG = HardwareUtility.class.getSimpleName();
    private Activity activity;
    private Camera cam = null;
    private Context context;
    private HardwareType type;
    private int count;
    private OnAutoHardwareTestListener onAutoHardwareTestListener;

    public HardwareUtility(Activity activity) {
        this.activity = activity;
    }

    public HardwareUtility(Context context, HardwareType type) {
        this.context = context;
        this.type = type;
    }

    public void setOnAutoHardwareTestListener(
            OnAutoHardwareTestListener onAutoHardwareTestListener) {
        this.onAutoHardwareTestListener = onAutoHardwareTestListener;
    }

    /**
     * This method is used to check vibration.
     */
    public synchronized boolean vibrate() {
        LogWrite.d(TAG, "Vibrate Method Enters.....");
        try {
            Vibrator vibrator = (Vibrator) activity
                    .getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator.hasVibrator()) {
                vibrator.vibrate(3000);
                Thread.sleep(3000);
                if (HardwareTestFragment.isAutoStartClicked)
                    onAutoHardwareTestListener.onHardwareTestFinish(0,
                            "Vibration", true);
                return true;
            }
        } catch (Exception e) {
            LogWrite.e(TAG, "VibrateException :---> " + e.toString());
        }
        if (HardwareTestFragment.isAutoStartClicked)
            onAutoHardwareTestListener.onHardwareTestFinish(0, "Vibration",
                    false);
        return false;
    }

    public void processOnClick() {
        if (cam == null) {
            try {
                cam = Camera.open();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (cam != null) {

            final Parameters params = cam.getParameters();

            List<String> flashModes = params.getSupportedFlashModes();

            if (flashModes == null) {
                return;
            } else {
                if (count == 0) {
                    params.setFlashMode(Parameters.FLASH_MODE_OFF);
                    cam.setParameters(params);
                    cam.startPreview();
                }

                String flashMode = params.getFlashMode();

                if (!Parameters.FLASH_MODE_TORCH.equals(flashMode)) {

                    if (flashModes.contains(Parameters.FLASH_MODE_TORCH)) {
                        params.setFlashMode(Parameters.FLASH_MODE_TORCH);
                        cam.setParameters(params);
                    } else {
                        // Toast.makeText(this,
                        // "Flash mode (torch) not supported",Toast.LENGTH_LONG).show();

                        params.setFlashMode(Parameters.FLASH_MODE_ON);

                        cam.setParameters(params);
                        try {
                            cam.autoFocus(new AutoFocusCallback() {
                                public void onAutoFocus(boolean success,
                                                        Camera camera) {
                                    count = 1;
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        if (cam == null) {
            return;
        }
    }

    public void processOffClick() {
        if (cam != null) {
            count = 0;
            cam.stopPreview();
        }
    }

    /**
     * This method is used to check flash-light.
     */
    public boolean ledon() {
        boolean workFlag = false;
        // if (Build.VERSION.SDK_INT >= 23) {
        // } else {
        String manuName = android.os.Build.MANUFACTURER.toLowerCase();
        Log.d(TAG, "Manufacturer : " + manuName);
        if (manuName.toLowerCase().equals("micromax")
                || manuName.toLowerCase().equals("motorola")) {
            DroidLED led;
            try {
                led = new DroidLED();
                led.enable(true);
                workFlag = true;
            } catch (Exception e) {
                Log.e(TAG, "DroidLEDException : " + e.toString());
            }
        } else if (manuName.toLowerCase().equals("lge")) {
            try {
                LogWrite.d(TAG, "FlashLight Check.....");
                // KTCamera camera = new KTCamera(activity);
                // cam = camera.getBackCameraInstance();
                cam = Camera.open();
                Parameters params = cam.getParameters();
                params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                cam.setParameters(params);
                SurfaceTexture mPreviewTexture = new SurfaceTexture(0);
                try {
                    cam.setPreviewTexture(mPreviewTexture);
                } catch (IOException ex) {
                    // Ignore
                    Log.e(TAG, "SurfaceTextureEx: " + ex.toString());
                }
                cam.startPreview();
                // try {
                // cam.autoFocus(new AutoFocusCallback() {
                // public void onAutoFocus(boolean success, Camera camera) {
                // }
                // });
                // } catch(ExceptionDTO e) {
                // Log.e(TAG, "AutoFocusException : " + e.toString());
                // }
                workFlag = true;
            } catch (Exception e) {
                e.printStackTrace();
                LogWrite.e(TAG, "FlashException : " + e.toString());
            }
        } else {

            try {
                LogWrite.d(TAG, "FlashLight Check.....");
                // KTCamera camera = new KTCamera(activity);
                // cam = camera.getBackCameraInstance();
                cam = Camera.open();
                Parameters params = cam.getParameters();
                params.setFlashMode(Parameters.FLASH_MODE_TORCH);
                cam.setParameters(params);
                cam.startPreview();
                try {
                    cam.autoFocus(new AutoFocusCallback() {
                        public void onAutoFocus(boolean success, Camera camera) {
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "AutoFocusException : " + e.toString());
                }
                workFlag = true;
            } catch (Exception e) {
                e.printStackTrace();
                LogWrite.e(TAG, "FlashException : " + e.toString());
            }
        }
        // }
        return workFlag;
    }

    public void ledoff() {

        Log.d(TAG, "ledoff method enters............");
        // if (Build.VERSION.SDK_INT >= 23) {
        // } else {

        try {

            String manuName = android.os.Build.MANUFACTURER.toLowerCase();
            if (manuName.toLowerCase().equals("micromax")
                    || manuName.toLowerCase().equals("motorola")) {
                DroidLED led;
                try {
                    led = new DroidLED();
                    led.enable(false);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } else {
                if (cam != null) {
                    cam.stopPreview();
                    cam.release();
                }
            }
            if (HardwareTestFragment.isAutoStartClicked)
                onAutoHardwareTestListener.onHardwareTestFinish(1,
                        "Flash Light", true);
        } catch (Exception e) {
            Log.e(TAG, "LEDOffException : " + e.toString());
            if (HardwareTestFragment.isAutoStartClicked)
                onAutoHardwareTestListener.onHardwareTestFinish(1,
                        "Flash Light", false);
        }

        // }
    }

    /**
     * This method is used to check flash is supported or not.
     *
     * @return hasFlash
     */
    public boolean hasFlash() {
        Camera camera = Camera.open();
        if (camera == null) {
            return false;
        }
        Camera.Parameters parameters = camera.getParameters();
        camera.release();
        if (parameters.getFlashMode() == null) {
            return false;
        }

        List<String> supportedFlashModes = parameters.getSupportedFlashModes();
        if (supportedFlashModes == null
                || supportedFlashModes.isEmpty()
                || supportedFlashModes.size() == 1
                && supportedFlashModes.get(0).equals(
                Camera.Parameters.FLASH_MODE_OFF)) {
            return false;
        }

        return true;
    }

    public boolean hasSystemFeature() {
        switch (type) {
            case HARDWARE_BLUETOOTH:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_BLUETOOTH) ? true : false;
            case HARDWARE_CAMERA:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_CAMERA) ? true : false;
            case HARDWARE_CAMERA_AUTOFOCUS:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_CAMERA_AUTOFOCUS) ? true : false;
            case HARDWARE_CAMERA_FLASH:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_CAMERA_FLASH) ? true : false;
            case HARDWARE_CAMERA_FRONT:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_CAMERA_FRONT) ? true : false;
            case HARDWARE_LIVE_WALLPAPER:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_LIVE_WALLPAPER) ? true : false;
            case HARDWARE_MICROPHONE:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_MICROPHONE) ? true : false;
            case HARDWARE_NFC:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_NFC) ? true : false;
            case HARDWARE_SENSOR_ACCELEROMETER:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_SENSOR_ACCELEROMETER) ? true : false;
            case HARDWARE_SENSOR_BAROMETER:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_SENSOR_BAROMETER) ? true : false;
            case HARDWARE_SENSOR_COMPASS:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_SENSOR_COMPASS) ? true : false;
            case HARDWARE_SENSOR_GYROSCOPE:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_SENSOR_GYROSCOPE) ? true : false;
            case HARDWARE_SENSOR_LIGHT:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_SENSOR_LIGHT) ? true : false;
            case HARDWARE_SENSOR_PROXIMITY:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_SENSOR_PROXIMITY) ? true : false;
            case HARDWARE_TOUCHSCREEN_MULTITOUCH:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH) ? true
                        : false;
            case HARDWARE_TOUCHSCREEN_MULTITOUCH_DISTINCT:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH_DISTINCT) ? true
                        : false;
            case HARDWARE_WIFI:
                return context.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_WIFI) ? true : false;
            default:
                return false;
        }
    }

    public enum HardwareType {
        HARDWARE_BLUETOOTH, HARDWARE_CAMERA, HARDWARE_CAMERA_AUTOFOCUS, HARDWARE_CAMERA_FLASH, HARDWARE_CAMERA_FRONT, HARDWARE_LIVE_WALLPAPER, HARDWARE_MICROPHONE, HARDWARE_NFC, HARDWARE_SENSOR_ACCELEROMETER, HARDWARE_SENSOR_BAROMETER, HARDWARE_SENSOR_COMPASS, HARDWARE_SENSOR_GYROSCOPE, HARDWARE_SENSOR_LIGHT, HARDWARE_SENSOR_PROXIMITY, HARDWARE_TOUCHSCREEN_MULTITOUCH, HARDWARE_TOUCHSCREEN_MULTITOUCH_DISTINCT, HARDWARE_WIFI
    }

    class DroidLED {
        private Object svc = null;
        private Method getFlashlightEnabled = null;
        private Method setFlashlightEnabled = null;

        public DroidLED() throws Exception {
            try {
                // call ServiceManager.getService("hardware") to get an IBinder
                // for the service.
                // this appears to be totally undocumented and not exposed in
                // the SDK whatsoever.
                Class<?> sm = Class.forName("android.os.ServiceManager");
                Object hwBinder = sm.getMethod("getService", String.class)
                        .invoke(null, "hardware");

                // get the hardware service stub. this seems to just get us one
                // step closer to the proxy
                Class<?> hwsstub = Class
                        .forName("android.os.IHardwareService$Stub");
                Method asInterface = hwsstub.getMethod("asInterface",
                        android.os.IBinder.class);
                svc = asInterface.invoke(null, (IBinder) hwBinder);

                // grab the class (android.os.IHardwareService$Stub$Proxy) so we
                // can reflect on its methods
                Class<?> proxy = svc.getClass();
                for (Method method : proxy.getMethods()) {
                    Log.d(TAG, "MethodName : " + method.getName());
                }
                // save methods
                getFlashlightEnabled = proxy.getMethod("getFlashlightEnabled");

                setFlashlightEnabled = proxy.getMethod("setFlashlightEnabled",
                        boolean.class);
            } catch (Exception e) {
                Log.e(TAG, "LEDinitializedException : " + e.toString());
                throw new Exception("LED could not be initialized");
            }
        }

        public boolean isEnabled() {
            try {
                return getFlashlightEnabled.invoke(svc).equals(true);
            } catch (Exception e) {
                return false;
            }
        }

        public void enable(boolean tf) {
            try {
                setFlashlightEnabled.invoke(svc, tf);
            } catch (Exception e) {
            }
        }
    }
}
