package com.kochartech.gizmodoctor.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class MyPreference {

	public static final String PREFERENCE_NAME = "gizmodoctor";
	public static final int PREFERENCE_MODE = 0;
	
	public SharedPreferences myPreference;
	public Editor editor;	
	public MyPreference(Context context) {
		myPreference = context.getSharedPreferences(PREFERENCE_NAME,
				PREFERENCE_MODE);
		editor = myPreference.edit();
	}

	public void setKeyValue(String key, String value) {
		editor.putString(key, value).commit();
	}

	public void setKeyValue(String key, int value) {
		editor.putInt(key, value).commit();
	}

	public String getValue(String key, String defaultValue)
	{	
		return myPreference.getString(key, defaultValue);
	}
	
	public int getValue(String key, int defaultValue)
	{	
		return myPreference.getInt(key, defaultValue);
	}
}
