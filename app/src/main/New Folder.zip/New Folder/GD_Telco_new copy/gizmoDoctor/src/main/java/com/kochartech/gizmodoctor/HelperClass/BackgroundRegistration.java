package com.kochartech.gizmodoctor.HelperClass;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;

import com.kochartech.HttpConn.HttpAsync;
import com.kochartech.gizmodoctor.Preferences.ActivationKeyPreference;
import com.kochartech.gizmodoctor.Preferences.AppFirstRunPreference;

public class BackgroundRegistration {

	private Context context;
	private ActivationKeyPreference activationKeyPreference;
	private AppFirstRunPreference appFirstRunPreference;

	public BackgroundRegistration(Context context) {

		this.context = context;
		activationKeyPreference = new ActivationKeyPreference(context);
		appFirstRunPreference = new AppFirstRunPreference(
				context.getApplicationContext());
		setup_ApplicationFirstRun();
	}

	public boolean hasActivationTime() {
		if (activationKeyPreference.getLeftTime() > 0)
			return true;
		else
			return false;
	}

	public void registerInBackground() {
		if (!activationKeyPreference.isActivationKeyRegister()) {
			String registrationData = getRegisterJsonObject();
			HttpAsync httpAsync = new HttpAsync(
					context.getApplicationContext(), 101,
					Config.getUrl_ValidateKey(), registrationData,
					HttpAsync.DATAFORMAT_JSON, false, true, true);
			httpAsync.execute("");
		}
	}

	private void setup_ApplicationFirstRun() {
		if (appFirstRunPreference.isApplicationFirstRun()) {
			activationKeyPreference.setLeftTime(864000000L);
			appFirstRunPreference.setApplicationFirstRun(false);
		}
	}

	private String getRegisterJsonObject() {
		DeviceInformation deviceInfo = new DeviceInformation(
				context.getApplicationContext());
		String imei = deviceInfo.getIMEI();
		String brand = deviceInfo.getBrand();
		String model = deviceInfo.getModel();
		String appVersion = AppInfo.getApplicationVersionName(context
				.getApplicationContext());
		JSONObject jsonRegisterInfo = new JSONObject();
		try {
			jsonRegisterInfo.put("ActivationKey", "GD-OD3BGCEH");
			jsonRegisterInfo.put("AppType", "Trial");
			jsonRegisterInfo.put("Brand", brand);
			jsonRegisterInfo.put("CustomerName", "NA");
			jsonRegisterInfo.put("Email", "NA");
			jsonRegisterInfo.put("IMEI", imei);
			jsonRegisterInfo.put("KeyCode",
					new AppConstants().getApplicationkeycode());
			jsonRegisterInfo.put("Mobile", "0");
			jsonRegisterInfo.put("Model", model);
			jsonRegisterInfo.put("Version", appVersion);
		} catch (JSONException e) {
		}
		return jsonRegisterInfo.toString();
	}

}
