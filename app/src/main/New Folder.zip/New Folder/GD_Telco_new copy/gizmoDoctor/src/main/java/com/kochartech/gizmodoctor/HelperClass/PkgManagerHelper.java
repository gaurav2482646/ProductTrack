package com.kochartech.gizmodoctor.HelperClass;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

public class PkgManagerHelper 
{
//	private Context context;
	private PackageManager pkgManager;
	public PkgManagerHelper(Context context)
	{
//		this.context = context;
		pkgManager = context.getPackageManager();
	}
	public List<ResolveInfo> getLauncherApps()
	{
		 Intent intent = new Intent(Intent.ACTION_MAIN, null);
		 intent.addCategory(Intent.CATEGORY_LAUNCHER);
		 return pkgManager.queryIntentActivities(intent, 0);    
	}
	public PackageManager getPackageManager()
	{
		return pkgManager;
	}
}
