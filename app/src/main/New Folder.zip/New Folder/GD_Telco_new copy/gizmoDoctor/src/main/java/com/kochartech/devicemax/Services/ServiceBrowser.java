package com.kochartech.devicemax.Services;
//package com.kochar.MDMS;
//
//import java.io.File;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.Timer;
//import java.util.TimerTask;
//
//
//
//import android.app.ActivityManager;
//import android.app.ActivityManager.RunningTaskInfo;
//import android.app.Service;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Environment;
//import android.os.Handler;
//import android.os.IBinder;
//import android.os.Message;
//import android.util.Log;
//
///*
// * Check TopMost App/Activity if ScreenLockFlag is true then password would be prompted  
// */
//public class ServiceBrowser extends Service 
//{  
//	String s1 = "";
//	private Timer timer = new Timer();
//	String activePackage = "";
//	StringBuilder log;
//	MyDataBaseHandlerClass myDataBase=null;
//	
//	
//	File root=null;
//	File file = null;
////	
//	public static boolean ScreenLockFlag=false;
//	String tag = ">>>> ServiceEg <<<<";
//	boolean f = false;
//
//	@Override
//	public void onCreate() 
//	{
//		super.onCreate();
//		startservice();
//		myDataBase = new MyDataBaseHandlerClass(getApplicationContext(),"operators.db",null,1);
//		myDataBase.getWritableDatabase();
//		root = Environment.getExternalStorageDirectory();
//        file = new File(root, "test.txt");
//	}
//
//	@Override
//	public IBinder onBind(Intent arg0) 
//	{
//		return null;
//	}
//
//	private void startservice() 
//	{
//		toastHandler.sendEmptyMessage(0);
//	}
//
//	private final Handler toastHandler = new Handler() 
//	{
//		@Override
//		public void handleMessage(Message msg) 
//		{
//			timer.scheduleAtFixedRate(new TimerTask() 
//			{
//				@Override
//				public void run() 
//				{
//					/*
//					 * we can't do events on ui directly inside main
//					 * thread,events like printing a toast message ,so we can do
//					 * this by using Handler so to print a toast message i use a
//					 * Handler object
//					 */
//					ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
//					RunningTaskInfo taskInfo = am.getRunningTasks(1).get(0);
//					String packageName = taskInfo.topActivity.getPackageName();
////					LogWrite.d(tag,"-----------------"+ packageName);
//					if(!ScreenLockFlag)
//					{
//						if(!packageName.trim().equalsIgnoreCase("com.kochar.MDMS"))
//						{
////							writeToFile(packageName.trim());
//							try
//							{
//							
////								if(Settings.System.getInt(getContentResolver(), Settings.System.AUTO_TIME, 0)==0)
////									Settings.System.putInt(getContentResolver(),Settings.System.AUTO_TIME, 1);  
////								Time now = new Time();
////						        now.setToNow();
////						        int hour = now.hour;
//						        String[] c =null;
//						        String[] c1=null;
//						        String[] c2=null;
////						        if(9<hour&&hour<19)
////								{
//						        	c = myDataBase.GetApplicationsFromDataBaseInBlockedTime();	
//						        	c1 = myDataBase.GetpackageFromDataBaseTime();
//						        	c2= myDataBase.GetApplicationFromDataBaseTime2();
//						        	
////								}
////						        else 
////						        {
////						        	c = myDataBase.GetApplicationsFromDataBaseInUnBlockedTime();
////								}
////						        LogWrite.d(tag,"----------------->"+ c.length+ "   "+hour);
//								for (int i = 0; i < c1.length; i++) 
//								{
//									int n=0;
//									if(packageName.trim().contains(""+c1[i]))
//									{
//										LogWrite.d(tag, "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
//									//	String[] AppsHardcoded={ };
//									//	LogWrite.d(tag," db pkg name"+c1[i]+"launched packg name=="+packageName);
//										n=i;
//										if(c2[n].contains("Browser")||c2[n].contains("opera")/*||c2[n].contains("firefox")||c2[n].contains("chrome")||c2[n].contains("Messenger")*/)
//										{
//											if(!activePackage.equalsIgnoreCase(""+packageName.trim())/*c1[i]*/)
//											{
//											 LogWrite.d(tag, "active pkg name="+activePackage+"app name=="+c1[i]);
//											 
//												activePackage = packageName.trim();
//												LogWrite.d(tag, "active pkg set=="+packageName.trim()+"mm");
//
//													Intent intent  = new Intent(ServiceBrowser.this,DisplayPasswordScreen.class);
//													intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
//													ServiceBrowser.this.startActivity(intent);
//								   		      }
//											break;
//											
//										}//End if(c2[n].contains("Browser"))
//										else
//										{
//											LogWrite.d(tag, "ffffffffffffffffffffffffffffffffffffffffffffff");
//											for (int e = 0; e < c.length; e++) 
//											{
//												LogWrite.d(tag, "pkg=="+packageName+" db pkg=="+c[e]);
//												if(packageName.trim().contains(""+c[e]))
//												{
//													LogWrite.d(tag,"inn iff");
//													if(!activePackage.equalsIgnoreCase(""+packageName.trim()))
//													{
//														activePackage = packageName.trim();
//
//															Intent intent  = new Intent(ServiceBrowser.this,DisplayPasswordScreen.class);
//															intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
//															ServiceBrowser.this.startActivity(intent);
////												
//													}
//													break;
//												}
//											}//end for
//										}//End else
//									}//end if(packageName.trim().contains(""+c1[i]))
//									
//								}//end for(c1)
//								
//								
//								
//								if(taskInfo.topActivity.getClassName().equals("com.android.settings.DeviceAdminSettings"))
//								{
//									if(!activePackage.equalsIgnoreCase(""+packageName.trim()))
//									{
//										
//									//	activePackage = packageName.trim().trim();
////										writeToFile(packageName.trim());
//										Intent intent  = new Intent(ServiceBrowser.this,DisplayPasswordScreen.class);
//										intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
//										ServiceBrowser.this.startActivity(intent);
//										
//									}
//								}
//								if(packageName.trim().equalsIgnoreCase("com.android.launcher")||
//										packageName.trim().equalsIgnoreCase("com.sec.android.app.twlauncher"))
//								{
//									activePackage = packageName.trim();
//									try
//									{
//									//	LogWrite.d("innnnnnnnnnnnnnnnnnnnnnnnnnn","launchereeerrrr");
//										DisplayPasswordScreen.getInstance().finish();
//									}
//									catch (ExceptionDTO e)
//									{
////										Log.e(tag,e.toString());s
//									}
//								}
//							}
//							catch (ExceptionDTO e)
//							{
//								e.printStackTrace();
//							}
//						}
//					}
//					else
//					{
//						if(!packageName.trim().equalsIgnoreCase("com.kochar.MDMS"))
//						{
//						//	
//						//	LogWrite.d("innnnnnnnnnnnnnnnnnnnnnnnnnn","not mdmsssssss");
//					/*************************************************************************************************************************/
////							Calendar cii=Calendar.getInstance();
////						      String CiiDateTime =  cii.get(Calendar.HOUR_OF_DAY) + ":" +
////							   cii.get(Calendar.MINUTE);
////						       LogWrite.d(" Current Time string",CiiDateTime);
////						   SimpleDateFormat dateFormat1 = new SimpleDateFormat("HH:mm");  
////						   Date crntTime;
////						   Date parseStartTime,parseEndTime;
////						   try {
////							crntTime=(Date) dateFormat1.parse(CiiDateTime);
////							LogWrite.d("time after parse",crntTime+"<<>>");
////							
////							String startTimeToParse="10:00";
////							String endTimeToParse="14:50";
////							parseStartTime=(Date) dateFormat1.parse(startTimeToParse);
////							parseEndTime=(Date) dateFormat1.parse(endTimeToParse);
////							LogWrite.d("parsed start time is",parseStartTime+"<<>>");
////							LogWrite.d("parsed end time is",parseEndTime+"<<>>");
////							if(crntTime.after(parseStartTime))
////							{
////								LogWrite.d(tag, "current time is after start time ");
////							}
////							if((crntTime.after(parseStartTime)) &&(crntTime.before(parseEndTime)))
////							{
////								LogWrite.d(tag, "current time is after start time n before end time");
////
////								Intent intent  = new Intent(ServiceEg.this,DisplayPasswordScreen.class);
////								intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
////								ServiceEg.this.startActivity(intent);
////							}
////							if(crntTime.before(parseEndTime))
////							{
////								LogWrite.d(tag, "current time is before end time ");
////							}
////							
////						} catch (ParseException e) {
////							// TODO Auto-generated catch block
////							e.printStackTrace();
////						}
//						
//				/******************************************************************************************************************************/
//							
//					//		writeToFile(packageName.trim());
//							Intent intent  = new Intent(ServiceBrowser.this,DisplayPasswordScreen.class);
//							intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |Intent.FLAG_ACTIVITY_NEW_TASK);
//							ServiceBrowser.this.startActivity(intent);
//						
//						}
//					}
//				}// end run
//			}, 0, 500);// end t
//		}
//	}; // End Handler
//
//	@Override
//	public void onDestroy() 
//	{
////		Toast.makeText(this, "My Service Stopped", Toast.LENGTH_LONG).show();
//	}
//
//	@Override
//	public void onStart(Intent intent, int startid) 
//	{
//		
//	}
//	@Override
//	public int onStartCommand(Intent intent, int flags, int startId) {
//		// TODO Auto-generated method stub
//		//return super.onStartCommand(intent, flags, startId);
//		startservice();
//		return Service.START_STICKY;
//	}
//	
////	void writeToFile(String str)
////	{
////		if (root.canWrite())
////		{
////            try 
////            {
////            	FileWriter filewriter = new FileWriter(file,true);
////                BufferedWriter out = new BufferedWriter(filewriter);
////				out.write(str+"\n");
////				out.close();
////			}
////            catch (IOException e) 
////            {
////            	Log.e(tag, "MSMS_Log-> IOException->"+e.toString());
////            }
////		}
////	}
//}
