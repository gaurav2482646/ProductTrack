package com.kochartech.devicemax.Utility;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.PermissionInfo;
import android.net.TrafficStats;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.kochartech.devicemax.Activities.RegisterUserActivity;

public class HandSetUtilty 
{
	TelephonyManager telephonyManager;
	String TAG = ">>>> MDMS <<<<";
	Context context;
	String IMSI;
	long dataUpdateInAllAPP;
	MyDataBaseHandlerClass dataBaseHandlerClass = null;

	public HandSetUtilty(Context cont) 
	{
		context = cont;
		IMSI = getIMSI();
	}

	public void getUidFromPackofInstalledApp() 
	{
		final PackageManager pm = context.getPackageManager();
		List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_UNINSTALLED_PACKAGES);
		dataBaseHandlerClass = new MyDataBaseHandlerClass(RegisterUserActivity.GetInstance(),"operators.db",null,1);
		dataBaseHandlerClass.getWritableDatabase();
		int UID;
		for (ApplicationInfo packageInfo : packages) 
		{
			UID = packageInfo.uid;
			boolean hasInternetPer = getPermissionsForPackage(pm,packageInfo.packageName);
//			String APPName = getAppNameFromPackage(packageInfo.packageName);
			// String per=packageInfo.permission;
			// int picon=packageInfo.icon;
			if (hasInternetPer) 
			{
//				LogWrite.d(TAG,">>>>>>>"+ packageInfo.packageName+"   >>>>"+hasInternetPer);
				insertORUpdate(UID, packageInfo.packageName);
			}
		}
		dataBaseHandlerClass.close();
	}

	public void insertORUpdate(int UID, String packageName)
	{
		
//		Cursor curUID = context.getContentResolver().query(
//				BillContentProvider.CONTENT_URIDATA,null,DataUsageTable.COLUMN_UID + "=? and "
//				+ DataUsageTable.COLUMN_IMSI + "=?",new String[] { UID + "", IMSI }, null);
//		LogWrite.d(TAG, "size===" + curUID.getCount());
//		ContentValues values = new ContentValues();
//		if (curUID.getCount() > 0) 
//		{
//			curUID.moveToFirst();
//			LogWrite.d(TAG,"UId=="+ (curUID.getString(curUID.getColumnIndex(DataUsageTable.COLUMN_UID)))
//					+ "AppName=="+ (curUID.getString(curUID.getColumnIndex(DataUsageTable.COLUMN_AppName))));
//			/*
//			 * values.put(DataUsageTable.COLUMN_ShowName,ShowName );
//			 * values.put(DataUsageTable.COLUMN_AppName,APPName );
//			 * values.put(DataUsageTable.COLUMN_UID,UID );
//			 */
//			String cc = curUID.getString(curUID.getColumnIndex(DataUsageTable.COLUMN_LastUsed));
//			long splastDataUsedSend;
//			if (cc.contains("-")) 
//			{
//				cc = cc.substring(1, cc.length());
//				splastDataUsedSend = -Long.parseLong(cc);
//			}
//			else 
//			{
//				splastDataUsedSend = Long.parseLong(cc);
//			}
//			// LogWrite.d(TAG, "cc=="+cc);
//			long dbLastDataUsedSend = curUID.getLong(curUID.getColumnIndex(DataUsageTable.COLUMN_AppDataUsed));
			// LogWrite.d(TAG, "dbLastDataUsedSend=="+dbLastDataUsedSend+"kb");
			long currentUsed = (TrafficStats.getUidTxBytes(UID) + TrafficStats.getUidRxBytes(UID)) / 1024;
			dataBaseHandlerClass.updatePresentDataCounter(packageName, currentUsed);
//			LogWrite.d(TAG,UID+">>>>"+ currentUsed+"<<<");
//			LogWrite.d(TAG, "UID----" + UID + "AppName==" + APPName+"  currentUsed---" +currentUsed+"  ShowName---" +ShowName);
			// LogWrite.d(TAG,
			// "currentUsed=="+currentUsed+"kb DDcurrentUsed=="+dbLastDataUsedSend+" kb splastDataUsedSend=="+splastDataUsedSend+"kb");
//			long newData = (currentUsed + splastDataUsedSend);
			// LogWrite.d(TAG, "con=="+newData);
//			if (newData > dbLastDataUsedSend) 
//			{
//				long DataUsed = currentUsed + splastDataUsedSend;
//				LogWrite.d(TAG, "Send==" + DataUsed);
//				long jj = (newData - dbLastDataUsedSend);
//				LogWrite.d(TAG, "jj==" + jj);
//				dataUpdateInAllAPP = dataUpdateInAllAPP + jj;
//				values.put(DataUsageTable.COLUMN_AppDataUsed, DataUsed);
//			}
//			else 
//			{
//				LogWrite.d(TAG, "send no value to update dbLastDataUsedSend=="+ dbLastDataUsedSend);
//			}
//			curUID.close();
//			try 
//			{
//				context.getContentResolver().update(BillContentProvider.CONTENT_URIDATA, values,
//						DataUsageTable.COLUMN_UID + "=?",new String[] { UID + "" });
//			}
//			catch (ExceptionDTO e)
//			{
//				LogWrite.d(TAG, "insert error ==" + e.toString());
//			}
//		}
//		else 
//		{
//
//			// values.put(DataUsageTable.COLUMN_ShowName,ShowName );
//			// values.put(DataUsageTable.COLUMN_AppName,APPName );
//			// values.put(DataUsageTable.COLUMN_UID,UID );
//			// long tBytes=
//			// ((TrafficStats.getUidTxBytes(UID)+TrafficStats.getUidRxBytes(UID))/1024);
//			// values.put(DataUsageTable.COLUMN_AppDataUsed, 0);
//			// values.put(DataUsageTable.COLUMN_IMSI, IMSI);
//			// values.put(DataUsageTable.COLUMN_LastSendData, 0);
//			// values.put(DataUsageTable.COLUMN_LastUsed, "-"+tBytes);
//			// db.insert("tblAppData", null,values);
//			curUID.close();
//			Uri todoUri = null;
//			LogWrite.d(TAG, "before insert");
//			try 
//			{
//				todoUri = context.getContentResolver().insert(BillContentProvider.CONTENT_URIDATA, values);
//				LogWrite.d(TAG, "todoUri==" + todoUri);
//			}
//			catch (ExceptionDTO e)
//			{
//				LogWrite.d(TAG, "insert error ==" + e.toString());
//			}
//		}
	}

	public String getAppNameFromPackage(String packageName) {
		final PackageManager pm = context.getPackageManager();
		ApplicationInfo ai;
		try {
			ai = pm.getApplicationInfo(packageName, 0);
		} catch (final NameNotFoundException e) {
			ai = null;
		}
		String applicationName = (String) (ai != null ? pm
				.getApplicationLabel(ai) : "(unknown)");
		// LogWrite.d(TAG, "applicationName==="+applicationName);
		return applicationName;
	}

	public final boolean getPermissionsForPackage(PackageManager pm,
			String packageName) {
//		LogWrite.d(TAG, "me==" + packageName);
		ArrayList<PermissionInfo> retval = new ArrayList<PermissionInfo>();
		try {
			PackageInfo packageInfo = pm.getPackageInfo(packageName,
					PackageManager.GET_PERMISSIONS);

			if (packageInfo.requestedPermissions != null) {
				for (String permName : packageInfo.requestedPermissions) {
					try {
						String per = pm.getPermissionInfo(permName,
								PackageManager.GET_META_DATA) + "";
						if (per.contains("android.permission.INTERNET")) {
							return true;

						}
						// LogWrite.d(TAG,
						// "Permission="+pm.getPermissionInfo(permName,
						// PackageManager.GET_META_DATA));
						retval.add(pm.getPermissionInfo(permName,
								PackageManager.GET_META_DATA));
					} catch (NameNotFoundException e) {
						// Not an official android permission... no big deal
					}
				}
			} 
//			else {
//				LogWrite.d(TAG, "packageInfo.requestedPermissions==="+ packageInfo.requestedPermissions);
//			}
		} catch (NameNotFoundException e) {
			Log.e(TAG, "That's odd package: " + packageName
					+ " should be here but isn't");
		}
		return false;
	}

	/*
	 * public String getApps() { String messageToSend=""; String appsStr="";
	 * ArrayList results = new ArrayList(); int appCount=1;
	 * 
	 * try { PackageManager pm = context.getPackageManager();
	 * 
	 * Intent intent = new Intent(Intent.ACTION_MAIN, null);
	 * intent.addCategory(Intent.CATEGORY_LAUNCHER); { List<ApplicationInfo>
	 * list =
	 * context.getPackageManager().getInstalledApplications(PackageManager
	 * .GET_UNINSTALLED_PACKAGES); for (int n=0;n<list.size();n++) {
	 * if((list.get(n).flags & ApplicationInfo.FLAG_SYSTEM)!=1) {
	 * results.add(list.get(n).loadLabel(pm).toString());
	 * LogWrite.d(TAG,list.get(n).loadLabel(pm).toString()+"  "+
	 * context.getString(R.string.app_name));
	 * if(!list.get(n).loadLabel(pm).toString
	 * ().equalsIgnoreCase(context.getString(R.string.app_name))) { appsStr+=
	 * "A"+ appCount + ":" +list.get(n).loadLabel(pm).toString() + ";" ;
	 * appCount++; LogWrite.d("Installed Applications",
	 * list.get(n).loadLabel(pm).toString()); int UID = list.get(n).uid;
	 * LogWrite.d(TAG, "packageInfo.packageName"+list.get(n).packageName); String
	 * APPName=getAppNameFromPackage(list.get(n).packageName);
	 * insertORUpdate(UID,APPName,list.get(n).loadLabel(pm).toString()); } } } }
	 * messageToSend= "<AP-"+(appCount-1)+":<"; messageToSend+=appsStr;
	 * messageToSend+=">;>;";
	 * 
	 * //breakMsgToSend(messageToSend, true); }catch(ExceptionDTO ex) {
	 * LogWrite.d(TAG,"error=="+ex.toString()); }
	 * 
	 * return messageToSend;
	 * 
	 * }
	 */
	public String getIMSI() {
		String serialNum = "";
		try {
			telephonyManager = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
			String NetworkMode = getNetworkMode();
			if (NetworkMode.equalsIgnoreCase("GSM")) {
				serialNum = telephonyManager.getSimSerialNumber();
				serialNum = serialNum.substring(5, serialNum.length());
			} else if (NetworkMode.equalsIgnoreCase("CDMA")) {
				serialNum = telephonyManager.getSubscriberId();
				int len = serialNum.length();
				for (int i = len; i < 15; i++) {
					serialNum = "0" + serialNum;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (serialNum == null) {
			serialNum = "";
		}
		return serialNum;
	}

	public String getNetworkMode() {
		telephonyManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		int phoneType = telephonyManager.getPhoneType();
		switch (phoneType) {
		case TelephonyManager.PHONE_TYPE_NONE:
			return "NONE";

		case TelephonyManager.PHONE_TYPE_GSM:
			return "GSM";

		case TelephonyManager.PHONE_TYPE_CDMA:
			return "CDMA";
		}
		return "";

	}
}
