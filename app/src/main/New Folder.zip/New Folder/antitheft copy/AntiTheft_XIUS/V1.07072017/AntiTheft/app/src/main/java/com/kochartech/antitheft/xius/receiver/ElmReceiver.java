package com.kochartech.antitheft.xius.receiver;

import android.app.enterprise.license.EnterpriseLicenseManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.MainActivity;
import com.kochartech.antitheft.xius.util.Utils;

/**
 * @author gagan.singh
 */
public class ElmReceiver extends BroadcastReceiver {

    private String TAG = ElmReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        String status = intent.getExtras().get(EnterpriseLicenseManager.EXTRA_LICENSE_STATUS).toString();
        int result_type = (Integer) intent.getExtras().get(EnterpriseLicenseManager.EXTRA_LICENSE_RESULT_TYPE);
        Intent intentBroadcast = new Intent(AppConstant.LOCAL_ELM_RECEIVER_ACTION1);
        Log.e(TAG, "status: " + status);
        Log.e(TAG, "result_type: " + result_type);
        if (status.equals("success")) {
            if (result_type == EnterpriseLicenseManager.LICENSE_RESULT_TYPE_ACTIVATION) {
                Toast.makeText(context, "ELM activation successful", Toast.LENGTH_LONG).show();
                editor.putBoolean(AppConstant.ELM_LICENSE_STATUS, true);
                editor.apply();
                Log.d(TAG, "onReceive: Sending broadcast");
                intentBroadcast.putExtra(AppConstant.LOCAL_ELM_RECEIVER_EXTRA_BOOLEAN,true);

                context.sendBroadcast(intentBroadcast);
                Log.d(TAG, "onReceive: Sending broadcast");

            }

            int error_code = (Integer) intent.getExtras().get(EnterpriseLicenseManager.EXTRA_LICENSE_ERROR_CODE);
            String error = foundError(error_code);

            if (error.equals("No error"))
                Toast.makeText(context, "KNOX licence validation completed successfully", Toast.LENGTH_LONG).show();

        } else if (status.equals("fail")) {
            editor.putBoolean(AppConstant.ELM_LICENSE_STATUS, false);
            editor.apply();
            int error_code = (Integer) intent.getExtras().get(EnterpriseLicenseManager.EXTRA_LICENSE_ERROR_CODE);
            String error = foundError(error_code);
            if (!error.equals("")) {
                Intent intentNotify = new Intent(context, MainActivity.class);
                intentNotify.putExtra("ActivateELM",false);
                Utils.showBigNotification("Samsung Knox Verification failed",context,intentNotify,101,true,true);

                intentBroadcast.putExtra(AppConstant.LOCAL_ELM_RECEIVER_EXTRA_BOOLEAN,false);
                context.sendBroadcast(intentBroadcast);

                Toast.makeText(context, "ELM KNOX Failed due to " + error, Toast.LENGTH_SHORT).show();

                // send callback
            }

        }


    }


    private String foundError(int error_code) {
        switch (error_code) {
            case EnterpriseLicenseManager.ERROR_INTERNAL:
                return "Internal Error";

            case EnterpriseLicenseManager.ERROR_INTERNAL_SERVER:
                return "Internal Server Error";

            case EnterpriseLicenseManager.ERROR_INVALID_LICENSE:
                return "Invalid Error";

            case EnterpriseLicenseManager.ERROR_INVALID_PACKAGE_NAME:
                return "Invalid Package Name";

            case EnterpriseLicenseManager.ERROR_LICENSE_TERMINATED:
                return "Licence Terminated";

            case EnterpriseLicenseManager.ERROR_NETWORK_DISCONNECTED:
                return "Network Disconnected";

            case EnterpriseLicenseManager.ERROR_NETWORK_GENERAL:
                return "General Network Error";

            case EnterpriseLicenseManager.ERROR_NO_MORE_REGISTRATION:
                return "No more registration with this device";

            case EnterpriseLicenseManager.ERROR_NONE:
                return "No error";

            case EnterpriseLicenseManager.ERROR_NOT_CURRENT_DATE:
                return "Not current date";

            case EnterpriseLicenseManager.ERROR_NULL_PARAMS:
                return "Error null parameters";
            case EnterpriseLicenseManager.ERROR_UNKNOWN:
                return "Unknown error";

            case EnterpriseLicenseManager.ERROR_USER_DISAGREES_LICENSE_AGREEMENT:
                return "User disagree licence agreement";
            default:
                return "";
        }
    }
}
