package com.kochartech.antitheft.xius.util;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;

import com.kochartech.antitheft.xius.AppConstant;
import com.sendgrid.SendGrid;
import com.sendgrid.SendGridException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import static com.kochartech.antitheft.xius.util.MailType.CALL_RECORDING;
import static com.kochartech.antitheft.xius.util.MailType.PHOTO;

/**
 * Created by gauravjeet on 18/3/17.
 */
//Used for sending mails through SendGrid API with attachment of any type
public class SendGridMailAsyncTask extends AsyncTask<Object, Void, Void> {
    private final String TAG = SendGridMailAsyncTask.class.getName();
    Context mContext = null;
    File file = null;
    String mMsgResponse, typeOfMail;


    /*
    private Context mAppContext;
       //TODO: add the following line if reqd:-->String mailTo,String mailFrom,String mailSubject,String mailText,Uri mailUri,String attachmentName
        public SendGridMailAsyncTask(Context context) {
        this.mAppContext= context;
            this.mTo=sharedPreferences.getString(AppConstant.EMAIL,null);
            this.mFrom="support@gizmohelp.com";
            this.mSubject="Snap Of Intruder";
            this.mText="PFA";
    //      this.mUri=mailUri;
            this.mAttachmentName="intruder";
    }   private String mMsgResponse;
        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(mAppContext);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        private String mTo;
        private String mFrom;
        private String mSubject;
        private String mText;
        private Uri mUri;
        private String mAttachmentName;
        NotificationManager notificationManager= (NotificationManager) mAppContext.getSystemService(Context.NOTIFICATION_SERVICE);
    */
    @Override
    protected Void doInBackground(Object... params) {
        try {
            Log.d(TAG, "doInBackground: Start Send Mail");
            //Context of Calling Component
            mContext = (Context) params[0];
            //Physical Path of Attached File
            file = new File((String) params[1]);
            //Type of Mail
            String mailType = (String) params[2];

            notifyEmailSendingInProgress(7, "Please wait while we you email regarding unauthorized access");
            Log.e(TAG, file.getAbsolutePath() + ">>>" + file.exists());
            if (file.exists()) {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                Log.d(TAG, "email address " + preferences
                        .getString(AppConstant.USER_EMAIL, ""));
                String[] toArr = new String[1];
                //Mail of Recipient
                toArr[0] = preferences
                        .getString(AppConstant.USER_EMAIL, "");
                SendGrid sendGrid = new SendGrid("kochargizmocontrol", "gizmo123");
                SendGrid.Email email = new SendGrid.Email();
//                email.addTo(toArr[0])
//                        .setFrom("support@gizmohelp.com")
//                        .setSubject("AntiTheft Alert")
//                        .setText("Dear Customer,\n There has been unauthorized access to your device.\n Download the Attachment for the snap of intruder.");
//                email.addAttachment("Snap.jpg", file);
                switch (mailType) {
                    case CALL_RECORDING:
                        Log.e(TAG, "doInBackground: sending CALL RECORDING");
                        email.addTo(toArr[0])
                                .setFrom("support@gizmohelp.com")
                                .setSubject("AntiTheft Alert")
                                .setText("Dear Customer,\n There has been unauthorized calls from your device.\n Download the Attachment for the to listen the conversation");
                        email.addAttachment("recording.amr", file);
                        break;
                    case PHOTO:
                        Log.e(TAG, "doInBackground: sending PHOTO");
                        email.addTo(toArr[0])
                                .setFrom("support@gizmohelp.com")
                                .setSubject("AntiTheft Alert")
                                .setText("Dear Customer,\n There has been unauthorized access to your device.\n Download the Attachment for the snap of intruder.");
                        email.addAttachment("Snap.jpg", file);
                        break;
                }
//            if(mUri!=null){
//                email.addAttachment(mAttachmentName,mAppContext.getContentResolver().openInputStream(mUri));
//            }
                SendGrid.Response response = sendGrid.send(email);
                mMsgResponse = response.getMessage();
                Log.d(TAG, "doInBackground: End of inBackground");
            }

        } catch (FileNotFoundException e) {
            Log.d(TAG, "doInBackground Exception: File dose'nt exist");
            e.printStackTrace();
        } catch (SendGridException | IOException e) {
            e.printStackTrace();
            Log.d(TAG, "doInBackground Exception: SendGrid Exception");
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        Log.d(TAG, "onPostExecute: Enter message response");
        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(7);
        notifyEmailSendingInProgress(8, "Mail Sent Successfully");
        Log.d(TAG, "onPostExecute: Response of EMAIL:= " + mMsgResponse);
    }

    void notifyEmailSendingInProgress(int id, String msg) {
        //TODO Notify user here
    }
}
