package com.kochartech.antitheft.xius.util;

/**
 * Created by gauravjeet on 2/1/18.
 */

public class MailType {
    public static final String CALL_RECORDING = "recording";
    public static final String PHOTO = "photo";
    public static final String BACKUP_CONTACTS = "backupContacts";


}
