package com.kochartech.antitheft.xius.user;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.dto.UserDTO;
import com.kochartech.antitheft.xius.util.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import br.com.simplepass.loading_button_lib.customViews.CircularProgressButton;
import br.com.simplepass.loading_button_lib.interfaces.OnAnimationEndListener;

public class UpdatePasswordActivity extends AppCompatActivity {
    private static final String TAG = "UpdatePasswordActivity";
    EditText etCurrentPassword, etNewPassword, etConfirmNewPassword;
    CircularProgressButton btnUpdatePassword;
    ProgressBar progressBar;
    PreferenceHelper preferenceHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_password);
        progressBar = (ProgressBar) findViewById(R.id.update_password_progress);
        etCurrentPassword = (EditText) findViewById(R.id.etCurrentPassword);
        etNewPassword = (EditText) findViewById(R.id.etNewPassword);
        etConfirmNewPassword = (EditText) findViewById(R.id.etConfirmNewPassword);
        btnUpdatePassword = (CircularProgressButton) findViewById(R.id.btnUpdatePassword);

        btnUpdatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mChangePassword(v);
            }
        });
        preferenceHelper = new PreferenceHelper(this);
    }


    //    method to check password validation
    private void mChangePassword(@Nullable View v) {

        if (!isValidPassword(etCurrentPassword.getText().toString())) {
            etCurrentPassword.requestFocus();
        } else if (!isValidPassword(etNewPassword.getText().toString())) {
            etNewPassword.requestFocus();
        } else if (!isValidConfirmPassword(etConfirmNewPassword.getText().toString())) {
            etConfirmNewPassword.requestFocus();

        } else if (!(etNewPassword.getText().toString().equals(etConfirmNewPassword.getText().toString()))) {
            etConfirmNewPassword.requestFocus();
            Toast.makeText(v.getContext(), "Password and confirm password does not match", Toast.LENGTH_SHORT).show();
            // mResetFields();

        } else if (!etCurrentPassword.getText().toString().equals(preferenceHelper.getString(AppConstant.PASSWORD, ""))) {
            Log.d(TAG, "mChangePassword Current: " + preferenceHelper.getString(AppConstant.PASSWORD, ""));
            Log.d(TAG, "mChangePassword New: " + etNewPassword.getText().toString());
            Toast.makeText(v.getContext(), "Please check the current password.", Toast.LENGTH_SHORT).show();
        } else {
//            Utils.isKeyBoardShow(UpdatePasswordActivity.this);
            btnUpdatePassword.startAnimation();
            volleyUpdatePasswordRequest();
        }
    }

    public void volleyUpdatePasswordRequest() {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();
        try {
            Log.d(TAG, "volleyUpdatePasswordRequest: " + getPasswordDTO().toString());
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    AppConstant.UPDATE_PASSWORD_URL, getPasswordDTO(),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject jsonObject) {
                            Log.d(TAG, jsonObject.toString());
                            mRequestQueue.stop();
                            try {

                                Log.d(TAG, "onResponse: " + jsonObject.toString());
                                if (jsonObject.getString("code").equals("0")) {
                                    btnUpdatePassword.revertAnimation(new OnAnimationEndListener() {
                                        @Override
                                        public void onAnimationEnd() {
                                            btnUpdatePassword.setText("Password Updated");
                                        }
                                    });
                                    Toast.makeText(UpdatePasswordActivity.this, "Password Successfully Changed", Toast.LENGTH_SHORT).show();
                                    preferenceHelper.saveString(AppConstant.PASSWORD, etNewPassword.getText().toString());
                                    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(UpdatePasswordActivity.this);

//
//                                showProgress(false);
                                } else {
                                    Toast.makeText(UpdatePasswordActivity.this, "Failed to change password", Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                btnUpdatePassword.revertAnimation();
                                Toast.makeText(UpdatePasswordActivity.this, "Some Error Occurred", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.d(TAG, "Error: " + error.getMessage());
                    Log.d(TAG, "onErrorResponse: " + error.getMessage());
                    Toast.makeText(UpdatePasswordActivity.this, "Failed to change password", Toast.LENGTH_SHORT).show();
                    btnUpdatePassword.revertAnimation();
                    Toast.makeText(UpdatePasswordActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    mRequestQueue.stop();
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }


            };
            mRequestQueue.add(jsonObjReq);
        } catch (Exception e) {
            btnUpdatePassword.revertAnimation();
            e.printStackTrace();
        }
    }

    private JSONObject getPasswordDTO() throws PackageManager.NameNotFoundException, JSONException {
        UserDTO userDTO = new UserDTO();
        userDTO.setPassword(etNewPassword.getText().toString());
        userDTO.setUserID(preferenceHelper.getInt(AppConstant.USER_ID, 0));
        Gson gson = new Gson();
        Log.d(TAG, "getPasswordDTO: " + userDTO.toString());
//        Toast.makeText(this, "getPasswordDTO: " + userDTO.toString(), Toast.LENGTH_LONG).show();
        return new JSONObject(gson.toJson(userDTO));
    }

    private boolean isValidPassword(String password) {
        if (password.length() == 0) {
            Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean isValidConfirmPassword(String password) {

        if (password.length() == 0) {
            Toast.makeText(this, "Please enter confirm password", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.length() < 6) {
            Toast.makeText(this, "Confirm Password must be atleast 6 characters long", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
