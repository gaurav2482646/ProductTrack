package com.kochartech.antitheft.xius.location;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStates;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.kochartech.antitheft.xius.dto.LocationDTO;
import com.kochartech.antitheft.xius.dto.Response;
import com.kochartech.antitheft.xius.dto.SendLocResponse;
import com.kochartech.antitheft.xius.dto.eventBus.GpsEvent;
import com.kochartech.antitheft.xius.util.Utils;
import com.yanzhenjie.permission.AndPermission;

import org.greenrobot.eventbus.EventBus;

//import com.google.android.gms.common.api.GoogleApiClient;

public class EnableLocationServiceActivity extends Activity implements
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {


    private static final int REQUEST_RESOLVE_ERROR = 1001;
    private static String TAG = EnableLocationServiceActivity.class.getName();
    // Bool to track whether the app is already resolving an error
    private static boolean mResolvingError = false;
    final int REQUEST_CHECK_SETTINGS = 10001;
    protected GoogleApiClient mGoogleApiClient;
    String commandID;

    protected Location mLastLocation;
    LocationRequest mLocationRequest = null;

    @Override
    public void onConnected(Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            Log.d(TAG, "onConnected:  Permission not Granted ");
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        commandID = getIntent().getStringExtra("CommandID");

        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "Connection suspended");
        mGoogleApiClient.connect();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.detail);


        buildGoogleApiClient();

        createLocationRequest();
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);

        PendingResult<LocationSettingsResult> result =
                LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient, builder.build());

        result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
            @Override
            public void onResult(LocationSettingsResult result) {
                final Status status = result.getStatus();
                final LocationSettingsStates states = result.getLocationSettingsStates();
                switch (status.getStatusCode()) {
                    case LocationSettingsStatusCodes.SUCCESS:
                        // All location settings are satisfied. The client can initialize location
                        // requests here.
                        Log.d(TAG, " success ");
                        finish();

                        break;
                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                        // Location settings are not satisfied. But could be fixed by showing the user
                        // a dialog.
                        Log.d(TAG, "resolution required ");
                        try {
                            // Show the dialog by calling startResolutionForResult(),
                            // and check the result in onActivityResult().
                            status.startResolutionForResult(
                                    EnableLocationServiceActivity.this,
                                    REQUEST_CHECK_SETTINGS);
                        } catch (IntentSender.SendIntentException e) {
                            Log.e(TAG, e.toString());
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        Log.d(TAG, "setting unavailable  ");
                        finish();
                        // Location settings are not satisfied. However, we have no way to fix the
                        // settings so we won't show the dialog.

                        break;
                }
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        final LocationSettingsStates states = LocationSettingsStates.fromIntent(data);
        switch (requestCode) {
            case REQUEST_CHECK_SETTINGS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        if (commandID != null) {
                            if (AndPermission.hasPermission(this, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) {
                                SingleShotLocationProvider.requestSingleUpdate(this,
                                        new SingleShotLocationProvider.LocationCallback() {
                                            @Override
                                            public void onNewLocationAvailable(SingleShotLocationProvider.GPSCoordinates location) {
                                                LocationDTO locDTO = new LocationDTO();
                                                locDTO.setMessageCommandId(commandID);
                                                locDTO.setCommandKey("LOC");
                                                locDTO.setMAC(Utils.getMACAddress().replace(":", ""));
                                                locDTO.setResponse(new Response(location.latitude + "", location.longitude + "", "Location Found"));
                                                new SendLocResponse(locDTO).start();
                                                Log.d(TAG, "my location is " + location.latitude + " " + location.longitude);
                                            }
                                        });
                            }
                        } else {
                            EventBus.getDefault().post(new GpsEvent(true));
                        }
                        // All required changes were successfully made
                        Log.d(TAG, "result ok ");
                        Log.d(TAG, "result ok ");
                        finish();

                        break;
                    case Activity.RESULT_CANCELED:
                        // The user was asked to change settings, but chose not to
                        //Send Response With 0 Lat and Lng with Correct Message, that GPS is OFF
                        Log.d(TAG, "result cancelled  ");
                        if (commandID != null) {
                            LocationDTO locDTO = new LocationDTO();
                            locDTO.setMessageCommandId(commandID);
                            locDTO.setCommandKey("LOC");
                            locDTO.setMAC(Utils.getMACAddress().replace(":", ""));
                            locDTO.setResponse(new Response(0 + "", 0 + "", "Gps is turned off on device."));
                            new SendLocResponse(locDTO).start();
                            Log.e(TAG, "onResultCancelled: " + locDTO.toString());
                            finish();
                        } else {
                            EventBus.getDefault().post(new GpsEvent(false));

                            finish();
                        }

                        break;
                    default:
                        break;
                }
                break;
        }

    }

    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        mGoogleApiClient.connect();

    }

    @Override
    public void onStop() {
        super.onStop();

        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }

    }

    public void openActivity(Context context2, Class<?> class1) {
        Intent intent = new Intent(this, class1).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.i(TAG, "Connection failed: ConnectionResult.getErrorCode() = " + connectionResult.getErrorCode());
        if (mResolvingError) {
            // Already attempting to resolve an error.
            return;
        } else if (connectionResult.hasResolution()) {
            try {
                mResolvingError = true;
                connectionResult.startResolutionForResult(this, REQUEST_RESOLVE_ERROR);
            } catch (IntentSender.SendIntentException e) {
                // There was an error with the resolution intent. Try again.
                mGoogleApiClient.connect();
            }
        } else {
            // Show dialog using GooglePlayServicesUtil.getErrorDialog()
            showErrorDialog(connectionResult.getErrorCode());
            mResolvingError = true;
        }


    }

    private void showErrorDialog(int errorCode) {
        Log.d(TAG, "showing error dialog");

    }


}
