package com.kochartech.antitheft.xius.sms;

import android.Manifest;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.backup.Contacts;
import com.kochartech.antitheft.xius.backup.SMS;
import com.kochartech.antitheft.xius.callRecord.CallController;
import com.kochartech.antitheft.xius.callRecord.CallRecordService;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.location.LocationTrackService;
import com.kochartech.antitheft.xius.lockscreen.ApplicationManager;
import com.kochartech.antitheft.xius.lockscreen.LockScreen;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.SamsungKNOX;
import com.yanzhenjie.permission.AndPermission;

import static android.content.Context.NOTIFICATION_SERVICE;

public class NotifySmsReceiver extends BroadcastReceiver {
    public static final String COMMAND_FORMAT = "AT PASSWORD COMMAND EG -> AT KIPL1234 CALL 9780898123";
    public static final String SMS_BACKUP = "sms";
    public static final String APPLY_POLICY = "applypolicy";
    public static final String REMOVE_POLICY = "removepolicy";
    public static final String START_ALARM = "Lost";
    public static final String STOP_ALARM = "Found";
    public static final String LOCK = "Lock";
    public static final String WIPE = "Wipe";
    public static final String UNLOCK = "Unlock";
    public static final String HIDE = "Hide";
    public static final String UNHIDE = "Unhide";
    public static final String START_RECORD = "Start Record";
    public static final String STOP_RECORD = "Stop Record";
    ComponentName LAUNCHER_COMPONENT_NAME;
    static final String ACTION_OLD = "android.provider.Telephony.SMS_RECEIVED";
    static final String ACTION = "android.provider.Telephony.SMS_DELIVER";
    private static final String TAG = "NotifySmsReceiver";
    private static final int REQUEST_CODE = 101;
    private static final String CONTACT_BACKUP = "contacts";
    private static final String START_LOCATE = "start_locate";
    private static final String STOP_LOCATE = "stop_locate";
    private static final String CALL = "call";
    private static final String FORWARD_SMS_START = "start_sms_forward";
    private static final String FORWARD_SMS_STOP = "stop_sms_forward";
    private static final String CC_SMS_START = "start_sms_cc";  // outgoing sms
    private static final String CC_SMS_STOP = "stop_sms_cc";
    private static final String CC_CALL_START = "start_call_cc";
    private static final String CC_CALL_STOP = "stop_call_cc";
    private static final String CC_ALL_START = "start_all_cc";
    private static final String CC_ALL_STOP = "stop_all_cc";
    PreferenceHelper preferenceHelper;
    boolean active;
    private DevicePolicyManager mDPM;
    private ComponentName mDeviceAdmin;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private Context mContext;
    private Context appContext;

    public NotifySmsReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent arg1) {
        mContext = context;
        appContext = ApplicationManager.getAppContext();
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = preferences.edit();
        mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        mDeviceAdmin = new ComponentName(context, KDeviceAdminReceiver.class);
        active = mDPM.isAdminActive(mDeviceAdmin);
        NotificationManager notiManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        preferenceHelper = new PreferenceHelper(context);
        Log.d(TAG, "onReceive: entered the method");
        if (arg1.getAction().equalsIgnoreCase(ACTION) || arg1.getAction().equalsIgnoreCase(ACTION_OLD)) {
            Log.d(TAG, "onReceive: Sms Received");
            Bundle extras = arg1.getExtras();

            String strMessage = "private message";
            if (extras != null) {
                Object[] smsextras = (Object[]) extras.get("pdus");

                for (int i = 0; i < smsextras.length; i++) {
                    SmsMessage smsmsg = SmsMessage.createFromPdu((byte[]) smsextras[i]);

                    String strMsgBody = smsmsg.getMessageBody().toString().trim();
                    String strMsgSrc = smsmsg.getOriginatingAddress();
                    Log.i(TAG, "MESSAGE TEXT:" + strMsgBody);
//                    Log.d(TAG,"From Other :"+strMsgBody);
//                    Toast.makeText(GasService.this,strMessage, Toast.LENGTH_SHORT).show();
                    //TODO UPDATE CONDITION
                    if (strMsgSrc.contains(preferences.getString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, ""))
                            ) {
//                    if (!strMsgSrc.isEmpty()) {

//                        strMessage += "SMS from " + strMsgSrc + " : " + strMsgBody;
                        Toast.makeText(context, strMsgBody, Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "From Registered: " + strMsgSrc);
                        if (strMsgBody.equalsIgnoreCase(APPLY_POLICY)) {
//                            notifyUser(context, "AntiTheft Alert!", "Policies are triggered via SMS Command", 11);
                            Log.d(TAG, "onReceive: in apply policy");
                            //TODO : Add own implementation Stealth Mode
//                            applyPolicy(true, arg0);
                        } else if (strMsgBody.equalsIgnoreCase(REMOVE_POLICY)) {
//                            notifyUser(context, "AntiTheft Alert!", "Policies are removed via SMS Command", 12);
                            Log.d(TAG, "onReceive:in remove policy ");
//                            applyPolicy(false, arg0);
                        }
//                        abortBroadcast();
                        else if (strMsgBody.equalsIgnoreCase(START_ALARM)) {
                            Log.d(TAG, "start alarm is called....");
//                            notifyUser(context, "AntiTheft Alert!", "Alarm is being played", 13);
                            SamsungKNOX.setPolicy(context, true);
                            showLockScreen(true);


//                            new AlarmServiceAsyncTask().execute(arg0);
                            new AlarmServiceAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, context);
                        } else if (strMsgBody.equalsIgnoreCase(STOP_ALARM)) {
                            Log.d(TAG, "stop alarm is called....");
//                            notiManager.cancel(13);
                            showLockScreen(false);

                            SamsungKNOX.setPolicy(context, false);
                            editor.putBoolean(AppConstant.ALARM_RUN_STATUS, false);
                            editor.apply();
                        } else if (strMsgBody.equalsIgnoreCase(LOCK)) {
                            Log.d(TAG, "Lock Device is called....");
                            DevicePolicyManager mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                            ComponentName mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
                            if (mDPM.isAdminActive(mDeviceAdminSample)) {
                                editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG + "", true);
                                editor.apply();
                                mDPM.lockNow();
//                                Intent in = new Intent(context, KDeviceAdminReceiver.Controller.class);
//                                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                in.putExtra("value", 4);
//                                context.startActivity(in);
                                showLockScreen(true);
                                SamsungKNOX.setPolicy(context, true);
//                                applyPolicy(true, arg0);

                            } else {
                                Log.d(TAG, "Lock Device Error: Admin is Not Active");
                            }

                        } else if (strMsgBody.equalsIgnoreCase(SMS_BACKUP)) {
                            Log.d(TAG, "SMS Backup is called....");
                            String path = SMS.backup(context);
                            Log.d(TAG, "onReceive: Path of SMS Backup " + path);
//                                new SendGridMailAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, arg0, path, "Mailing SMS Backup");
                        } else if (strMsgBody.equalsIgnoreCase(CONTACT_BACKUP)) {
                            Log.d(TAG, "Contact Backup is called....");
                            String path = Contacts.backup(context);

                            Log.d(TAG, "onReceive: Path of Contact Backup " + path);
//                                new SendGridMailAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, arg0, path, "Mailing SMS Backup");
                        } else if (strMsgBody.equalsIgnoreCase(UNLOCK)) {
                            Log.d(TAG, "Unlock Device Called....");
                            unlockDevice(context);
                            SamsungKNOX.setPolicy(context, false);

//                            applyPolicy(false,arg0);
                        } else if (strMsgBody.equalsIgnoreCase(START_LOCATE)) {
                            Log.d(TAG, "Unlock Device Called....");
                            context.startService(new Intent(context, LocationTrackService.class));

//                            applyPolicy(false,arg0);
                        } else if (strMsgBody.equalsIgnoreCase(WIPE)) {
                            Log.d(TAG, "Unlock Device Called....");
                            wipe();
//                            applyPolicy(false,arg0);
                        } else if (strMsgBody.trim().equalsIgnoreCase(HIDE)) {
                            LAUNCHER_COMPONENT_NAME = new ComponentName("com.kochartech.antitheft.xius", "com.kochartech.antitheft.xius.Launcher");
                            if (isLauncherIconVisible()) {
                                hideIcon(true);
                            }
                        } else if (strMsgBody.trim().equalsIgnoreCase(UNHIDE)) {
                            LAUNCHER_COMPONENT_NAME = new ComponentName("com.kochartech.antitheft.xius", "com.kochartech.antitheft.xius.Launcher");
                            if (!isLauncherIconVisible()) {
                                hideIcon(false);
                            }
                        } else if (strMsgBody.trim().equalsIgnoreCase(START_RECORD)) {
                            if (AndPermission.hasPermission(mContext, Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                                Intent intent = new Intent(mContext, CallRecordService.class);
                                mContext.startService(intent);
                                preferenceHelper.saveBoolean(AppConstant.IS_CALL_RECORDING_ENABLED, true);

                            } else if (strMsgBody.trim().equalsIgnoreCase(STOP_RECORD)) {
                                Intent intent = new Intent(mContext, CallRecordService.class);
                                mContext.stopService(intent);
                                preferenceHelper.saveBoolean(AppConstant.IS_CALL_RECORDING_ENABLED, true);
                            }
                            if (strMsgBody.equalsIgnoreCase(STOP_LOCATE)) {
                                Log.d(TAG, "Unlock Device Called....");
                                context.stopService(new Intent(context, LocationTrackService.class));
//                            applyPolicy(false,arg0);
                            }
                            if (strMsgBody.equalsIgnoreCase(CALL)) {
                                Log.d(TAG, "Unlock Device Called....");
                                CallController.makeACall(context, AppConstant.PREMIUM_NUMBER);
                            }
                        }
                    }
                }
            }
        }
    }

    public void unlockDevice(Context context) {

        KeyguardManager km = (KeyguardManager) context
                .getSystemService(Context.KEYGUARD_SERVICE);
        final KeyguardManager.KeyguardLock kl = km
                .newKeyguardLock("MyKeyguardLock");
        kl.disableKeyguard();

        PowerManager pm = (PowerManager) context
                .getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK
                | PowerManager.ACQUIRE_CAUSES_WAKEUP
                | PowerManager.ON_AFTER_RELEASE, "MyWakeLock");
        wakeLock.acquire();
        showLockScreen(false);

    }

    private void showLockScreen(boolean show) {

        int theme = android.R.style.Theme;
        try {
            PackageManager packageManager = mContext.getPackageManager();
            ApplicationInfo info = packageManager.getApplicationInfo(mContext.getPackageName(), PackageManager.GET_META_DATA);
            theme = info.theme;
        } catch (Exception e) {
            Log.e("showLockScreen", " " + e.toString());
        }
        LockScreen lockScreen = LockScreen.getInstance(theme);
        if (show) {
            Log.e(TAG, "showLockScreen: Lock Called");
            editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG, true);
            editor.commit();
            lockScreen.show();
        } else {
            Log.e(TAG, "showLockScreen: Unlock Called");
            editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG, false);
            editor.commit();
            lockScreen.remove();
        }
    }

    private boolean isLauncherIconVisible() {


        int isEnabled = appContext.getPackageManager().getComponentEnabledSetting(LAUNCHER_COMPONENT_NAME);
        return isEnabled != PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
    }

    private void hideIcon(boolean enable) {
        if (enable) {
            appContext.getPackageManager().setComponentEnabledSetting(LAUNCHER_COMPONENT_NAME,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            Log.d(TAG, "hideIcon:Enabled ");
            preferenceHelper.saveBoolean(AppConstant.IS_APP_HIDE_ENABLED, true);
        } else {
            appContext.getPackageManager().setComponentEnabledSetting(LAUNCHER_COMPONENT_NAME,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            preferenceHelper.saveBoolean(AppConstant.IS_APP_HIDE_ENABLED, false);
            Log.d(TAG, "hideIcon:Disabed ");

        }
    }

    private void notifyUser(Context context, CharSequence title, CharSequence msg, int noti_id) {
        Intent intent1 = new Intent();
        PendingIntent pendingIntent = PendingIntent.getActivity(context, REQUEST_CODE, intent1, 0);
        Notification n = new Notification.Builder(context)
                .setContentTitle(title)
                .setContentText(msg)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .build();
        NotificationManager notificationManage = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        notificationManage.notify(noti_id, n);
    }

    private void wipe() {
        /**
         *  wipe command response would be sent to server, if success/failure received
         *  wipe would be performed.
         *  WIPE_RECEIVED updated in preferences.
         *
         *   command would be sent only
         */
//        DevicePolicyManager mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
//        ComponentName mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
//        String commandResponse;
        if (mDPM.isAdminActive(mDeviceAdmin)) {

//            commandResponse = "MessageClass:Action;Command:GizmoControlRegistraion;Method:UpdateStatusAfterCommandExecute;" +
//                    "MsgCmdID:" + commandDTO.getId() + ";CmdStatus:1;Message:Done;";
            Intent in = new Intent(mContext, KDeviceAdminReceiver.Controller.class);
            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            in.putExtra("value", 1);
            mContext.startActivity(in);
        } else {
//            commandResponse = "MessageClass:Action;Command:GizmoControlRegistraion;Method:UpdateStatusAfterCommandExecute;" +
//                    "MsgCmdID:" + commandDTO.getId() + ";CmdStatus:0;Message:Device Admin is not active;";
            //TODO: Send Response here
        }
    }
}
