package com.kochartech.antitheft.xius.receiver;

import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.BuildConfig;
import com.kochartech.antitheft.xius.MainActivity;
import com.kochartech.antitheft.xius.StartupOperations;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.lockscreen.LockScreen;
import com.kochartech.antitheft.xius.sms.AlarmServiceAsyncTask;
import com.kochartech.antitheft.xius.util.PermissionUtilOLD;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;
import com.yanzhenjie.permission.AndPermission;


public class OnBootCompleteReceiver extends BroadcastReceiver implements DialogInterface.OnCancelListener {
    private static final String TAG = "BootReceiver";
    private static final int REQUEST_PREM = 11;
    SharedPreferences sharedPreference = PreferenceHelper.getSharedPreference();
    SharedPreferences.Editor editor = PreferenceHelper.getSharedPreferenceEditor();
    boolean googlePlayServicesExist = false;
    boolean active;
    Utils networkUtils;
    String regId;
    private DevicePolicyManager mDPM;
    private ComponentName mDeviceAdmin;
    private String imeiNumber;
    private Context mContext;
    PreferenceHelper preferenceHelper;

    public OnBootCompleteReceiver() {

    }

    @Override
    public void onReceive(Context context, Intent intent) {
        mContext = context;
        preferenceHelper = new PreferenceHelper(context);
        mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        mDeviceAdmin = new ComponentName(context, KDeviceAdminReceiver.class);
        active = mDPM.isAdminActive(mDeviceAdmin);

        networkUtils = new Utils();
        if (intent.getAction().equalsIgnoreCase(Intent.ACTION_BOOT_COMPLETED) || intent.getAction().equalsIgnoreCase("com.kochar.action.BOOT_COMPLETED")) {
            //Toast.makeText(context, "Boot Completed", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "onReceive: Boot Completed ");
           /* BootOperations bootOperations = new BootOperations();
            bootOperations.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, context);*/

            //IS USER REGISTERED CODE BLOCK
            if (sharedPreference.getBoolean(AppConstant.IS_LOGGED_IN, false)) {
                //Device Registered Block

                if (preferenceHelper.isDeviceRegistered()) {
                    //Check If Lost
                   /* if (sharedPreference.getBoolean(AppConstant.ALARM_RUN_STATUS, false)) {
                        new AlarmServiceAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, context);


                        lockDevice(context);

                    }
                    //Check If Locked

                    if (sharedPreference.getBoolean(AppConstant.SCREEN_LOCK_FLAG, false)) {
                        Log.e(TAG, "onReceive: SCREEN IS LOCKED HERE");
                        lockDevice(context);
                    }*/

                    //If SIM Changed
                    if (AndPermission.hasPermission(context, android.Manifest.permission.READ_PHONE_STATE)) {
                        if (networkUtils.isSimChanged(context)) {
//                    Utils.showOnGoingNotification("AntiTheft","Sim change detected",context,null,98);
                            Intent intent1 = new Intent(context, MainActivity.class);
                            Utils.showBigNotification("Sim change detected",
                                    context, intent1, 600, true, true);
                        }
                    }
                    if (!checkPermissions(context)) { //Check permissions here
                        Intent intent1 = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + BuildConfig.APPLICATION_ID));

                        Utils.showBigNotification("Missing Required Permission,Security is compromised",
                                context, intent1, 600, true, true);
                    }
                    startServices(context);
//                    if (networkUtils.isSimChanged(context)) {
////                    Utils.showOnGoingNotification("AntiTheft","Sim change detected",context,null,98);
//                        Intent intent1 = new Intent(context, DisplayActivity.class);
//                        Utils.showBigNotification("Sim change detected",
//                                context, intent1, 600, true, true);
//                    }
//                    if (!checkPermissions(context)) { //Check permissions here
//                        Intent intent1 = new Intent(context, DisplayActivity.class);
//                        Utils.showBigNotification("Missing Required Permission,Security is compromised",
//                                context, intent1, 600, true, true);
//                    }
//                    startServices(context);
                }
            }//IS USER REGISTERED CODE BLOCK END
        }
    }

    public void startServices(Context context) {
        Intent intent = new Intent();
        intent.setAction("com.kochartech.antitheft.xius.SCREEN_ON_SERVICE");
        intent.setPackage("com.kochartech.antitheft.xius");
        context.startService(intent);
        context.startService(new Intent(context, StartupOperations.class));
//        FirebaseJobDispatcher dispatcher =
//                new FirebaseJobDispatcher(new GooglePlayDriver(context));
//        Job myJob = dispatcher.newJobBuilder()
//                .setService(MyJobService.class)
//                .setLifetime(Lifetime.UNTIL_NEXT_BOOT)
//                .setTag(AppConstant.FCM_MESSAGE)
//                .build();
//        dispatcher.mustSchedule(myJob);
    }

    public void lockDevice(Context context) {
        ComponentName mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
        if (mDPM.isAdminActive(mDeviceAdminSample)) {
            editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG + "", true);
            editor.apply();
            mDPM.lockNow();
//          mDPM.lockNow();
//            Intent in = new Intent(context, KDeviceAdminReceiver.Controller.class);
//            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            in.putExtra("value", 4);
//            Intent lockScreenActivity = new Intent(context,LockActivity.class);
//            lockScreenActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//            context.startActivity(in);
//            context.startActivities(new Intent[]{in,lockScreenActivity},new Bundle());

            new Thread(new Runnable() {

                @Override
                public void run() {
                    Looper.prepare();
                    if (sharedPreference.getBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, false)) {
                        showLockScreen(true);
                    }
                    Looper.loop();
                }

            }).start();


        } else {
            Log.e(TAG, "lockDevice: Device Admin is not enabled");
        }
    }


    private void showLockScreen(boolean show) {
        int theme = android.R.style.Theme;
        try {
            PackageManager packageManager = mContext.getPackageManager();
            ApplicationInfo info = packageManager.getApplicationInfo(mContext.getPackageName(), PackageManager.GET_META_DATA);
            theme = info.theme;
        } catch (Exception e) {
            Log.e("showLockScreen", " " + e.toString());
        }
        LockScreen lockScreen = LockScreen.getInstance(theme);

        if (show) {
            lockScreen.show();
        } else {
            lockScreen.remove();

        }
    }

    void startAlarm(Context context) {
        new CountDownTimer(30 * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {

            }
        };
        new AlarmServiceAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, context);
    }

    @Override
    public void onCancel(DialogInterface dialogInterface) {

        //TODO : yet to a add some code here

    }

    void registerWithGCM(Context context) {
        Log.e(TAG, "registerWithGCM: called");

    }

    private boolean checkPlayServices(Context context) {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(context);
        Log.e(TAG, "checkPlayServices: " + resultCode);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                Log.d(TAG, "recoverable error occurred");
//                showErrorDialog(resultCode, context);
            }
            return false;
        }
        return true;
    }


    public boolean isSubscriptionExpired() {
        return false;
    }

    boolean checkPermissions(Context context) {
        return AndPermission.hasPermission(context, AppConstant.REQUIRED_PERMISSIONS);
    }


    class BootOperations extends AsyncTask<Context, Void, Void> {

        @Override
        protected Void doInBackground(Context... params) {
            Context context = params[0];
          /*  sharedPreference = PreferenceManager.getDefaultSharedPreferences(context);
            editor = sharedPreference.edit();*/
            try {
                if (sharedPreference.getBoolean(AppConstant.IS_LOGGED_IN, false)) {

                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    if (new PermissionUtilOLD().isPhonePermission(context) &&
                            new PermissionUtilOLD().isSMSPermission(context)) {
//              Utils.startLockAlarmService(context); // service only starts if phone and sms permission granted in case of Android M and after
                    }
                } else // for prior Android M ie. upto lollipop version
                {
//              Utils.startLockAlarmService(context);
                }
                /*if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {

                Utils.startLockAlarmService(context);
                Log.d(TAG, "service started");
                }else {

                Utils.registerPollReceiver(context);
                Log.d(TAG, "receiver registered");
                }*/


                /*Intent intentLock = new Intent(context, MainActivity.class);
                intentLock.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intentLock.putExtra("BootOn", 1);

                context.startActivity(intentLock);*/
                if (checkPlayServices(context)) {
                    Log.e(TAG, "onResume: gcm called");
                    googlePlayServicesExist = true;

//              if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    if (new PermissionUtilOLD().isPhonePermission(context)) {
                        Log.d(TAG, "onResume:before startupOperations Phone Permission Granted");
//              if (!isSubscriptionExpired() && sharedPreference.getBoolean(AppConstant.APP_OK_INSTALLED, false)) {
                        //GCM CODE
                        if (new Utils().isNetworkAvailable(context)) {

                            if (googlePlayServicesExist) {
                                Log.e(TAG, "doInBackground: Google PlayServices exist ");
                                registerWithGCM(context);
                            }
                        }
                        Log.e(TAG, "GCM Registration Executed");
                    }
                }
//              }
            } catch (Exception e) {
                Toast.makeText(context, "Error No. 1-1" + e.toString(), android.widget.Toast.LENGTH_LONG).show();
            }

            editor.commit();
            return null;
        }

    }
//
}
