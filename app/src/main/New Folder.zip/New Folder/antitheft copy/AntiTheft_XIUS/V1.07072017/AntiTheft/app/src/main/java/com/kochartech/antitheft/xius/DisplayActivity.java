package com.kochartech.antitheft.xius;

import android.app.ProgressDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.user.LoginActivity;
import com.kochartech.antitheft.xius.lockscreen.ApplicationManager;
import com.kochartech.antitheft.xius.services.ScreenOnOffService;
import com.kochartech.antitheft.xius.util.SamsungKNOX;
import com.kochartech.antitheft.xius.util.Utils;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.yanzhenjie.alertdialog.AlertDialog;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;
import com.yanzhenjie.permission.Rationale;
import com.yanzhenjie.permission.RationaleListener;
import com.yanzhenjie.permission.SettingService;

import java.util.List;

public class DisplayActivity extends AppCompatActivity {
    private static final String TAG = "DisplayActivity";
    private static final ComponentName LAUNCHER_COMPONENT_NAME = new ComponentName(
            "com.kochartech.antitheft.xius", "com.kochartech.antitheft.xius.Launcher");
    private static final int REQUEST_PREM = 1;
    private static final int REQUEST_APP_SETTING_FOR_PREM = 500;
    private static final int REQUEST_CODE_OVERLAY_PERMISSION = 171;
    private static final int REQUEST_CODE_DEVICE_ADMIN = 172;
    Button btn_hide;
    Boolean isHidden = false;
    ProgressDialog progressDialog;
    ConstraintLayout constraintLayout;
    SharedPreferences sharedPreferences = PreferenceHelper.getSharedPreference();
    SharedPreferences.Editor editor = PreferenceHelper.getSharedPreferenceEditor();
    boolean isOverlayGranted;
    private DevicePolicyManager mDPM;
    private ComponentName mAdminName;
    //    ArrayList<String> permissions = new ArrayList<>();
//    PermissionUtils permissionUtils;
//    boolean isPermissionGranted;
    private PermissionListener permissionListener;
    private RationaleListener rationaleListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_display);
        mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        mAdminName = new ComponentName(this, KDeviceAdminReceiver.class);
        if (isLauncherIconVisible()) {
            hideIcon();
        }

//        DeviceSettingsService.getInstance(getApplicationContext()).start();
//        Log.d(TAG, "onCreate: Alternate Number " + sharedPreferences.getString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, "default"));
        init();
        if (!checkOverlayPermission()) {
            overlayPermissionRationale();


        }
        if (!Utils.isMyServiceRunning(ScreenOnOffService.class, this)) {
            Log.d(TAG, "onResume: Service is not running ");
            Intent intent = new Intent();
            intent.setAction("com.kochartech.antitheft.xius.SCREEN_ON_SERVICE");
            intent.setPackage("com.kochartech.antitheft.xius");
            startService(intent);
        }
        initPermissionListener();
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1) {
            if (!sharedPreferences.getBoolean(AppConstant.IS_HIDE_APP_ALERT_SHOWN, false)) {
                hideAppAlert();
            }
        }
    }

    void overlayPermissionRationale() {

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage("Overlay permission is needed for locking functionality ?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.cancel();
                    }
                });

        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("AntiTheft Alert");
        alert.show();
    }

    private void initPermissionListener() {
        permissionListener = new PermissionListener() {
            @Override
            public void onSucceed(int i, @NonNull List<String> list) {
                switch (i) {
                    case REQUEST_PREM: {
                        Toast.makeText(DisplayActivity.this, "Permission Granted !", Toast.LENGTH_SHORT).show();
                        if (Utils.isNetworkAvailable(DisplayActivity.this)) {
                        } else {
                        }
                        break;
                    }
                }
            }

            @Override
            public void onFailed(int i, @NonNull List<String> list) {
                switch (i) {
                    case REQUEST_PREM: {
                        Toast.makeText(DisplayActivity.this, "Permissions required to continue !", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
                if (AndPermission.hasAlwaysDeniedPermission(DisplayActivity.this, list)) {
//                    AndPermission.defaultSettingDialog(DisplayActivity.this, REQUEST_PREM)
//                            .setTitle("Permissions Disabled")
//                            .setMessage("Please go to App Settings to Enable the Permissions Manaually")
//                            .setPositiveButton("Ok")
//                            .setNegativeButton("NO",
//                                    new DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int which) {
//                                            dialog.dismiss();
//                                        }
//                                    })
//                            .show();
                    SettingService settingHandle = AndPermission.defineSettingDialog(DisplayActivity.this, REQUEST_APP_SETTING_FOR_PREM);
                    settingHandle.execute();


                }
            }
        };
        rationaleListener = new RationaleListener() {
            @Override
            public void showRequestPermissionRationale(int requestCode, final Rationale rationale) {
                AlertDialog.newBuilder(DisplayActivity.this)
                        .setTitle("Permissions Required !")
                        .setMessage("Please enable all the permissions")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                                rationale.resume();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                                rationale.cancel();
                            }
                        }).show();
            }
        };
    }

    void showOverlayPermissionRationale() {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!AndPermission.hasPermission(DisplayActivity.this, AppConstant.REQUIRED_PERMISSIONS)) {
            Log.d(TAG, "onResume: not granted");
            Snackbar snackbar = Snackbar.make(constraintLayout, "Please Grant Permmision", Snackbar.LENGTH_INDEFINITE)
                    .setAction("Grant", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            AndPermission.with(DisplayActivity.this)
                                    .permission(AppConstant.REQUIRED_PERMISSIONS)
                                    .callback(permissionListener)
                                    .requestCode(REQUEST_PREM)
                                    .start();
                        }
                    });

            snackbar.show();
        } else {
            Log.d(TAG, "onResume: Permissions are granted");
        }
        if (!sharedPreferences.getBoolean(AppConstant.IS_USER_REGISTERED, false)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            startService(new Intent(this, StartupOperations.class));
            checkDeviceAdmin();
        }

//        permissionUtils.check_permission(permissions,"Need Permissions For App To Function !",REQUEST_PREM);
//        Utils.getSimNumber(this,1);
//        Log.d(TAG,"sim " + new DualSimInfo(this).getIMEI(1) + "carrier "+ new DualSimInfo(this).getCarrierName(1));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        /*if (requestCode == REQUEST_READ_PHONE_STATE) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            }
        }*/
//        permissionUtils.onRequestPermissionsResult(requestCode,permissions,grantResults);

    }

    public void hideAppAlert() {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setTitle("Note")
                .setMessage("App will be in hidden mode, Dial 1122 to launch it. ")
                .setCancelable(false)
                .setNeutralButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        editor.putBoolean(AppConstant.IS_HIDE_APP_ALERT_SHOWN, true);
                        editor.commit();
                        finish();
                    }
                });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_APP_SETTING_FOR_PREM: {
                if (AndPermission.hasPermission(DisplayActivity.this
                        , AppConstant.REQUIRED_PERMISSIONS)) {
                    Toast.makeText(this, "Anti-Theft is protecting your device", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "App will not be functional without permissions !", Toast.LENGTH_SHORT).show();
                }
                break;
            }

            case REQUEST_CODE_OVERLAY_PERMISSION: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(ApplicationManager.getAppContext())) {
                        editor.putBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, true);
                        editor.apply();
                        Toast.makeText(this, "Overlay permission is successfully granted", Toast.LENGTH_SHORT).show();
                        if (!sharedPreferences.getBoolean(AppConstant.IS_HIDE_APP_ALERT_SHOWN, false)) {
                            hideAppAlert();
                        }

                    } else {
                        editor.putBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, false);
                        editor.apply();
                        Toast.makeText(this, "Overlay permission is not granted, Lock Screen will not work.", Toast.LENGTH_SHORT).show();
                        if (!sharedPreferences.getBoolean(AppConstant.IS_HIDE_APP_ALERT_SHOWN, false)) {
                            hideAppAlert();
                        }
                    }
                }
                break;
            }
            case REQUEST_CODE_DEVICE_ADMIN: {
                if (resultCode == RESULT_OK) {
                    if (Utils.isDeviceSamsung(this)) {
                        if (sharedPreferences.getBoolean(AppConstant.ELM_LICENSE_STATUS, false)) {
                            Toast.makeText(this, "Please wait, Activating Samsung KNOX license", Toast.LENGTH_SHORT).show();
                            new SamsungKNOX().activateSamsunglicense(this);
                        } else {
                            Toast.makeText(this, "Device Admin is Active, AntiTheft is protecting your device.", Toast.LENGTH_SHORT).show();

                        }
                    } else {
                        Toast.makeText(this, "Device Admin is Active, AntiTheft is protecting your device.", Toast.LENGTH_SHORT).show();

                    }
                } else if (resultCode == RESULT_CANCELED) {
                    Toast.makeText(this, "Device Admin is not active, Device Security is compromised", Toast.LENGTH_LONG).show();
                    finish();
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private void init() {
        constraintLayout = (ConstraintLayout) findViewById(R.id.display_activity_constraint_layout);
        btn_hide = (Button) findViewById(R.id.btnHide);
        progressDialog = new ProgressDialog(DisplayActivity.this);
        progressDialog.setTitle("Hiding App");
        progressDialog.setMessage("Please Wait");
        if (isLauncherIconVisible()) {
            btn_hide.setText("HideMe");
        } else {
            btn_hide.setText("UnHide");
        }
    }

    //TODO Uncomment the code
    public void onAppHide(View view) {
      /*  new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                progressDialog.dismiss();
                if (isLauncherIconVisible()) {
                    btn_hide.setText("Hide");
                } else {
                    btn_hide.setText("Unhide");
                }
            }
        }, 10000);*/
//        if (isLauncherIconVisible()) {
//            btn_hide.setText("Hide");
//        } else {
//            btn_hide.setText("Unhide");
//        }


//        if (boolean_permission) {

        if (isLauncherIconVisible()) {
            hideIcon();
        } else {
            unHideIcon();
        }
    }

    private boolean isLauncherIconVisible() {
        int enabledSetting = getPackageManager().getComponentEnabledSetting(LAUNCHER_COMPONENT_NAME);
        return enabledSetting != PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
    }

    private void hideIcon() {
    /*    AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Important!");
        builder.setMessage("To launch the app again, dial phone number 1122");
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {*/
        getPackageManager().setComponentEnabledSetting(LAUNCHER_COMPONENT_NAME,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
//        onBackPressed();
      /*      }
        });
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.show();*/
    }

    private void unHideIcon() {
        PackageManager p = getPackageManager();
        ComponentName componentName = new ComponentName(this, com.kochartech.antitheft.xius.DisplayActivity.class);
        p.setComponentEnabledSetting(LAUNCHER_COMPONENT_NAME, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
    }

    private boolean checkOverlayPermission() {
        if (Build.VERSION_CODES.M <= Build.VERSION.SDK_INT) {
            return Settings.canDrawOverlays(this);

        }
        editor.putBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, true);
        editor.apply();
        return true;
    }

    private void checkDeviceAdmin() {
        if (!mDPM.isAdminActive(mAdminName)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminName);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Click on Activate                   button to secure your application.");
            startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN);
        } else {

        }
    }

}
