package com.kochartech.antitheft.xius.billing;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.kochartech.antitheft.xius.R;

import java.util.ArrayList;
import java.util.List;

public class MyBillingActivity extends AppCompatActivity implements BillingManager.BillingUpdatesListener, SkuDetailsResponseListener {
    BillingManager mBillingManager;
    private static final String TAG = "MyBillingActivity";
    List<String> stringList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_billing);
        stringList = new ArrayList<>();
        mBillingManager = new BillingManager(MyBillingActivity.this, this);
        stringList.add("sub1");
        mBillingManager.querySkuDetailsAsync(BillingClient.SkuType.SUBS, stringList, this);
        mBillingManager.queryPurchases();
    }

    public void startPurchase(View view) {
        mBillingManager.initiatePurchaseFlow("sub1", BillingClient.SkuType.SUBS);
    }

    @Override
    public void onBillingClientSetupFinished() {
        Log.e(TAG, "onBillingClientSetupFinished: ");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mBillingManager != null
                && mBillingManager.getBillingClientResponseCode() == BillingClient.BillingResponse.OK) {
            mBillingManager.queryPurchases();
        }
    }

    @Override
    public void onConsumeFinished(String token, int result) {
        Log.e(TAG, "onConsumeFinished: ");
    }

    @Override
    public void onPurchasesUpdated(List<Purchase> purchases) {
        Toast.makeText(this, "Purchase updated", Toast.LENGTH_SHORT).show();
        for (Purchase purchase : purchases) {
            Log.e(TAG, "onPurchasesUpdated List: " + purchase.toString());

        }
        Log.e(TAG, "onPurchasesUpdated: ");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mBillingManager.destroy();
    }

    @Override
    public void onSkuDetailsResponse(int responseCode, List<SkuDetails> skuDetailsList) {
        Log.i(TAG, "onSkuDetailsResponse: Response Code :" + responseCode);
        //todo if (responseCode != BillingResponse.OK) then traverse
        for (SkuDetails skuDetails : skuDetailsList) {
            Log.e(TAG, "onSkuDetailsList: " + skuDetails.toString());
        }
    }

    public void startProductPurchase(View view) {
        mBillingManager.initiatePurchaseFlow("mp1", BillingClient.SkuType.INAPP);

    }


}
