package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 24/8/17.
 */

public class Response
{
    public Response(String latitude, String longitude, String message){
        this.setLatitude(latitude);
        this.setLongitude(longitude);
        this.setMessage(message);
    }
    private String Latitude;

    private String Longitude;

    private  String Message;

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getLatitude ()
    {
        return Latitude;
    }

    public void setLatitude (String Latitude)
    {
        this.Latitude = Latitude;
    }

    public String getLongitude ()
    {
        return Longitude;
    }

    public void setLongitude (String Longitude)
    {
        this.Longitude = Longitude;
    }

    @Override
    public String toString()
    {
        return "Response [Latitude = "+Latitude+", Longitude = "+Longitude+"," +
                "Message = "+Message+"]";
    }
}