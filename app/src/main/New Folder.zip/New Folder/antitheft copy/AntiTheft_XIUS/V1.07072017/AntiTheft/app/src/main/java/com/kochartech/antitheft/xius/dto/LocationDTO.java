package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 24/8/17.
 */

public class LocationDTO
{
    private Response Response;

    private String CommandKey;

    private String MAC;

    private String MessageCommandId;

    public Response getResponse()
    {
        return Response;
    }

    public void setResponse(Response Response)
    {
        this.Response = Response;
    }

    public String getCommandKey ()
    {
        return CommandKey;
    }

    public void setCommandKey (String CommandKey)
    {
        this.CommandKey = CommandKey;
    }

    public String getMAC ()
    {
        return MAC;
    }

    public void setMAC (String MAC)
    {
        this.MAC = MAC;
    }

    public String getMessageCommandId ()
    {
        return MessageCommandId;
    }

    public void setMessageCommandId (String MessageCommandId)
    {
        this.MessageCommandId = MessageCommandId;
    }

    @Override
    public String toString()
    {
        return "LocationDTO [Response = "+ Response +", CommandKey = "+CommandKey+", MAC = "+MAC+", MessageCommandId = "+MessageCommandId+"]";
    }
}