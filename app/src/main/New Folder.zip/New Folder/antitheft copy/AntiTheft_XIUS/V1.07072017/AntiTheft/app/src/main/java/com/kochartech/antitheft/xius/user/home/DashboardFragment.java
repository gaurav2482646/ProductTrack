package com.kochartech.antitheft.xius.user.home;


import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.dto.eventBus.GpsEvent;
import com.kochartech.antitheft.xius.dto.eventBus.PinSetEvent;
import com.kochartech.antitheft.xius.dto.eventBus.ValidityEvent;
import com.kochartech.antitheft.xius.location.EnableLocationServiceActivity;
import com.kochartech.antitheft.xius.lockscreen.ApplicationManager;
import com.kochartech.antitheft.xius.user.ActivateAdminActivity;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;


/**
 * A simple {@link Fragment} subclass.
 */
public class DashboardFragment extends Fragment {
    boolean isNewDevice, fromRegisterActivity;
    boolean isDeviceActivated;
    PreferenceHelper preferenceHelper;
    CardView linearLayoutPending;
    TextView mTextViewValidity, mTextViewPendingAbsent, mTextViewPendingAdmin, mTextViewPendingPin, mTextViewOverlayPermission,
            mTextViewPendingTask, mTextViewLocationServices;
    int validity;
    Button activateDevice;
    private static final String TAG = "DashboardFragment";
    private boolean adminPendingTask;
    private boolean loginPinPendingTask;
    private boolean overlayPermissionPendingTask;
    private boolean locationServicesPendingTask;
    final int REQUEST_CODE_OVERLAY_PERMISSION = 1;
    boolean isOverlayPermissionGranted = false;
    private Utils utils;
    String manufacturerName;
    LocationManager locationManager;

    public DashboardFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: Called");

//        if (getActivity().getIntent() != null) {
//            isNewDevice = getActivity().getIntent().getBooleanExtra("newDevice", true);
//            fromRegisterActivity = getActivity().getIntent().getBooleanExtra("fromRegisterActivity", false);
//        }
        utils = new Utils();
        preferenceHelper = new PreferenceHelper(ApplicationManager.getAppContext());
        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        isDeviceActivated = preferenceHelper.isDeviceRegistered();
        manufacturerName = preferenceHelper.getString(AppConstant.MANUFACTURER_PHONE, "");
        validity = preferenceHelper.getInt(AppConstant.VALIDITY_AT_LOGIN, 0);
        checkPendingTask();
        if (manufacturerName.equals("xiaomi") || manufacturerName.equals("oppo") || manufacturerName.equals("vivo")) {
            utils.showAutoStartDialog(getActivity());
        }

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView: Called");
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        mTextViewValidity = (TextView) view.findViewById(R.id.tvValidity);
        mTextViewPendingTask = (TextView) view.findViewById(R.id.pending_task_textView);
        mTextViewPendingAbsent = (TextView) view.findViewById(R.id.tvPendingAbsent);
        mTextViewPendingAdmin = (TextView) view.findViewById(R.id.tvPendingActivateAdmin);
        mTextViewPendingPin = (TextView) view.findViewById(R.id.tvPendingSetupPin);
        mTextViewOverlayPermission = (TextView) view.findViewById(R.id.tvPendingOverlayPermission);
        mTextViewLocationServices = (TextView) view.findViewById(R.id.tvPendingLocationServices);
        linearLayoutPending = (CardView) view.findViewById(R.id.pending_task_cardView);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        checkPendingTask();
        utils.isAppExpired(getActivity());
        mTextViewValidity.setText(String.valueOf((preferenceHelper.getInt(AppConstant.VALIDITY_AT_LOGIN, 1)) - preferenceHelper.getInt(AppConstant.DAYS_ELAPSED, 0)));
        if (!(adminPendingTask || loginPinPendingTask || overlayPermissionPendingTask || locationServicesPendingTask)) {
            mTextViewPendingAdmin.setVisibility(View.GONE);
            mTextViewPendingPin.setVisibility(View.GONE);
            mTextViewOverlayPermission.setVisibility(View.GONE);
            mTextViewLocationServices.setVisibility(View.GONE);
            mTextViewPendingTask.setVisibility(View.VISIBLE);
            mTextViewPendingAbsent.setVisibility(View.VISIBLE);
        } else {
            mTextViewPendingAdmin.setVisibility(adminPendingTask ? View.VISIBLE : View.GONE);
            mTextViewPendingPin.setVisibility(loginPinPendingTask ? View.VISIBLE : View.GONE);
            mTextViewOverlayPermission.setVisibility(overlayPermissionPendingTask ? View.VISIBLE : View.GONE);
            mTextViewLocationServices.setVisibility(locationServicesPendingTask ? View.VISIBLE : View.GONE);
            mTextViewPendingAbsent.setVisibility(View.GONE);
            mTextViewPendingPin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    SetupPinDialogFragment setupPinDialogFragment = SetupPinDialogFragment.newInstance("", "");
                    FragmentManager fragmentManager = getFragmentManager();
                    setupPinDialogFragment.show(fragmentManager, "setup_pin_fragment");
                }
            });
            mTextViewPendingAdmin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), ActivateAdminActivity.class);
                    startActivity(intent);
                }
            });
            mTextViewOverlayPermission.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    utils.overlayPermissionRationale(getActivity(), REQUEST_CODE_OVERLAY_PERMISSION);
                }
            });
            mTextViewLocationServices.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getActivity().startActivity(new Intent(getActivity(), EnableLocationServiceActivity.class));
                }
            });
        }

        Log.d(TAG, "onResume: Called");

    }

    @Override
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }


    void checkPendingTask() {
        DevicePolicyManager mDPM;
        ComponentName mAdminName;
        mDPM = (DevicePolicyManager) getActivity().getSystemService(Context.DEVICE_POLICY_SERVICE);
        mAdminName = new ComponentName(getActivity(), KDeviceAdminReceiver.class);
        adminPendingTask = !mDPM.isAdminActive(mAdminName);
        loginPinPendingTask = !preferenceHelper.isLoginPinSetup();
        overlayPermissionPendingTask = Build.VERSION.SDK_INT > 20 && !utils.checkOverlayPermission(getActivity());
        locationServicesPendingTask = !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {


            case REQUEST_CODE_OVERLAY_PERMISSION: {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(ApplicationManager.getAppContext())) {
                        preferenceHelper.saveBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, true);
                        Toast.makeText(getActivity(), "Overlay permission is successfully granted", Toast.LENGTH_SHORT).show();
                        if (!preferenceHelper.getBoolean(AppConstant.IS_HIDE_APP_ALERT_SHOWN, false)) {
//                        hideAppAlert();
                        }

                    } else {
                        preferenceHelper.saveBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, false);
                        Toast.makeText(getActivity(), "Overlay permission is not granted, Lock Screen will not work.", Toast.LENGTH_SHORT).show();
                        if (!preferenceHelper.getBoolean(AppConstant.IS_HIDE_APP_ALERT_SHOWN, false)) {
//                        hideAppAlert();
                        }
                    }
                }
                break;
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onPinSetEvent(PinSetEvent pinSetEvent) {
        if (pinSetEvent.isSet) {
            if (!(adminPendingTask || overlayPermissionPendingTask || locationServicesPendingTask)) {
                mTextViewPendingAbsent.setVisibility(View.VISIBLE);
                mTextViewPendingTask.setVisibility(View.VISIBLE);
                mTextViewPendingPin.setVisibility(View.GONE);
                mTextViewPendingAdmin.setVisibility(View.GONE);
                mTextViewOverlayPermission.setVisibility(View.GONE);
                mTextViewLocationServices.setVisibility(View.GONE);

            } else {
                mTextViewPendingPin.setVisibility(View.GONE);
                mTextViewPendingAbsent.setVisibility(View.GONE);

            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onValidityEvent(ValidityEvent validityEvent) {
        Log.d(TAG, "onValidityEvent: Event Received");
        if (validityEvent.isExpired) {
            //Show Expired Fragment Or NotActivated
            Log.e(TAG, "onValidityEvent: App is expired");
            preferenceHelper.setAppExpired();
            preferenceHelper.setDeviceUnRegistered();
            Intent intent = new Intent(getActivity(), HomeActivity.class);
            intent.putExtra(HomeActivity.IS_EXPIRED, true);
            intent.putExtra(HomeActivity.DAYS_EXPIRED, (preferenceHelper.getInt(AppConstant.VALIDITY_AT_LOGIN, 1)) - preferenceHelper.getInt(AppConstant.DAYS_ELAPSED, 0));
            startActivity(intent);
            getActivity().finishAffinity();
        }
        mTextViewValidity.setText(String.valueOf((preferenceHelper.getInt(AppConstant.VALIDITY_AT_LOGIN, 1)) - preferenceHelper.getInt(AppConstant.DAYS_ELAPSED, 0)));
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onGpsEvent(GpsEvent gpsEvent) {
        if (gpsEvent.isTurnedOn) {
            mTextViewLocationServices.setVisibility(View.GONE);
            locationServicesPendingTask = false;
        }
    }

    @Override
    public void onStop() {
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        super.onStop();
    }


    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Called");
    }
}






