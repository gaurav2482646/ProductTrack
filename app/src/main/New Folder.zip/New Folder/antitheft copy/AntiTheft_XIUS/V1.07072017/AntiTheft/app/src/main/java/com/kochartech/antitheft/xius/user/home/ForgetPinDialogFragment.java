package com.kochartech.antitheft.xius.user.home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.util.PreferenceHelper;

/**
 * Created by gauravjeet on 29/11/17.
 */

public class ForgetPinDialogFragment extends DialogFragment {
    public static String ARG1 = "arg1";
    public static String ARG2 = "arg2";
    EditText editTextCurrentPassword;
    EditText editTextNewPin;
    EditText editTextNewPinConfirm;
    Button buttonSubmit;
    PreferenceHelper preferenceHelper;

    public ForgetPinDialogFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferenceHelper = new PreferenceHelper(getContext());
    }

    public static ForgetPinDialogFragment newInstance(String arg1, String arg2) {
        ForgetPinDialogFragment setupPinDialogFragment = new ForgetPinDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG1, arg1);
        args.putString(ARG2, arg2);
        setupPinDialogFragment.setArguments(args);
        return setupPinDialogFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog_forget_pin, container);
        editTextCurrentPassword = (EditText) view.findViewById(R.id.editTextCurrentPin);
        editTextNewPin = (EditText) view.findViewById(R.id.editTextNewPin);
        editTextNewPinConfirm = (EditText) view.findViewById(R.id.editTextConfirmNewPin);
        buttonSubmit = (Button) view.findViewById(R.id.button_change_pin);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final String accountPassword = preferenceHelper.getString(AppConstant.PASSWORD, "");
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editTextCurrentPassword.getText())) {
                    Toast.makeText(getActivity(), "Enter the password", Toast.LENGTH_SHORT).show();
                } else if (!TextUtils.equals(editTextCurrentPassword.getText().toString(), accountPassword)) {
                    Toast.makeText(getActivity(), "Wrong password entered", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.equals(editTextCurrentPassword.getText().toString(), accountPassword)) {
                    Toast.makeText(getActivity(), "Login Pin Successfully Reset", Toast.LENGTH_SHORT).show();
                    Toast.makeText(getActivity(), "Please Set a new Login Pin", Toast.LENGTH_SHORT).show();
                    preferenceHelper.saveBoolean(AppConstant.IS_LOGIN_PIN_SET, false);
                    preferenceHelper.removeKey(AppConstant.LOGIN_PIN_CODE);
                    dismiss();
                    startActivity(new Intent(getActivity(), HomeActivity.class));
                }
            }
        });
    }
}
