package com.kochartech.antitheft.xius.lockscreen;

import android.content.Context;

/**
 * Created by S on 11/15/2016.
 */

public class ApplicationManager {
    private static Context appContext;

    protected static void setAppContext(Context context) {
        appContext = context;
    }

    public static Context getAppContext() {
        return appContext;
    }
}
