package com.kochartech.antitheft.xius.user;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.StartupOperations;
import com.kochartech.antitheft.xius.dto.eventBus.LogoutEvent;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by gauravjeet on 23/11/17.
 */

public class UserSessionManager {
    PreferenceHelper preferenceHelper;
    Context context;
    private static final String TAG = "UserSessionManager";

    public UserSessionManager(Context context) {
        this.context = context;
        preferenceHelper = new PreferenceHelper(context);
    }

    void createLoginSession(boolean isActivated) {
        if (isActivated) {
            preferenceHelper.saveBoolean(AppConstant.IS_LOGGED_IN, true);
        } else {
            preferenceHelper.saveBoolean(AppConstant.IS_LOGGED_IN, true);
        }
    }

    public boolean checkLogin() {
        if (!this.isLoggedIn()) {
            if (context instanceof Activity) {
                ((Activity) (context)).finish();
            }
//            logout();
            Intent i = new Intent(context, LoginOrRegisterActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);

            return false;
        }
        return true;
        //Clear all the Login Related Pref , like IsLoggedIn, IsRegistered, IsActivated
    }

    public void logout() {
        preferenceHelper.saveBoolean(AppConstant.IS_LOGGED_IN, false);
        preferenceHelper.setDeviceUnRegistered();
        preferenceHelper.setUserUnRegistered();
        resetSharedPreference();
        EventBus.getDefault().post(new LogoutEvent(true));
        context.startService(new Intent(context, StartupOperations.class));
        preferenceHelper.saveBoolean(AppConstant.IS_LOGIN_PIN_SET, false);
        //Unhide the app if it is hidden
        Utils.unHideIcon(context);
        Utils utils = new Utils();
        Activity activity = utils.getActivity(context);
        activity.finishAffinity();
        Intent i = new Intent(context, LoginOrRegisterActivity.class);
//        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(i);
        Log.d(TAG, "logout: ");
    }

    void resetSharedPreference() {
        preferenceHelper.removeKey(AppConstant.DAYS_ELAPSED);
        preferenceHelper.removeKey(AppConstant.LOGIN_TIME);
        preferenceHelper.removeKey(AppConstant.IS_APP_HIDE_ENABLED);
        preferenceHelper.removeKey(AppConstant.IS_CALL_RECORDING_ENABLED);
        preferenceHelper.removeKey(AppConstant.LOGIN_PIN_CODE);
        preferenceHelper.removeKey(AppConstant.IS_APP_EXPIRED);
    }
    boolean isLoggedIn() {
        return preferenceHelper.getBoolean(AppConstant.IS_LOGGED_IN, false);
    }

}
