package com.kochartech.antitheft.xius.fcm;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import com.google.firebase.iid.FirebaseInstanceId;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.util.Utils;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by gaurav on 1/8/17.
 */

public class MyJobService extends JobService {
    private static final String TAG = "JobService";

    @Override
    public boolean onStartJob(JobParameters job) {
        Log.d(TAG, "Start Job");
        String tag = job.getTag();
        boolean fromMainActivity = job.getExtras().getBoolean("fromMainActivity", false);
        if (fromMainActivity) {
            sendBroadcast(new Intent("com.kochar.action.BOOT_COMPLETED"));
        } else {
            switch (tag) {
                case AppConstant.FCM_MESSAGE:

                    break;
            }
            volleyUpdateRegistrationID();
        }
        jobFinished(job, true);
        return false;
    }


    @Override
    public boolean onStopJob(JobParameters job) {
        return true;
    }

    public void volleyUpdateRegistrationID() {
        RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();

        HashMap<String, String> params = getRegisterDeviceMap();

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                AppConstant.UPDATE_DEVICE_REGISTRATION_ID, new JSONObject(params),
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());

                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());

            }
        }) {

            /**
             * Passing some request headers
             * */
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }


        };
        mRequestQueue.add(jsonObjReq);

    }

    HashMap<String, String> getRegisterDeviceMap() {
        try {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String refreshedToken = FirebaseInstanceId.getInstance().getToken();
            String regId = sharedPreferences.getString(AppConstant.REGISTRATION_ID_FCM, "");
            int userId = sharedPreferences.getInt(AppConstant.USER_ID, 0);

            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put(AppConstant.MAC_ADDRESS, Utils.getMACAddress().replace(":", ""));
            hashMap.put(AppConstant.REGISTRATION_ID_FCM, refreshedToken);
            hashMap.put(AppConstant.USER_ID, String.valueOf(userId));
            Log.d(TAG, "json " + hashMap.toString());

            return hashMap;

        } catch (Exception ex) {
            Log.e(TAG, "ex create json " + ex.toString());
        }
        return null;
    }
}
