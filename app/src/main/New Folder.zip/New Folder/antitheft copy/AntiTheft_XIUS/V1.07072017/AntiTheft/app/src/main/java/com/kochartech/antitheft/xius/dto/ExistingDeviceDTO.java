package com.kochartech.antitheft.xius.dto;

/**
 * Created by sukhbir_singh on 10/11/17.
 */

public class ExistingDeviceDTO
{

    private String macAddress;

    public String getMacAddress ()
    {
        return macAddress;
    }

    public void setMacAddress (String macAddress)
    {
        this.macAddress = macAddress;
    }


    @Override
    public String toString()
    {
        return "DeviceDTO [macAddress = "+macAddress+"]";
    }
}
