package com.kochartech.antitheft.xius.lockscreen;

import android.app.Application;

/**
 * Created by S on 11/15/2016.
 */

public class Main extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        ApplicationManager.setAppContext(getApplicationContext());
    }
}
