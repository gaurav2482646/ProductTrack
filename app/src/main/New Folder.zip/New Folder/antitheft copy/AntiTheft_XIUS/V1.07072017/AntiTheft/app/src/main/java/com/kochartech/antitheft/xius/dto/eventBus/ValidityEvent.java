package com.kochartech.antitheft.xius.dto.eventBus;

/**
 * Created by gauravjeet on 18/12/17.
 */

public class ValidityEvent {
    public boolean isExpired = false;
    public int daysLeft;

    public ValidityEvent(boolean isExpired, int daysLeft) {
        this.isExpired = isExpired;
        this.daysLeft = daysLeft;
    }
}
