package com.kochartech.antitheft.xius;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.fcm.MyJobService;
import com.kochartech.antitheft.xius.user.UserSessionManager;
import com.kochartech.antitheft.xius.user.home.HomeActivity;
import com.kochartech.antitheft.xius.user.home.LoginWithPinActivity;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.SamsungKNOX;
import com.kochartech.antitheft.xius.util.Utils;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_RESOLVE_ERROR = 1;
    private static final String TAG = "MainActivity";
    private static final int REQUEST_CODE_DEVICE_ADMIN = 2;
    private DevicePolicyManager mDPM;
    private View mMainProgressView;
    private View mMainLayoutView;
    private ComponentName mAdminName;
    SharedPreferences sharedPreferences;
    UserSessionManager userSessionManager;
    PreferenceHelper preferenceHelper;
    SharedPreferences.Editor editor;
    boolean isActivatedKNOX;
    LocalElmActivationReceiver localElmActivationReceiver;
    Utils utils;
    boolean isAppExpired;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        preferenceHelper = new PreferenceHelper(this);
        userSessionManager = new UserSessionManager(this);
        mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        mAdminName = new ComponentName(this, KDeviceAdminReceiver.class);
        sharedPreferences = PreferenceHelper.getSharedPreference();
        editor = PreferenceHelper.getSharedPreferenceEditor();
        utils = new Utils();
        mMainLayoutView = findViewById(R.id.main_activity_layout);
        mMainProgressView = findViewById(R.id.main_activity_progress);
        isAppExpired = preferenceHelper.isAppExpired();
        if (utils.isAppFirstRun(this)) {
            Log.d(TAG, "onCreate: APP IS RUN FOR FIRST TIME");
            utils.getSamsungBrand(this);
            utils.storeManufactureName(this);
        }
//        scheduleJob();
        openTheCorrectActivity();

//        showProgress(true);
       /* PermissionUtilOLD.checkPermission(this, Manifest.permission.ACCESS_FINE_LOCATION,this);
        PermissionUtilOLD.checkPermission(this, Manifest.permission.READ_PHONE_STATE,this);
        PermissionUtilOLD.checkPermission(this, Manifest.permission.PROCESS_OUTGOING_CALLS,this);
        PermissionUtilOLD.checkPermission(this, Manifest.permission.READ_SMS,this);*/
//        checkDeviceAdmin();

    }

    private void scheduleJob() {
        FirebaseJobDispatcher dispatcher =
                new FirebaseJobDispatcher(new GooglePlayDriver(this));
        Bundle bundle = new Bundle();
        bundle.putBoolean("fromMainActivity", true);
        Job myJob = dispatcher.newJobBuilder()
                .setService(MyJobService.class)
                .setLifetime(Lifetime.FOREVER)
                .setTag("my-unique-tag-test")
                .setRecurring(true)
                .setTrigger(Trigger.executionWindow(0, 60))
                .setReplaceCurrent(false)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .setConstraints()
                .setExtras(bundle)
                .build();
        dispatcher.mustSchedule(myJob);
        Log.d(TAG, "scheduleJob:Job Scheduled ");
    }

    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mMainLayoutView.setVisibility(show ? View.GONE : View.VISIBLE);
            mMainLayoutView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mMainLayoutView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mMainProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mMainProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mMainProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mMainProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mMainLayoutView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (checkPlayServices(this)) {
            // if user is not logged in present register screen login into app a
            if (userSessionManager.checkLogin()) {
                if (preferenceHelper.isLoginPinSetup()) {
                    //Open Unlock Pin Screen
                    finish();
                    Intent intent = new Intent(this, LoginWithPinActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);

                } else {
                    //Open Dashboard
                    Intent intent = new Intent(this, HomeActivity.class);
                    intent.putExtra(HomeActivity.IS_EXPIRED, isAppExpired);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
            }
//                startActivity(new Intent(this, LoginActivity.class));
//                finish();
        } else {
//                startService(new Intent(this, StartupOperations.class));
//                checkDeviceAdmin();
        }
    }

    void openTheCorrectActivity() {
        if (userSessionManager.checkLogin()) {
            // if user is not logged in present register screen login into app a
            if (preferenceHelper.isLoginPinSetup()) {
                //Open Unlock Pin Screen
                Intent intent = new Intent(this, LoginWithPinActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();

            } else {
                //Open Dashboard
                Intent intent = new Intent(this, HomeActivity.class);
                intent.putExtra(HomeActivity.IS_EXPIRED, isAppExpired);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        }
    }
//    }  @Override
//    protected void onResume() {
//        super.onResume();
//        if (checkPlayServices(this)) {
//            // if user is not registered present register screen login into app a
//            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
//            if (!sharedPreferences.getBoolean(AppConstant.IS_USER_REGISTERED, false)) {
//                startActivity(new Intent(this, LoginActivity.class));
//                finish();
//            } else {
//                startService(new Intent(this, StartupOperations.class));
//                checkDeviceAdmin();
//            }
//        }
//    }
//If LoggedIN-->IfPinset-->Pin Screen else Dashboard

    private void checkDeviceAdmin() {
        if (!mDPM.isAdminActive(mAdminName)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminName);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Click on Activate button to secure your application.");
            startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN);
        } else if (Utils.isDeviceSamsung(this)) {

            isActivatedKNOX = getIntent().getBooleanExtra(AppConstant.LOCAL_ELM_RECEIVER_EXTRA_BOOLEAN, false);
            if (!sharedPreferences.getBoolean(AppConstant.ELM_LICENSE_STATUS, false)) {
                new SamsungKNOX().activateSamsunglicense(this);
                Toast.makeText(this, R.string.please_wait_knox_activate, Toast.LENGTH_SHORT).show();

            } else {
                Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        } else {
            Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        }
    }


    private boolean checkPlayServices(Context context) {
        int resultCode = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context);
        Log.e(TAG, "checkPlayServices: " + resultCode);
        if (resultCode != ConnectionResult.SUCCESS) {

            if (GoogleApiAvailability.getInstance().isUserResolvableError(resultCode)) {
                Log.d(TAG, "recoverable");
                showErrorDialog(resultCode);
            }
            return false;
        }
        return true;
    }

    private void showErrorDialog(int errorCode) {
        GoogleApiAvailability.getInstance().getErrorDialog(this, errorCode, REQUEST_RESOLVE_ERROR).show();
//        GooglePlayServicesUtil.getErrorDialog(errorCode, this,
//                REQUEST_RESOLVE_ERROR, this).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            //Unregister Receiver
            if (localElmActivationReceiver != null) {
                unregisterReceiver(localElmActivationReceiver);
            }
        } catch (Exception e) {
            localElmActivationReceiver = null;
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (REQUEST_CODE_DEVICE_ADMIN == requestCode && resultCode == RESULT_OK) {
            if (Utils.isDeviceSamsung(this)) {

                if (sharedPreferences.getBoolean(AppConstant.ELM_LICENSE_STATUS, false)) {
                    Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                    startActivity(intent);
                } else {
                    localElmActivationReceiver = new LocalElmActivationReceiver();
                    IntentFilter intentFilter = new IntentFilter(AppConstant.LOCAL_ELM_RECEIVER_ACTION);
                    registerReceiver(localElmActivationReceiver, intentFilter);
                    Toast.makeText(this, R.string.please_wait_knox_activate, Toast.LENGTH_LONG).show();
                    new SamsungKNOX().activateSamsunglicense(this);
                    showProgress(true);
                }
            } else {
                Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                startActivity(intent);
            }

        } else if (requestCode == REQUEST_CODE_DEVICE_ADMIN && resultCode == RESULT_CANCELED) {
            Toast.makeText(this, R.string.enable_device_admin, Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    //Local Elm Receiver to get the events of activation by ElmReceiver.java receiver

    class LocalElmActivationReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            boolean isActivated = intent.getBooleanExtra(AppConstant.LOCAL_ELM_RECEIVER_EXTRA_BOOLEAN, false);
            if (isActivated) {
                Intent intent1 = new Intent(context, DisplayActivity.class);
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent1);
            } else {
                finish();
            }
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
