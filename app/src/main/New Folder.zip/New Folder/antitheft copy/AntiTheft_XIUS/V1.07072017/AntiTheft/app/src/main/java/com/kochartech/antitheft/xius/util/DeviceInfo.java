package com.kochartech.antitheft.xius.util;

/**
 * Created by gauravjeet on 20/9/17.
 */
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.bluetooth.BluetoothAdapter;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

/**
 * This Class is used to fetch Device related Information.
 *
 * @author aman.arora
 */
public class DeviceInfo {
    private Context context;

    /**
     * Default Constructor that pass a context from your Application
     *
     * @param context Application Context
     */
    public DeviceInfo(Context context) {
        this.context = context;
    }

    /**
     * This Method is used to get Screen Timeout value
     *
     * @return Current Screen TimeOut Value
     */
    public String getScreenOffTimeout() {
        long timeout = Settings.System.getLong(context.getContentResolver(),
                Settings.System.SCREEN_OFF_TIMEOUT, -1);
        long sec = timeout / 1000;
        if (timeout < 0) // close.
            return null;
        else if (sec >= 60) // to minute
            return String.format((sec / 60) + " Min");
        else
            return String.format(sec + " Sec");
    }

    /**
     * This Method is used to set Screen TimeOut value
     *
     * @param screenOffTimeout requires value from 0-5 else set screen out time value to null
     * @throws Exception when value is greater then 5 or less then 0.
     *                   <p>
     *                   Requires {@link android.Manifest.permission#WRITE_SETTINGS}
     *                   Permission.
     */
    public void setScreenOffTimeout(int screenOffTimeout) throws Exception {
        int time;
        switch (screenOffTimeout) {
            case 0:
                time = 15000;
                break;
            case 1:
                time = 30000;
                break;
            case 2:
                time = 60000;
                break;
            case 3:
                time = 120000;
                break;
            case 4:
                time = 600000;
                break;
            case 5:
                time = 1800000;
                break;
            default:
                throw new Exception(
                        "ScreenOff TimeOut Value will be between 0 to 5");
        }
        Settings.System.putInt(context.getContentResolver(),
                Settings.System.SCREEN_OFF_TIMEOUT, time);
    }

    /**
     * This Method is used to get Bluetooth State
     *
     * @return Current Bluetooth State
     * <p>
     * Requires {@link android.Manifest.permission#BLUETOOTH}
     * Permission.
     */
    public boolean isBluetoothEnabled() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter
                .getDefaultAdapter();
        return (bluetoothAdapter != null) ? bluetoothAdapter.isEnabled()
                : false;
    }

    /**
     * This Method is used to set Bluetooth State
     *
     * @param state Boolean value to enable/disable.
     *              <p>
     *              Requires the
     *              {@link android.Manifest.permission#BLUETOOTH_ADMIN}
     *              Permission.
     *              </p>
     */
    public void setBluetoothEnabled(boolean state) {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter
                .getDefaultAdapter();
        if (state)
            mBluetoothAdapter.enable();
        else
            mBluetoothAdapter.disable();
    }

    /**
     * This Method is used to fetch GPS Stats this method works on OS 4.0 and
     * below.
     *
     * @return Current GPS State
     * @throws SecurityException if {@link android.Manifest.permission#ACCESS_FINE_LOCATION}
     *                           permission is not present.
     */
    public boolean isGPSEnabled() {
        final LocationManager manager = (LocationManager) context
                .getSystemService(Context.LOCATION_SERVICE);
        return (manager != null) ? manager
                .isProviderEnabled(LocationManager.GPS_PROVIDER) : false;
    }

    /**
     * This Method is used to set GPS State on OS 4.0 and below
     *
     * @param state Boolean value to enable/disable.
     * @throws SecurityException if {@link android.Manifest.permission#ACCESS_FINE_LOCATION}
     *                           permission is not present
     */
    public void setGPSEnabled(boolean state) {
        String provider = Settings.Secure.getString(
                context.getContentResolver(),
                Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
        if (state != provider.contains("gps")) // Add comments
        {
            final Intent intent = new Intent();
            intent.setClassName("com.android.settings",
                    "com.android.settings.widget.SettingsAppWidgetProvider");
            intent.addCategory(Intent.CATEGORY_ALTERNATIVE);
            intent.setData(Uri.parse("3"));
            context.sendBroadcast(intent);
        }
    }

    /**
     * This Method is used to fetch WIFI State.
     *
     * @return Current Wifi State
     * <p>
     * Requires the
     * {@link android.Manifest.permission#ACCESS_WIFI_STATE} ,
     * {@link android.Manifest.permission#CHANGE_WIFI_STATE}
     * Permissions.
     * </p>
     */
    public boolean isWifiEnabled() {
        WifiManager wifiManager = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        return (wifiManager != null) ? wifiManager.isWifiEnabled() : false;
    }

    /**
     * This Method is used to set WiFi State
     *
     * @param state Boolean value to enable/disable.
     *              <p>
     *              Requires the
     *              {@link android.Manifest.permission#ACCESS_WIFI_STATE} ,
     *              {@link android.Manifest.permission#CHANGE_WIFI_STATE}
     *              Permissions.
     *              </p>
     */
    public void setWifiEnabled(boolean state) {
        WifiManager wifi = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        wifi.setWifiEnabled(state);
    }

    /**
     * This Method is used to fetch AutoSync State.
     *
     * @return Current AutoSync State
     * <p>
     * Requires {@link android.Manifest.permission#READ_SYNC_SETTINGS}
     * Permission.
     * </p>
     */
    public boolean isAutoSyncEnabled() {
        return ContentResolver.getMasterSyncAutomatically();
    }

    /**
     * This Method is used to set AutoSync State.
     *
     * @param state Boolean value to enable/disable.
     *              <p>
     *              Requires
     *              {@link android.Manifest.permission#WRITE_SYNC_SETTINGS}
     *              Permission.
     *              </p>
     */
    public void setAutoSyncEnabled(boolean state) {
        ContentResolver.setMasterSyncAutomatically(state);
    }

    /**
     * This Method is used to fetch AirplaneMode State.
     *
     * @return Boolean true for enabled/false for disabled
     */
    public boolean isAirplaneModeEnabled() {
        return (Settings.System.getInt(context.getContentResolver(),
                Settings.System.AIRPLANE_MODE_ON, 0) == 1);
    }

    /**
     * This Method is used to set AirplaneMode State
     *
     * @param state Boolean value to enable/disable.
     *              <p>
     *              Requires {@link android.Manifest.permission#WRITE_SETTINGS} ,
     *              {@link android.Manifest.permission#WRITE_SECURE_SETTINGS}
     *              Permissions.
     *              </p>
     */
    public void setAirplaneModeEnabled(boolean state) {
        Settings.System.putInt(context.getContentResolver(),
                Settings.System.AIRPLANE_MODE_ON, (state) ? 1 : 0);
        Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        intent.putExtra("state", state);
        context.sendBroadcast(intent);
    }

    /**
     * This Method is used to fetch MobileData State.
     *
     * @return Boolean true for enabled/false for disabled
     * <p>
     * Require permissions: {@link android.Manifest.permission#INTERNET}
     * {@link android.Manifest.permission#CHANGE_NETWORK_STATE} ,
     * {@link android.Manifest.permission#ACCESS_NETWORK_STATE} ,
     * {@link android.Manifest.permission#UPDATE_DEVICE_STATS} ,
     * {@link android.Manifest.permission#MODIFY_PHONE_STATE} ,
     * {@link android.Manifest.permission#READ_PHONE_STATE} .
     * </p>
     */
    public boolean isMobileDataEnabled() {
        boolean flag = false; // Assume disabled
        ConnectivityManager cm = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            Class cmClass = Class.forName(cm.getClass().getName());
            Method method = cmClass.getDeclaredMethod("getMobileDataEnabled");
            method.setAccessible(true);
            flag = (Boolean) method.invoke(cm);
        } catch (Exception e) {
            /*
             * If Exception then it means getMobileDataEnabled method does not
			 * exsists and then i try the another way.
			 */
            ContentResolver cr = context.getContentResolver();
            String status = Settings.Secure.getString(cr, "mobile_data");
            if (status != null) {
                if (status.equalsIgnoreCase("1")) {
                    flag = true;
                } else if (status.equalsIgnoreCase("0")) {
                    flag = false;
                }
            }
        }
        return flag;
    }

    /**
     * This Method is used to set MobileData State
     *
     * @param state Boolean value to enable/disable.
     * @throws Exception - if mobile data state unable to set
     *                   <p>
     *                   Require permissions:
     *                   {@link android.Manifest.permission#INTERNET}
     *                   {@link android.Manifest.permission#CHANGE_NETWORK_STATE} ,
     *                   {@link android.Manifest.permission#ACCESS_NETWORK_STATE} ,
     *                   {@link android.Manifest.permission#UPDATE_DEVICE_STATS} ,
     *                   {@link android.Manifest.permission#MODIFY_PHONE_STATE} ,
     *                   {@link android.Manifest.permission#READ_PHONE_STATE} .
     *                   </p>
     */
    public void setMobileDataEnable(boolean state) throws Exception {
        int version = VERSION.SDK_INT;
        try {
            if (version == Build.VERSION_CODES.FROYO) {
                TelephonyManager telephonyManager = (TelephonyManager) context
                        .getSystemService(Context.TELEPHONY_SERVICE);
                Class<?> telephonyManagerClass = Class.forName(telephonyManager
                        .getClass().getName());

                Method getITelephonyMethod = telephonyManagerClass
                        .getDeclaredMethod("getITelephony");
                getITelephonyMethod.setAccessible(true);

                Object ITelephonyStub = getITelephonyMethod
                        .invoke(telephonyManager);
                Class<?> ITelephonyClass = Class.forName(ITelephonyStub
                        .getClass().getName());

                Method dataConnSwitchmethod = ITelephonyClass
                        .getDeclaredMethod(state ? "enableDataConnectivity"
                                : "disableDataConnectivity");
                dataConnSwitchmethod.setAccessible(true);
                dataConnSwitchmethod.invoke(ITelephonyStub);
            } else {
                // Log.e(">>>>","App running on Ginger bread+");
                final ConnectivityManager conman = (ConnectivityManager) context
                        .getSystemService(Context.CONNECTIVITY_SERVICE);
                final Class<?> conmanClass = Class.forName(conman.getClass()
                        .getName());

                final Field iConnectivityManagerField = conmanClass
                        .getDeclaredField("mService");
                iConnectivityManagerField.setAccessible(true);

                final Object iConnectivityManager = iConnectivityManagerField
                        .get(conman);
                final Class<?> iConnectivityManagerClass = Class
                        .forName(iConnectivityManager.getClass().getName());

                final Method setMobileDataEnabledMethod = iConnectivityManagerClass
                        .getDeclaredMethod("setMobileDataEnabled", Boolean.TYPE);
                setMobileDataEnabledMethod.setAccessible(true);
                setMobileDataEnabledMethod.invoke(iConnectivityManager, state);
            }
        } catch (Exception e) {
            throw new Exception(e.toString());
        }
    }

    /**
     * This method is used to fetch Brand Name of Device.
     *
     * @return <b>String</b> - Device Brand
     */
    public String getDeviceBrand() {
        return Build.BRAND;
    }

    /**
     * This method is used to fetch Model Name of Device.
     *
     * @return <b>String</b> - Device Model
     */
    public String getDeviceModel() {
        return Build.MODEL;
    }

    /**
     * This method is used to fetch Device OS Version
     *
     * @return <b>String</b> - Device OS Version
     */
    public String getDeviceOSVersion() {
        return VERSION.RELEASE;
    }

    /**
     * This Method is used to get unique device ID, for example, the IMEI for
     * GSM and the MEID or ESN for CDMA phones. Return null if device ID is not
     * available.
     *
     * @return <b>String</b> - the unique device ID, for example, the IMEI for
     * GSM and the MEID or ESN for CDMA phones. Return null if device ID
     * is not available.
     * <p>
     * Requires Permission:
     * {@link android.Manifest.permission#READ_PHONE_STATE
     * READ_PHONE_STATE}
     */
    public String getDeviceId() {
        return ((TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId();
    }

    /**
     * This method returns current battery level.
     *
     * @return <b>Integer</b> - returns battery level in percentage
     */
    public int getBatteryLevel() {
        Intent batteryIntent = context.registerReceiver(null, new IntentFilter(
                Intent.ACTION_BATTERY_CHANGED));
        return batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
    }


    public boolean isHotspotEnable() {
        boolean state = false;
        Log.d("HandsetInfo", "checkUSBTethering");
        WifiManager wifi = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        Method[] wmMethods = wifi.getClass().getDeclaredMethods();
        for (Method method : wmMethods) {
            if (method.getName().equals("isWifiApEnabled")) {

                try {
                    state = (Boolean) method.invoke(wifi);

                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
            }
        }
        return state;
    }

    public int getBrightnessPercentage() {
        int percentage = 0;
        try {
            int userBrightness = Settings.System.getInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, -1);
            percentage = userBrightness * 100 / 255;
        } catch (Exception e) {
        }
        return percentage;
    }

    public boolean isDataRoamingEnabled() {
        try {
            // return true or false if data roaming is enabled or not
            return Settings.Secure.getInt(context.getContentResolver(),
                    Settings.Secure.DATA_ROAMING) == 1;
        } catch (Settings.SettingNotFoundException e) {
            // return null if no such settings exist (device with no radio data
            // ?)
            return false;
        }
    }
}