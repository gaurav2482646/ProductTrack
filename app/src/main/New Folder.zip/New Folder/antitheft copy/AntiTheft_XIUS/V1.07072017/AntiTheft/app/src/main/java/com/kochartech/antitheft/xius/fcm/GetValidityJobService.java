package com.kochartech.antitheft.xius.fcm;

import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import com.google.gson.Gson;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.dto.AppDTO;
import com.kochartech.antitheft.xius.dto.ExistingDeviceDTO;
import com.kochartech.antitheft.xius.dto.UserDTO;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by gauravjeet on 17/1/18.
 */

public class GetValidityJobService extends JobService {
    private static final String TAG = "GetValidityJobService";
    PreferenceHelper preferenceHelper;

    @Override
    public boolean onStartJob(JobParameters job) {
        preferenceHelper = new PreferenceHelper(getApplicationContext());
        Log.d(TAG, "onStartJob: ValidityServiceCalled");
        if (preferenceHelper.isDeviceRegistered()) {
            getExistingDevice(job);
        } else {
            jobFinished(job, false);
        }
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        return false;
    }


    public void getExistingDevice(final JobParameters job) {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();
        final String ALREADY_REGISTERED = "0";
        final String NEW_DEVICE = "1";

        try {
            Log.d(TAG, "getExistingDeviceRequest: " + getExistingDeviceDTO().toString());
            JsonObjectRequest jsonObjReqExistDevice = new JsonObjectRequest(Request.Method.POST,
                    AppConstant.GET_EXISTING_DEVICE_URL, getExistingDeviceDTO(),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject jsonObjectExistDevice) {
                            Log.d(TAG, jsonObjectExistDevice.toString());
                            mRequestQueue.stop();
                            try {
                                // NEW DEVICE(Device is not associated with any user)
                                if (jsonObjectExistDevice.getString("code").equals(NEW_DEVICE)) {
                                    //TODO START LOGIN SESSION HERE
                                    jobFinished(job, false);
//                                    intent.putExtra("isNewDevice", true);
                                }
                                //Device is Already Registered with some user
                                else {
                                    //TODO Compare the user id with the existing device
                                    Log.d(TAG, "Already Registered: " + jsonObjectExistDevice.toString());
                                    Gson gson = new Gson();
                                    UserDTO userDTO = gson.fromJson(jsonObjectExistDevice.get("user").toString(), UserDTO.class);
                                    AppDTO appDTO = gson.fromJson(jsonObjectExistDevice.get("app").toString(), AppDTO.class);

                                    //Check if Registered device is of the  current user
                                    if (preferenceHelper.getInt(AppConstant.USER_ID, 0) == userDTO.getUserID()) {

                                        //TODO UNCOMMENT THE CODE
//
                                        //TODO We will Use it to check the validity at login
                                        int validity = appDTO.getValidity();
//                                        int validity = -1;
//                                        validity = - 1;
                                        if (validity < 1) {
                                            preferenceHelper.setAppExpired();
                                            preferenceHelper.setDeviceUnRegistered();
                                            Utils.showBigNotification("App is Expired", getApplicationContext(), null, 101, true, true);
                                            preferenceHelper.saveInt(AppConstant.VALIDITY_AT_LOGIN, validity);

                                            Log.d(TAG, "isAppExpired: true");
                                            //Show Expired Fragment Or NotActivated
                                            preferenceHelper.saveBoolean(AppConstant.IS_LOGIN_PIN_SET, false);
                                            preferenceHelper.removeKey(AppConstant.LOGIN_PIN_CODE);
                                            jobFinished(job, false);

                                        } else {
                                            jobFinished(job, false);

                                        }
//                                        Intent intent = new Intent(GetValidityJobService.this, HomeActivity.class);
//                                        intent.putExtra(HomeActivity.IS_EXPIRED, preferenceHelper.isAppExpired());
                                        //TODO START LOGIN SESSION HERE
//                                        startActivity(intent);
                                    }
                                    //Device is of Another user, prompt the user with dialog
                                    else {
                                        jobFinished(job, true);

                                    }
//                                    String message = jsonObjectExistDevice.toString();
//                                    Toast.makeText(LoginActivity.this, "Device registered with other user", Toast.LENGTH_SHORT).show();
//                                    Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
//

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                jobFinished(job, true);

                            }
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.d(TAG, "Error: " + error.getMessage());

                    Log.d(TAG, "onErrorResponse: " + error.getMessage());
                    mRequestQueue.stop();
                    jobFinished(job, true);
                }
            }) {


                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }


            };
            mRequestQueue.add(jsonObjReqExistDevice);
        } catch (Exception e) {
            e.printStackTrace();

            Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private JSONObject getExistingDeviceDTO() throws PackageManager.NameNotFoundException, JSONException {
        ExistingDeviceDTO existingDeviceDTO = new ExistingDeviceDTO();

        existingDeviceDTO.setMacAddress(Utils.getMACAddress().replace(":", ""));
        Gson gson = new Gson();
        return new JSONObject(gson.toJson(existingDeviceDTO));
    }

}