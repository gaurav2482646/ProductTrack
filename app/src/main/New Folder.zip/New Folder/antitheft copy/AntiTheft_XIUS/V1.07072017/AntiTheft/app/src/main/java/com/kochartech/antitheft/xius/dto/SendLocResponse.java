package com.kochartech.antitheft.xius.dto;

import android.util.Log;

import com.google.gson.Gson;
import com.kochartech.antitheft.xius.AppConstant;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by gauravjeet on 24/8/17.
 */

public class SendLocResponse extends Thread {
    public static final MediaType JSON
            = MediaType.parse("application/json; charset=utf-8");
    private static final String TAG = "SendLocResponse";
    String location_json;
    Gson gson;

    public SendLocResponse(LocationDTO locationDTO) {
        this.gson = new Gson();
        location_json = gson.toJson(locationDTO);
        Log.e(TAG, "Sending the LOC RESPONSE JSON:" + location_json);
    }

    @Override
    public void run() {
        super.run();
        try {
            String response_from_server = post(AppConstant.LOC_URL, this.location_json);
            Log.e(TAG, "Response of loc_response:" + response_from_server);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    String post(String url, String json) throws IOException {
        final OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        return response.body().string();
    }
}
