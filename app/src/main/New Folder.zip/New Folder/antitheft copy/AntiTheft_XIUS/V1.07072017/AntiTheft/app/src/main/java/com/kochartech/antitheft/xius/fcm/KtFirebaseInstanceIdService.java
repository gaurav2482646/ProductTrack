package com.kochartech.antitheft.xius.fcm;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.StartupOperations;

public class  KtFirebaseInstanceIdService extends FirebaseInstanceIdService {

    public KtFirebaseInstanceIdService() {
    }

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d("KTFirebaseInstanceID", "Refreshed token: " + refreshedToken);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(AppConstant.REGISTRATION_ID_FCM, refreshedToken);
        editor.apply();
        startService(new Intent(this,StartupOperations.class));
//TODO Change from is_user_registered to is_user_logged_in
        if (sharedPreferences.getBoolean(AppConstant.IS_LOGGED_IN, false)) {
            scheduleJob();
        }
        else {
            Log.d("KTFirebaseInstanceID", "user not registered yet");
        }

//        sendRegistrationToServer(refreshedToken);

    }
    private void scheduleJob() {
        FirebaseJobDispatcher dispatcher =
                new FirebaseJobDispatcher(new GooglePlayDriver(this));
        Job myJob = dispatcher.newJobBuilder()
                .setService(MyJobService.class)
                .setTag("my-job-tag")
                .build();
        dispatcher.mustSchedule(myJob);
    }

    private void sendRegistrationToServer(String refreshedToken) {

    }
}
