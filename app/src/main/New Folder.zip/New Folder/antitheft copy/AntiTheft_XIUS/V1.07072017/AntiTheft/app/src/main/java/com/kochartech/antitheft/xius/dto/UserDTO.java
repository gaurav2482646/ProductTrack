package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 2/11/17.
 */
//Contains Information About The USER

public class UserDTO
{
    private int userID;

    private String name;

    private String emailAddress;

    private String mobileNumber;

    private String alternateNumber;

    private String password;

    public int getUserID ()
    {
        return userID;
    }

    public void setUserID (int userID)
    {
        this.userID = userID;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getEmailAddress()
    {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }

    public String getMobileNumber ()
    {
        return mobileNumber;
    }

    public void setMobileNumber (String mobileNumber)
    {
        this.mobileNumber = mobileNumber;
    }

    public String getAlternateNumber ()
    {
        return alternateNumber;
    }

    public void setAlternateNumber (String alternateNumber)
    {
        this.alternateNumber = alternateNumber;
    }

    public String getPassword ()
    {
        return password;
    }

    public void setPassword (String password)
    {
        this.password = password;
    }

    @Override
    public String toString()
    {
        return "UserDTO [userID = "+userID+", name = "+name+", emailAddress = "+ emailAddress +", mobileNumber = "+mobileNumber+", alternateNumber = "+alternateNumber+", password = "+password+"]";
    }
}