package com.kochartech.antitheft.xius;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.firebase.jobdispatcher.Constraint;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;
import com.kochartech.antitheft.xius.callRecord.CallRecordService;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.dto.DeviceDTO;
import com.kochartech.antitheft.xius.dto.RegisterDTO;
import com.kochartech.antitheft.xius.dto.UserDTO;
import com.kochartech.antitheft.xius.dto.eventBus.LogoutEvent;
import com.kochartech.antitheft.xius.dto.eventBus.ValidityEvent;
import com.kochartech.antitheft.xius.fcm.GetValidityJobService;
import com.kochartech.antitheft.xius.fcm.MyJobService;
import com.kochartech.antitheft.xius.lockscreen.LockScreen;
import com.kochartech.antitheft.xius.receiver.TimeLeftReceiver;
import com.kochartech.antitheft.xius.services.ScreenOnOffService;
import com.kochartech.antitheft.xius.sms.AlarmServiceAsyncTask;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;
import com.yanzhenjie.permission.AndPermission;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static android.app.AlarmManager.ELAPSED_REALTIME;
import static android.os.SystemClock.elapsedRealtime;


public class StartupOperations extends Service {
    public static final String TAG = "StartupOperations";
    String msisdn = "9781809124";
    String token = "12345";
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    boolean active;
    private DevicePolicyManager mDPM;
    private ComponentName mDeviceAdmin;
    PreferenceHelper preferenceHelper;
    Runnable validityRunnable;
    Utils utils;
    Handler handler;


    public StartupOperations() {

    }

    @Override
    public void onCreate() {
        super.onCreate();
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = sharedPreferences.edit();
        preferenceHelper = new PreferenceHelper(this);
        mDPM = (DevicePolicyManager) getApplicationContext().getSystemService(Context.DEVICE_POLICY_SERVICE);
        mDeviceAdmin = new ComponentName(getApplicationContext(), KDeviceAdminReceiver.class);
        active = mDPM.isAdminActive(mDeviceAdmin);
        utils = new Utils();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
        validityRunnable = new Runnable() {
            @Override
            public void run() {
//                                if (Utils.isTimeAutomaticEnabled(StartupOperations.this)) {
                utils.isAppExpired(StartupOperations.this);
//                              if (stop) {
                handler.postDelayed(this, 1000 * 60 * 2);
//                                }else{
//                                    Utils.showBigNotification("Network Time is Disabled, App will not function",StartupOperations.this, new Intent(Settings.ACTION_DATE_SETTINGS),101,true,true);
//                                }
//                                }
            }
        };
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "FCM token: " + refreshedToken);
        preferenceHelper.saveString(AppConstant.REGISTRATION_ID_FCM, refreshedToken);
//        scheduleJob();
        //USER REGISTER BLOCK START
//        final boolean stop = preferenceHelper.isDeviceRegistered() && preferenceHelper.isUserLoggedIn();
        if (preferenceHelper.getBoolean(AppConstant.IS_LOGGED_IN, false)) {
            volleyUpdateRegistrationID();
            handler = new Handler();

            if (preferenceHelper.isDeviceRegistered()) {
                checkOperations();
                Log.d(TAG, "onStartCommand: Runnable Started");
                handler.post(validityRunnable);
            } else if (handler != null) {
                handler.removeCallbacks(validityRunnable);
            }
        }        //USER REGISTER BLOCK END

        return START_STICKY;


    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onLogoutEvent(LogoutEvent logoutEvent) {
        Log.d(TAG, "onLogoutEvent: Event Received");
        if (logoutEvent != null) {
            if (logoutEvent.isLogout) {
                handler.removeCallbacks(validityRunnable);

            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onValidityEvent(ValidityEvent validityEvent) {
        Log.d(TAG, "onValidityEvent: Event Received");
        if (validityEvent.isExpired) {
            //Show Expired Fragment Or NotActivated
            Log.e(TAG, "onValidityEvent: App is expired");
            handler.removeCallbacks(validityRunnable);

        }
    }

    void checkOperations() {
        if (preferenceHelper.getBoolean(AppConstant.IS_LOGGED_IN, false)) {
            //Check If Lost
            if (preferenceHelper.isDeviceRegistered()) {
                if (AndPermission.hasPermission(this, android.Manifest.permission.READ_PHONE_STATE)) {
                    if (utils.isSimChanged(this)) {
//                    Utils.showOnGoingNotification("AntiTheft","Sim change detected",context,null,98);
                        Intent intent1 = new Intent(this, MainActivity.class);
                        Utils.showBigNotification("Sim change is detected",
                                this, intent1, 600, true, true);
                    }
                }
                if (!checkPermissions(this)) { //Check permissions here
                    Intent intent1 = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + BuildConfig.APPLICATION_ID));

                    Utils.showBigNotification("Missing Required Permission,Security is compromised", this
                            , intent1, 600, true, true);
                }
                if (preferenceHelper.getBoolean(AppConstant.IS_CALL_RECORDING_ENABLED, false)) {
                    if (Utils.isMyServiceRunning(CallRecordService.class, StartupOperations.this)) {
                        Log.e(TAG, "checkOperations: CallRecordService is not running ");
                        startService(new Intent(StartupOperations.this, CallRecordService.class));
                    }
                }
                if (!Utils.isMyServiceRunning(ScreenOnOffService.class, this)) {
                    Log.e(TAG, "checkOperations: SCREEN_ON_SERVICE is not running ");
                    Intent intent = new Intent();
                    intent.setAction("com.kochartech.antitheft.xius.SCREEN_ON_SERVICE");
                    intent.setPackage("com.kochartech.antitheft.xius");
                    startService(intent);
                }
                if (preferenceHelper.getBoolean(AppConstant.ALARM_RUN_STATUS, false)) {
                    new AlarmServiceAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getApplicationContext());
                    lockDevice(getApplicationContext());
               /* new CountDownTimer(30 * 1000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        Log.d(TAG, "onTick: ");
                    }

                    @Override
                    public void onFinish() {
                        Log.d(TAG, "onFinish: Finished Successfully :)");
                    }
                };*/
                }
                final String JOB_SERVICE_TAG = "get-validity-job-service";

                if (!Utils.isTimeAutomaticEnabled(getApplicationContext())) {
                    Log.d(TAG, "onReceive:Scheduling of Validity Job as Automatic Time is Off");
                    FirebaseJobDispatcher firebaseJobDispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(getApplicationContext()));
                    Job job = firebaseJobDispatcher.newJobBuilder()
                            .setService(GetValidityJobService.class)
                            .setTag(JOB_SERVICE_TAG)
                            .setRecurring(false)
                            .setLifetime(Lifetime.FOREVER)
                            .setTrigger(Trigger.executionWindow(0, 60 * 10))
                            .setReplaceCurrent(true)
                            .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                            .setConstraints(Constraint.ON_ANY_NETWORK)
                            .build();
                    firebaseJobDispatcher.mustSchedule(job);
                }
                if (preferenceHelper.getBoolean(AppConstant.SCREEN_LOCK_FLAG, false)) {
                    Log.e(TAG, "onReceive: SCREEN IS LOCKED HERE");
                    lockDevice(this);
                }
            }
            //Check If Locked
//            if (sharedPreferences.getBoolean(AppConstant.SCREEN_LOCK_FLAG, false)) {
//                Log.e(TAG, "onReceive: SCREEN IS LOCKED HERE");
//                new CountDownTimer(7 * 1000, 1000) {
//                    @Override
//                    public void onTick(long millisUntilFinished) {
//                        Log.d(TAG, "onTick: " + millisUntilFinished);
//                    }
//
//                    @Override
//                    public void onFinish() {
//                    lockDevice(getApplicationContext());
//                    }
//                }.start();
//            }
        }
    }

    boolean checkPermissions(Context context) {
        return AndPermission.hasPermission(context, AppConstant.REQUIRED_PERMISSIONS);
    }

    public void lockDevice(Context context) {
        ComponentName mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
        if (mDPM.isAdminActive(mDeviceAdminSample)) {
            editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG + "", true);
            editor.apply();
            mDPM.lockNow();
//          mDPM.lockNow();
//            Intent in = new Intent(context, KDeviceAdminReceiver.Controller.class);
//            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            in.putExtra("value", 4);
//            Intent lockScreenActivity = new Intent(context,LockActivity.class);
//            lockScreenActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//            context.startActivity(in);
//            context.startActivities(new Intent[]{in,lockScreenActivity},new Bundle());

            new Thread(new Runnable() {

                @Override
                public void run() {
                    Looper.prepare();
                    if (sharedPreferences.getBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, false)) {
                        showLockScreen(true);
                    }
                    Looper.loop();
                }

            }).start();


        } else {
            Log.e(TAG, "lockDevice: Device Admin is not enabled");
        }
    }

    private void showLockScreen(boolean show) {
        int theme = android.R.style.Theme;
        try {
            PackageManager packageManager = getApplicationContext().getPackageManager();
            ApplicationInfo info = packageManager.getApplicationInfo(getApplicationContext().getPackageName(), PackageManager.GET_META_DATA);
            theme = info.theme;
        } catch (Exception e) {
            Log.e("showLockScreen", " " + e.toString());
        }
        LockScreen lockScreen = LockScreen.getInstance(theme);

        if (show) {
            lockScreen.show();
        } else {
            lockScreen.remove();

        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Intent restartServiceIntent = new Intent(getApplicationContext(), this.getClass());

        PendingIntent restartServicePendingIntent = PendingIntent.getService(
                getApplicationContext(), 1, restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmService = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmService.set(ELAPSED_REALTIME, elapsedRealtime() + 1000,
                restartServicePendingIntent);
        super.onTaskRemoved(rootIntent);

        Log.d(TAG, "onTaskRemoved: Task is Removed");

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    //Used to send FCM Token To Server
    public void volleyUpdateRegistrationID() {
        RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();

//        HashMap<String, String> params = getRegisterDeviceMap();

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                AppConstant.UPDATE_DEVICE_REGISTRATION_ID, getUpdateRegisterIDMap(),
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, "Response of send FCM Token to server: " + response.toString());

                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());

            }
        }) {

            /**
             * Passing some request headers
             * */
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }


        };
        mRequestQueue.add(jsonObjReq);

    }

    HashMap<String, String> getRegisterDeviceMap() {
        try {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String fcmtoken = FirebaseInstanceId.getInstance().getToken();
            String regId = sharedPreferences.getString(AppConstant.REGISTRATION_ID_FCM, "");
            int userId = sharedPreferences.getInt(AppConstant.USER_ID, 0);
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put(AppConstant.MAC_ADDRESS, Utils.getMACAddress().replace(":", ""));
            hashMap.put(AppConstant.REGISTRATION_ID_FCM, fcmtoken);
            hashMap.put(AppConstant.USER_ID, String.valueOf(userId));
            Log.d(TAG, "json " + hashMap.toString());
            return hashMap;

        } catch (Exception ex) {
            ex.printStackTrace();
            Log.e(TAG, "ex create json " + ex.toString());
        }
        return null;
    }

    JSONObject getUpdateRegisterIDMap() {
        try {

            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String fcmtoken = FirebaseInstanceId.getInstance().getToken();
            String regId = sharedPreferences.getString(AppConstant.REGISTRATION_ID_FCM, "");
            int userId = sharedPreferences.getInt(AppConstant.USER_ID, 0);
            DeviceDTO deviceDTO = new DeviceDTO();
            deviceDTO.setRegistrationId(fcmtoken);
            deviceDTO.setMacAddress(Utils.getMACAddress().replace(":", ""));
            UserDTO userDTO = new UserDTO();
            userDTO.setUserID(userId);
            RegisterDTO registerDTO = new RegisterDTO();
            registerDTO.setUserDTO(userDTO);
            registerDTO.setDeviceDTO(deviceDTO);
            Gson gson = new Gson();
            String s = gson.toJson(registerDTO);

            Log.d(TAG, "getUpdateRegisterIDMap: " + s);

            return new JSONObject(s);

        } catch (Exception ex) {
            ex.printStackTrace();
            Log.e(TAG, "ex create json " + ex.toString());
        }
        return null;
    }

    private void scheduleJob() {
        FirebaseJobDispatcher dispatcher =
                new FirebaseJobDispatcher(new GooglePlayDriver(getApplicationContext()));
        Job myJob = dispatcher.newJobBuilder()
                .setService(MyJobService.class)
                .setTag("my-job-tag")
                .build();
        dispatcher.mustSchedule(myJob);

        stopSelf();
    }

    public void setAlarm() {
        Log.d(TAG, "setAlarm: called");
        Calendar calendarObj = Calendar.getInstance();
        Intent intent = new Intent(StartupOperations.this, TimeLeftReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(StartupOperations.this,
                0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        long wakeUpTime = calendarObj.getTimeInMillis() + 36000;
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, wakeUpTime, 360000, pendingIntent);
//        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,);
    }


}

