package com.kochartech.antitheft.xius;

/**
 * Created by gaurav on 17/7/17.
 */

public class Constants {

    public static final String IS_USER_REGISTERED = "is_user_registered";
    public static final String USER_REGISTRATION_URL = "http://172.17.103.82/Antitheftservice/Service1.svc/AntiTheftServiceClientRest/ActivateUserfromMobileApplication";
    public static final String DEVICE_REGISTRATION_URL = "http://172.17.103.82/Antitheftservice/Service1.svc/AntiTheftServiceClientRest/DeviceRegistration";
    public static final String UPDATE_DEVICE_REGISTRATION_ID = "http://172.17.103.82/AntitheftService/Service1.svc/AntiTheftServiceClientRest/UpdateRegistrationID";

    public static final String USER_ID = "userID";
    public static final String SCHEDULE_SET = "schedule_set";
    public static final String TOKEN = "token";
    public static final String BRAND = "brand";
    public static final String IMEI = "imei";
    public static final String INSTALL_DATE = "installDate";
    public static final String MAC_ADDRESS = "macAddress";
    public static final String MODEL = "model";
    public static final String REGISTRATION_ID = "registrationId";
    public static final String SIM_NUMBER_ONE = "simNumber";
    public static final String SIM_NUMBER_TWO = "simNumberTwo";
}
