package com.kochartech.antitheft.xius.location;

/**
 * Created by gauravjeet on 29/8/17.
 */

public interface Workable<T> {

    public void work(T t);
}
