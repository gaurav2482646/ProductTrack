package com.kochartech.antitheft.xius.sms;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;


/**
 * Created by gauravjeet on 27/2/17.
 */

public class AlarmServiceAsyncTask extends AsyncTask<Object, Object, Object> {
    // public static boolean runningAllarmFlag = false;
    MediaPlayer mediaPlayer = null;
    private String tag = AlarmServiceAsyncTask.class.getName();
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    @Override
    protected Object doInBackground(Object... objects) {
        Context context = (Context) objects[0];
        mediaPlayer = MediaPlayer.create(context, R.raw.alarmstolen);
        mediaPlayer.setLooping(true);
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = preferences.edit();
        editor.putBoolean(AppConstant.ALARM_RUN_STATUS, true);
        editor.apply();
        // runningAllarmFlag = true;
        while (preferences.getBoolean(AppConstant.ALARM_RUN_STATUS, false)) {
            try {
                Thread.sleep(2000);
            } catch (Exception e) {
                Log.d(tag,e.getMessage());

            }
            Log.d(tag, "Alarm Running Status "+preferences.getBoolean(AppConstant.ALARM_RUN_STATUS, false));
            final AudioManager mAudioManager;
            mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            final int originalVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            Log.d(tag, ">>>>>>>>>>>>>" + originalVolume);
            mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);

            if (!mediaPlayer.isPlaying())
                mediaPlayer.start();
        }
        if (mediaPlayer.isPlaying())
            mediaPlayer.stop();
        return "";
    }

}