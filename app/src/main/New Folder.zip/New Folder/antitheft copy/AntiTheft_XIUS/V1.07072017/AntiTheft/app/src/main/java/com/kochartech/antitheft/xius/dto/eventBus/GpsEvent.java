package com.kochartech.antitheft.xius.dto.eventBus;

/**
 * Created by gauravjeet on 28/12/17.
 */

public class GpsEvent {
    public boolean isTurnedOn;

    public GpsEvent(boolean isTurnedOn) {
        this.isTurnedOn = isTurnedOn;
    }
}
