package com.kochartech.antitheft.xius.util;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.kochartech.antitheft.xius.AppConstant;

import static android.content.Context.ALARM_SERVICE;

/**
 * Created by gaurav on 28/7/17.
 */

public class CellIDUtils {

    public static void saveData(Context context, String key, String value) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public void captureCellId(Context context, boolean action, int interval) {

        if (action) {
            // set alarm after x interval
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(AppConstant.SCHEDULE_SET, true);

            editor.commit();

            AlarmManager alarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
            Intent myIntent = new Intent(context, PostCellIdService.class);
//				PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, myIntent, 0);
            long time = (1000 * 60 * interval);
            PendingIntent pendingIntent = PendingIntent.getService(context, 0,
                    myIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);
            alarmManager.cancel(pendingIntent);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + time, time, pendingIntent);

        } else {
//            cancel Alarm
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
            Intent myIntent = new Intent(context, PostCellIdService.class);
            PendingIntent pendingIntent = PendingIntent.getService(context, 0,
                    myIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);
            alarmManager.cancel(pendingIntent);

            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(AppConstant.SCHEDULE_SET, false);

            editor.commit();
        }

    }
}
