package com.kochartech.antitheft.xius.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;

/**
 * Created by gauravjeet on 18/12/17.
 */

public class TimeLeftReceiver extends BroadcastReceiver {
    PreferenceHelper preferenceHelper;
    private static final String TAG = "TimeLeftReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "onReceive: TimeLeftReceiver called");
        preferenceHelper = new PreferenceHelper(context);
//        preferenceHelper.getInt(AppConstant.VALIDITY_AT_LOGIN,1);
//        long timeLeft = preferenceHelper.getLong(AppConstant.VALIDITY_LEFT,0);
//        timeLeft = timeLeft - 360000;
//        preferenceHelper.saveLong(AppConstant.VALIDITY_LEFT,timeLeft);
//        Log.d(TAG, "onReceive: ");
        if (preferenceHelper.getBoolean(AppConstant.IS_LOGGED_IN, false)) {
            if (preferenceHelper.isDeviceRegistered()) {
                Utils utils = new Utils();
                utils.isAppExpired(context);
            }
        }
    }
}
