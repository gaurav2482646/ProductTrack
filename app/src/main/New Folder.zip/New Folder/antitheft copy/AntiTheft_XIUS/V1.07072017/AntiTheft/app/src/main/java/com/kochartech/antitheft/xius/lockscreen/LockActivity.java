package com.kochartech.antitheft.xius.lockscreen;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.kochartech.antitheft.xius.R;

public class LockActivity extends AppCompatActivity implements View.OnClickListener {

    private final int REQUEST_CODE_OVERLAY_PERMISSION = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lock_screen);
        findViewById(R.id.bt_lock).setOnClickListener(this);
        findViewById(R.id.bt_lock).performClick();
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_lock:
                lockDevice();
                break;
        }
    }
    private void lockDevice() {
        if (Build.VERSION_CODES.M <= Build.VERSION.SDK_INT) {
            if (Settings.canDrawOverlays(this)) {
                showLockScreen();
            } else {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION);
            }
        } else {
            showLockScreen();
        }
    }
    private void showLockScreen() {
        int theme = android.R.style.Theme;
        try {
            PackageManager packageManager = getPackageManager();
            ApplicationInfo info = packageManager.getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            theme = info.theme;
        } catch (Exception e) {
            Log.e("showLockScreen", " " + e.toString());
        }
        LockScreen lockScreen = LockScreen.getInstance(theme);
        lockScreen.show();
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OVERLAY_PERMISSION) {
            if (Settings.canDrawOverlays(this)) {
                showLockScreen();
            } else {
                Toast.makeText(this, "Overlay permission is not granted", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
