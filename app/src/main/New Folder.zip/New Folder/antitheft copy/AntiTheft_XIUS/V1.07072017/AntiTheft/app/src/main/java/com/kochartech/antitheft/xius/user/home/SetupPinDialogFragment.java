package com.kochartech.antitheft.xius.user.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.dto.eventBus.PinSetEvent;
import com.kochartech.antitheft.xius.util.PreferenceHelper;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by gauravjeet on 29/11/17.
 */

public class SetupPinDialogFragment extends DialogFragment {
    public static String ARG1 = "arg1";
    public static String ARG2 = "arg2";
    EditText editTextPin;
    EditText editTextPinConfirm;
    Button buttonSubmit;
    PreferenceHelper preferenceHelper;

    public SetupPinDialogFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferenceHelper = new PreferenceHelper(getContext());
    }

    public static SetupPinDialogFragment newInstance(String arg1, String arg2) {
        SetupPinDialogFragment setupPinDialogFragment = new SetupPinDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG1, arg1);
        args.putString(ARG2, arg2);
        setupPinDialogFragment.setArguments(args);
        return setupPinDialogFragment;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog_setup_pin, container);
        editTextPin = (EditText) view.findViewById(R.id.editTextPin);
        editTextPinConfirm = (EditText) view.findViewById(R.id.editTextConfirmPin);
        buttonSubmit = (Button) view.findViewById(R.id.button_setup_pin);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editTextPin.getText())) {
                    Toast.makeText(getActivity(), "Enter the pin", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(editTextPinConfirm.getText())) {
                    Toast.makeText(getActivity(), "Enter the pin", Toast.LENGTH_SHORT).show();

                } else if (!TextUtils.equals(editTextPin.getText(), editTextPinConfirm.getText())) {
                    Toast.makeText(getActivity(), "Recheck the confirm pin", Toast.LENGTH_SHORT).show();

                } else if (editTextPin.getText().toString().length() != 4 && editTextPinConfirm.getText().toString().length() != 4) {
                    Toast.makeText(getActivity(), "Pin should be of 4 digits", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(getActivity(), "Login Pin Successfully Set", Toast.LENGTH_SHORT).show();
                    EventBus.getDefault().post(new PinSetEvent(true));
                    preferenceHelper.saveString(AppConstant.LOGIN_PIN_CODE, editTextPin.getText().toString());
                    preferenceHelper.setLoginPinSetup();
                    dismiss();


                }
            }
        });
    }
}
