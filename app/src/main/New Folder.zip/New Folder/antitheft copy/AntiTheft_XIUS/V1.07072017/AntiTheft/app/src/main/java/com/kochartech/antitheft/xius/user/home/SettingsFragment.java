package com.kochartech.antitheft.xius.user.home;


import android.Manifest;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.callRecord.CallRecordService;
import com.kochartech.antitheft.xius.user.UserSessionManager;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class SettingsFragment extends Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    boolean isDeviceActivated = false;
    View tvRemoveDevice, tvLogout, tvDeleteAccount, tvChangeUnlockPin;
    CheckBox cbSettingsEnableCallRecording, cbSettingsEnableHideApp;
    PreferenceHelper preferenceHelper;
    UserSessionManager userSessionManager;
    boolean isPinSetup;
    private ComponentName LAUNCHER_COMPONENT_NAME;
    private static final String TAG = "SettingsFragment";

    public SettingsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferenceHelper = new PreferenceHelper(getActivity());
        isDeviceActivated = preferenceHelper.getBoolean(AppConstant.IS_DEVICE_ACTIVATED, false);
        isPinSetup = preferenceHelper.getBoolean(AppConstant.IS_LOGIN_PIN_SET, false);
        userSessionManager = new UserSessionManager(getActivity());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_settings, container, false);
        cbSettingsEnableCallRecording = (CheckBox) view.findViewById(R.id.cbSettingsEnableCallRecording);
        cbSettingsEnableHideApp = (CheckBox) view.findViewById(R.id.cbSettingsEnableHideApp);
        tvRemoveDevice = view.findViewById(R.id.tvRemoveDevice);
        tvLogout = view.findViewById(R.id.tvSettingsLogout);
        tvDeleteAccount = view.findViewById(R.id.tvSettingsDeleteAccount);
        tvChangeUnlockPin = view.findViewById(R.id.tvSettingsChangePin);
        tvChangeUnlockPin.setEnabled(isPinSetup);
        cbSettingsEnableCallRecording.setChecked(preferenceHelper.getBoolean(AppConstant.IS_CALL_RECORDING_ENABLED, false));
        cbSettingsEnableHideApp.setChecked(preferenceHelper.getBoolean(AppConstant.IS_APP_HIDE_ENABLED, false));
        tvChangeUnlockPin.setClickable(isPinSetup);
        tvRemoveDevice.setVisibility(isDeviceActivated ? View.VISIBLE : View.GONE);
        init();
        return view;
    }

    private void init() {
        tvLogout.setOnClickListener(this);
        tvDeleteAccount.setOnClickListener(this);
        tvRemoveDevice.setOnClickListener(this);
        tvChangeUnlockPin.setOnClickListener(this);
        cbSettingsEnableCallRecording.setOnCheckedChangeListener(this);
        cbSettingsEnableHideApp.setOnCheckedChangeListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        isDeviceActivated = preferenceHelper.getBoolean(AppConstant.IS_DEVICE_ACTIVATED, false);
        isPinSetup = preferenceHelper.getBoolean(AppConstant.IS_LOGIN_PIN_SET, false);
        tvChangeUnlockPin.setEnabled(isPinSetup);
        tvChangeUnlockPin.setClickable(isPinSetup);
        if (isDeviceActivated) {
            tvRemoveDevice.setVisibility(View.VISIBLE);
            cbSettingsEnableCallRecording.setEnabled(true);
            cbSettingsEnableHideApp.setEnabled(true);
        } else {
            tvRemoveDevice.setVisibility(View.GONE);
            cbSettingsEnableCallRecording.setEnabled(false);
            cbSettingsEnableHideApp.setEnabled(false);
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvSettingsLogout:
                getActivity().finishAffinity();
                userSessionManager.logout();
                Toast.makeText(getActivity(), "Successfully Logged Out", Toast.LENGTH_SHORT).show();
                break;
            case R.id.tvSettingsDeleteAccount:
                //TODO call Remove Device Method Here
                Toast.makeText(getActivity(), "In Development", Toast.LENGTH_SHORT).show();
                break;
            case R.id.tvRemoveDevice:
                //TODO Call Remove Device Method Here
                Toast.makeText(getActivity(), "In Development", Toast.LENGTH_SHORT).show();
                break;
            case R.id.tvSettingsChangePin: {
                ChangePinDialogFragment changePinDialogFragment = ChangePinDialogFragment.newInstance("", "");
                FragmentManager fragmentManager = getFragmentManager();
                changePinDialogFragment.show(fragmentManager, "change_pin_fragment");
            }

        }
    }

    @Override
    public void onCheckedChanged(final CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.cbSettingsEnableCallRecording:
                final Intent intent = new Intent(getActivity(), CallRecordService.class);

                if (isChecked) {
                    if (AndPermission.hasPermission(getActivity(), Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        Toast.makeText(getActivity(), "Call Recording Started", Toast.LENGTH_SHORT).show();
                        preferenceHelper.saveBoolean(AppConstant.IS_CALL_RECORDING_ENABLED, true);

                        getActivity().startService(intent);
                    } else {
                        AndPermission.with(this).permission(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE).callback(new PermissionListener() {
                            @Override
                            public void onSucceed(int requestCode, @NonNull List<String> grantPermissions) {
                                buttonView.setChecked(true);
                                preferenceHelper.saveBoolean(AppConstant.IS_CALL_RECORDING_ENABLED, true);

                                getActivity().startService(intent);

                            }

                            @Override
                            public void onFailed(int requestCode, @NonNull List<String> deniedPermissions) {
                                buttonView.setChecked(false);
                                Toast.makeText(getActivity(), "Call Record permission is not granted.", Toast.LENGTH_SHORT).show();
                                if (AndPermission.hasAlwaysDeniedPermission(SettingsFragment.this, deniedPermissions)) {
                                    AndPermission.defaultSettingDialog(SettingsFragment.this, 101)
                                            .setTitle("Permissions Disabled")
                                            .setMessage("Please go to App Settings to Enable the Permissions Manaually")
                                            .setPositiveButton("Ok")
                                            .setNegativeButton("NO",
                                                    new DialogInterface.OnClickListener() {
                                                        @Override
                                                        public void onClick(DialogInterface dialog, int which) {
                                                            dialog.dismiss();
                                                        }
                                                    })
                                            .show();

                                }
                            }
                        }).start();

                    }
                } else {
                    getActivity().stopService(intent);
                    preferenceHelper.saveBoolean(AppConstant.IS_CALL_RECORDING_ENABLED, false);
                    Toast.makeText(getActivity(), "Call Recording Stopped", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.cbSettingsEnableHideApp:
                LAUNCHER_COMPONENT_NAME = new ComponentName("com.kochartech.antitheft.xius", "com.kochartech.antitheft.xius.Launcher");
                if (isChecked) {
                    if (isLauncherIconVisible()) {
                        hideAppAlert();
                        hideIcon(true);
                    }
                } else {
                    if (!isLauncherIconVisible())
                        hideIcon(false);
                }
        }
    }

    private boolean isLauncherIconVisible() {
        int isEnabled = getActivity().getPackageManager().getComponentEnabledSetting(LAUNCHER_COMPONENT_NAME);
        return isEnabled != PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
    }

    private void hideIcon(boolean enable) {
        if (enable) {
            getActivity().getPackageManager().setComponentEnabledSetting(LAUNCHER_COMPONENT_NAME,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            Log.d(TAG, "hideIcon:Enabled ");
            preferenceHelper.saveBoolean(AppConstant.IS_APP_HIDE_ENABLED, true);
        } else {
            getActivity().getPackageManager().setComponentEnabledSetting(LAUNCHER_COMPONENT_NAME,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            preferenceHelper.saveBoolean(AppConstant.IS_APP_HIDE_ENABLED, false);
            Log.d(TAG, "hideIcon:Disabed ");

        }
    }

    public void hideAppAlert() {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(getActivity());
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setTitle("Note")
                .setMessage("App will be in hidden mode, Dial 1122 to launch it.\n Or Type *#*#1122#*#* in dialer to launch the app.")
                .setCancelable(false)
                .setNeutralButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
//                        editor.putBoolean(AppConstant.IS_HIDE_APP_ALERT_SHOWN, true);
//                        editor.commit();
//                        finish();
                    }
                });
        builder.show();
    }
}

