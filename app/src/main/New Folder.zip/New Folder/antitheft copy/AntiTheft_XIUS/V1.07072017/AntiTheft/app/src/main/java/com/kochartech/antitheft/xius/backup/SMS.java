package com.kochartech.antitheft.xius.backup;

/**
 * Created by gauravjeet on 10/8/17.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Telephony;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by gaurav on 21/2/17.
 */

public class SMS {
    private static final String LOG_TAG = "SMS_BACKUP";

    public static String backup(Context context) {
        Cursor cursor = null;
        try {
            JSONArray jsonArray = new JSONArray();
            cursor = context.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI, null, null, null, null);

            int smsCount = cursor.getCount();

            Log.d(LOG_TAG, "cursor length " + smsCount);
            // Read the sms data and store it in the list
            if (cursor.moveToFirst()) {

                for (int i = 0; i < cursor.getCount(); i++) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("address", cursor.getString(cursor.getColumnIndexOrThrow("address")).toString());
                    jsonObject.put("body", cursor.getString(cursor.getColumnIndexOrThrow("body")).toString());
                    jsonObject.put("date", cursor.getString(cursor.getColumnIndexOrThrow("date")).toString());
                    jsonObject.put("read", cursor.getString(cursor.getColumnIndexOrThrow("read")).toString());
//                    Log.e(TAG, "onCreate: body: "+ c.getString(c.getColumnIndexOrThrow("person")).toString());
                    jsonArray.put(jsonObject);
                    cursor.moveToNext();
                }
            }

            cursor.close();

            //  makeFile(jsonArray.toString());

            Log.e(LOG_TAG, "onCreate: JSON : " + jsonArray.toString());
            File file = makeFile(jsonArray.toString());
            return file.getAbsolutePath();
//            return Utils.jsonFromString("{\"count\": " + smsCount + ", \"path\": \"" + file.getAbsolutePath().toString() + "\", \"size\": " + file.length() + ", \"fileName\": \"" + file.getName() + "\"}").toString();

        } catch (Exception e) {
            Log.e(LOG_TAG, "onCreate: json exception : " + e.toString());
            if (cursor != null) {
                if (!cursor.isClosed()) {
                    cursor.close();
                }
            }

        }
        return "not found";
    }

    public static File makeFile(String data) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_a");
        String currentDateAndTime = sdf.format(new Date());
        String fileName = Environment.getExternalStorageDirectory() + "/SMS_" + currentDateAndTime + ".json"; // .vcf file path

        File file = new File(fileName);
        if (!file.exists()) {
            try {
                Writer writer = null;
                try {
                    writer = new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream(fileName), "utf-8"));
                    writer.write(data);
                } catch (IOException ex) {
                    // report
                } finally {
                    try {
                        writer.close();
                    } catch (Exception ex) {/*ignore*/}
                }

                Log.e(LOG_TAG, "makeFile: created file: " + file.exists());
            } catch (Exception e) {
                Log.e(LOG_TAG, "makeFile: error: " + e.toString());
                // do something
            }
        }
        return file;
    }

    public static int totalSms(Context context) {

        int smsCount = 0;
        try {
            Cursor cursor = context.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI, null, null, null, null);

            smsCount = cursor.getCount();
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return smsCount;

    }

    static void deleteSms(Context context) {
        Uri inboxUri = Uri.parse("content://sms/inbox");
        int count = 0;
        Cursor c = context.getContentResolver().query(inboxUri, null, null, null, null);
        while (c.moveToNext()) {
            try {
                // Delete the SMS
                String pid = c.getString(0); // Get id;
                String uri = "content://sms/" + pid;
                count = context.getContentResolver().delete(Uri.parse(uri),
                        null, null);
            } catch (Exception e) {
                Log.e(LOG_TAG, e.toString());
            }
        }
    }

    public static void restore(Context context, String fileName) {
        deleteSms(context);     //Delete all existing SMS
        File file = new File(fileName);
        StringBuilder text = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
            Log.e(LOG_TAG, "restore: line i read i file : " + text.toString());
            parseTheJson(context, text.toString());

//            restoreDefaultSmsApp(context);
        } catch (IOException e) {
            //You'll need to add proper error handling here
            Log.e(LOG_TAG, " restore  " + e.toString());
        }
    }

    public static void parseTheJson(Context context, String jsonString) {
        try {

            JSONArray jsonArray = new JSONArray(jsonString);
            for (int i = 0; i < jsonArray.length(); i++) {

                String body = jsonArray.getJSONObject(i).getString("body");
                String address = jsonArray.getJSONObject(i).getString("address");
                String date = jsonArray.getJSONObject(i).getString("date");
                String read = jsonArray.getJSONObject(i).getString("read");

                Log.e(LOG_TAG, "parseTheJso: name : " + body);
                Log.e(LOG_TAG, "parseTheJso: address : " + address);
                Log.e(LOG_TAG, "parseTheJso: date : " + date);
                Log.e(LOG_TAG, "parseTheJso: read: " + read);
                insertSms(context, body, address, date, read);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void insertSms(Context context, String body, String address, String date, String read) {
        ContentValues values = new ContentValues();
        values.put("address", address);
        values.put("date", date);
        values.put("read", read);
//        values.put("status", "0");
//        values.put("type", "1");
        values.put("body", body);
        Log.d(LOG_TAG, values.toString() + ">>>>>>>>>");
        //  Toast.makeText(this, "inserted", Toast.LENGTH_SHORT).show();
//        Log.d(TAG,   ""+getContentResolver().insert(Uri.parse("content://sms/inbox"), values));
        // Toast.makeText(this, "inserted : "+getContentResolver().insert(Uri.parse("content://sms/inbox"),values)+"", Toast.LENGTH_SHORT).show();
        Log.e(LOG_TAG, "inserted : " + context.getContentResolver().insert(Uri.parse("content://sms/inbox"), values) + "");

    }

    public static boolean isDefaultSmsApp(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            return context.getPackageName().equals(Telephony.Sms.getDefaultSmsPackage(context));
        }

        return true;
    }

    /*public static void becomeDefaultSmsApp(Context context, PluginHandler pluginHandler) {
        String defaultSmsApp = Telephony.Sms.getDefaultSmsPackage(context);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(AppConstants.SMS_APP_PACKAGE,defaultSmsApp);
        editor.commit();
        Log.d(LOG_TAG,"Default sms app "+ defaultSmsApp);

        Intent intent =
                new Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT);
        intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME,
                context.getPackageName());
        intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        pluginHandler.cordova.startActivityForResult(pluginHandler, intent, AppConstants.BECOME_DEFAULT_SMS_APP_CODE);
    }

    public static void restoreDefaultSmsApp(Context context)
    {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String messagingApp = sharedPreferences.getString(AppConstants.SMS_APP_PACKAGE,"");

        Intent intent =
                new Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT);
        intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME,
                messagingApp);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }*/

 /*   public static void importSMS(Context context, String filePath) {
        filePath = filePath.replace("file:///", "");
        String fileName = filePath.substring(filePath.lastIndexOf("/"));
        String destinationPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Aircel";

        Utils.copyFile(filePath.replace(fileName, ""), fileName, destinationPath);

        SMS.restore(context, destinationPath + fileName);
    }*/
}

