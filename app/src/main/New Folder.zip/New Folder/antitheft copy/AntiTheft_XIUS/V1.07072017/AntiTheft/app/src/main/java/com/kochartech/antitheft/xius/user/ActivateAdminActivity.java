package com.kochartech.antitheft.xius.user;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.DisplayActivity;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.util.Utils;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.SamsungKNOX;

public class ActivateAdminActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferences = PreferenceHelper.getSharedPreference();
    private SharedPreferences.Editor editor = PreferenceHelper.getSharedPreferenceEditor();
    private DevicePolicyManager mDPM;
    private ComponentName mAdminName;
    private static final int REQUEST_CODE_DEVICE_ADMIN = 200;
    LocalElmActivationReceiver localElmActivationReceiver;
    private View mProgressView;
    private View mLinearLayout;
    private static final String TAG = "ActivateAdminActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activate_admin);
        mLinearLayout = findViewById(R.id.linearLayout);
        mProgressView = findViewById(R.id.admin_progress);
        mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        mAdminName = new ComponentName(this, KDeviceAdminReceiver.class);
//        Utils.getSamsungBrand(this);
    }

    public void onActivateProtection(View view) {
        if (!mDPM.isAdminActive(mAdminName)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminName);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Click on Activate button to secure your application.");
            startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN);
        } else {
            Intent intent = new Intent(ActivateAdminActivity.this, DisplayActivity.class);
            startActivity(intent);
        }
    }



    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLinearLayout.setVisibility(show ? View.GONE : View.VISIBLE);
            mLinearLayout.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLinearLayout.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLinearLayout.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        switch (requestCode) {

//            case (DENIED_PERMISSION_ACTIVITY_CODE): {
//                if (AndPermission.hasPermission(ActivateAdminActivity.this, AppConstant.REQUIRED_PERMISSIONS)) {
//                    Toast.makeText(this, "Permission Granted, Continue with work.", Toast.LENGTH_SHORT).show();
//
//                } else {
//                    Toast.makeText(this, "Permission Not Denied", Toast.LENGTH_SHORT).show();
//                }
//                break;

//            }
            case (REQUEST_CODE_DEVICE_ADMIN): {
                if (resultCode == RESULT_OK) {

                    if (Utils.isDeviceSamsung(this)) {

                        if (!sharedPreferences.getBoolean(AppConstant.ELM_LICENSE_STATUS, false)) {
                            localElmActivationReceiver = new LocalElmActivationReceiver();
                            IntentFilter intentFilter = new IntentFilter(AppConstant.LOCAL_ELM_RECEIVER_ACTION1);
                            registerReceiver(localElmActivationReceiver, intentFilter);
                            new SamsungKNOX().activateSamsunglicense(this);
                            Log.d(TAG, "onActivityResult: Activating ELM");
                            Toast.makeText(this, R.string.please_wait_knox_activate, Toast.LENGTH_SHORT).show();
                            showProgress(true);
                        } else {
//                            Intent intent = new Intent(ActivateAdminActivity.this, DisplayActivity.class);
//                            startActivity(intent);
                            finish();
                        }
                    } else {
//                        Intent intent = new Intent(ActivateAdminActivity.this, DisplayActivity.class);
//                        startActivity(intent);
                        finish();
                    }
                } else if (resultCode == RESULT_CANCELED) {
                    Toast.makeText(this, R.string.enable_device_admin, Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;

            }
        }

    }
    //Local Elm Receiver to get the events of activation by ElmReceiver.java receiver
    class LocalElmActivationReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "onReceive ELmActivation ");
            boolean isActivated = intent.getBooleanExtra(AppConstant.LOCAL_ELM_RECEIVER_EXTRA_BOOLEAN, false);
            Log.d(TAG, "isActivated :->"+isActivated);
            if (isActivated) {
                //TODO uncomment if required
//                Intent intent1 = new Intent(context, DisplayActivity.class);
//                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                context.startActivity(intent1);
                finish();
            }

        }
    }
}
