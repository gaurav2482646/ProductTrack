package com.kochartech.antitheft.xius.user.home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.util.PreferenceHelper;

/**
 * Created by gauravjeet on 29/11/17.
 */

public class ChangePinDialogFragment extends DialogFragment {
    public static String ARG1 = "arg1";
    public static String ARG2 = "arg2";
    EditText editTextCurrentPin;
    EditText editTextNewPin;
    EditText editTextNewPinConfirm;
    Button buttonSubmit;
    PreferenceHelper preferenceHelper;

    public ChangePinDialogFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferenceHelper = new PreferenceHelper(getContext());
    }

    public static ChangePinDialogFragment newInstance(String arg1, String arg2) {
        ChangePinDialogFragment setupPinDialogFragment = new ChangePinDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG1, arg1);
        args.putString(ARG2, arg2);
        setupPinDialogFragment.setArguments(args);
        return setupPinDialogFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dialog_change_pin, container);
        editTextCurrentPin = (EditText) view.findViewById(R.id.editTextCurrentPin);
        editTextNewPin = (EditText) view.findViewById(R.id.editTextNewPin);
        editTextNewPinConfirm = (EditText) view.findViewById(R.id.editTextConfirmNewPin);
        buttonSubmit = (Button) view.findViewById(R.id.button_change_pin);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final String currentPin = preferenceHelper.getString(AppConstant.LOGIN_PIN_CODE, "");
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editTextNewPin.getText())) {
                    Toast.makeText(getActivity(), "Enter the pin", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(editTextNewPinConfirm.getText())) {
                    Toast.makeText(getActivity(), "Enter the pin", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(editTextCurrentPin.getText())) {
                    Toast.makeText(getActivity(), "Enter the current pin", Toast.LENGTH_SHORT).show();
                } else if (!TextUtils.equals(editTextCurrentPin.getText().toString(), currentPin)) {
                    Toast.makeText(getActivity(), "Wrong current pin entered", Toast.LENGTH_SHORT).show();
                } else if (!TextUtils.equals(editTextNewPin.getText(), editTextNewPinConfirm.getText())) {
                    Toast.makeText(getActivity(), "Recheck the confirm pin", Toast.LENGTH_SHORT).show();
                } else if (editTextNewPin.getText().toString().length() != 4 && editTextNewPinConfirm.getText().toString().length() != 4) {
                    Toast.makeText(getActivity(), "Pin should be of 4 digits", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getActivity(), "Login Pin Changed Successfully Set", Toast.LENGTH_SHORT).show();
                    preferenceHelper.saveString(AppConstant.LOGIN_PIN_CODE, editTextNewPin.getText().toString());
                    preferenceHelper.setLoginPinSetup();
                    dismiss();
                }
            }
        });
    }
}
