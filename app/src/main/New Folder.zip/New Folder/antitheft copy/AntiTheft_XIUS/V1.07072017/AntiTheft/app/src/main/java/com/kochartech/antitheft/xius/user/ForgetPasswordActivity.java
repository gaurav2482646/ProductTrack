package com.kochartech.antitheft.xius.user;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import br.com.simplepass.loading_button_lib.customViews.CircularProgressButton;

public class ForgetPasswordActivity extends AppCompatActivity implements View.OnClickListener {
    CircularProgressButton btn;
    EditText editTextEmail;
    private static final String TAG = "ForgetPasswordActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        editTextEmail = (EditText) findViewById(R.id.editTextForgotPassword);
        btn = (CircularProgressButton) findViewById(R.id.btnEnterForget);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case (R.id.btnEnterForget):
                if (isValidEmail(editTextEmail.getText().toString())) {
                    volleyForgotPasswordRequest();
                } else {
                    editTextEmail.setError("Enter your email");
                }
                break;
        }
    }

    public void volleyForgotPasswordRequest() {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();

        HashMap<String, String> params = new HashMap<>();
        params.put("emailAddress", editTextEmail.getText().toString().trim());
        Log.d(TAG, "forgot password request: " + new JSONObject(params).toString());

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                AppConstant.FORGET_PASSWORD_URL, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        Log.d(TAG, jsonObject.toString());
                        mRequestQueue.stop();
                        try {
                            if (jsonObject.getString("code").equals("0")) {
                                btn.revertAnimation();
                                Log.d(TAG, "onResponse: " + jsonObject.toString());
                                com.kochartech.antitheft.xius.util.Utils.showAlertDialog("Reset Link has been sent to the associated Email", "Password Reset", ForgetPasswordActivity.this);
                            } else {
                                btn.revertAnimation();
                                com.kochartech.antitheft.xius.util.Utils.showAlertDialog("Email address is not found", "Password Reset", ForgetPasswordActivity.this);
//                                String message = jsonObject.getString(RESPONSE_MESSAGE);
                                Log.d(TAG, "onResponse: " + jsonObject.toString());
//                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            btn.revertAnimation();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                Log.d(TAG, "onErrorResponse: " + error.getMessage());
                Toast.makeText(ForgetPasswordActivity.this, "Error " + error.getMessage(), Toast.LENGTH_SHORT).show();
                btn.revertAnimation();
                mRequestQueue.stop();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }


        };
        btn.startAnimation();
        mRequestQueue.add(jsonObjReq);

    }

    private static boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
}
