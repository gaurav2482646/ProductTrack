package com.kochartech.antitheft.xius.services;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.kochartech.antitheft.xius.receiver.DeviceSettingsListener;
import com.kochartech.antitheft.xius.util.DeviceInfo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DeviceSettingsService extends Service {
    // private static String PREF_IS_RUNNING =
    // DeviceSettingsService.class.getSimpleName();
    public final static String KEY_BLUETOOTH = "Bluetooth";
    public final static String KEY_GPS = "GPS";
    public final static String KEY_HOTSPOT = "WiFi hotspot";
    public final static String KEY_WIFI = "WiFi";
    public final static String KEY_MOBILE_DATA = "Mobile Data";
    public final static String KEY_AIRPLANE_MODE = "Airplane Mode";
    private static String TAG = DeviceSettingsService.class.getSimpleName();
    private static Intent serviceIntent;
    private static Context context;
    private static DeviceSettingsService deviceSettingsService;
    private DeviceSettingsListener mReceiver;

    // private static OnConnectionChange onConnectionChange;

    public static DeviceSettingsService getInstance(Context context) {

        if (deviceSettingsService == null) {
            DeviceSettingsService.context = context;
            serviceIntent = new Intent(context, DeviceSettingsService.class);
            deviceSettingsService = new DeviceSettingsService();
        }
//        WriteToFile.write("DeviceSettingsService.txt", "IsMyServiceRunning : "
//                + isMyServiceRunning(DeviceSettingsService.class));
        return deviceSettingsService;
    }

    private static boolean isMyServiceRunning(Class<?> serviceClass) {
        try {
            ActivityManager manager = (ActivityManager) context
                    .getSystemService(Context.ACTIVITY_SERVICE);
            for (ActivityManager.RunningServiceInfo service : manager
                    .getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(
                        service.service.getClassName())) {
                    Log.i("isMyServiceRunning?", true + "");
                    return true;
                }
            }
            Log.i("isMyServiceRunning?", false + "");
        } catch (SecurityException e) {
            Log.e(TAG, "Exception : " + e.toString());
            e.printStackTrace();
            return false;
        }
        return false;
    }

    // OnConnectionChange onConnectionChange
    public void start() {
        if (!isMyServiceRunning(DeviceSettingsService.class)) {
            Log.i(TAG, "Need to start DeviceSettingsService...........");
            context.startService(serviceIntent);
        }

        // if (!isRunning(context)) {
        // Log.i(TAG, "Need to start DeviceSettingsService...........");
        // context.startService(serviceIntent);
        // }
        // DeviceSettingsService.onConnectionChange = onConnectionChange;
    }

    public void stop() {
        if (isMyServiceRunning(DeviceSettingsService.class)) {
            Log.i(TAG, "Need to start DeviceSettingsService...........");
            context.stopService(serviceIntent);
            serviceIntent = null;
        }
        // if (isRunning(context)) {
        // Log.i(TAG, "Need to stop DeviceSettingsService...........");
        // context.stopService(serviceIntent);
        // serviceIntent = null;
        // }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        // setRunning(context, true);
        // Register receiver that handles screen on and screen off logic
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        // filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        filter.addAction("android.intent.action.AIRPLANE_MODE");
        mReceiver = new DeviceSettingsListener();
        registerReceiver(mReceiver, filter);

    }

    // @Override
    // public void onStart(Intent intent, int startId) {
    //
    // }
    // }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int wifiOn = -1;
        int mobileDataOn = -1;
        int airplaneModeOn = -1;

        DeviceInfo deviceInfo = new DeviceInfo(getApplicationContext());

        try {
            airplaneModeOn = intent.getIntExtra(KEY_AIRPLANE_MODE,
                    airplaneModeOn);
            switch (airplaneModeOn) {
                case 0:
//                    Toast.makeText(context, "AirplaneMode is OFF",
//                            Toast.LENGTH_SHORT).show();
                    break;
                case 1:
//                    Toast.makeText(context, "AirplaneMode is ON",
//                            Toast.LENGTH_SHORT).show();
                    break;

                default:
                    break;
            }
        } catch (Exception e) {
            Log.e(TAG, "AirplaneModeDbException: " + e.toString());
        }
        if (!deviceInfo.isAirplaneModeEnabled()) {
            try {
                wifiOn = intent.getIntExtra(KEY_WIFI, wifiOn);
                switch (wifiOn) {
                    case 0:
//                        Toast.makeText(context, "WiFi is OFF",
//                                Toast.LENGTH_SHORT)
//                                .show();

                        break;
                    case 1:
//                        Toast.makeText(context, "WiFi is ON", Toast.LENGTH_SHORT)
//                                .show();


                        break;

                    default:
                        break;
                }
            } catch (Exception e) {
                Log.e(TAG, "WifiDbException: " + e.toString());
            }

            if (!deviceInfo.isWifiEnabled()) {
                try {
                    mobileDataOn = intent.getIntExtra(KEY_MOBILE_DATA,
                            mobileDataOn);
                    switch (mobileDataOn) {
                        case 0:
//                            Toast.makeText(context, "MobileData is OFF",
//                                    Toast.LENGTH_SHORT).show();
                            // onConnectionChange.onMobileDataChange(false);
                            break;
                        case 1:
//                             Toast.makeText(context, "MobileData is  ON",
//                             Toast.LENGTH_SHORT).show();
                            // onConnectionChange.onMobileDataChange(true);
                            if (haveNetworkConnection()) {
//                                Toast.makeText(context, "MobileData is  ON",
//                                        Toast.LENGTH_SHORT).show();
                            } else {
//                                Toast.makeText(context, "No Network Connection", Toast.LENGTH_SHORT).show();
                            }
                            break;

                        default:
                            break;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "MobileDataDbException: " + e.toString());
                }
            }
        }
        return START_STICKY;
    }

    private String getDateTime() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        return dateFormat.format(date);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "Service  destroy");
        start();
//        if (mReceiver != null)
//            unregisterReceiver(mReceiver);
        // setRunning(getApplicationContext(), false);
//        Intent intent = new Intent("com.android.kochar.servicestop");
//        sendBroadcast(intent);
    }

    // public static void setRunning(Context context, boolean running) {
    // SharedPreferences pref = PreferenceManager
    // .getDefaultSharedPreferences(context);
    // SharedPreferences.Editor editor = pref.edit();
    //
    // editor.putBoolean(PREF_IS_RUNNING, running);
    // editor.commit();
    // }
    //
    // private static boolean isRunning(Context context) {
    // SharedPreferences pref = PreferenceManager
    // .getDefaultSharedPreferences(context.getApplicationContext());
    // return pref.getBoolean(PREF_IS_RUNNING, false);
    // }

    @SuppressWarnings("deprecation")
    private boolean haveNetworkConnection() {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }

    @SuppressWarnings("deprecation")
    private boolean isWifiConnected() {
        boolean haveConnectedWifi = false;
        // boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            // if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
            // if (ni.isConnected())
            // haveConnectedMobile = true;
        }
        return haveConnectedWifi;
    }

    public String getNetworkClass(Context context) {

        if (!isWifiConnected()) {
            TelephonyManager mTelephonyManager = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);
            int networkType = mTelephonyManager.getNetworkType();
            switch (networkType) {
                case TelephonyManager.NETWORK_TYPE_GPRS:
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_CDMA:
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                case TelephonyManager.NETWORK_TYPE_IDEN:
                    return "2G";
                case TelephonyManager.NETWORK_TYPE_UMTS:
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_EVDO_B:
                case TelephonyManager.NETWORK_TYPE_EHRPD:
                case TelephonyManager.NETWORK_TYPE_HSPAP:
                    return "3G";
                case TelephonyManager.NETWORK_TYPE_LTE:
                    return "LTE";
                default:
                    return "NA";
            }
        } else {
            return "WiFi";
        }
    }
}