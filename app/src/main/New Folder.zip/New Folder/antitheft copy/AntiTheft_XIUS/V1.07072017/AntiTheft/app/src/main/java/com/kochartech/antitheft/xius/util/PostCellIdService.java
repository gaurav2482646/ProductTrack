package com.kochartech.antitheft.xius.util;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;


import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.kochartech.antitheft.xius.AppConstant;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PostCellIdService extends Service {
    RequestQueue requestQueue = null;
    String mToken ="12345";
    String url ="http://172.17.98.22/retailer/1.0/visitCell/token/";
    public static String TAG ="PostService";

    public PostCellIdService() {
    }

    @Override
    public IBinder onBind(Intent intent) {

        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent,  int flags, int startId) {

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if ( sharedPreferences.getBoolean(AppConstant.SCHEDULE_SET,false)) {
            String token = sharedPreferences.getString(AppConstant.TOKEN,mToken);
            url = url +token;
            postData(url);
        }

        else {
            AlarmManager alarmManager =  (AlarmManager)getSystemService(ALARM_SERVICE);
            Intent myIntent =  new Intent(this, PostCellIdService.class);
            PendingIntent pendingIntent = PendingIntent.getService(this, 0,
                    myIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);
            alarmManager.cancel(pendingIntent);
        }


        return super.onStartCommand(intent, flags, startId);

    }

    public void postData(String url  ) {
        RequestQueue mRequestQueue;
        Cache cache  = new DiskBasedCache(getCacheDir(), 1024* 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue =  new RequestQueue(cache,network);
        mRequestQueue.start();

        HashMap<String, String> params = new HashMap<String, String>();
        params.put("cellId", getCellId(this));

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                url, new JSONObject(params),
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG, response.toString());
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }
        };
        mRequestQueue.add(jsonObjReq);
    }

    public String getCellId(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) {
            final GsmCellLocation location = (GsmCellLocation) telephonyManager.getCellLocation();
            if (location != null) {
                Log.d(TAG," CID: " + location.getCid());
                return location.getCid()+"";
            }
        }
        return null;

    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        // stop task
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(AppConstant.SCHEDULE_SET,false);
        editor.commit();

        AlarmManager alarmManager =  (AlarmManager)getSystemService(ALARM_SERVICE);
        Intent myIntent =  new Intent(this, PostCellIdService.class);
        PendingIntent pendingIntent = PendingIntent.getService(this, 0,
                myIntent,
                PendingIntent.FLAG_CANCEL_CURRENT);
        alarmManager.cancel(pendingIntent);

    }
}
