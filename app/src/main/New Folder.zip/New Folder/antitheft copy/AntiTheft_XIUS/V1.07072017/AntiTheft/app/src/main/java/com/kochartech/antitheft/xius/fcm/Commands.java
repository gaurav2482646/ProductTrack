package com.kochartech.antitheft.xius.fcm;

/**
 * Created by gauravjeet on 17/8/17.
 */

public enum Commands {
    WIPE, LOCK, UNLOCK, SIREN, LOCATE, GEOFENCE, ALARM_ON, ALARM_OFF,LOC_TRACK,PING
}
