package com.kochartech.antitheft.xius.backup;

/**
 * Created by gauravjeet on 10/8/17.
 */


        import android.content.ContentValues;
        import android.content.Context;
        import android.content.Intent;
        import android.database.Cursor;
        import android.graphics.Bitmap;
        import android.net.Uri;
        import android.os.Build;
        import android.os.Environment;
        import android.provider.MediaStore;
        import android.util.Base64;
        import android.util.Log;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;

        import java.io.ByteArrayOutputStream;
        import java.io.File;
        import java.io.FileOutputStream;
        import java.util.ArrayList;

/**
 * Created by gaurav on 6/12/16.
 */

public class Images {

    private static String IMAGE_ID = "_id";
    private static String IMAGE_SOURCE = "iSource";
    private static String DATA = "_data";
    private static String SIZE = "_size";
    private static String DISPLAY_NAME = "_display_name";
    private static String MIME_TYPE = "mime_type";
    private static String TITLE = "title";
    private static String DATE_ADDED = "date_added";
    private static String DATE_MODIFIED = "date_modified";
    private static String DATE_TAKEN = "datetaken";
    private static String ORIENTATION = "orientation";
    private static String BUCKET_ID = "bucket_id";
    private static String BUCKET_DISPLAY_NAME = "bucket_display_name";
    private static String WIDTH = "width";
    private static String HEIGHT = "height";
    private static String THUMBNAIL="thumbnail";

    private static final String TAG = "Images";
    public static JSONArray getImagePaths(Context context) {
        String[] columns = {MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media._ID};

        final Cursor cursor = context.getContentResolver().
                query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, // Specify the provider
                        columns, // The columns we're interested in
                        null, // A WHERE-filter query
                        null, // The arguments for the filter-query
                        MediaStore.Images.Media.DATE_ADDED + " DESC" // Order the results, newest first
                );

        JSONArray paths = new JSONArray();

        if (cursor.moveToFirst()) {
            do {
                JSONObject image = new JSONObject();
                try {
                    image.put("path", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));
                    image.put("id", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)));
                    paths.put(image);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
            while (cursor.moveToNext());
        }



        return paths;

    }
    public static ArrayList<JSONObject> getImagePathsList(Context context) {
        String[] columns = {MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media._ID};

        final Cursor cursor = context.getContentResolver().
                query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, // Specify the provider
                        columns, // The columns we're interested in
                        null, // A WHERE-filter query
                        null, // The arguments for the filter-query
                        MediaStore.Images.Media.DATE_ADDED + " DESC" // Order the results, newest first
                );

        ArrayList<JSONObject> paths = new ArrayList<JSONObject>();

        int max = 0;

        while (cursor.moveToNext()) {

            max++;

            if(max == 50)
            {
                break;
            }

            JSONObject image = new JSONObject();
            try {
                image.put("path", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));
                image.put("id", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)));
                paths.add(image);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        cursor.close();




        /*if (cursor.moveToFirst()) {
            do {
                JSONObject image = new JSONObject();
                try {
                    image.put("path", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)));
                    image.put("id", cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)));
                    paths.add(image);

                }
                catch (JSONException e) {
                    e.printStackTrace();
                }

            }
            while (cursor.moveToNext());
        }
        cursor.close();*/

        return paths;
    }



    public static JSONArray getImageMetadata(Context context, JSONArray images) {
        JSONArray newImages = new JSONArray();
        String[] projection = {IMAGE_ID, BUCKET_DISPLAY_NAME,
                BUCKET_ID, DATA, DATE_ADDED,
                DATE_MODIFIED, DATE_TAKEN, DISPLAY_NAME,
                HEIGHT, MIME_TYPE, ORIENTATION,
                SIZE, TITLE, WIDTH};

        for (int i = 0; i < images.length(); i++) {
            try {
                JSONObject image = images.getJSONObject(i);
                Uri uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + image.getInt("id"));
                Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);

                if (cursor != null) {
                    cursor.moveToFirst();

                    String source = cursor.getString(cursor.getColumnIndex(DATA));
                    JSONObject metadata = new JSONObject();
                    metadata.put(BUCKET_DISPLAY_NAME, cursor.getString(cursor.getColumnIndex(BUCKET_DISPLAY_NAME)));
                    metadata.put(BUCKET_ID, cursor.getString(cursor.getColumnIndex(BUCKET_ID)));
                    metadata.put(DATA, cursor.getString(cursor.getColumnIndex(DATA)));
                    metadata.put(DATE_ADDED, "" + cursor.getInt(cursor.getColumnIndex(DATE_ADDED)));
                    metadata.put(DATE_MODIFIED, "" + cursor.getInt(cursor.getColumnIndex(DATE_MODIFIED)));
                    metadata.put(DATE_TAKEN, "" + cursor.getInt(cursor.getColumnIndex(DATE_TAKEN)));
                    metadata.put(DISPLAY_NAME, cursor.getString(cursor.getColumnIndex(DISPLAY_NAME)));
                    metadata.put(HEIGHT, "" + cursor.getInt(cursor.getColumnIndex(HEIGHT)));
                    metadata.put(MIME_TYPE, cursor.getString(cursor.getColumnIndex(MIME_TYPE)));
                    metadata.put(ORIENTATION, "" + cursor.getInt(cursor.getColumnIndex(ORIENTATION)));
                    metadata.put(SIZE, "" + cursor.getInt(cursor.getColumnIndex(SIZE)));
                    metadata.put(TITLE, cursor.getString(cursor.getColumnIndex(TITLE)));
                    metadata.put(WIDTH, "" + cursor.getInt(cursor.getColumnIndex(WIDTH)));
                    metadata.put(IMAGE_SOURCE, source);

                    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    long imageId = cursor.getLong(column_index);
                    metadata.put(THUMBNAIL, imageThumbnail(context, imageId));

                    cursor.close();

                    JSONObject imageMetadata = new JSONObject();
                    imageMetadata.put("path", image.getString("path"));
                    imageMetadata.put("id", image.getInt("id"));
                    imageMetadata.put("metadata", metadata);
                    newImages.put(imageMetadata);
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return newImages;
    }

    public static JSONObject getImageMetaSingle(Context context, JSONObject image) {

//        JSONObject metadata = new JSONObject();
        JSONObject metadata = new JSONObject();
//        HashMap<String,String> metadata = new HashMap<String, String>();

        String[] projection = {IMAGE_ID, BUCKET_DISPLAY_NAME,
                BUCKET_ID, DATA, DATE_ADDED,
                DATE_MODIFIED, DATE_TAKEN, DISPLAY_NAME,
                HEIGHT, MIME_TYPE, ORIENTATION,
                SIZE, TITLE, WIDTH};
        try {

            Uri uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + image.getInt("id"));
            Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);

            if (cursor != null) {
                cursor.moveToFirst();

                String source = cursor.getString(cursor.getColumnIndex(DATA));
                String name =cursor.getString(cursor.getColumnIndex(DISPLAY_NAME));

                metadata.put(BUCKET_DISPLAY_NAME, cursor.getString(cursor.getColumnIndex(BUCKET_DISPLAY_NAME)));
                metadata.put(BUCKET_ID, cursor.getString(cursor.getColumnIndex(BUCKET_ID)));
                metadata.put(DATA, cursor.getString(cursor.getColumnIndex(DATA)));
                metadata.put(DATE_ADDED, "" + cursor.getInt(cursor.getColumnIndex(DATE_ADDED)));
                metadata.put(DATE_MODIFIED, "" + cursor.getInt(cursor.getColumnIndex(DATE_MODIFIED)));
                metadata.put(DATE_TAKEN, "" + cursor.getInt(cursor.getColumnIndex(DATE_TAKEN)));
                metadata.put(DISPLAY_NAME, name);
                metadata.put(HEIGHT, "" + cursor.getInt(cursor.getColumnIndex(HEIGHT)));
                metadata.put(MIME_TYPE, cursor.getString(cursor.getColumnIndex(MIME_TYPE)));
                metadata.put(ORIENTATION, "" + cursor.getInt(cursor.getColumnIndex(ORIENTATION)));
                metadata.put(SIZE, "" + cursor.getInt(cursor.getColumnIndex(SIZE)));
                metadata.put(TITLE, cursor.getString(cursor.getColumnIndex(TITLE)));
                metadata.put(WIDTH, "" + cursor.getInt(cursor.getColumnIndex(WIDTH)));
                metadata.put(IMAGE_SOURCE, source);

                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                long imageId = cursor.getLong(column_index);
                metadata.put(THUMBNAIL, imageThumbnailIn(context, imageId,name));

                cursor.close();

                JSONObject imageMetadata = new JSONObject();
                imageMetadata.put("path", image.getString("path"));
                imageMetadata.put("id", image.getInt("id"));
                imageMetadata.put("metadata", metadata);

//                Log.d("image","json image "+ imageMetadata.toString());

            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }


        return metadata;
    }

    public static String imageThumbnail(Context context, long imageId) {
        Bitmap bitmap = MediaStore.Images.Thumbnails.getThumbnail(context.getContentResolver(), imageId,
                MediaStore.Images.Thumbnails.MICRO_KIND, null);

        String encoded = "";
        if (bitmap != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            encoded = Base64.encodeToString(byteArray, Base64.DEFAULT).replace("\n", "").replace("\r", "");
        }

        return encoded;

    }

    public static String imageThumbnailIn(Context context, long imageId,String name) {
        String encoded = "";
        try {
            Bitmap bitmap = MediaStore.Images.Thumbnails.getThumbnail(context.getContentResolver(), imageId,
                    MediaStore.Images.Thumbnails.MICRO_KIND, null);


            if (bitmap != null) {
//                Log.d("images ", "bitmap");
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);

                File f = new File(Environment.getExternalStorageDirectory()
                        + "/test/"+name);
                f.createNewFile();
                FileOutputStream fo = new FileOutputStream(f);
                fo.write(byteArrayOutputStream.toByteArray());

                fo.close();

                return f.getAbsolutePath();


            }
        }catch (Exception e)
        {
            Log.d("iamge ", e.toString());
        }
        return encoded;

//        return encoded;
    }

    /*public static void showImageInGallery(Context context, String jsonString) {
        JSONObject image = Utils.jsonFromString(jsonString);
        try {
            JSONObject metadata = image.getJSONObject("metadata");

            String filePath = metadata.getString(DATA);

            ContentValues values = new ContentValues();
            values.put(BUCKET_DISPLAY_NAME, metadata.getString(BUCKET_DISPLAY_NAME));
            values.put(BUCKET_ID, metadata.getString(BUCKET_ID));
            values.put(DATA, filePath);
            values.put(DATE_ADDED, Integer.parseInt(metadata.getString(DATE_ADDED)));
            values.put(DATE_MODIFIED, Integer.parseInt(metadata.getString(DATE_MODIFIED)));
            values.put(DATE_TAKEN, Integer.parseInt(metadata.getString(DATE_TAKEN)));
            values.put(DISPLAY_NAME, metadata.getString(DISPLAY_NAME));
            values.put(HEIGHT, Integer.parseInt(metadata.getString(HEIGHT)));
            values.put(MIME_TYPE, metadata.getString(MIME_TYPE));
            values.put(ORIENTATION, Integer.parseInt(metadata.getString(ORIENTATION)));
            values.put(SIZE, Integer.parseInt(metadata.getString(SIZE)));
            values.put(TITLE, metadata.getString(TITLE));
            values.put(WIDTH, Integer.parseInt(metadata.getString(WIDTH)));

            context.getContentResolver().insert(MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI,values);

            refreshGallery(context,new File(filePath));

        }
        catch (Exception ex){
            //Do nothing
            Log.e("Images "," images "+ ex.toString());
        }
    }*/
    public static  void refreshGallery(Context context,File file)
    {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                Intent mediaScanIntent = new Intent(
                        Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                Uri contentUri = Uri.fromFile(file); //file is your file you saved/deleted/moved/copied
                mediaScanIntent.setData(contentUri);
                context.sendBroadcast(mediaScanIntent);
            } else {
                context.sendBroadcast(new Intent(
                        Intent.ACTION_MEDIA_MOUNTED,
                        Uri.parse("file://"
                                + Environment.getExternalStorageDirectory())));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}