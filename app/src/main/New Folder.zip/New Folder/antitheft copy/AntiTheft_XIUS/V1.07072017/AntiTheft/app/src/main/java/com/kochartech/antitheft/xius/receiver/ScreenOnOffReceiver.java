package com.kochartech.antitheft.xius.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.services.ScreenOnOffService;

/**
 * Created by gauravjeet on 25/9/17.
 */
//// FIXME: 17/10/17 

public class ScreenOnOffReceiver extends BroadcastReceiver {
    boolean screenOn;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
            screenOn = true;
        }
        if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
            screenOn = false;
        }
        Intent screenServiceIntent = new Intent(context, ScreenOnOffService.class);
        screenServiceIntent.putExtra(AppConstant.SCREEN_ON_STATUS, screenOn);
        context.startService(screenServiceIntent);
    }
}
