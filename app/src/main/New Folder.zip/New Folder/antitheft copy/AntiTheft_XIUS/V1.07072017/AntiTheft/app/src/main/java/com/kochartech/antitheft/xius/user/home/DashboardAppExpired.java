package com.kochartech.antitheft.xius.user.home;

import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.dto.AppDTO;
import com.kochartech.antitheft.xius.dto.DeviceDTO;
import com.kochartech.antitheft.xius.dto.RegisterDTO;
import com.kochartech.antitheft.xius.dto.UserDTO;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class DashboardAppExpired extends Fragment implements View.OnClickListener, PurchasesUpdatedListener, BillingClientStateListener {

    private DevicePolicyManager mDPM;
    private ComponentName mAdminName;
    private static final String RESPONSE_MESSAGE = "message";
    private View mViewLinearLayout;
    private ProgressBar mProgressView;
    private Button mbtnAddDevice;
    private static final String TAG = "DashboardAppExpired";
    private static final String ARG_PARAM1 = "isExpired";
    private static final String ARG_PARAM2 = "daysExpired";
    private static final int REQUEST_CODE_DEVICE_ADMIN = 200;
    private BillingClient mBillingClient;
    boolean billingClientReady = false;
    PreferenceHelper preferenceHelper;
    // TODO: Rename and change types of parameters
    private boolean mIsExpired;
    private int mDaysSinceExpiry;
    private String purchaseToken;

    public DashboardAppExpired() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param isExpired              Parameter 1.
     * @param daysElapsedSinceExpiry Parameter 2.
     * @return A new instance of fragment DashboardAppExpired.
     */
    // TODO: Rename and change types and number of parameters
    public static DashboardAppExpired newInstance(boolean isExpired, int daysElapsedSinceExpiry) {
        DashboardAppExpired fragment = new DashboardAppExpired();
        Bundle args = new Bundle();
        args.putBoolean(ARG_PARAM1, isExpired);
        args.putInt(ARG_PARAM2, daysElapsedSinceExpiry);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferenceHelper = new PreferenceHelper(getContext());
        if (getArguments() != null) {
            mIsExpired = getArguments().getBoolean(ARG_PARAM1);
            mDaysSinceExpiry = getArguments().getInt(ARG_PARAM2);
        }
        mBillingClient = BillingClient.newBuilder(getActivity()).setListener(this).build();
        mBillingClient.startConnection(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard_app_expired, container, false);
        mViewLinearLayout = view.findViewById(R.id.updateValidity_linearLayout);
        mProgressView = (ProgressBar) view.findViewById(R.id.validity_progress);
        mbtnAddDevice = (Button) view.findViewById(R.id.btnUpdateValidity);
        mbtnAddDevice.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnUpdateValidity:
                dialogChooseLicense(getActivity());
                Toast.makeText(getContext(), "Add a device here", Toast.LENGTH_SHORT).show();

//                volleyRegisterDeviceRequest();
                break;


        }
    }

    private void dialogChooseLicense(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        CharSequence[] licenseType = {"Yearly (365 days)"};
        final boolean[] isTrial = {true};
        builder.setTitle("Select License");
        builder.setSingleChoiceItems(licenseType, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
             /*   if (which == 0) {
                    isTrial[0] = true;
//                    Toast.makeText(context, "Trial Selected", Toast.LENGTH_SHORT).show();
                } else if (which == 1) {
                    isTrial[0] = false;
//                    Toast.makeText(context, "Yearly Selected", Toast.LENGTH_SHORT).show();
                }*/
            }
        })
                .setPositiveButton("Buy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showProgress(true);
                        startPurchaseProduct();

                    }
                });
        builder.show();
    }

    public void volleyRegisterDeviceRequest(boolean isTrial) {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getActivity().getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();
        int userID = preferenceHelper.getInt(AppConstant.USER_ID, 0);
        JSONObject jsonObject = getUpdateValidityJSONObject(userID, isTrial);
        Log.d(TAG, "volleyRegisterDeviceRequest: JSON OF ADD DEVICE REQUEST: " + jsonObject.toString());
        Toast.makeText(getActivity(), "Activating Device", Toast.LENGTH_SHORT).show();
        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                AppConstant.UPDATE_VALIDITY, jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        Log.d(TAG, jsonObject.toString());
                        mRequestQueue.stop();
                        try {
                            if (jsonObject.getString("code").equals("0")) {
                                Log.d(TAG, "SUCCESS STRING : " + jsonObject);
//                                if (!mDPM.isAdminActive(mAdminName)) {
//                                    Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
//                                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminName);
//                                    intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Click on Activate button to secure your application.");
//                                    startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN);
//                                } else {
                                preferenceHelper.saveLong(AppConstant.LOGIN_TIME, new Date().getTime());
                                preferenceHelper.saveInt(AppConstant.VALIDITY_AT_LOGIN, 365);
                                preferenceHelper.saveBoolean(AppConstant.IS_APP_EXPIRED, false);
                                preferenceHelper.setDeviceRegistered();
                                String message = jsonObject.getString(RESPONSE_MESSAGE);
                                Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
                                Toast.makeText(getActivity(), "Successfully Activated Device", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getActivity(), HomeActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                                getActivity().startService(new Intent(getContext(), StartupOperations.class));
                                getActivity().startActivity(intent);
//                                getActivity().finishAffinity();
//                                }
                            } else {
                                showProgress(false);
                                Log.d(TAG, "FAILURE STRING : " + jsonObject);

                                String message = jsonObject.getString(RESPONSE_MESSAGE);
                                Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            showProgress(false);

                            Toast.makeText(getActivity(), "Json Parsing Error", Toast.LENGTH_LONG).show();

                        }
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                showProgress(false);
                Log.d(TAG, "onErrorResponse: " + error.getMessage());
                Toast.makeText(getContext(), "Check Your Network Connection", Toast.LENGTH_SHORT).show();
                mRequestQueue.stop();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }


        };
        mRequestQueue.add(jsonObjReq);

    }

    private JSONObject getUpdateValidityJSONObject(int userId, boolean isTrial) {
        Log.d(TAG, "User ID is: " + userId);
        try {
            DeviceDTO deviceDTO = new DeviceDTO();
            AppDTO appDTO = new AppDTO();
            UserDTO userDTO = new UserDTO();
            deviceDTO.setMacAddress(Utils.getMACAddress().replace(":", ""));
            //Todo Can add the version field in future
//            appDTO.setAppVersion(getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0).versionName);
//            appDTO.setAppName(Utils.getApplicationName(getContext()));
            appDTO.setIsTrial(isTrial);
//            appDTO.setValidity(isTrial ? 30 : 365);
            userDTO.setUserID(userId);

            //Save the Validity Locally
//            preferenceHelper.saveBoolean(AppConstant.IS_TRIAL, isTrial);
//            preferenceHelper.saveInt(AppConstant.VALIDITY_AT_LOGIN, isTrial ? 30 : 365);

            RegisterDTO registerDTO = new RegisterDTO();
            registerDTO.setAppDTO(appDTO);
            registerDTO.setDeviceDTO(deviceDTO);
            registerDTO.setUserDTO(userDTO);
            Gson gson = new Gson();
            Log.d(TAG, "json " + new JSONObject(gson.toJson(registerDTO)));

            return new JSONObject(gson.toJson(registerDTO));

        } catch (Exception ex) {
            Log.e(TAG, "exception create json " + ex.toString());
        }
        return null;
    }

    private void showProgress(final boolean show) {
        mProgressView.setVisibility(show ? View.VISIBLE : View.INVISIBLE);

    }

    private void refreshNavigationView() {

        getActivity().setContentView(R.layout.activity_home);
        BottomNavigationView navigationView = (BottomNavigationView) getActivity().findViewById(R.id.bottom_navigation);

    }


    @Override
    public void onPurchasesUpdated(int responseCode, @Nullable List<Purchase> purchases) {
        if (responseCode == BillingClient.BillingResponse.OK
                && purchases != null) {
            for (Purchase purchase : purchases) {
                purchaseToken = purchase.getPurchaseToken();
                Log.i(TAG, "onPurchasesUpdated: " + purchase.getOriginalJson());
            }
            Log.i(TAG, "onPurchasesUpdated " + responseCode);

            if (!purchaseToken.isEmpty()) {
                consumePurchaseProduct();
            }

        } else if (responseCode == BillingClient.BillingResponse.USER_CANCELED) {
            // Handle an error caused by a user cancelling the purchase flow.
            showProgress(false);
            Log.i(TAG, "onPurchasesUpdated: Billing Was cancelled");
        } else if (responseCode == BillingClient.BillingResponse.ERROR) {
            // Handle any other error codes.
            showProgress(false);
            Log.i(TAG, "onPurchasesUpdated:Any other error");
        } else if (responseCode == BillingClient.BillingResponse.FEATURE_NOT_SUPPORTED) {
            Log.i(TAG, "onPurchasesUpdated:Feature not supported");
            showProgress(false);
        } else if (responseCode == BillingClient.BillingResponse.SERVICE_UNAVAILABLE) {
            Log.i(TAG, "onPurchasesUpdated: Service Unavailable");
            showProgress(false);


        }
    }

    @Override
    public void onBillingSetupFinished(int responseCode) {
//        if (responseCode == BillingClient.BillingResponse.OK) {
        // The billing client is ready. You can query purchases here.
        queryPurchasedItems();
//            queryPurchase();
//            queryPurchasedItems();
//        }
//        int responseCode = mBillingClient.launchBillingFlow(getActivity(), flowParams);
        switch (responseCode) {
            case BillingClient.BillingResponse.OK:
                Log.i(TAG, "Items Purchased: " + responseCode);
                Log.d(TAG, "onBillingSetupFinished: Now Start Query Purchase ");
                billingClientReady = true;
                break;
            case BillingClient.BillingResponse.ITEM_ALREADY_OWNED:
                Log.i(TAG, "Item  Already Purchased: " + responseCode);
                break;
            case BillingClient.BillingResponse.ERROR:
                Toast.makeText(getActivity(), "Error connecting to billing client. Try again.", Toast.LENGTH_SHORT).show();
                Log.i(TAG, "Item  Not Owned: " + responseCode);
                showProgress(false);

                break;
            case BillingClient.BillingResponse.SERVICE_DISCONNECTED:
                Log.i(TAG, "Service Disconnected: " + responseCode);
                Toast.makeText(getActivity(), "disconnected from billing client. Try again.", Toast.LENGTH_SHORT).show();
                showProgress(false);

                break;
            case BillingClient.BillingResponse.SERVICE_UNAVAILABLE:
                Log.i(TAG, "Service Unavailable: " + responseCode);
                Toast.makeText(getActivity(), "billing service is unavailable. Try again.", Toast.LENGTH_SHORT).show();
                showProgress(false);

                break;
        }
    }

    @Override
    public void onBillingServiceDisconnected() {
        billingClientReady = false;
//        if (!billingClientReady) {
//            mBillingClient.startConnection(this);
//        }
    }

    public void startPurchaseProduct() {
        if (billingClientReady) {
            BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                    .setSku("mp2")
                    .setType(BillingClient.SkuType.INAPP)
                    .build();
            int responseCode = mBillingClient.launchBillingFlow(getActivity(), flowParams);
            switch (responseCode) {
                case BillingClient.BillingResponse.OK:
                    Log.i(TAG, "Items Purchased: " + responseCode);
                    break;
                case BillingClient.BillingResponse.ITEM_ALREADY_OWNED:
                    Log.i(TAG, "Item  Already Purchased: " + responseCode);
                    Toast.makeText(getActivity(), "Item  Already Purchased.", Toast.LENGTH_SHORT).show();

                    break;
                case BillingClient.BillingResponse.ERROR:
                    Toast.makeText(getActivity(), "Error connecting to billing client. Try again.", Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "Item  Not Owned: " + responseCode);
                    break;
                case BillingClient.BillingResponse.SERVICE_DISCONNECTED:
                    Log.i(TAG, "Service Disconnected: " + responseCode);
                    Toast.makeText(getActivity(), "disconnected from billing client. Try again.", Toast.LENGTH_SHORT).show();
                    break;
                case BillingClient.BillingResponse.SERVICE_UNAVAILABLE:
                    Log.i(TAG, "Service Unavailable: " + responseCode);
                    Toast.makeText(getActivity(), "billing service is unavailable. Try again.", Toast.LENGTH_SHORT).show();
                    break;
            }
            Log.i(TAG, "startPurchaseProduct Response: " + responseCode);
        } else {
            Toast.makeText(getActivity(), "Billing Client is not yet setup, restart the app with working connection", Toast.LENGTH_LONG).show();
            Log.i(TAG, "startPurchaseProduct: Billing Client is not yet setup");
        }

    }

    public void consumePurchaseProduct() {
        mBillingClient.consumeAsync(purchaseToken, new ConsumeResponseListener() {
            @Override
            public void onConsumeResponse(int responseCode, String purchaseToken) {
                switch (responseCode) {
                    case BillingClient.BillingResponse.OK:
                        Log.i(TAG, "Item Consumed: " + responseCode);
//                        Toast.makeText(getActivity(), "Item Consumed", Toast.LENGTH_SHORT).show();
                        //Purchase is successfull , add the device to server and activate the app
                        volleyRegisterDeviceRequest(false);
                        break;
                    case BillingClient.BillingResponse.ITEM_ALREADY_OWNED:
                        Log.i(TAG, "Item  Already Purchased: " + responseCode);
                        break;
                    case BillingClient.BillingResponse.ITEM_NOT_OWNED:
                        Log.i(TAG, "Item  Not Owned: " + responseCode);
                        Toast.makeText(getActivity(), "Item  Not Owned", Toast.LENGTH_SHORT).show();
                        break;
                    case BillingClient.BillingResponse.ERROR:
                        Log.i(TAG, "Some fatal error occurred: " + responseCode);
//                        Toast.makeText(getActivity(), "Some fatal error occurred, restart the app", Toast.LENGTH_SHORT).show();
                        break;
                    case BillingClient.BillingResponse.SERVICE_DISCONNECTED:
                        Log.i(TAG, "Service Disconnected: " + responseCode);
                        Toast.makeText(getActivity(), "Service Disconnected", Toast.LENGTH_SHORT).show();
                        break;
                    case BillingClient.BillingResponse.SERVICE_UNAVAILABLE:
                        Log.i(TAG, "Service Unavailable: " + responseCode);
                        Toast.makeText(getActivity(), "Billing Service Unavailable", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }

    private void queryPurchasedItems() {
        Log.i(TAG, "queryPurchasedItems Called");
        Purchase.PurchasesResult purchasesResult = mBillingClient.queryPurchases(BillingClient.SkuType.INAPP);
        List<Purchase> purchaseList = purchasesResult.getPurchasesList();
        try {
            if (purchaseList.isEmpty()) {
//            hasPurchasedLicence = false;
                Log.i(TAG, "queryPurchasedItems: User has purchased nothing");

            } else {

                for (Purchase purchase : purchaseList) {
                    Log.i(TAG, "queryPurchasedItems: " + purchase.getOriginalJson());
                    purchaseToken = purchase.getPurchaseToken();
                    mBillingClient.consumeAsync(purchaseToken, new ConsumeResponseListener() {
                        @Override
                        public void onConsumeResponse(int responseCode, String purchaseToken) {
                            if (responseCode == BillingClient.BillingResponse.OK) {
                                Log.d(TAG, "onConsumeResponse: Pending Items Consumed");
                            }
                        }
                    });
                }
            }

        } catch (Exception e) {
            Log.d(TAG, "Error :queryPurchasedItems: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
