package com.kochartech.antitheft.xius.user.home;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.user.UpdatePasswordActivity;
import com.kochartech.antitheft.xius.user.UpdateProfileActivity;
import com.kochartech.antitheft.xius.util.PreferenceHelper;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "ProfileFragment";
    TextView tvFullname, tvNumber, tvAlternateNumber, tvEmail;
    Button buttonEditProfile, buttonUpdatePassword;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String name, number, email, alternateNumber;
    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: Called");
        name = sharedPreferences.getString(AppConstant.USER_NAME,"");
        number = sharedPreferences.getString(AppConstant.PHONE_NUMBER,"");
        email = sharedPreferences.getString(AppConstant.USER_EMAIL,"");
        alternateNumber = sharedPreferences.getString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, "");
        tvFullname.setText(name);
        tvNumber.setText(number);
        tvEmail.setText(email);
        tvAlternateNumber.setText(alternateNumber);
    }

//    @Override
//    public void onResume() {
//        Log.d(TAG, "onResume:Called ");
//        super.onResume();
//
//    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate:Called ");
        sharedPreferences = PreferenceHelper.getSharedPreference();
        editor = PreferenceHelper.getSharedPreferenceEditor();
        name = sharedPreferences.getString(AppConstant.USER_NAME,"");
        number = sharedPreferences.getString(AppConstant.PHONE_NUMBER,"");
        email = sharedPreferences.getString(AppConstant.USER_EMAIL,"");
        alternateNumber = sharedPreferences.getString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE,"");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView: Called");
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        buttonEditProfile = (Button) view.findViewById(R.id.btn_editProfile);
        buttonUpdatePassword = (Button) view.findViewById(R.id.btn_changePassword);
        tvFullname = (TextView) view.findViewById(R.id.textFullName);
        tvFullname.setMovementMethod(new ScrollingMovementMethod());
        tvNumber = (TextView) view.findViewById(R.id.textMobileNo);
        tvEmail = (TextView) view.findViewById(R.id.textEmail);
        tvAlternateNumber = (TextView) view.findViewById(R.id.textAlternateMobileNo);
        buttonUpdatePassword.setOnClickListener(this);
        buttonEditProfile.setOnClickListener(this);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Called");

        name = sharedPreferences.getString(AppConstant.USER_NAME, "");
        number = sharedPreferences.getString(AppConstant.PHONE_NUMBER, "");
        email = sharedPreferences.getString(AppConstant.USER_EMAIL, "");
        alternateNumber = sharedPreferences.getString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, "");
        tvFullname.setText(name);
        tvNumber.setText(number);
        tvEmail.setText(email);
        tvAlternateNumber.setText(alternateNumber);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_changePassword:
                startActivity(new Intent(getActivity(), UpdatePasswordActivity.class));
                break;
            case R.id.btn_editProfile:
                startActivity(new Intent(getActivity(), UpdateProfileActivity.class));
                break;
        }
    }
}
