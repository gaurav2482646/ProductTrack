package com.kochartech.antitheft.xius.util;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.StartupOperations;
import com.kochartech.antitheft.xius.dto.eventBus.ValidityEvent;
import com.kochartech.antitheft.xius.lockscreen.ApplicationManager;
import com.kochartech.antitheft.xius.receiver.ButtonReceiver;

import org.greenrobot.eventbus.EventBus;

import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;

/**
 * Created by gaurav on 27/7/17.
 */

public class
Utils {
    public static final String TAG = "Utils";

    public static String getMACAddress() {
        try {
            String interfaceName = "wlan0";
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                if (!intf.getName().equalsIgnoreCase(interfaceName)) {
                    continue;
                }

                byte[] mac = intf.getHardwareAddress();
                if (mac == null) return "";
                StringBuilder buf = new StringBuilder();
                for (int idx = 0; idx < mac.length; idx++)
                    buf.append(String.format("%02X:", mac[idx]));
                if (buf.length() > 0) buf.deleteCharAt(buf.length() - 1);
                return buf.toString();
            }
        } catch (Exception ex) {
        } // for now eat exceptions
        return "";
        /*try {
            // this is so Linux hack
            return loadFileAsString("/sys/class/net/" +interfaceName + "/address").toUpperCase().trim();
        } catch (IOException ex) {
            return null;
        }*/
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    public static String getSimNumber(Context context, int simNumber) {
        SubscriptionManager subscriptionManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        List<SubscriptionInfo> subscriptionInfoList = subscriptionManager.getActiveSubscriptionInfoList();
        int size = subscriptionInfoList.size();
        Log.d(TAG, "sub size " + size);
        if (size > 0) {
            SubscriptionInfo subscriptionInfo = subscriptionInfoList.get(0);
            Log.d(TAG, " id " + subscriptionInfo.getSubscriptionId());
        }

        if (size == 0) {
            return null;
        }

        /*
        if(size >= 2) {
            return ((SubscriptionInfo) subscriptionInfoList.get(simNumber)).getSubscriptionId();
        }
        else {
            if(simNumber == 1 ) {
              return  subscriptionInfoList.get(simNumber);
            } else {
                return null;
            }
        }
        */
        return null;

    }

    public static boolean isNetworkAvailable(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

            Log.d(TAG, " network name " + networkInfo.getTypeName());
            if (networkInfo.isConnectedOrConnecting()) {
                return true;

            }

        } catch (Exception e) {
            Log.d(TAG, "is network available " + e.toString());
        }

        return false;
    }

    public static void isKeyBoardShow(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (imm.isActive()) {
            imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0); // hide
        } else {
            imm.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY); // show
        }
    }

    public static void unHideIcon(Context context) {
        ComponentName LAUNCHER_COMPONENT_NAME = new ComponentName(
                "com.kochartech.antitheft.xius", "com.kochartech.antitheft.xius.Launcher");
        PackageManager p = context.getPackageManager();
//        ComponentName componentName = new ComponentName(context, com.kochartech.antitheft.xius.DisplayActivity.class);
        p.setComponentEnabledSetting(LAUNCHER_COMPONENT_NAME, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
    }

    public static void showOnGoingNotification(String notificationTitle,
                                               String message, Context context, Intent viewIntent,
                                               int notificationId) {
        int icon = android.R.drawable.btn_star;
        int stopIcon = android.R.drawable.stat_notify_more;

        Intent buttonIntent = new Intent(context, ButtonReceiver.class);
        buttonIntent.putExtra("notificationId", notificationId);
        if (notificationTitle == null) {
            notificationTitle = context.getString(R.string.app_name);
        }
        Log.d(TAG, " notification message " + message);
        NotificationCompat.Builder mBuilder = null;

        if (viewIntent != null) {
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
                    AppConstant.REQUEST_CODE, buttonIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);

      /*PendingIntent pendingIntent = PendingIntent.getActivity(context,
            AppConstant.REQUEST_CODE, buttonIntent,
            PendingIntent.FLAG_CANCEL_CURRENT);*/
            mBuilder = new NotificationCompat.Builder(context)
                    .setSmallIcon(icon)
                    .setContentTitle(notificationTitle).setContentText(message)
                    .setOngoing(true)
                    .setColor(Color.parseColor("#1976d2"))
                    .addAction(stopIcon, "Dismiss", pendingIntent);

        } else {
            mBuilder = new NotificationCompat.Builder(context)
                    .setSmallIcon(icon)
                    .setContentTitle(notificationTitle)
                    .setOngoing(true)
                    .setColor(Color.parseColor("#1976d2"))
                    .setContentText(message).setAutoCancel(true);
        }

        NotificationManagerCompat notificationManager = NotificationManagerCompat
                .from(context);
        notificationManager.notify(notificationId, mBuilder.build());

    }

    public static void showBigNotification(
            String message, Context context, Intent viewIntent,
            int notificationId, boolean isSound, boolean isVibrate) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
//        int appType = preferences.getInt(AppConstant.APPLICATION_TYPE, 0);

        int icon = android.R.drawable.ic_lock_lock;

        String notificationTitle = context.getString(R.string.app_name);
        Log.d(TAG, " notification message " + message);
        NotificationCompat.Builder mBuilder = null;
        Notification note = new Notification();
        if (isSound) {
            note.defaults |= Notification.DEFAULT_SOUND;
        }
        if (isVibrate) {
            note.defaults |= Notification.DEFAULT_VIBRATE;
            note.defaults |= Notification.DEFAULT_LIGHTS;
        }
        if (viewIntent != null) {
            PendingIntent pendingIntent = PendingIntent.getActivity(context,
                    AppConstant.REQUEST_CODE, viewIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);
            mBuilder = new NotificationCompat.Builder(context)
                    .setDefaults(note.defaults)
                    .setSmallIcon(icon)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setContentTitle(notificationTitle).setContentText(message)
                    .setColor(Color.parseColor("#1976d2"))
                    .setContentIntent(pendingIntent).setAutoCancel(true);

        } else {
            mBuilder = new NotificationCompat.Builder(context)
                    .setSmallIcon(icon)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setContentTitle(
                            notificationTitle)
                    .setColor(Color.parseColor("#1976d2"))
                    .setContentText(message).setAutoCancel(true);
        }
        NotificationManagerCompat notificationManager = NotificationManagerCompat
                .from(context);
        notificationManager.notify(notificationId, mBuilder.build());

    }

    public void getCellId(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) {
            final GsmCellLocation location = (GsmCellLocation) telephonyManager.getCellLocation();
            if (location != null) {
                Log.d(TAG, " CID: " + location.getCid());
            }
        }

    }

    public boolean isSimChanged(Context context) {
        TelephonyInfo telephonyInfo = TelephonyInfo.getInstance(context);
        DualSimInfo dualSimInfo = new DualSimInfo(context);
        SharedPreferences sharedPreferences = PreferenceHelper.getSharedPreference();
        String sim1 = sharedPreferences.getString(AppConstant.SIM_NUMBER_ONE, "");
        String sim2 = sharedPreferences.getString(AppConstant.SIM_NUMBER_TWO, "");
        String newSim1 = "";
        String newSim2 = "";
        if (new DualSimInfo(context).isDualSim() && Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
//            if (telephonyInfo.isSIM1Ready()) {
//                newSim1 = telephonyInfo.getImsiSIM1();
//            }
//            if (telephonyInfo.isSIM2Ready()) {
//                newSim2 = telephonyInfo.getImsiSIM2();
//            }
            newSim1 = dualSimInfo.getIMSI(0) == null ? "" : dualSimInfo.getIMSI(0);
            newSim2 = dualSimInfo.getIMSI(1) == null ? "" : dualSimInfo.getIMSI(1);
            Log.d(TAG, "isSimChanged: sim 1:" + sim1);
            Log.d(TAG, "isSimChanged: new sim 1:" + newSim1);
            Log.d(TAG, "isSimChanged: sim 2:" + sim2);
            Log.d(TAG, "isSimChanged: new sim 2:" + newSim2);
            boolean b = !(sim1.equals(newSim1)) || !(sim2.equals(newSim2));
            Log.d(TAG, "isSimChanged: " + b);
            Log.d(TAG, "isSimChanged1: " + !(sim1.equals(newSim1)));
            Log.d(TAG, "isSimChanged2: " + !(sim2.equals(newSim2)));
            return !(sim1.equals(newSim1)) || !(sim2.equals(newSim2));
        } else {
            TelephonyManager telephonyManager = (TelephonyManager) ApplicationManager.getAppContext().getSystemService(Context.TELEPHONY_SERVICE);
            newSim1 = telephonyManager.getSubscriberId() == null ? "" : telephonyManager.getSubscriberId();
//            if (newSim1 == null) {
//                if (telephonyInfo.isSIM1Ready()) {
//                    newSim1 = telephonyInfo.getImsiSIM1();
//                }
//            }
            Log.d(TAG, "isSimChanged: sim 1:" + sim1);
            Log.d(TAG, "isSimChanged: New sim 1:" + newSim1);
            return !sim1.equals(newSim1);
        }
    }

    public static String getApplicationName(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        int stringId = applicationInfo.labelRes;
        return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : context.getString(stringId);
    }

    public static boolean isMyServiceRunning(Class<?> serviceClass, Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void getSamsungBrand(Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        String isbrandSamsung = Build.BRAND;
        if (isbrandSamsung.equalsIgnoreCase("samsung") && Build.VERSION.SDK_INT >= 17) {
            editor.putBoolean("IS_DEVICE_SAMSUNG_COMPILATION", true);
            Log.d(TAG, "Samsung Handset Found");
        }
        editor.apply();
    }

    public boolean isAppFirstRun(Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        if (preferences.getBoolean(AppConstant.IS_APP_FIRST_RUN, true)) {
            editor.putBoolean(AppConstant.IS_APP_FIRST_RUN, false);
            editor.commit();
            return true;
        } else {
            return false;
        }
    }

    public static boolean isDeviceSamsung(Context context) {
        SharedPreferences preferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        return preferences.getBoolean("IS_DEVICE_SAMSUNG_COMPILATION", false);
    }

    public void storeManufactureName(Context context) {
        final String manufacturer = android.os.Build.MANUFACTURER;
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(AppConstant.MANUFACTURER_PHONE, manufacturer);
        editor.commit();

    }

    public boolean checkOverlayPermission(Context context) {
        if (Build.VERSION_CODES.M <= Build.VERSION.SDK_INT) {

            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, Settings.canDrawOverlays(context));
            editor.apply();
            return Settings.canDrawOverlays(context);

        } else {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, true);
            editor.apply();
            return true;
        }
    }

    public void overlayPermissionRationale(final Context context, final int requestCode) {

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(context);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage("Overlay permission is needed for locking functionality ?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + context.getPackageName()));
                        ((Activity) context).startActivityForResult(intent, requestCode);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.cancel();
                    }
                });

        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("AntiTheft Alert");
        alert.show();
    }

    public static Intent createExplicitFromImplicitIntent(Context context, Intent implicitIntent) {
        //Retrieve all services that can match the given intent
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> resolveInfo = pm.queryIntentServices(implicitIntent, 0);

        //Make sure only one match was found
        if (resolveInfo == null || resolveInfo.size() != 1) {
            return null;
        }

        //Get component info and create ComponentName
        ResolveInfo serviceInfo = resolveInfo.get(0);
        String packageName = serviceInfo.serviceInfo.packageName;
        String className = serviceInfo.serviceInfo.name;
        ComponentName component = new ComponentName(packageName, className);

        //Create a new intent. Use the old one for extras and such reuse
        Intent explicitIntent = new Intent(implicitIntent);

        //Set the component to be explicit
        explicitIntent.setComponent(component);

        return explicitIntent;
    }

    public static float getBatteryLevel() {
        Intent batterIntent = ApplicationManager.getAppContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = batterIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batterIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

        if (level == -1 || scale == -1) {
            return -1.0f;
        }
        return level / scale * 100.0f;


    }

    public static void showAlertDialog(String content, String title, Context context) {

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(context);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage(content)
                .setCancelable(false)
                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });


        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle(title);
        alert.show();
    }

    public static void storeSimSerial(Context context) {
        PreferenceHelper preferenceHelper;
        preferenceHelper = new PreferenceHelper(context);
        TelephonyInfo telephonyInfo = TelephonyInfo.getInstance(context);
        boolean isDualSim;
        String simOne = null;
        String simTwo = null;
        DualSimInfo dualSimInfo = new DualSimInfo(context);
        isDualSim = dualSimInfo.isDualSim();
        if (isDualSim && Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
            simOne = dualSimInfo.getIMSI(0);
            simTwo = dualSimInfo.getIMSI(1);
//            if (simOne == null) {
//                if (telephonyInfo.isSIM1Ready()) {
//                    simOne = telephonyInfo.getImsiSIM1();
//                }
//            }
//            if (simTwo == null) {
//                if (telephonyInfo.isSIM2Ready()) {
//                    simTwo = telephonyInfo.getImsiSIM2();
//                }
//            }
            Log.d(TAG, "storeSimSerial: Sim1 :" + simOne);
            Log.d(TAG, "storeSimSerial: Sim2 :" + simTwo);
            preferenceHelper.saveString(AppConstant.SIM_NUMBER_ONE, simOne);
            preferenceHelper.saveString(AppConstant.SIM_NUMBER_TWO, simTwo);


        } else {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                simOne = telephonyManager.getSubscriberId();
//
//                return;
//            }
            simOne = telephonyManager.getSubscriberId();
//            if (simOne == null) {
//                if (telephonyInfo.isSIM1Ready()) {
//                    simOne = telephonyInfo.getImsiSIM1();
//                }
//            }
            Log.d(TAG, "storeSimSerial: Sim1 :" + simOne);
            preferenceHelper.saveString(AppConstant.SIM_NUMBER_ONE, simOne);
        }
    }

    /**
     * @return true if SIM card exists
     * false if SIM card is locked or doesn’t exists <br/><br/>
     * <b>Note:</b> This method requires permissions <b> “android.permission.READ_PHONE_STATE” </b>
     */
    public boolean isSimAvailable(Context context) {
        boolean isAvailable = false;
        TelephonyManager telMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        int simState = telMgr.getSimState();
        switch (simState) {
            case TelephonyManager.SIM_STATE_ABSENT: //SimState = “No Sim Found!”;
                break;
            case TelephonyManager.SIM_STATE_NETWORK_LOCKED: //SimState = “Network Locked!”;
                break;
            case TelephonyManager.SIM_STATE_PIN_REQUIRED: //SimState = “PIN Required to access SIM!”;
                break;
            case TelephonyManager.SIM_STATE_PUK_REQUIRED: //SimState = “PUK Required to access SIM!”; // Personal Unblocking Code
                break;
            case TelephonyManager.SIM_STATE_READY:
                isAvailable = true;
                break;
            case TelephonyManager.SIM_STATE_UNKNOWN: //SimState = “Unknown SIM State!”;
                break;
        }
        return isAvailable;
    }

    public boolean isSimAvailable2(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            SubscriptionManager sManager = (SubscriptionManager) context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            SubscriptionInfo infoSim1 = sManager.getActiveSubscriptionInfoForSimSlotIndex(0);
            SubscriptionInfo infoSim2 = sManager.getActiveSubscriptionInfoForSimSlotIndex(1);
            if (infoSim1 != null || infoSim2 != null) {
                return true;
            }
        } else {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (telephonyManager.getSimSerialNumber() != null) {
                return true;
            }
        }
        return false;
    }

    //M E B E
    public boolean isAppExpired(Context context) {
        Log.d(TAG, "isAppExpired: Called");
        PreferenceHelper preferenceHelper = new PreferenceHelper(context);
        long ONE_DAY = 24 * 60 * 60 * 1000;
//      long validityApp = TimeUnit.DAYS.toMillis(preferenceHelper.getInt(AppConstant.VALIDITY_LEFT, 1));
        long before = preferenceHelper.getLong(AppConstant.LOGIN_TIME, 0);
        int validiyAtLogin = preferenceHelper.getInt(AppConstant.VALIDITY_AT_LOGIN, 0);
//        if(Utils.isTimeAutomaticEnabled(context)){
//            long difference = System.currentTimeMillis() - before;
//        }else{
        long difference = System.currentTimeMillis() - before;

//        }
        Log.i(TAG, "isAppExpired: Difference of Time :-> " + String.valueOf(difference));
        long days = (difference / ONE_DAY);
        Log.i(TAG, "isAppExpired: Difference of Days :-> " + days);
        preferenceHelper.saveInt(AppConstant.DAYS_ELAPSED, Integer.parseInt(String.valueOf(days)));
        int daysLeft = preferenceHelper.getInt(AppConstant.DAYS_ELAPSED, 0);
        Log.d(TAG, "Validity DaysLeft:->  " + (validiyAtLogin - days));
        if (days > validiyAtLogin) {
            EventBus.getDefault().post(new ValidityEvent(true, preferenceHelper.getInt(AppConstant.DAYS_ELAPSED, 0)));
            context.startService(new Intent(context, StartupOperations.class));

            showBigNotification("App is Expired", context, null, 101, true, true);
            Log.d(TAG, "isAppExpired: true");
            //Show Expired Fragment Or NotActivated
            preferenceHelper.saveBoolean(AppConstant.IS_LOGIN_PIN_SET, false);
            preferenceHelper.removeKey(AppConstant.LOGIN_PIN_CODE);
            preferenceHelper.setDeviceUnRegistered();
            preferenceHelper.setAppExpired();
            return true;
        } else {
            EventBus.getDefault().post(new ValidityEvent(false, preferenceHelper.getInt(AppConstant.DAYS_ELAPSED, 0)));
            Log.d(TAG, "isAppExpired: false");
            return false;
        }

    }

    public static boolean isTimeAutomaticEnabled(Context c) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return Settings.Global.getInt(c.getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
        } else {
            return android.provider.Settings.System.getInt(c.getContentResolver(), Settings.System.AUTO_TIME, 0) == 1;
        }


    }

    public static void displayWrongDateNotification(final Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Network Time Disabled");
        builder.setMessage("Network date is required for registering with server. Please enable it.");
        builder.setCancelable(false);
        builder.setPositiveButton("Do you like to enable it ?", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                activity.startActivity(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS));
                activity.finish();
//                RegisterUser.getRegisterUser().finish();
            }
        });
        builder.setNegativeButton("Exit App", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                activity.finish();
            }
        });
        builder.show();
    }

    /*
    * This method is used to wrap a activity around a context*/
    public Activity getActivity(Context context) {
        if (context == null) {
            return null;
        } else if (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity) context;
            } else {
                return getActivity(((ContextWrapper) context).getBaseContext());
            }
        }

        return null;
    }

    private boolean isServiceRunning(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if ("com.kochartech.antitheft.xius".equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void showAutoStartDialog(final Activity activity) {
        final PreferenceHelper preferenceHelper = new PreferenceHelper(activity);

        try {
            if (!preferenceHelper.getString("skipMessage", "").equals("checked")) {
                final Intent intent = new Intent();
                final String manufacturer = android.os.Build.MANUFACTURER;

                Log.d(TAG, "openActivity: Autostart");
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                LayoutInflater layoutInflater = LayoutInflater.from(activity);
                View CheckBoxLayout = activity.getLayoutInflater().inflate(R.layout.dialog_autostart_enable, null);
                final CheckBox checkBox = (CheckBox) CheckBoxLayout.findViewById(R.id.checkboxSkip);
                builder.setView(CheckBoxLayout);
                builder.setTitle("Allow Permission");
                builder.setMessage("Please enable autostart permission to allow the app work in background.\nAntitheft will not be able to protect your device without autostart permission.\n\n Ignore if already given");
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String checkBoxResult = "Not Checked";
                        dialog.dismiss();

                        if (checkBox.isChecked()) {
                            checkBoxResult = "checked";
                            preferenceHelper.saveString("skipMessage", checkBoxResult);

                        }

                        if ("xiaomi".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
                        } else if ("oppo".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"));
                            //intent.setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity"));
                        } else if ("vivo".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
                        } else if ("huawei".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"));
                        }
                        List<ResolveInfo> list = activity.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
                        if (list.size() > 0) {
                            activity.startActivity(intent);

                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String checkBoxResult = "Not Checked";
                        if (checkBox.isChecked()) {
                            checkBoxResult = "checked";
                            preferenceHelper.saveString("skipMessage", checkBoxResult);
                        }
                        dialog.dismiss();
                    }
                });
                if (!preferenceHelper.getString("skipMessage", "").equals("checked")) {
                    builder.show();
                }
                //OpenDialog here promt the user to enable the autostart permission in certaim phones

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//    public long getActualTime(){
//        final String TIME_SERVER = "time-a.nist.gov";
//        long currentTime;
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                Looper.prepare();
//                NTPUDPClient timeClient = new NTPUDPClient();
//                InetAddress inetAddress = null;
//                try {
//                    inetAddress = InetAddress.getByName(TIME_SERVER);
//                } catch (UnknownHostException e) {
//                    e.printStackTrace();
//                }
//                TimeInfo timeInfo = null;
//                try {
//                    timeInfo = timeClient.getTime(inetAddress);
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                return timeInfo.getMessage().getReceiveTimeStamp().getTime();
//                Looper.loop();
//            }
//
//        }).start();
//    }
}
