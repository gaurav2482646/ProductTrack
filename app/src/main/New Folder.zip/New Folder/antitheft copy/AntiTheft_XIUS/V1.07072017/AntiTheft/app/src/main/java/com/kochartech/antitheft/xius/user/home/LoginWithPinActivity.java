package com.kochartech.antitheft.xius.user.home;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.camera.OnPictureCapturedListener;
import com.kochartech.antitheft.xius.camera.PictureService;
import com.kochartech.antitheft.xius.util.MailType;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.SendGridMailAsyncTask;
import com.kochartech.antitheft.xius.util.Utils;

import java.util.TreeMap;

public class LoginWithPinActivity extends AppCompatActivity implements OnPictureCapturedListener {
    EditText editTextEnterPin;
    Button buttonSubmitPin;
    PreferenceHelper preferenceHelper;
    private TextView mforgetPinTextview;
    private static final String TAG = "LoginWithPinActivity";
    boolean isAppExpired = false;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferenceHelper = new PreferenceHelper(this);
        setContentView(R.layout.activity_login_with_pin);
        mforgetPinTextview = (TextView) findViewById(R.id.tvForgetPin);
        editTextEnterPin = (EditText) findViewById(R.id.editTextEnterPin);
        buttonSubmitPin = (Button) findViewById(R.id.unlock_pin_button);
        isAppExpired = preferenceHelper.getBoolean(AppConstant.IS_APP_EXPIRED, false);
        buttonSubmitPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.equals(editTextEnterPin.getText(), preferenceHelper.getString(AppConstant.LOGIN_PIN_CODE, ""))) {
                    finish();
                    Intent intent = new Intent(LoginWithPinActivity.this, HomeActivity.class);
                    intent.putExtra(HomeActivity.IS_EXPIRED, isAppExpired);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginWithPinActivity.this, "Incorrect Pin", Toast.LENGTH_SHORT).show();
                    count = count + 1;
                    if (count == 3) {
                        count = 0;
                        Log.d(TAG, "onClick: Start Picture Service");
                        new PictureService().startCapturing(LoginWithPinActivity.this, LoginWithPinActivity.this);

                    }
                }
            }
        });
        mforgetPinTextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ForgetPinDialogFragment forgetPinDialogFragment = ForgetPinDialogFragment.newInstance("", "");
                FragmentManager fragmentManager = getSupportFragmentManager();
                forgetPinDialogFragment.show(fragmentManager, "forget_pin_fragment");
            }
        });
    }

    /*This is the Code For Clicking Picture Incase Of Wrong Login And Then Send It To The Mail Of User
       * */
    @Override
    public void onDoneCapturingAllPhotos(TreeMap<String, byte[]> picturesTaken) {
        if (picturesTaken != null && !picturesTaken.isEmpty()) {
            showToast("Done capturing all photos!");
            //TODO: add the line -- , Environment.getExternalStorageDirectory() + "/1_pic.jpg" below
//            new SendMailAsyncTask().execute(getApplicationContext(),Environment.getExternalStorageDirectory() + "/1_pic.jpg","Sending mail");
            try {
                if (Utils.isNetworkAvailable(LoginWithPinActivity.this)) {
                    Log.d(TAG, "onDoneCapturingAllPhotos: Sending Mail");
                    new SendGridMailAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getApplicationContext(), Environment.getExternalStorageDirectory() + "/1_pic.jpg", MailType.PHOTO);
                } else {
                    Log.d(TAG, "onDoneCapturingAllPhotos: Network Not Available,Mail Not Sent");
                }
            } catch (NullPointerException ex) {
                ex.printStackTrace();
                Log.d(TAG, "onDoneCapturingAllPhotos: " + ex.toString());
            }

            return;
        }
        showToast("No camera detected!");
    }

    @Override
    public void onCaptureDone(final String pictureUrl, final byte[] pictureData) {
        if (pictureData != null && pictureUrl != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    final Bitmap bitmap = BitmapFactory.decodeByteArray(pictureData, 0, pictureData.length);
                    final int nh = (int) (bitmap.getHeight() * (512.0 / bitmap.getWidth()));
                    final Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 512, nh, true);
                    if (pictureUrl.contains("0_pic.jpg")) {
//                    uploadBackPhoto.setImageBitmap(scaled);
                    } else if (pictureUrl.contains("1_pic.jpg")) {
//                    uploadFrontPhoto.setImageBitmap(scaled);
                    }
                }
            });

            showToast("Picture saved to " + pictureUrl);

        }
    }

    /**
     * Shows a {@link Toast} on the UI thread.
     *
     * @param text The message to show
     */

    private void showToast(final String text) {
        runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              Toast.makeText(LoginWithPinActivity.this.getApplicationContext(), text, Toast.LENGTH_SHORT).show();
                          }
                      }
        );
    }


}
