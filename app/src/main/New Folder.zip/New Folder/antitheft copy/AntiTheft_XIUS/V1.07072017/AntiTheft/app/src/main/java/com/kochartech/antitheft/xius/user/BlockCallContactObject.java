package com.kochartech.antitheft.xius.user;

public class BlockCallContactObject {


    private String name;
    private String phone;
    private int isOutgoingBlocked;
    private int isIncomingBlocked;

    public int getIsOutgoingBlocked() {
        return isOutgoingBlocked;
    }

    public void setIsOutgoingBlocked(int isOutgoingBlocked) {
        this.isOutgoingBlocked = isOutgoingBlocked;
    }

    public int getIsIncomingBlocked() {
        return isIncomingBlocked;
    }

    public void setIsIncomingBlocked(int isIncomingBlocked) {
        this.isIncomingBlocked = isIncomingBlocked;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


}
