package com.kochartech.antitheft.xius.dto.eventBus;

/**
 * Created by gauravjeet on 15/12/17.
 */

public class PinSetEvent {
    public final boolean isSet;

    public PinSetEvent(boolean isSet) {
        this.isSet = isSet;
    }
}
