package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 2/11/17.
 */
//Contains Information About The App

public class AppDTO
{
    private String appName;

    private boolean isTrial;

    private String appVersion;

    private int validity;

    public String getAppName ()
    {
        return appName;
    }

    public void setAppName (String appName)
    {
        this.appName = appName;
    }

    public boolean getIsTrial ()
    {
        return isTrial;
    }

    public void setIsTrial (boolean isTrial)
    {
        this.isTrial = isTrial;
    }

    public String getAppVersion ()
    {
        return appVersion;
    }

    public void setAppVersion (String appVersion)
    {
        this.appVersion = appVersion;
    }

    public int getValidity ()
    {
        return validity;
    }

    public void setValidity (int validity)
    {
        this.validity = validity;
    }

    @Override
    public String toString()
    {
        return "AppDTO [appName = "+appName+", isTrial = "+isTrial+", appVersion = "+appVersion+", validity = "+validity+"]";
    }
}