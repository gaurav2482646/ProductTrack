package com.kochartech.antitheft.xius.deviceadmin;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.admin.DevicePolicyManager;

//import android.app.enterprise.EnterpriseDeviceManager;
//import android.app.enterprise.RestrictionPolicy;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.kochartech.antitheft.xius.MainActivity;
import com.kochartech.antitheft.xius.util.Utils;

//import com.kochartech.antitheft.LockActivity;
//import com.kochartech.antitheft.helper.Utils;

/**
 * it lets you control some
 * of its policy and reports when there is interesting activity.
 */
public class KDeviceAdminReceiver extends android.app.admin.DeviceAdminReceiver {
    private static final String TAG = "AdminDevice";
    static Activity activityContext = null;

    void showToast(Context context, CharSequence msg) {
        Toast.makeText(context, "Antitheft Admin: " + msg, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        showToast(context, "enabled");

    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {

        return "Removing Device Admin will compromise your device security.";


    }

    @Override
    public void onDisabled(Context context, Intent intent) {

    }

    @Override
    public void onPasswordChanged(Context context, Intent intent) {
        showToast(context, "pw changed");
    }

    @Override
    public void onPasswordFailed(Context context, Intent intent) {
        showToast(context, "pw failed");
    }

    @Override
    public void onPasswordSucceeded(Context context, Intent intent) {
        showToast(context, "pw succeeded");
    }


    public static class Controller extends Activity {
        static final int REQUEST_CODE_ENABLE_ADMIN = 1;
        static final int REQUEST_CODE_START_ENCRYPTION = 2;
        private static final int REQUEST_CODE_INTERNET = 3;
        public static DevicePolicyManager mDPM;
        public static Controller controller;
        static ActivityManager mAM;
        static ComponentName mDeviceAdminSample;
//        private static EnterpriseDeviceManager mEDM;
        SharedPreferences sharedPreferences = null;
        SharedPreferences.Editor editor = null;

        public static Controller getController() {
            return controller;
        }

        public static void startActivtiy(Context context) {
            //TODO: recheck the flow of the code
            /*SharedPreferences sharedPreferences = null;
            SharedPreferences.Editor editor = null;
            sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            Boolean isRegistered = sharedPreferences.getBoolean(AppConstant.REGISTERED, false);
            if (!isRegistered) {
                Intent intent = new Intent(context, LockActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } else {*/

            Intent intentMmdsStart = new Intent(context, MainActivity.class);
            intentMmdsStart.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intentMmdsStart);
          /*  }*/
        }

        public static boolean isAdminActive(Context context) {
            mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            mAM = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
            if (mDPM != null) {
                return mDPM.isAdminActive(mDeviceAdminSample);
            } else {
                return false;
            }
        }

        public static void toDisableAdmin(Context context) {
            try {

                Log.d(TAG, "inside to disable admin");
                mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                mAM = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
                mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
                if (mDPM != null) {
                    mDPM.removeActiveAdmin(mDeviceAdminSample);
                }

            } catch (Exception e) {
                Log.d(TAG, "error: " + e.getMessage());
                e.printStackTrace();
            }

        }

        public static void applyPolicy(boolean flag, Context context) {
            Intent i = new Intent("com.kochartech.antitheft.SMS_RECEIVED");
            if (isAdminActive(context)) {
                /*mEDM = new EnterpriseDeviceManager(context);
                RestrictionPolicy rp = mEDM.getRestrictionPolicy();
                rp.allowFactoryReset(flag);
                rp.allowPowerOff(flag);
                mEDM.setAdminRemovable(flag);
                Log.d(TAG, "applyPolicy: Applied");
                rp.setUsbDebuggingEnabled(flag);
                rp.allowAirplaneMode(flag);*/

                /*rp.setUsbMassStorage(flag);
                rp.allowUsbHostStorage(flag);
                rp.setSdCardState(flag);*/

               /* rp.setUsbKiesAvailability(flag);
                rp.setUsbMediaPlayerAvailability(flag);*/
                try {
                    context.sendBroadcast(i);
                } catch (Exception e) {
                    Log.e(TAG, "Some error occured");
                }
            } else {
                Log.d(TAG, "admin is disabled");
            }
        }
/*

        void displayConnectToInternetDialog() {
            AlertDialog.Builder builder = new AlertDialog.Builder(Controller.this);
            builder.setTitle("Connection Error");
            builder.setMessage(getString(R.string.no_network_message));
            builder.setCancelable(false);
            builder.setPositiveButton("Do you like to enable it ?", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                    Controller.getController().finish();

                }


            });
            builder.setNegativeButton("Exit App", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    finish();
                }


            });
            builder.create().show();
        }
*/

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            activityContext = this;
            sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            editor = sharedPreferences.edit();

//            mEDM = new EnterpriseDeviceManager(getApplicationContext());

            mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            mAM = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            mDeviceAdminSample = new ComponentName(Controller.this, KDeviceAdminReceiver.class);
            int value = this.getIntent().getIntExtra("value", 0);
            switch (value) {

                case 0:
                    if (!isAdminActive(getApplicationContext())) {
                        Log.d(TAG, "inside the admin activation");
                        if (Utils.isNetworkAvailable(this)) {
                            Log.d(TAG, "onCreate: Not Connected");
                            Toast.makeText(getBaseContext(), "Please Connect To Internet To Activate License", Toast.LENGTH_LONG).show();
//                            displayConnectToInternetDialog();
                            finish();
                        }

                        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mDeviceAdminSample);
                        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Additional text explaining why this needs to be added.");
                        startActivityForResult(intent, REQUEST_CODE_ENABLE_ADMIN);
                    } else {
                        startApplication(getApplicationContext());
//                        finish();
                    }
//					finish();
                    break;
                case 1:
                    mDPM.wipeData(0);
                    finish();
                    break;

                case 2:
                    mDPM.setCameraDisabled(mDeviceAdminSample, true);
                    finish();
                    break;

                case 3:
                    Log.d(TAG, "inside case 3");
                    mDPM.setCameraDisabled(mDeviceAdminSample, false);
                    finish();
                    break;
                case 4:
                    Log.d(TAG, "inside case 4");
                    mDPM.lockNow();
                    finish();
                    break;

                default:
                    break;
            }
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {

            super.onActivityResult(requestCode, resultCode, data);

            try {
                Log.d(TAG, "result code = " + resultCode + "  requestcode: " + requestCode);
                if (resultCode != 0 && requestCode == 1) {
                    Log.d(TAG, "inside if result code is -1");
                    Toast.makeText(getApplicationContext(), "Please Wait..Activating ELM", Toast.LENGTH_LONG).show();

                }
            } catch (Exception e) {
                Log.d(TAG, "Exception: " + e.getMessage());
                e.printStackTrace();
            }
            this.finish();
        }

        private void startApplication(Context context) {

                finish();
                startActivtiy(context);
            }


        }

    }



