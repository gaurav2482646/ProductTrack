package com.kochartech.antitheft.xius.receiver;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.android.internal.telephony.ITelephony;
import com.kochartech.antitheft.xius.MainActivity;

import java.lang.reflect.Method;

public class AppLauncher extends BroadcastReceiver {
    public static final ComponentName LAUNCHER_COMPONENT_NAME =
            new ComponentName("com.kochartech.antitheft.xius", "com.kochartech.antitheft.xius.Launcher");
    String LAUNCHER_NUMBER = "1122";
    ITelephony m_telInterface;
    private static final String TAG = "AppLauncher";
    @Override
    public void onReceive(Context context, Intent intent) {
        String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
        if (LAUNCHER_NUMBER.equals(phoneNumber)) {
            setResultData(null);
            if (isLauncherIconVisible(context)) {
            } else {
                killCall(null);
//                endCall(context);

                Intent openMainActivity = new Intent(context, MainActivity.class);
                openMainActivity.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(openMainActivity);
            }
        }
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
    }

    private boolean isLauncherIconVisible(Context context) {
        int enabledSetting = context.getPackageManager().getComponentEnabledSetting(
                LAUNCHER_COMPONENT_NAME);
        return enabledSetting != PackageManager.COMPONENT_ENABLED_STATE_DISABLED;

    }
    public boolean killCall(String head) {
        try {
            m_telInterface.endCall();
            Log.d(TAG, "killCall() success");
        } catch (Exception ex) { // Many things can go wrong with reflection calls
            Log.e(TAG, "killCall() error: " + ex.toString());
            return false;
        }
        return true;
    }
    public void endCall(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        try {
            Class c = Class.forName(tm.getClass().getName());
            Method m = c.getDeclaredMethod("getITelephony");
            m.setAccessible(true);
            Object telephonyService = m.invoke(tm);

            c = Class.forName(telephonyService.getClass().getName());
            m = c.getDeclaredMethod("endCall");
            m.setAccessible(true);
            m.invoke(telephonyService);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
