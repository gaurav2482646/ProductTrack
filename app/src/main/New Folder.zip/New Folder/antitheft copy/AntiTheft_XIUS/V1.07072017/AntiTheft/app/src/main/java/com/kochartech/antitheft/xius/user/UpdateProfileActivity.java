package com.kochartech.antitheft.xius.user;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.dto.UserDTO;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UpdateProfileActivity extends AppCompatActivity {
    EditText etFullName, etMobileNo, etAlternateMobileNo;
    Button btnUpdateDetails;
    private static final String TAG = "UpdateProfileActivity";
    PreferenceHelper preferenceHelper;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);
        preferenceHelper = new PreferenceHelper(this);
        etFullName = (EditText) findViewById(R.id.etFullName);
        etMobileNo = (EditText) findViewById(R.id.etMobileNumber);
        etAlternateMobileNo = (EditText) findViewById(R.id.etAlternateNumber);
        btnUpdateDetails = (Button) findViewById(R.id.btnUpdateUserDetails);
        progressBar = (ProgressBar) findViewById(R.id.update_profile_progress);

        etFullName.setText(preferenceHelper.getString(AppConstant.USER_NAME,""));
        etMobileNo.setText(preferenceHelper.getString(AppConstant.PHONE_NUMBER, ""));
        etAlternateMobileNo.setText(preferenceHelper.getString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE,""));
        btnUpdateDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mEditUserDetails(v);
            }
        });
    }

    //Check validation while editing details
    private void mEditUserDetails(View v) {

        if (etFullName.getText().toString().trim().length() == 0) {
            Toast.makeText(v.getContext(), "Please Enter First Name", Toast.LENGTH_SHORT).show();
            etFullName.requestFocus();

        } else if (!isValidMobileNumber(etMobileNo.getText().toString())) {
            etMobileNo.requestFocus();
            // mResetFields();
        } else if (etAlternateMobileNo.getText().toString().length() == 0) {
            etAlternateMobileNo.requestFocus();
            Toast.makeText(v.getContext(), "Please enter alternative number", Toast.LENGTH_SHORT).show();
            // mResetFields();
        } else if (etAlternateMobileNo.getText().toString().length() < 10) {
            etAlternateMobileNo.requestFocus();
            Toast.makeText(v.getContext(), "Please enter valid alternative number", Toast.LENGTH_SHORT).show();
            // mResetFields();
        } /*else if (!etAlternateMobileNo.getText().toString().trim().startsWith("+")) {
            etAlternateMobileNo.requestFocus();
            Toast.makeText(v.getContext(), "Please add country code along with alternate mobile number eg +91 ", Toast.LENGTH_SHORT).show();

        } */ else if (etAlternateMobileNo.getText().toString().equals(etMobileNo.getText().toString())) {
            etAlternateMobileNo.requestFocus();
            Toast.makeText(v.getContext(), "Mobile Number And Alternate Number Must be Different", Toast.LENGTH_SHORT).show();
            // mResetFields();
        } else {
            Utils.isKeyBoardShow(UpdateProfileActivity.this);

            progressBar.setVisibility(View.VISIBLE);
            volleyUpdateProfileRequest();
        }

    }

    public void volleyUpdateProfileRequest() {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();


        try {
            Log.d(TAG, "volleyUpdateProfileRequest: " + getUserDTO().toString());
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    AppConstant.UPDATE_PROFILE, getUserDTO(),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject jsonObject) {
                            Log.d(TAG, jsonObject.toString());
                            mRequestQueue.stop();
                            try {
                                Log.d(TAG, "onResponse: " + jsonObject.toString());
                                if (jsonObject.getString("code").equals("0")) {
                                    Toast.makeText(UpdateProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                                    preferenceHelper.saveString(AppConstant.USER_NAME, etFullName.getText().toString());
                                    preferenceHelper.saveString(AppConstant.PHONE_NUMBER, etMobileNo.getText().toString());
                                    preferenceHelper.saveString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, etAlternateMobileNo.getText().toString());
//                                    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(UpdateProfileActivity.this);
//                                    SharedPreferences.Editor editor = sharedPreferences.edit();
//                                    editor.putBoolean(AppConstant.IS_USER_REGISTERED, true);
//                                    editor.apply();
//
//                                showProgress(false);
                                    progressBar.setVisibility(View.INVISIBLE);


                                } else {
                                    progressBar.setVisibility(View.INVISIBLE);
                                    Toast.makeText(UpdateProfileActivity.this, "Failed to update profile", Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                progressBar.setVisibility(View.INVISIBLE);

                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.d(TAG, "Error: " + error.getMessage());
                    Log.d(TAG, "onErrorResponse: " + error.getMessage());
                    progressBar.setVisibility(View.INVISIBLE);

                    Toast.makeText(UpdateProfileActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(UpdateProfileActivity.this, "Internet is not working", Toast.LENGTH_SHORT).show();
                    mRequestQueue.stop();
                }
            }) {


                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }


            };
            mRequestQueue.add(jsonObjReq);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private JSONObject getUserDTO() throws PackageManager.NameNotFoundException, JSONException {
        UserDTO userDTO = new UserDTO();
        userDTO.setName(etFullName.getText().toString());
        userDTO.setAlternateNumber(etAlternateMobileNo.getText().toString());
        userDTO.setMobileNumber(etMobileNo.getText().toString());
        userDTO.setUserID(preferenceHelper.getInt(AppConstant.USER_ID, 0));

        Gson gson = new Gson();
        return new JSONObject(gson.toJson(userDTO));
    }

//    check mobile number validations

    private boolean isValidMobileNumber(String mobileNumber) {
        if (mobileNumber.length() == 0) {
            Toast.makeText(this, "Please enter mobile number", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (mobileNumber.length() < 10) {
            Toast.makeText(this, "Mobile number must be 10 digits long", Toast.LENGTH_SHORT).show();

            return false;
        }
       /* if (!mobileNumber.startsWith("+")) {
            Toast.makeText(this, "Please add country code along with mobile number eg +91 ", Toast.LENGTH_SHORT).show();

            return false;
        }*/

        return true;
    }
}
