package com.kochartech.antitheft.xius.util;

import android.content.Context;
import android.os.Build;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.List;


public class DualSimInfo {
    private static final String TAG = "Dual Sim";
    private Context context;

    public DualSimInfo(Context context) {
        this.context = context;
    }

    public boolean isDualSim() {
        boolean isDualSim = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                isDualSim = getDualSimStatus(context) > 1 ? true : false;
                Log.e("Dual Sim ","Is Dual Sim "+  isDualSim);

            }catch (Exception e){
                Log.e("Dual Sim ","ex "+ e.toString());

            }
        }
        return isDualSim;
    }

    public boolean isVolteEnabled() {
        Object tm = context.getSystemService(Context.TELEPHONY_SERVICE);
        Method method_getDefaultSim;
        boolean isEnabled = false;
        try {
            method_getDefaultSim = tm.getClass().getDeclaredMethod(
                    "isVolteEnabled");
            method_getDefaultSim.setAccessible(true);
            isEnabled = (Boolean) method_getDefaultSim.invoke(tm);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                method_getDefaultSim = tm.getClass().getDeclaredMethod(
                        "isVolteAvailable");
                method_getDefaultSim.setAccessible(true);
                isEnabled = (Boolean) method_getDefaultSim.invoke(tm);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        return isEnabled;
    }

    public boolean isWifiCallingEnabled() {
        Object tm = context.getSystemService(Context.TELEPHONY_SERVICE);
        Method method_getDefaultSim;
        boolean isEnabled = false;
        try {

            method_getDefaultSim = tm.getClass().getDeclaredMethod(
                    "isWifiCallingEnabled");
            method_getDefaultSim.setAccessible(true);
            isEnabled = (Boolean) method_getDefaultSim.invoke(tm);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                method_getDefaultSim = tm.getClass().getDeclaredMethod(
                        "isWifiCallingAvailable");
                method_getDefaultSim.setAccessible(true);
                isEnabled = (Boolean) method_getDefaultSim.invoke(tm);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        return isEnabled;
    }

    public int getDualSimStatus(Context context) {

        Object tm = context.getSystemService(Context.TELEPHONY_SERVICE);
        Method method_getDefaultSim;
        int dualSim = -1;
        try {
            method_getDefaultSim = tm.getClass().getDeclaredMethod(
                    "getPhoneCount");
            method_getDefaultSim.setAccessible(true);
            dualSim = (Integer) method_getDefaultSim.invoke(tm);
            Log.i("Dual Sim ","Dual Sim value "+  dualSim);
        } catch (Exception e) {
            Log.e("Dual Sim "," ex Dual Sim "+  e.toString());

            e.printStackTrace();
        }

        return dualSim;
    }

    public int getDefaultSimmm() {

        Object tm = context.getSystemService(Context.TELEPHONY_SERVICE);
        Method method_getDefaultSim;
        int defaultSimm = -1;
        try {
            method_getDefaultSim = tm.getClass().getDeclaredMethod(
                    "getDefaultSim");
            method_getDefaultSim.setAccessible(true);
            defaultSimm = (Integer) method_getDefaultSim.invoke(tm);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultSimm;
    }


    public String getIMSI(int simSlotIndex) {
        try {
            int subscriptionId = SubscriptionManager.from(context)
                    .getActiveSubscriptionInfoForSimSlotIndex(simSlotIndex)
                    .getSubscriptionId();
            String imsi = "NA";

            imsi = getOutput(context, "getSubscriberId", subscriptionId);


        if (imsi.equals(""))
            imsi = "NA";
        return imsi;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /*
    * *
    * */
    public String getIMEI(int simSlotIndex) {
        String imei = "NA";
        try {
            imei = getOutput(context, "getImei", simSlotIndex);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imei;
    }

    public String getCarrierName(int simSlotIndex) {
        String operatorName = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                final List<SubscriptionInfo> subscriptionInfos = SubscriptionManager
                        .from(context).getActiveSubscriptionInfoList();

                operatorName = subscriptionInfos.get(simSlotIndex).getCarrierName()
                        .toString();

            }
        } catch (Exception e) {
            Log.e(TAG, "SubscriptionManagergetCarrierNameExc: " + e.toString());
        }
        if (operatorName == null || operatorName.equals(""))
            operatorName = getOutput(context,
                    "getSimOperatorNameForSubscription", simSlotIndex);
        if (operatorName == null || operatorName.equals(""))
            operatorName = getOutput(context, "getSimOperator", simSlotIndex);
        if (operatorName == null || operatorName.equals(""))
            operatorName = getOutput(context, "getCarrierName", simSlotIndex);
        if (operatorName == null || operatorName.equals(""))
            operatorName = getOutput(context, "getCarrierNameGemni",
                    simSlotIndex);
        if (operatorName == null || operatorName.equals(""))
            operatorName = getOutput(context, "SimOperatorName", simSlotIndex);
        if (operatorName == null || operatorName.equals(""))
            operatorName = getOutput(context, "getSimOperatorName",
                    simSlotIndex);
        if (operatorName == null || operatorName.equals(""))
            operatorName = getOutput(context, "getSimOperatorNameForPhone",
                    simSlotIndex);
        return operatorName;
    }





    private String getOutput(Context context, String methodName, int slotId) {
        TelephonyManager telephony = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        Class<?> telephonyClass;
        String reflectionMethod = null;
        String output = null;
        try {
            telephonyClass = Class.forName(telephony.getClass().getName());
            for (Method method : telephonyClass.getMethods()) {
                String name = method.getName();
                if (name.contains(methodName)) {
                    Class<?>[] params = method.getParameterTypes();
                    if (params.length == 1 && params[0].getName().equals("int")) {
                        reflectionMethod = name;
                    }
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if (reflectionMethod != null) {
            try {
                output = getOpByReflection(telephony, reflectionMethod, slotId,
                        false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return output;
    }

    public String getImsi()
    {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager.getSubscriberId();
    }

    private String getOpByReflection(TelephonyManager telephony,
                                     String predictedMethodName, int slotID, boolean isPrivate) {

        // Log.i("Reflection", "Method: " + predictedMethodName+" "+slotID);
        String result = null;

        try {

            Class<?> telephonyClass = Class.forName(telephony.getClass()
                    .getName());

            Class<?>[] parameter = new Class[1];
            parameter[0] = int.class;
            Method getSimID;
            if (slotID != -1) {
                if (isPrivate) {
                    getSimID = telephonyClass.getDeclaredMethod(
                            predictedMethodName, parameter);
                } else {
                    getSimID = telephonyClass.getMethod(predictedMethodName,
                            parameter);
                }
            } else {
                if (isPrivate) {
                    getSimID = telephonyClass
                            .getDeclaredMethod(predictedMethodName);
                } else {
                    getSimID = telephonyClass.getMethod(predictedMethodName);
                }
            }

            Object ob_phone;
            Object[] obParameter = new Object[1];
            obParameter[0] = slotID;
            if (getSimID != null) {
                if (slotID != -1) {
                    ob_phone = getSimID.invoke(telephony, obParameter);
                } else {
                    ob_phone = getSimID.invoke(telephony);
                }

                if (ob_phone != null) {
                    result = ob_phone.toString();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return result;
    }

}
