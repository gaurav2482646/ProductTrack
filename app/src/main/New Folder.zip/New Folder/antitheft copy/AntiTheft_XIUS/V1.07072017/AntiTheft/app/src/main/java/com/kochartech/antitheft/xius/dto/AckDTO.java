package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 18/8/17.
 */
//location_json object
public class AckDTO {

    private boolean Status;

    private String Description;

    private String MessageCommandId;

    public boolean getStatus() {
        return Status;
    }

    public void setStatus(boolean Status) {
        this.Status = Status;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getMessageCommandId() {
        return MessageCommandId;
    }

    public void setMessageCommandId(String MessageCommandId) {
        this.MessageCommandId = MessageCommandId;
    }

    @Override
    public String toString() {
        return "AckDTO [Status = " + Status + ", Description = " + Description + ", MessageCommandId = " + MessageCommandId + "]";
    }
}