package com.kochartech.antitheft.xius;

/**
 * Created by gaurav on 17/7/17.
 */

public class AppConstant {

    public static final String IS_USER_REGISTERED = "is_user_registered";
    public static final String USER_REGISTRATION_URL_LOCAL = "http://172.17.103.82/Antitheftservice/Service1.svc/AntiTheftServiceClientRest/ActivateUserfromMobileApplication";

    public static final String USER_REGISTRATION_URL_OLD = "http://gizmocontrol.com/AntitheftRegistrationService/Service1.svc/AntiTheftServiceClientRest/ActivateUserfromMobileApplication";
    public static final String DEVICE_REGISTRATION_LOCAL = "http://172.17.103.82/Antitheftservice/Service1.svc/AntiTheftServiceClientRest/DeviceRegistration";
    public static final String DEVICE_REGISTRATION_URL_OLD = " http://202.164.36.66/AntitheftRegistrationservice/Service1.svc/AntiTheftServiceClientRest/DeviceRegistration";
    public static final String DEVICE_REGISTRATION_URL = "http://gizmocontrol.com/AntitheftRegistrationService/Service1.svc/AntiTheftServiceClientRest/DeviceRegistration";
    public static final String FORGET_PASSWORD_URL = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/ForgotPassword";
    public static final String UPDATE_VALIDITY = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/UpdateValidity";
    public static final String ADD_NEW_DEVICE_URL = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/AddNewDevice";
    public static final String UPDATE_PASSWORD_URL = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/UpdatePassword";
    public static final String USER_REGISTRATION_URL_MOBILE = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/RegistrationMobileApplication";
    public static final String UPDATE_PROFILE = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/UpdateProfile";
    public static final String UPDATE_DEVICE_REGISTRATION_LOCAL = "http://172.17.103.82/AntitheftService/Service1.svc/AntiTheftServiceClientRest/UpdateRegistrationID";
    public static final String UPDATE_DEVICE_REGISTRATION_ID_OLD = " http://202.164.36.66/AntitheftRegistrationservice/Service1.svc/AntiTheftServiceClientRest/UpdateRegistrationID";
    //    public static final String UPDATE_DEVICE_REGISTRATION_ID = "http://gizmocontrol.com/AntitheftRegistrationService/Service1.svc/AntiTheftServiceClientRest/UpdateRegistrationID";
    public static final String UPDATE_DEVICE_REGISTRATION_ID = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/UpdateRegistrationID";
    public static final String ACK_URL_LOCAL = "http://172.17.103.17/antitheftwebservice/AntitheftService.svc/webclient/device/commandacknowledge";
    public static final String ACK_URL_OLD = "http://202.164.36.66/antitheftwebservice/AntitheftService.svc/webclient/device/commandacknowledge";
    public static final String ACK_URL = " http://gizmocontrol.com/antitheftwebservice/antitheftservice.svc/webclient/device/commandacknowledge";
    public static final String LOC_URL_LOCAL = " http://172.17.103.17/antitheftwebservice/AntitheftService.svc/webclient/device/pushresponse/location";
    public static final String LOC_URL_OLD = " http://202.164.36.66/antitheftwebservice/AntitheftService.svc/webclient/device/pushresponse/location";
    public static final String LOC_URL = "http://gizmocontrol.com/antitheftwebservice/antitheftservice.svc/webclient/device/pushresponse/location";
    public static final String GET_EXISTING_DEVICE_URL = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/GetExistingDevice";
    public static final String LOGIN_URL = "http://gizmocontrol.com/AntitheftRegService/Service1.svc/AntiTheftServiceClientRest/ValidateLoginfromMobileApp";

    public static final String[] REQUIRED_PERMISSIONS =
            {android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECEIVE_SMS,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    android.Manifest.permission.READ_PHONE_STATE,
                    android.Manifest.permission.RECORD_AUDIO};
    public static final String USER_ID = "userID";
    public static final String SCHEDULE_SET = "schedule_set";
    public static final String TOKEN = "token";
    public static final String BRAND = "brand";
    public static final String IMEI = "imei";
    public static final String INSTALL_DATE = "installDate";
    public static final String MAC_ADDRESS = "macAddress";
    public static final String MODEL = "model";
    public static final String REGISTRATION_ID_FCM = "registrationId";
    public static final String SIM_NUMBER_ONE = "simNumberOne";
    public static final String SIM_NUMBER_TWO = "simNumberTwo";
    public static final String SCREEN_LOCK_FLAG = "screenLockFlag";
    public static final String USER_EMAIL = "userEmail";
    public static final String FCM_MESSAGE = "fcmMessage";
    public static final String LOCATION_TRACKING = "location_tracking";
    public static final String LOCATION_TRACKING_INTERVAL = "locationTrackingInterval";
    public static final String PREMIUM_NUMBER = "+919780898201";
    public static final String ALARM_RUN_STATUS = "alarmRunStatus";
    public static final int REQUEST_CODE = 101;
    public static final String IS_OVERLAY_PERMISSION_GRANTED = "isGranted";
    public static final String PASSWORD = "password";
    public static final String IS_DIALOG_PERMISSION_RATIONALE_SHOWN = "isDialogShown";
    public static final String IS_HIDE_APP_ALERT_SHOWN = "hideAppAlert";
    public static final String ALTERNATE_PHONE_NUMBER_ONE = "alternateNumberOne";
    public static final String ALTERNATE_PHONE_NUMBER_TWO = "alternateNumberTwo";
    public static final String APP_VERSION = "appVersion";
    public static final String APP_NAME = "appName";
    public static final String SCREEN_ON_STATUS = "screenOnStatus";
    public static final String ELM_LICENSE_STATUS = "elmLicenseStatus";
    //Broadcast Receiver Action
    public static final String LOCAL_ELM_RECEIVER_ACTION = "com.kochartech.antitheft.xius.localelm";
    public static final String LOCAL_ELM_RECEIVER_ACTION1 = "com.kochartech.antitheft.xius.localelm";
    public static final String LOCAL_ELM_RECEIVER_EXTRA_BOOLEAN = "isElmActivated";

    public static final String USER_NAME ="userName" ;
    public static final String PHONE_NUMBER ="phoneNumber" ;
    public static final String IS_DEVICE_ACTIVATED = "isDeviceActivated";
    public static final String IS_TRIAL = "isTrial";
    public static final String VALIDITY_AT_LOGIN = "validity";
    public static final String IS_LOGIN_PIN_SET = "isLoginPinSet";
    public static final String IS_LOGGED_IN = "isLoggedIn" ;
    public static final String LOGIN_PIN_CODE = "loginPinCode";
    public static final String BILLING_PURCHASE_TOKEN = "billingPurchaseToken";
    public static final String VALIDITY_LEFT = "validityLeft";
    public static final String LOGIN_TIME = "loginDate";
    public static final String DAYS_ELAPSED = "loginDateDays";
    public static final String IS_APP_EXPIRED = "isAppExpired";
    public static final String IS_CALL_RECORDING_ENABLED = "isCallRecordingEnabled";
    public static final String MANUFACTURER_PHONE = "manufacturerPhone";
    public static final String IS_APP_FIRST_RUN = "isAppFirstRun";
    public static boolean WIPE_RECEIVED;
    public static final String IS_APP_HIDE_ENABLED = "isAppHideEnabled";
}
