//package com.kochartech.antitheft.xius.receiver;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.util.Log;
//
//public class NetworkChangeReceiver extends BroadcastReceiver {
//    private static final String TAG = "NetworkChangeReceiver";
//    @Override
//    public void onReceive(Context context, Intent intent) {
//        // TODO: This method is called when the BroadcastReceiver is receiving
//        // an Intent broadcast.
//        Log.d(TAG, "onReceive: Network Has Been Changed");
//    }
//}
