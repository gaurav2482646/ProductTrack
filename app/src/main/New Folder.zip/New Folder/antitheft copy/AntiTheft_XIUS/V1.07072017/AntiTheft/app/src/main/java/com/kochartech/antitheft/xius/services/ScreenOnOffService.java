package com.kochartech.antitheft.xius.services;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.util.Log;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.receiver.ScreenOnOffReceiver;
import com.kochartech.antitheft.xius.util.PreferenceHelper;

public class ScreenOnOffService extends Service {
    BroadcastReceiver mBroadcastReceiver = null;
    SharedPreferences sharedPreferences = null;
    SharedPreferences.Editor editor = null;
    private static final String TAG = "ScreenOnOffService";
    public ScreenOnOffService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_SCREEN_ON);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        mBroadcastReceiver = new ScreenOnOffReceiver();
        registerReceiver(mBroadcastReceiver,intentFilter);
        sharedPreferences = PreferenceHelper.getSharedPreference();
        editor = PreferenceHelper.getSharedPreferenceEditor();
        Log.d(TAG, "onCreate: Service Created");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        boolean isScreenOn = intent.getBooleanExtra(AppConstant.SCREEN_ON_STATUS,false);
        editor.putBoolean(AppConstant.SCREEN_ON_STATUS,isScreenOn);
        editor.apply();
        Log.d(TAG, "Screen On Status "+isScreenOn);
        return START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(mBroadcastReceiver!=null){
            unregisterReceiver(mBroadcastReceiver);
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Log.d(TAG, "onTaskRemoved: Task is removed");
        onStartCommand(rootIntent,Service.START_FLAG_REDELIVERY,0);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
