package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 17/8/17.
 */

public class CommandDTO {

        private String Params;

        public String getParams() { return this.Params; }

        public void setParams(String Params) { this.Params = Params; }

        private String CommandKey;

        public String getCommandKey() { return this.CommandKey; }

        public void setCommandKey(String CommandKey) { this.CommandKey = CommandKey; }

        private String MAC;

        public String getMAC() { return this.MAC; }

        public void setMAC(String MAC) { this.MAC = MAC; }

        private String MessageCommandId;

        public String getMessageCommandId() { return this.MessageCommandId; }

        public void setMessageCommandId(String MessageCommandId) { this.MessageCommandId = MessageCommandId; }
    }

