package com.kochartech.antitheft.xius.user;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.util.DualSimInfo;
import com.kochartech.antitheft.xius.util.Utils;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.yanzhenjie.alertdialog.AlertDialog;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;
import com.yanzhenjie.permission.Rationale;
import com.yanzhenjie.permission.RationaleListener;

import java.util.List;

public class LoginOrRegisterActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_DEVICE_ADMIN = 200;
    private static final String RESPONSE_MESSAGE = "message";
    private static final int REQUEST_PREM = 400;
    private static final int DENIED_PERMISSION_ACTIVITY_CODE = 300;
    boolean isdialogPermissionRationaleShown;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private DualSimInfo dualSimInfo;
    private PermissionListener permissionListener = new PermissionListener() {
        @Override
        public void onSucceed(int i, @NonNull List<String> list) {
            switch (i) {
                case REQUEST_PREM: {
                    if (dualSimInfo.getImsi() != null) {


                        break;
                    } else {
                        dialogSimNotAvailabe();
                    }
                }
            }
        }

        @Override
        public void onFailed(int i, @NonNull List<String> list) {
            switch (i) {
                case REQUEST_PREM: {
                    Toast.makeText(LoginOrRegisterActivity.this, "Permissions required to continue !", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
            if (AndPermission.hasAlwaysDeniedPermission(LoginOrRegisterActivity.this, list)) {
                AndPermission.defaultSettingDialog(LoginOrRegisterActivity.this, DENIED_PERMISSION_ACTIVITY_CODE)
                        .setTitle("Permissions Disabled")
                        .setMessage("Please go to App Settings to Enable the Permissions Manually")
                        .setPositiveButton("Ok")
                        .setNegativeButton("NO",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                        .show();

            }
        }
    };
    private RationaleListener rationaleListener = new RationaleListener() {
        @Override
        public void showRequestPermissionRationale(int requestCode, final Rationale rationale) {
            AlertDialog.newBuilder(LoginOrRegisterActivity.this)
                    .setTitle("Permissions Required !")
                    .setMessage("Please enable all the permissions")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            rationale.resume();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            rationale.cancel();
                        }
                    }).show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = PreferenceHelper.getSharedPreference();
        editor = PreferenceHelper.getSharedPreferenceEditor();
        setContentView(R.layout.activity_login_or_register);
        dualSimInfo = new DualSimInfo(this);
        //hello

    }

    public void onButtonClick(View view) {
        if (AndPermission.hasPermission(this, AppConstant.REQUIRED_PERMISSIONS)) {


            switch (view.getTag().toString()) {
                case "login":
                    if (dualSimInfo.getImsi() != null) {

                        Intent intent1 = new Intent(this, LoginActivity.class);
                        startActivity(intent1);
                        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                    } else {
                        dialogSimNotAvailabe();
                    }
                    break;
                case "register":
                    if (dualSimInfo.getImsi() != null) {
                        Intent intent2 = new Intent(this, RegistrationActivity.class);
                        startActivity(intent2);
                        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                    } else {
                        dialogSimNotAvailabe();
                    }
                    break;
            }

        } else {
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
                if (!isdialogPermissionRationaleShown) {
                    dialogPermissionRationale();
                } else {
                    AndPermission.with(LoginOrRegisterActivity.this)
                            .requestCode(REQUEST_PREM)
                            .permission(AppConstant.REQUIRED_PERMISSIONS)
                            .callback(permissionListener)
                            .rationale(rationaleListener)
                            .start();
                }
            } else {
                if (Utils.isNetworkAvailable(LoginOrRegisterActivity.this)) {
                } else {
                    showToast(getString(R.string.check_internet));
                }

            }
        }
    }

    void dialogSimNotAvailabe() {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage(R.string.insert_sim)
                .setCancelable(false)
                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("Insert Sim");
        alert.show();
    }

    void dialogPermissionRationale() {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);
        //Setting message manually and performing action on button click
        builder.setMessage("Certain permissions are needed to continue.")
                .setCancelable(false)
                .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        isdialogPermissionRationaleShown = true;
                        editor.putBoolean(AppConstant.IS_DIALOG_PERMISSION_RATIONALE_SHOWN, true);
                        editor.apply();
                        AndPermission.with(LoginOrRegisterActivity.this)
                                .requestCode(REQUEST_PREM)
                                .permission(AppConstant.REQUIRED_PERMISSIONS)
                                .callback(permissionListener)
                                .rationale(rationaleListener)
                                .start();

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.cancel();
                    }
                });

        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("AntiTheft Alert");
        alert.show();
    }

    private void showToast(final String text) {
        runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              Toast.makeText(LoginOrRegisterActivity.this.getApplicationContext(), text, Toast.LENGTH_SHORT).show();
                          }
                      }
        );
    }

}
