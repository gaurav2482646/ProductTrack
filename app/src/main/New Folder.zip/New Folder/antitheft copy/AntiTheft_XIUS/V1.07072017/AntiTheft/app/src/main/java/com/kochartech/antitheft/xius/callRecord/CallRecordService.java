package com.kochartech.antitheft.xius.callRecord;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.kochartech.antitheft.xius.util.MailType;
import com.kochartech.antitheft.xius.util.SendGridMailAsyncTask;
import com.kochartech.antitheft.xius.util.Utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;

/**
 * Created by gauravjeet on 9/8/17.
 */

//Call the Service Using startService(name of service)
//Used for recording Outgoing and incoming calls

public class CallRecordService extends Service {
    private static final String TAG = "CallRecordService";
    private static final String ACTION_IN = "android.intent.action.PHONE_STATE";
    private static final String ACTION_OUT = "android.intent.action.NEW_OUTGOING_CALL";
    public String Audio_Type;
    MediaRecorder recorder;
    File audiofile;
    String name, phonenumber;
    String audio_format;
    int audioSource;
    Context context;
    Timer timer;
    Boolean offHook = false, ringing = false;
    Toast toast;
    Boolean isOffHook = false;
    private Handler handler;
    private boolean recordstarted = false;
    private CallBroadcastReceiver callBroadcastReceiver;


    @Override
    public IBinder onBind(Intent arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        Log.d("service", "destroy");
        this.unregisterReceiver(this.callBroadcastReceiver);

        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: Service Started");
        final IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_OUT);
        filter.addAction(ACTION_IN);
        this.callBroadcastReceiver = new CallBroadcastReceiver();
        this.registerReceiver(this.callBroadcastReceiver, filter);

        return START_STICKY;
    }

    private void startRecord(String seed) {
        String out = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss").format(new Date());
        File sampleDir = new File(Environment.getExternalStorageDirectory(), "/RecAT");
        if (!sampleDir.exists()) {
            sampleDir.mkdirs();
        }
        String file_name = "Record" + seed;
        try {
            audiofile = File.createTempFile(file_name, ".amr", sampleDir);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String path = Environment.getExternalStorageDirectory().getAbsolutePath();

        recorder = new MediaRecorder();

        recorder.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        recorder.setOutputFile(audiofile.getAbsolutePath());
        try {
            recorder.prepare();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            recorder.start();
            recordstarted = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class CallBroadcastReceiver extends BroadcastReceiver {
        public boolean wasRinging = false;
        Bundle bundle;
        String state;
        String inCall, outCall;
        private boolean answered = false;

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "onReceive: Call Receiver Started !");
            if (intent.getAction().equals(ACTION_IN)) {
                if ((bundle = intent.getExtras()) != null) {
                    state = bundle.getString(TelephonyManager.EXTRA_STATE);
                    if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                        Log.d(TAG, "onReceive: Ringing");
                        inCall = bundle.getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                        wasRinging = true;
                        Toast.makeText(context, "IN : " + inCall, Toast.LENGTH_LONG).show();
                    } else if (state.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                        if (wasRinging) {
                            Log.d(TAG, "onReceive: answer");
                            Toast.makeText(context, "ANSWERED", Toast.LENGTH_LONG).show();
                            answered = true;
                            String out = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss").format(new Date());
                            File sampleDir = new File(Environment.getExternalStorageDirectory(), "/ATCalls");
                            if (!sampleDir.exists()) {
                                sampleDir.mkdirs();
                            }
                            String file_name = "Record";
                            try {
                                audiofile = File.createTempFile(file_name, ".amr", sampleDir);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            String path = Environment.getExternalStorageDirectory().getAbsolutePath();

                            recorder = new MediaRecorder();
//                          recorder.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);

                            recorder.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
                            recorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
                            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                            recorder.setOutputFile(audiofile.getAbsolutePath());
                            try {
                                recorder.prepare();
                            } catch (IllegalStateException e) {
                                e.printStackTrace();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            recorder.start();
                            recordstarted = true;
                        }
                    } else if (state.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                        wasRinging = false;
                        Log.d(TAG, "onReceive: reject");
                        Toast.makeText(context, "REJECT || DISCO", Toast.LENGTH_LONG).show();

                        if (recordstarted) {
                            recorder.stop();
                            recordstarted = false;
                        }
                        if (Utils.isNetworkAvailable(context) && answered) {
                            Log.d(TAG, "CallBroadcastReceiver: Sending Mail");
                            try {
                                new SendGridMailAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getApplicationContext(), audiofile.getAbsolutePath(), MailType.CALL_RECORDING);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
//            } else if (intent.getAction().equals(ACTION_OUT)) {
//                if ((bundle = intent.getExtras()) != null) {
//                    outCall = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
//                    Toast.makeText(context, "OUT : " + outCall, Toast.LENGTH_LONG).show();
//                }
            } else if (intent.getAction().equals(ACTION_OUT)) {
                if ((bundle = intent.getExtras()) != null && !intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER).equals("1122")) {
                    outCall = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
                    Log.d(TAG, "onReceive: OutGoing Call");
                    Toast.makeText(context, "OUT : " + outCall, Toast.LENGTH_LONG).show();
                    startRecord("outgoing");
                    if ((bundle = intent.getExtras()) != null) {
                        state = bundle.getString(TelephonyManager.EXTRA_STATE);
                        if (state != null) {
                            if (state.equals(TelephonyManager.EXTRA_STATE_IDLE) && !outCall.equals("1122")) {
                                wasRinging = false;
                                Log.d(TAG, "onReceive: Call Close");
                                Toast.makeText(context, "REJECT || DISCO", Toast.LENGTH_LONG).show();

                                if (recordstarted) {
                                    recorder.stop();
                                    recordstarted = false;
                                }
                                if (Utils.isNetworkAvailable(context)) {
                                    Log.d(TAG, "CallBroadcastReceiver: Sending Mail");
                                    try {
                                        new SendGridMailAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getApplicationContext(), audiofile.getAbsolutePath(), MailType.CALL_RECORDING);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
