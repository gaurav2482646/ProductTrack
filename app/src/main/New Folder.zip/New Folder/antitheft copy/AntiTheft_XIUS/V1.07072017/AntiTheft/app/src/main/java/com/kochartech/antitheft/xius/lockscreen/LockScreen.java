package com.kochartech.antitheft.xius.lockscreen;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.PixelFormat;
import android.os.PowerManager;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.camera.OnPictureCapturedListener;
import com.kochartech.antitheft.xius.camera.PictureService;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.SamsungKNOX;
import com.kochartech.antitheft.xius.util.Utils;

import java.util.TreeMap;

public class LockScreen extends ContextThemeWrapper implements View.OnClickListener, OnPictureCapturedListener {

    private static boolean showing;
    private static LockScreen lockScreen;
    SharedPreferences sharedPreferences = PreferenceHelper.getSharedPreference();
    SharedPreferences.Editor editor = PreferenceHelper.getSharedPreferenceEditor();
    int count;
    private static final String TAG = "LockScreen";
    private View lockView;
    private EditText editTextPassword;
    private TextView textViewWrongPassword;

    public LockScreen(int theme) {
        super(ApplicationManager.getAppContext(), theme);

        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.layout_lock_screen, new FrameLayout(this), false);
        view.findViewById(R.id.buttonUnlock).setOnClickListener(this);
        editTextPassword = (EditText) view.findViewById(R.id.editTextPassword);
        textViewWrongPassword = (TextView) view.findViewById(R.id.textView_wrong_password);
        this.lockView = view;
    }

    public static LockScreen getInstance(int theme) {

        if (lockScreen == null) {
            lockScreen = new LockScreen(theme);
        }

        return lockScreen;

    }

    public void show() {
        if (showing) {
            return;
        }
        if (null == lockView) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(R.layout.layout_lock_screen, new FrameLayout(this), false);
            view.findViewById(R.id.buttonUnlock).setOnClickListener(this);
            editTextPassword = (EditText) view.findViewById(R.id.editTextPassword);
            textViewWrongPassword = (TextView) view.findViewById(R.id.textView_wrong_password);
            this.lockView = view;
        } else {

        }
        WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        ViewGroup.LayoutParams old = lockView.getLayoutParams();

        if (null == old) {
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        } else if (old instanceof WindowManager.LayoutParams) {
            params.copyFrom((WindowManager.LayoutParams) old);
        } else {
            params.width = old.width;
            params.height = old.height;
            params.layoutAnimationParameters = old.layoutAnimationParameters;
        }
        params.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
        params.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
        params.flags |= WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR | WindowManager.LayoutParams.FLAG_FULLSCREEN;
        params.format = PixelFormat.TRANSPARENT;
        getWindowManager().addView(lockView, params);
        showing = true;
    }

    public void remove() {
        if (!showing) {
            return;
        }
        if ((null == lockView)) {
            return;
        }
        getWindowManager().removeView(lockView);
        lockView = null;
        showing = false;
    }

    private WindowManager getWindowManager() {
        return (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onClick(View view) {
        Log.d(TAG, "PAssword is :" + sharedPreferences.getString(AppConstant.PASSWORD, "default"));
        String password = sharedPreferences.getString(AppConstant.PASSWORD, "default");
        String pin = sharedPreferences.getString(AppConstant.LOGIN_PIN_CODE, "default");
        if (R.id.buttonUnlock == view.getId()) {
            String editTextValue = editTextPassword.getText().toString();
            if (editTextValue.equals(password) || editTextValue.equals(pin)) {
                editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG, false);
                editor.apply();
                textViewWrongPassword.setVisibility(View.GONE);
                remove();
                if (sharedPreferences.getBoolean(AppConstant.ALARM_RUN_STATUS, false)) {
                    editor.putBoolean(AppConstant.ALARM_RUN_STATUS, false);
                    editor.apply();
                }
                if (Utils.isDeviceSamsung(getApplicationContext())) {
                    SamsungKNOX.setPolicy(getApplicationContext(), false);
                }
//                unlockDevice();
            } else {
                textViewWrongPassword.setVisibility(View.VISIBLE);
                try {
                    Utils utils = new Utils();
                    new PictureService().startCapturing(utils.getActivity(this), this);

                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        }
    }

    public void unlockDevice() {
        KeyguardManager km = (KeyguardManager) getApplicationContext()
                .getSystemService(Context.KEYGUARD_SERVICE);
        final KeyguardManager.KeyguardLock kl = km
                .newKeyguardLock("MyKeyguardLock");
        kl.disableKeyguard();
        PowerManager pm = (PowerManager) getApplicationContext()
                .getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK
                | PowerManager.ACQUIRE_CAUSES_WAKEUP
                | PowerManager.ON_AFTER_RELEASE, "MyWakeLock");
        wakeLock.acquire();

    }

    @Override
    public void onCaptureDone(String pictureUrl, byte[] pictureData) {
        Log.d(TAG, "onCaptureDone: Capture Done");
    }

    @Override
    public void onDoneCapturingAllPhotos(TreeMap<String, byte[]> picturesTaken) {
        Log.d(TAG, "onDoneCapturingAllPhotos: Done");
    }
}
