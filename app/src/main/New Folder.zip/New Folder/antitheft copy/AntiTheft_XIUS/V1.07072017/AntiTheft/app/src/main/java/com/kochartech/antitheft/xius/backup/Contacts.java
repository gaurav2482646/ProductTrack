package com.kochartech.antitheft.xius.backup;

/**
 * Created by gauravjeet on 10/8/17.
 */
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.ContactsContract;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by amanpreet on 29/11/16.
 */

public class Contacts {

    public static String backup(Context context) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_a");
        String currentDateAndTime = sdf.format(new Date());
        String vcfPath = Environment.getExternalStorageDirectory() + "/CONTACTS_" + currentDateAndTime + ".vcf"; // .vcf file path
        File file = new File(vcfPath);
        Cursor contacts = context.getContentResolver().query(
                ContactsContract.Contacts.CONTENT_URI, null,
                null, null, null
        );

        String path = file.getAbsolutePath();
        try {
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(path, true));
            while (contacts.moveToNext()) {
                if (Integer.parseInt(contacts.getString(contacts.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    String lookupKey = contacts.getString(contacts.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY));

                    Uri uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, lookupKey);
                    AssetFileDescriptor fd = context.getContentResolver().openAssetFileDescriptor(uri, "r");
                    FileInputStream fis = fd.createInputStream();
                    byte[] buf =null;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        buf = readBytes(fis);

                    }
                    else
                    {
                        buf = new byte[(int) fd.getDeclaredLength()];
                        fis.read(buf);
                    }

                    fis.close();
                    fd.close();
                    bufferedOutputStream.write(buf);
                }
            }
            contacts.close();
            bufferedOutputStream.close();

            return file.getAbsolutePath();
        } catch (Exception ex) {
            int i = 0;
            //Do nothing
        } finally {
            contacts.close();
        }

        return "{}";
    }

    static public byte[] readBytes(InputStream inputStream) throws IOException {
        // this dynamically extends to take the bytes you read
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();

        // this is storage overwritten on each iteration with bytes
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        // we need to know how may bytes were read to write them to the byteBuffer
        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }

        // and then we can return your byte array.
        return byteBuffer.toByteArray();
    }




    public static int totalContacts(Context context) {
        int totalContactCount=0;
        Cursor phones = context.getContentResolver().query(
                ContactsContract.Contacts.CONTENT_URI, null, null,
                null, null
        );
        while (phones.moveToNext()) {
            if (Integer.parseInt(phones.getString(phones.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                ++totalContactCount;
            }
        }
        phones.close();
        return totalContactCount;
    }
}