package com.kochartech.antitheft.xius.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.kochartech.antitheft.xius.MainActivity;

public class SecretCodeReceiver extends BroadcastReceiver {
    private static final String TAG = "SecretCodeReceiver";
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "onReceive: Secret Code Received!");
       if(intent.getAction().equals("android.provider.Telephony.SECRET_CODE")){
           Intent intentApp = new Intent(context, MainActivity.class);
           intentApp.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
           context.startActivity(intentApp);
       }
    }
}
