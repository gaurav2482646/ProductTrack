package com.kochartech.antitheft.xius.billing;

import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.util.PreferenceHelper;

import java.util.ArrayList;
import java.util.List;

public class MyBillingActivityNew extends AppCompatActivity {
    private BillingClient mBillingClient;
    private static final String TAG = "MyBillingActivityNew";
    String purchaseToken;
    boolean clientReady = false;
    boolean hasPurchasedLicence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_billing_new);
        mBillingClient = BillingClient.newBuilder(this).setListener(new PurchasesUpdatedListener() {
            @Override
            public void onPurchasesUpdated(int responseCode, @Nullable List<Purchase> purchases) {
                if (responseCode == BillingClient.BillingResponse.OK
                        && purchases != null) {
                    for (Purchase purchase : purchases) {
                        purchaseToken = purchase.getPurchaseToken();
                        Log.i(TAG, "onPurchasesUpdated: " + purchase.getOriginalJson());
                    }
                    Log.i(TAG, "onPurchasesUpdated " + responseCode);

                    if (!purchaseToken.isEmpty()) {
                        consumePurchaseProduct(null);
                    }
                } else if (responseCode == BillingClient.BillingResponse.USER_CANCELED) {
                    // Handle an error caused by a user cancelling the purchase flow.
                    Log.i(TAG, "onPurchasesUpdated: Billing Was cancelled");
                } else {
                    switch (responseCode) {
                        case BillingClient.BillingResponse.OK:
                            Log.i(TAG, "onPurchasesUpdated: Itemss Purchased: " + responseCode);

                            break;
                        case BillingClient.BillingResponse.ITEM_ALREADY_OWNED:
                            Log.i(TAG, "onPurchasesUpdated: Item  Already Purchased: " + responseCode);

                            break;
                        case BillingClient.BillingResponse.ITEM_NOT_OWNED:
                            Log.i(TAG, "onPurchasesUpdated: Item  Not Owned: " + responseCode);

                            break;
                        case BillingClient.BillingResponse.SERVICE_DISCONNECTED:
                            Log.i(TAG, "onPurchasesUpdated: Service Disconnected: " + responseCode);

                            break;
                        case BillingClient.BillingResponse.SERVICE_UNAVAILABLE:
                            Log.i(TAG, "onPurchasesUpdated: Service Unavailable: " + responseCode);


                            break; // Handle any other error codes.
                    }
                }

            }
        }).build();
        mBillingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@BillingClient.BillingResponse int billingResponseCode) {
                if (billingResponseCode == BillingClient.BillingResponse.OK) {
                    // The billing client is ready. You can query purchases here.
                    Log.d(TAG, "onBillingSetupFinished: Now Start Query Purchase ");
                    clientReady = true;
                    queryPurchase();
                    queryPurchasedItems();

                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.
                mBillingClient.startConnection(null);
            }
        });

    }

    private void queryPurchase() {
        Log.i(TAG, "queryPurchase: Called");
        List<String> skuList = new ArrayList<>();
        skuList.add("mp1");
        SkuDetailsParams.Builder params = SkuDetailsParams.newBuilder();
        params.setSkusList(skuList).setType(BillingClient.SkuType.INAPP);
        mBillingClient.querySkuDetailsAsync(params.build(), new SkuDetailsResponseListener() {
            @Override
            public void onSkuDetailsResponse(int responseCode, List<SkuDetails> skuDetailsList) {

                switch (responseCode) {
                    case BillingClient.BillingResponse.OK:
                        Log.i(TAG, "Item Purchased: " + responseCode);
                        if (skuDetailsList != null) {

                            for (SkuDetails skuDetails : skuDetailsList) {
                                Log.i(TAG, "Query Purchase :" + skuDetails.toString());
                                String sku = skuDetails.getSku();
                                String price = skuDetails.getPrice();
//                        if ("premium_upgrade".equals(sku)) {
//                            mPremiumUpgradePrice = price;
//                        } else if ("gas".equals(sku)) {
//                            mGasPrice = price;
//                        }
                            }
                        }

                        break;
                    case BillingClient.BillingResponse.ERROR:
                        Log.i(TAG, "Item Purchased :Some fatal error occurred: " + responseCode);

                }

            }
        });


    }

    private void queryPurchasedItems() {
        Log.i(TAG, "queryPurchasedItems Called");
        Purchase.PurchasesResult purchasesResult = mBillingClient.queryPurchases(BillingClient.SkuType.INAPP);
        List<Purchase> purchaseList = purchasesResult.getPurchasesList();
        if (purchaseList.isEmpty()) {
            hasPurchasedLicence = false;
            Log.i(TAG, "queryPurchasedItems: User has purchased nothing");
        }
        for (Purchase purchase : purchaseList) {
            Log.i(TAG, "queryPurchasedItems: " + purchase.getOriginalJson());
            purchaseToken = purchase.getPurchaseToken();
        }


    }

    public void startPurchaseProduct(View view) {
        if (clientReady) {
            BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                    .setSku("mp2")
                    .setType(BillingClient.SkuType.INAPP)
                    .build();
            int responseCode = mBillingClient.launchBillingFlow(this, flowParams);
            switch (responseCode) {
                case BillingClient.BillingResponse.OK:
                    Log.i(TAG, "Itemss Purchased: " + responseCode);


                    break;
                case BillingClient.BillingResponse.ITEM_ALREADY_OWNED:
                    Log.i(TAG, "Item  Already Purchased: " + responseCode);
                    Toast.makeText(this, "Item  Already Purchased", Toast.LENGTH_SHORT).show();
                    break;
                case BillingClient.BillingResponse.ITEM_NOT_OWNED:
                    Log.i(TAG, "Item  Not Owned: " + responseCode);
                    Toast.makeText(this, "Item  Not Owned", Toast.LENGTH_SHORT).show();

                    break;
                case BillingClient.BillingResponse.SERVICE_DISCONNECTED:
                    Log.i(TAG, "Service Disconnected: " + responseCode);
                    Toast.makeText(this, "Service Disconnected", Toast.LENGTH_SHORT).show();

                    break;
                case BillingClient.BillingResponse.SERVICE_UNAVAILABLE:
                    Log.i(TAG, "Service Unavailable: " + responseCode);
                    Toast.makeText(this, "Service Unavailable", Toast.LENGTH_SHORT).show();


                    break;
            }
            Log.i(TAG, "startPurchaseProduct Response: " + responseCode);
        } else {
            Log.i(TAG, "startPurchaseProduct: Billing Client is not yet setup");
        }

    }

    public void consumePurchaseProduct(View view) {

        mBillingClient.consumeAsync(purchaseToken, new ConsumeResponseListener() {
            @Override
            public void onConsumeResponse(int responseCode, String purchaseToken) {
                switch (responseCode) {
                    case BillingClient.BillingResponse.OK:
                        Log.i(TAG, "Item Consumed: " + responseCode);
                        Toast.makeText(MyBillingActivityNew.this, "Item Consumed", Toast.LENGTH_SHORT).show();
                        break;
                    case BillingClient.BillingResponse.ITEM_ALREADY_OWNED:
                        Log.i(TAG, "Item  Already Purchased: " + responseCode);

                        break;
                    case BillingClient.BillingResponse.ITEM_NOT_OWNED:
                        Log.i(TAG, "Item  Not Owned: " + responseCode);
                        Toast.makeText(MyBillingActivityNew.this, "Item  Not Owned", Toast.LENGTH_SHORT).show();

                        break;
                    case BillingClient.BillingResponse.ERROR:
                        Log.i(TAG, "Some fatal error occurred: " + responseCode);
                        Toast.makeText(MyBillingActivityNew.this, "Some fatal error occurred", Toast.LENGTH_SHORT).show();
                        break;
                    case BillingClient.BillingResponse.SERVICE_DISCONNECTED:
                        Log.i(TAG, "Service Disconnected: " + responseCode);
                        Toast.makeText(MyBillingActivityNew.this, "Service Disconnected", Toast.LENGTH_SHORT).show();


                        break;
                    case BillingClient.BillingResponse.SERVICE_UNAVAILABLE:
                        Log.i(TAG, "Service Unavailable: " + responseCode);
                        Toast.makeText(MyBillingActivityNew.this, "Service Service Unavailable", Toast.LENGTH_SHORT).show();


                        break;
                }

            }
        });
    }

    public void openActivity(View view) {
        try {
            final PreferenceHelper preferenceHelper = new PreferenceHelper(MyBillingActivityNew.this);

            final Intent intent = new Intent();
            final String manufacturer = android.os.Build.MANUFACTURER;
            if (manufacturer.equals("xiaomi") || manufacturer.equals("oppo") || manufacturer.equals("vivo")) {
                Log.d(TAG, "openActivity: Autostart");
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                LayoutInflater layoutInflater = LayoutInflater.from(this);
                View CheckBoxLayout = getLayoutInflater().inflate(R.layout.dialog_autostart_enable, null);
                final CheckBox checkBox = (CheckBox) CheckBoxLayout.findViewById(R.id.checkboxSkip);
                builder.setView(CheckBoxLayout);
                builder.setTitle("Allow Autostart Permission");
                builder.setMessage("Please enable autostart permission to allow the app work in background.\nAntitheft will not be able to protect your device without autostart permission.\n\n Ignore if already given");
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String checkBoxResult = "Not Checked";
                        if (checkBox.isChecked()) {
                            checkBoxResult = "checked";
                            preferenceHelper.saveString("skipMessage", checkBoxResult);

                        }
                        if ("xiaomi".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
                        } else if ("oppo".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"));
                            //intent.setComponent(new ComponentName("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity"));
                        } else if ("vivo".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
                        } else if ("huawei".equalsIgnoreCase(manufacturer)) {
                            intent.setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"));
                        }
                        List<ResolveInfo> list = getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
                        if (list.size() > 0) {
                            startActivity(intent);
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String checkBoxResult = "Not Checked";
                        if (checkBox.isChecked()) {
                            checkBoxResult = "checked";
                            preferenceHelper.saveString("skipMessage", checkBoxResult);
                        }
                        dialog.dismiss();
                    }
                });
                if (!preferenceHelper.getString("skipMessage", "").equals("checked")) {
                    builder.show();
                }
                //OpenDialog here promt the user to enable the autostart permission in certaim phones

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
