package com.kochartech.antitheft.xius.fcm;

import android.util.Log;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.util.PreferenceHelper;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class KtFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "KTFirebaseService";
    PreferenceHelper preferenceHelper;
    public KtFirebaseMessagingService() {
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "onMessageReceived: A message is received");
        Map<String, String> data;
        CommandController commandController = new CommandController(getApplication());
        preferenceHelper = new PreferenceHelper(getApplicationContext());

        try {

            Log.d(TAG, "FCM message " + remoteMessage.getData().toString());

         /*   Log.w(TAG, "FCM message " + new JSONObject(remoteMessage.getData()).toString());
            JSONObject objOuter = new JSONObject(remoteMessage.getData());
            JSONObject inner = new JSONObject(objOuter.get("Params").toString());

            Log.d(TAG, "onMessageReceived: " + inner.toString());
            Log.d(TAG, "onMessageReceivedValue: " + inner.get("Lock"));*/
            if (preferenceHelper.getBoolean(AppConstant.IS_LOGGED_IN, false)) {
                if (preferenceHelper.isDeviceRegistered()) {
                    if ((remoteMessage.getData()) != null) {
                        data = remoteMessage.getData();
                        commandController.extractCommand(data);
                        Set<String> set = remoteMessage.getData().keySet();
                        Iterator<String> keyIterator = set.iterator();
                        while (keyIterator.hasNext()) {
                            Log.d("Key ", " key " + keyIterator.next());
                        }
                        Log.d(TAG, "FCM message " + remoteMessage.getData().toString());
                    }
                } else {
                    Log.e(TAG, "onMessageReceived: DEVICE IS NOT REGISTERED");

                }
         }else{
             Log.e(TAG, "onMessageReceived: USER IS NOT LOGGED IN");
         }
            try {
//                Log.d(TAG, "notification body " + remoteMessage.getNotification().getBody());
            } catch (Exception e) {
                Log.e(TAG, e.toString());
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        /*if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getNotification().getBody());


            if (*//* Check if data needs to be processed by long running job *//* true) {
                // For long-running tasks (10 seconds or more) use Firebase Job Dispatcher.
         //       scheduleJob();
            } else {
                // Handle message within 10 seconds
           //     handleNow();
            }

        }

        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }*/

    }

//    @Override
//    public void handleIntent(Intent intent) {
//        try {
//            super.handleIntent(intent);
//            Bundle extras = intent.getExtras();
////            Log.d(TAG,"extras "+extras.toString());
////            Log.d(TAG, "message from FCM "+ extras.getString("gcm.notification.body"));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        /*Log.d(TAG,"extras "+extras.toString());
        Set<String> set = extras.keySet();
        Iterator<String> iterator = set.iterator();
        while (iterator.hasNext())
        {
            String key = iterator.next();
            Log.d(TAG, " key "+ key + " val "+ extras.get(key));

        }*/


//    }

    private void scheduleJob() {
        FirebaseJobDispatcher dispatcher =
                new FirebaseJobDispatcher(new GooglePlayDriver(this));
        Job myJob = dispatcher.newJobBuilder()
                .setService(MyJobService.class)
                .setLifetime(Lifetime.UNTIL_NEXT_BOOT)
                .setTag(AppConstant.FCM_MESSAGE)
                .build();
        dispatcher.mustSchedule(myJob);
    }


}
