package com.kochartech.antitheft.xius.user;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.kochartech.antitheft.xius.R;

public class ViewProfileActivity extends AppCompatActivity {

    Button btnEditProfile, btnChangePassw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        btnEditProfile = (Button) findViewById(R.id.btn_editProfile);
        btnChangePassw = (Button) findViewById(R.id.btn_changePassword);

        btnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewProfileActivity.this, UpdateProfileActivity.class);
                startActivity(intent);
            }
        });

        btnChangePassw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(ViewProfileActivity.this, UpdatePasswordActivity.class);
                startActivity(intent1);
            }
        });
    }
}
