package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 2/11/17.
 */
//Contains Information About The Device
public class DeviceDTO
{
    private String model;

    private String registrationId;

    private String imei;

    private String brand;

    private String simNumberTwo;

    private String macAddress;

    private String simNumber;

    public String getModel ()
    {
        return model;
    }

    public void setModel (String model)
    {
        this.model = model;
    }

    public String getRegistrationId ()
    {
        return registrationId;
    }

    public void setRegistrationId (String registrationId)
    {
        this.registrationId = registrationId;
    }

    public String getImei ()
    {
        return imei;
    }

    public void setImei (String imei)
    {
        this.imei = imei;
    }

    public String getBrand ()
    {
        return brand;
    }

    public void setBrand (String brand)
    {
        this.brand = brand;
    }

    public String getSimNumberTwo ()
    {
        return simNumberTwo;
    }

    public void setSimNumberTwo (String simNumberTwo)
    {
        this.simNumberTwo = simNumberTwo;
    }

    public String getMacAddress ()
    {
        return macAddress;
    }

    public void setMacAddress (String macAddress)
    {
        this.macAddress = macAddress;
    }

    public String getSimNumber ()
    {
        return simNumber;
    }

    public void setSimNumber (String simNumber)
    {
        this.simNumber = simNumber;
    }

    @Override
    public String toString()
    {
        return "DeviceDTO [model = "+model+", registrationId = "+registrationId+", imei = "+imei+", brand = "+brand+", simNumberTwo = "+simNumberTwo+", macAddress = "+macAddress+", simNumber = "+simNumber+"]";
    }
}
