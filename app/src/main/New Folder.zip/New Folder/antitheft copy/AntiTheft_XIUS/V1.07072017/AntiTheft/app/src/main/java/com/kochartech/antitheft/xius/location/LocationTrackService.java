package com.kochartech.antitheft.xius.location;

import android.app.Activity;
import android.app.Service;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.kochartech.antitheft.xius.AppConstant;

/**
 * Created by gauravjeet on 8/8/17.
 */

public class LocationTrackService extends Service implements
        LocationListener, GoogleApiClient.ConnectionCallbacks {
    private static final String TAG = "LocationTracker";

    private static final int FASTEST_UPDATE_INTERVAL = 2 * 1000;
    private static final int REQUEST_CODE_PERMISSIONS = 101;
    private GoogleApiClient mApiClient;
    /* Metadata about updates we want to receive */
    private LocationRequest mLocationRequest;
    /* Last-known device location */
    private Location mCurrentLocation;
    private boolean isLocate =false;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "onCreate: Serviced Created");
        int resultCode = GoogleApiAvailability.getInstance()
                .isGooglePlayServicesAvailable(this);
        switch (resultCode) {
            case ConnectionResult.SUCCESS:
                Log.d(TAG, "Google Play Services is ready to go!");
                break;
            default:
                showPlayServicesError(resultCode);
                return;
        }
        mApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .build();


    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        Log.e(TAG, "onStartCommand");
        isLocate = intent.getBooleanExtra(AppConstant.LOCATION_TRACKING,false);
        if(isLocate) {
            // send location
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            int interval = sharedPreferences.getInt(AppConstant.LOCATION_TRACKING_INTERVAL,1);
            long UPDATE_INTERVAL = interval * 1000 *60  ;
            mLocationRequest = LocationRequest.create()
                    //Set the required accuracy level
                    .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    //Set the desired (inexact) frequency of location updates
                    .setInterval(UPDATE_INTERVAL)
                    //Throttle the max rate of update requests
                    .setFastestInterval(FASTEST_UPDATE_INTERVAL);


        }else {
            // stop service
        }

        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /*
    * When Play Services is missing or at the wrong version, the client
    * library will assist with a dialog to help the user update.
    */
    private void showPlayServicesError(int errorCode) {
        GoogleApiAvailability.getInstance()
                .showErrorDialogFragment((Activity) getApplicationContext(), errorCode, 10,
                        new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface dialogInterface) {
//                                getApplication().finish();
                            }
                        });
    }

    @Override
    public void onConnected(Bundle bundle) {
        Log.d(TAG, "Connected to Play Services");
//Get last known location immediately



        fetchAndListenForLocation();
    }

    @SuppressWarnings("MissingPermission")
    private void fetchAndListenForLocation() {
        mCurrentLocation = LocationServices.FusedLocationApi
                .getLastLocation(mApiClient);
//Register for updates
        LocationServices.FusedLocationApi.requestLocationUpdates(mApiClient,
                mLocationRequest, this);
    }

    @Override
    public void onConnectionSuspended(int i) {
    }

    /**
     * LocationListener Callbacks
     */
    @Override
    public void onLocationChanged(Location location) {
        Log.d(TAG, "Received location update");
        mCurrentLocation = location;
        Log.d(TAG, "onLocationChangedService: "+location.getLatitude()+" "+location.getLongitude());
        // TODO: 8/8/17 send the changed location here
//        updateDisplay();
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode,
//                                           @NonNull String[] permissions,
//                                           @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions,
//                grantResults);
//        if (requestCode == REQUEST_CODE_PERMISSIONS) {
//            for (int i = 0; i < grantResults.length; i++) {
//                int grantResult = grantResults[i];
//                String permission = permissions[i];
//                if (grantResult != PackageManager.PERMISSION_GRANTED) {
//                    Log.d(TAG, "Permission " + permission
//                            + " is required for this application to work.");
//                    Toast.makeText(this, "GPS Permission Required", Toast.LENGTH_SHORT).show();
//                    finish();
//                    return;
//                }
}




