package com.kochartech.antitheft.xius.user;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.dto.AppDTO;
import com.kochartech.antitheft.xius.dto.DeviceDTO;
import com.kochartech.antitheft.xius.dto.RegisterDTO;
import com.kochartech.antitheft.xius.dto.UserDTO;
import com.kochartech.antitheft.xius.util.DualSimInfo;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.TelephonyInfo;
import com.yanzhenjie.alertdialog.AlertDialog;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;
import com.yanzhenjie.permission.Rationale;
import com.yanzhenjie.permission.RationaleListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegistrationActivity extends AppCompatActivity {
    private EditText firstName, lastName, mobileNumber, alternateMobileNumber, confirmPassword, password, email;
    private static final int REQUEST_CODE_DEVICE_ADMIN = 200;
    private static final String RESPONSE_MESSAGE = "message";
    private static final int REQUEST_PREM = 400;
    private static final int DENIED_PERMISSION_ACTIVITY_CODE = 300;
    Button btnRegister;
    DualSimInfo dualSimInfo;
    private static final String TAG = "RegistrationActivity";
    private View mProgressView;
    private View mRegistrationForm;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private PermissionListener permissionListener = new PermissionListener() {
        @Override
        public void onSucceed(int i, @NonNull List<String> list) {
            switch (i) {
                case REQUEST_PREM: {
                    if (dualSimInfo.getImsi() != null) {
                        volleyRegisterDeviceRequest();
                    } else {
                        dialogSimNotAvailabe();
                    }
                    break;
                }
            }
        }

        @Override
        public void onFailed(int i, @NonNull List<String> list) {
            switch (i) {
                case REQUEST_PREM: {
                    Toast.makeText(RegistrationActivity.this, "Permissions required to continue !", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
            if (AndPermission.hasAlwaysDeniedPermission(RegistrationActivity.this, list)) {
                AndPermission.defaultSettingDialog(RegistrationActivity.this, DENIED_PERMISSION_ACTIVITY_CODE)
                        .setTitle("Permissions Disabled")
                        .setMessage("Please go to App Settings to Enable the Permissions Manually")
                        .setPositiveButton("Ok")
                        .setNegativeButton("NO",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                        .show();

            }
        }
    };
    private RationaleListener rationaleListener = new RationaleListener() {
        @Override
        public void showRequestPermissionRationale(int requestCode, final Rationale rationale) {
            AlertDialog.newBuilder(RegistrationActivity.this)
                    .setTitle("Permissions Required !")
                    .setMessage("Please enable all the permissions")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            rationale.resume();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            rationale.cancel();
                        }
                    }).show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        dualSimInfo = new DualSimInfo(this);
        sharedPreferences = PreferenceHelper.getSharedPreference();
        editor = PreferenceHelper.getSharedPreferenceEditor();
        firstName = (EditText) findViewById(R.id.etFullName);
        mRegistrationForm = findViewById(R.id.registrationForm);
        mProgressView = (ProgressBar) findViewById(R.id.registration_progress);
        mobileNumber = (EditText) findViewById(R.id.etMobileNumber);
        alternateMobileNumber = (EditText) findViewById(R.id.etAlternateNumber);
        email = (EditText) findViewById(R.id.etEmail);
        password = (EditText) findViewById(R.id.etPassword);
        confirmPassword = (EditText) findViewById(R.id.etRetypePassword);
        btnRegister = (Button) findViewById(R.id.btnRegister);
//        firstName.setText("Gauravjeet");
//        mobileNumber.setText("9646285596");
//        alternateMobileNumber.setText("9646285594");
//        email.setText("gaurav2482646@gmail.com");
//        password.setText("111111");
//        confirmPassword.setText("111111");
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mRegisterUser(v);
            }
        });

    }


    // check registration form validation
    private void mRegisterUser(View v) {

        if (firstName.getText().toString().trim().length() == 0) {
            Toast.makeText(v.getContext(), "Please Enter First Name", Toast.LENGTH_SHORT).show();
            firstName.requestFocus();

        } else if (!isValidMobileNumber(mobileNumber.getText().toString())) {
            mobileNumber.requestFocus();
            // mResetFields();
        } else if (alternateMobileNumber.getText().toString().length() == 0) {
            alternateMobileNumber.requestFocus();
            Toast.makeText(v.getContext(), "Please enter alternative number", Toast.LENGTH_SHORT).show();
            // mResetFields();
        } else if (alternateMobileNumber.getText().toString().length() < 10) {
            alternateMobileNumber.requestFocus();
            Toast.makeText(v.getContext(), "Please enter valid alternative number", Toast.LENGTH_SHORT).show();
            // mResetFields();
        } else if (alternateMobileNumber.getText().toString().equals(mobileNumber.getText().toString())) {
            alternateMobileNumber.requestFocus();
            Toast.makeText(v.getContext(), "Mobile Number And Alternate Number Must be Different", Toast.LENGTH_SHORT).show();
            // mResetFields();
        }
//			| Integer.parseInt(mobileNumber.getText().toString().substring(0, 1)) < 7
        else if (email.getText().toString().length() == 0) {
            email.requestFocus();
            Toast.makeText(v.getContext(), "Please enter Email Address", Toast.LENGTH_SHORT).show();
            // mResetFields();
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.getText()).matches()) {
            email.requestFocus();
            Toast.makeText(v.getContext(), "Please enter valid Email Address", Toast.LENGTH_SHORT).show();
            // mResetFields();
        } else if (!isValidPassword(password.getText().toString())) {
            password.requestFocus();
        } else if (!isValidConfirmPassword(confirmPassword.getText().toString())) {
            confirmPassword.requestFocus();

        } else if (!(password.getText().toString().equals(confirmPassword.getText().toString()))) {
            confirmPassword.requestFocus();
            Toast.makeText(v.getContext(), "Password and confirm password does not match", Toast.LENGTH_SHORT).show();
            // mResetFields();

        } else {
            if (AndPermission.hasPermission(this, AppConstant.REQUIRED_PERMISSIONS)) {
                if (dualSimInfo.getImsi() != null) {
                    volleyRegisterDeviceRequest();
                } else {
                    dialogSimNotAvailabe();
                }
            } else {
                AndPermission.with(RegistrationActivity.this)
                        .requestCode(REQUEST_PREM)
                        .permission(AppConstant.REQUIRED_PERMISSIONS)
                        .callback(permissionListener)
                        .rationale(rationaleListener)
                        .start();

            }
        }

    }

    //    check mobile number validation
    private boolean isValidMobileNumber(String mobileNumber) {
        if (mobileNumber.length() == 0) {
            Toast.makeText(this, "Please enter mobile number", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (mobileNumber.length() < 10) {
            Toast.makeText(this, "Mobile number must be 10 digits long", Toast.LENGTH_SHORT).show();
            return false;
        }
//        if (!mobileNumber.startsWith("+")) {
//            Toast.makeText(this, "Please add country code along with mobile number eg +91 ", Toast.LENGTH_SHORT).show();
//            return false;
//        }

        return true;
    }

    void dialogSimNotAvailabe() {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage(R.string.insert_sim)
                .setCancelable(false)
                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("Insert Sim");
        alert.show();
    }

    //    check password validation
    private boolean isValidPassword(String password) {

        if (password.length() == 0) {
            Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRegistrationForm.setVisibility(show ? View.GONE : View.VISIBLE);
            mRegistrationForm.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRegistrationForm.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRegistrationForm.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    //    check confirm password validation
    private boolean isValidConfirmPassword(String password) {

        if (password.length() == 0) {
            Toast.makeText(this, "Please enter confirm password", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.length() < 6) {
            Toast.makeText(this, "Confirm Password must be atleast 6 characters long", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    public void volleyRegisterDeviceRequest() {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();
        showProgress(true);

        try {
            Log.d(TAG, "volleyRegisterDeviceRequest: " + getRegisterDTO().toString());
            JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                    AppConstant.USER_REGISTRATION_URL_MOBILE, getRegisterDTO(),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject jsonObject) {
                            Log.d(TAG, jsonObject.toString());
                            mRequestQueue.stop();
                            try {
                                Log.d(TAG, "onResponse: " + jsonObject.toString());
                                if (jsonObject.getString("code").equals("0")) {
                                    JSONObject jsonObject1 = jsonObject.getJSONObject("user");
                                    int userID = jsonObject1.getInt("userID");
                                    Log.d(TAG, "onResponse: "+userID);
                                    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(RegistrationActivity.this);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();

                                    editor.putInt(AppConstant.USER_ID, userID);
                                    editor.putBoolean(AppConstant.IS_USER_REGISTERED, true);
                                    editor.apply();
                                    saveUserDetails();


//                                if (!mDPM.isAdminActive(mAdminName)) {
//                                    Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
//                                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminName);
//                                    intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Click on Activate button to secure your application.");
//                                    startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN);
//                                } else {
//                                    Intent intent = new Intent(LoginActivity.this, DisplayActivity.class);
//                                    startActivity(intent);
//                                }
//                                startService(new Intent(LoginActivity.this, StartupOperations.class));

                                    Toast.makeText(RegistrationActivity.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
                                    Toast.makeText(RegistrationActivity.this, "Please Login with your credentials", Toast.LENGTH_LONG).show();
                                    showProgress(false);

                                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                                } else {
                                    String message = jsonObject.getString("message");
                                    Toast.makeText(RegistrationActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                                    Toast.makeText(RegistrationActivity.this, message, Toast.LENGTH_LONG).show();

                                    showProgress(false);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                showProgress(false);

                            }
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.d(TAG, "Error: " + error.getMessage());
                    Log.d(TAG, "onErrorResponse: " + error.getMessage());
                    showProgress(false);
                    Toast.makeText(RegistrationActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(RegistrationActivity.this, "Check your Internet Connection", Toast.LENGTH_SHORT).show();
                    mRequestQueue.stop();
                }
            }) {


                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }


            };
            mRequestQueue.add(jsonObjReq);
        } catch (Exception e) {
            e.printStackTrace();
            showProgress(false);

        }
    }


    private void saveUserDetails() {
        editor.putString(AppConstant.USER_NAME, firstName.getText().toString());
        editor.putString(AppConstant.PASSWORD, password.getText().toString());
        editor.putString(AppConstant.USER_EMAIL, email.getText().toString());
        editor.putString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, alternateMobileNumber.getText().toString());
        editor.putString(AppConstant.PHONE_NUMBER, mobileNumber.getText().toString());
        editor.apply();
    }

    private JSONObject getRegisterDTO() throws PackageManager.NameNotFoundException, JSONException {
        TelephonyInfo telephonyInfo = TelephonyInfo.getInstance(this);
        DeviceDTO deviceDTO = new DeviceDTO();
        UserDTO userDTO = new UserDTO();
        AppDTO appDTO = new AppDTO();

       /* deviceDTO.setBrand(Build.MANUFACTURER);
        deviceDTO.setImei(dualSimInfo.getIMEI(0));
        deviceDTO.setMacAddress(Utils.getMACAddress().replace(":", ""));
        deviceDTO.setModel(Build.MODEL);
        deviceDTO.setSimNumber("0");
        boolean isDualSim;
        String simOne = null;
        String simTwo = null;
        DualSimInfo dualSimInfo = new DualSimInfo(this);
        isDualSim = dualSimInfo.isDualSim();
        if (isDualSim) {
            simOne = dualSimInfo.getIMSI(0);
            simTwo = dualSimInfo.getIMSI(1);
            if (simOne == null || simTwo == null) {
                if (telephonyInfo.isSIM1Ready()) {
                    simOne = telephonyInfo.getImsiSIM1();
                }
                if (telephonyInfo.isSIM2Ready()) {
                    simTwo = telephonyInfo.getImsiSIM2();
                }
            }
            editor.putString(AppConstant.SIM_NUMBER_ONE, simOne);
            editor.putString(AppConstant.SIM_NUMBER_TWO, simTwo);
            editor.apply();
            deviceDTO.setSimNumber(simOne == null ? "0" : simOne);
            deviceDTO.setSimNumber(simTwo == null ? "0" : simTwo);
        } else {
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            simOne = telephonyManager.getSubscriberId();
            if (simOne == null) {
                if (telephonyInfo.isSIM1Ready()) {
                    simOne = telephonyInfo.getImsiSIM1();
                }
            }
            editor.putString(AppConstant.SIM_NUMBER_ONE, simOne);
            editor.apply();
            deviceDTO.setSimNumber(simOne == null ? "0" : simOne);
//            hashMap.put(AppConstant.SIM_NUMBER_ONE, simOne == null ? "0" : simOne);
//            if (dualSimInfo.isDualSim()) {
//                deviceDTO.setSimNumberTwo("1");
//
            }
            appDTO.setAppName(Utils.getApplicationName(this));
            appDTO.setAppVersion(getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
            appDTO.setIsTrial(true);
            appDTO.setValidity(7);*/

        userDTO.setName(firstName.getText().toString());
        userDTO.setEmailAddress(email.getText().toString());
        userDTO.setPassword(password.getText().toString());

        userDTO.setMobileNumber(mobileNumber.getText().toString());
        userDTO.setAlternateNumber(alternateMobileNumber.getText().toString());

        RegisterDTO registerDTO = new RegisterDTO();
//          registerDTO.setAppDTO(appDTO);
//          registerDTO.setDeviceDTO(deviceDTO);
        registerDTO.setUserDTO(userDTO);
        Gson gson = new Gson();

        return new JSONObject(gson.toJson(registerDTO));
    }











}


