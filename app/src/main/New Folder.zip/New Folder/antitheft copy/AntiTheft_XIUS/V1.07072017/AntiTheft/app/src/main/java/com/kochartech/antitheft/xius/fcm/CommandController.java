package com.kochartech.antitheft.xius.fcm;

import android.Manifest;
import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Looper;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;

import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.dto.AckCommand;
import com.kochartech.antitheft.xius.dto.AckDTO;
import com.kochartech.antitheft.xius.dto.LocationDTO;
import com.kochartech.antitheft.xius.dto.Response;
import com.kochartech.antitheft.xius.dto.SendLocResponse;
import com.kochartech.antitheft.xius.location.EnableLocationServiceActivity;
import com.kochartech.antitheft.xius.location.LocationTrackService;
import com.kochartech.antitheft.xius.location.SingleShotLocationProvider;
import com.kochartech.antitheft.xius.lockscreen.ApplicationManager;
import com.kochartech.antitheft.xius.lockscreen.LockScreen;
import com.kochartech.antitheft.xius.sms.AlarmServiceAsyncTask;
import com.kochartech.antitheft.xius.util.Utils;
import com.kochartech.antitheft.xius.util.SamsungKNOX;
import com.yanzhenjie.permission.AndPermission;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;


/**
 * Created by gauravjeet on 17/8/17.
 */
//This is used to handle the fcm related commands
public class CommandController {
    private static final String TAG = "CommandController";
    private static final int PREM_LOC_REQUEST = 101;

    static Commands command;
    boolean active;
    Context context;
    String commandID;
    AckDTO ack;

    private DevicePolicyManager mDPM;
    private ComponentName mDeviceAdmin;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;


    public CommandController(Commands command) {
        this.command = command;
    }

    public CommandController(Context context) {
        this.context = context;
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = preferences.edit();
        mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        mDeviceAdmin = new ComponentName(context, KDeviceAdminReceiver.class);
        active = mDPM.isAdminActive(mDeviceAdmin);
        {
            ack = new AckDTO();
        }
    }

    public void extractCommand(Map<String, String> data) {
        JSONObject outerObject = new JSONObject(data);
        try {
            JSONObject params = new JSONObject(outerObject.get("Params").toString());
            String commandKey = outerObject.get("CommandKey").toString();
            String MAC_ADDRESS = outerObject.get("MAC").toString(); //This is MAC Address.
            commandID = outerObject.get("MessageCommandId").toString();
//            JSONObject params = new JSONObject();

            switch (commandKey) {
                case "WP"://Wipe
                    passCommand(Commands.WIPE, commandID);
                    break;
                case "PI"://Ping
                    if (params.getBoolean("Ping")) {
                        passCommand(Commands.PING, commandID);
                    }
                    break;
                case "GF"://GeoFence
                    passCommand(Commands.GEOFENCE, commandID);
                    break;
                case "LST"://Lost
                    if (params.getBoolean("Lost")) {
                        passCommand(Commands.ALARM_ON, commandID);
                    } else {
                        passCommand(Commands.ALARM_OFF, commandID);
                    }
                    break;
                case "LK"://Lock
                    if (params.getBoolean("Lock")) {
                        passCommand(Commands.LOCK, commandID);
                    } else {
                        passCommand(Commands.UNLOCK, commandID);
                    }
                    break;
                case "LOC"://Locate
                    passCommand(Commands.LOCATE, commandID);
                    break;
                case "LT"://Location Track
                    passCommand(Commands.LOCATE, commandID);
                    break;
                case "LR"://Location Track
                    if (params.getBoolean("Track"))
                        passCommand(Commands.LOC_TRACK, commandID);
                    break;
                default:
                    Log.d(TAG, "extractCommand: No Command Received");

            }
//            params.get("");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    void passCommand(Commands commands, final String commandID) {
        switch (commands) {
            case PING: {
                Log.d(TAG, "passCommand: PING");

                if (preferences.getBoolean(AppConstant.SCREEN_ON_STATUS, false)) {
                    ack.setMessageCommandId(commandID);
                    ack.setStatus(true);
                    ack.setDescription("Active");
                } else {
                    ack.setMessageCommandId(commandID);
                    ack.setStatus(true);
                    ack.setDescription("Idle");
                }
                acknowledgeCommand(ack);
            }
            break;
            case WIPE:
                //TODO Add functionality here+ add AckCommand Implementation
                Log.d(TAG, "passCommand: WIPE");
                if (mDPM.isAdminActive(mDeviceAdmin)) {
                    ack.setMessageCommandId(commandID);
                    ack.setStatus(true);
                    ack.setDescription("Wipe Device");
                    acknowledgeCommand(ack);
                    wipe();
                } else {
                    ack.setMessageCommandId(commandID);
                    ack.setStatus(false);
                    ack.setDescription("Device Admin is not Active");
                    acknowledgeCommand(ack);

                }
                break;
            case LOCK:
                Log.e(TAG, "passCommand: Lock");
                if (mDPM.isAdminActive(mDeviceAdmin)) {
                    lockDevice();
                    ack.setMessageCommandId(commandID);
                    ack.setStatus(true);
                    ack.setDescription("Locked Device");
                    acknowledgeCommand(ack);
                } else {
                    ack.setMessageCommandId(commandID);
                    ack.setStatus(false);
                    ack.setDescription("Device Admin is not Active");
                    acknowledgeCommand(ack);

                }
                break;
            case UNLOCK:
                unlockDevice();
                Log.e(TAG, "passCommand: UnLock");
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Unlocked Device");
                acknowledgeCommand(ack);
                break;
            case ALARM_ON:
                Log.e(TAG, "passCommand: Alarm On");
                new AlarmServiceAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this.context);
                lockDevice();
                SamsungKNOX.setPolicy(context, true);
                //build the ack_json object
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Enabled Alarm");
                acknowledgeCommand(ack);
                break;
            case ALARM_OFF:
                Log.e(TAG, "passCommand: Alarm Off");
                editor.putBoolean(AppConstant.ALARM_RUN_STATUS, false);
                editor.apply();
                SamsungKNOX.setPolicy(context, false);
                unlockDevice();
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Disabled Alarm");
                acknowledgeCommand(ack);
                break;
            case LOCATE:
                Log.e(TAG, "passCommand: Locate");
                ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Fetching Location");
                acknowledgeCommand(ack);
                fetchLocation();
                break;
            case LOC_TRACK:
                Log.e(TAG, "passCommand: Location Tracking");
             /*   ack.setMessageCommandId(commandID);
                ack.setStatus(true);
                ack.setDescription("Starting Tracking");
                acknowledgeCommand(ack);*/
                Log.e(TAG, "passCommand: Started Track");
                ApplicationManager.getAppContext().startService(
                        new Intent(ApplicationManager.getAppContext(), LocationTrackService.class).putExtra(AppConstant.LOCATION_TRACKING, true));
                Log.d(TAG, "passCommand: ");
              /*  new Thread(new Runnable() {

                    @Override
                    public void run() {
                        Looper.prepare();
                        Wherebouts.instance().onChange(new Workable<GPSPoint>() {
                            @Override
                            public void work(GPSPoint gpsPoint) {
                                Log.d(TAG, "work: "+gpsPoint.toString());
                            }
                        });

                        Looper.loop();
                    }
              }).start();*/
                break;
            case GEOFENCE:
                Log.e(TAG, "passCommand: GEOFENCE !");
                break;
        }
    }

    private void wipe() {
        /**
         *  wipe command response would be sent to server, if success/failure received
         *  wipe would be performed.
         *  WIPE_RECEIVED updated in preferences.
         *
         *   command would be sent only
         */
//        DevicePolicyManager mDPM = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
//        ComponentName mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
        String commandResponse;
        if (mDPM.isAdminActive(mDeviceAdmin)) {

//            commandResponse = "MessageClass:Action;Command:GizmoControlRegistraion;Method:UpdateStatusAfterCommandExecute;" +
//                    "MsgCmdID:" + commandDTO.getId() + ";CmdStatus:1;Message:Done;";
            Intent in = new Intent(context, KDeviceAdminReceiver.Controller.class);
            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            in.putExtra("value", 1);
            context.startActivity(in);
        } else {
//            commandResponse = "MessageClass:Action;Command:GizmoControlRegistraion;Method:UpdateStatusAfterCommandExecute;" +
//                    "MsgCmdID:" + commandDTO.getId() + ";CmdStatus:0;Message:Device Admin is not active;";
            //TODO: Send Response here
        }
    }

    /**
     * Locks the device with Admin Permission
     **/
    public void lockDevice() {
//        ComponentName mDeviceAdminSample = new ComponentName(context, KDeviceAdminReceiver.class);
        if (mDPM.isAdminActive(mDeviceAdmin)) {
            editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG + "", true);
            editor.commit();
//          mDPM.lockNow(); TODO:try this example also
            Intent in = new Intent(context, KDeviceAdminReceiver.Controller.class);
            in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            in.putExtra("value", 4);
//            Intent lockScreenActivity = new Intent(context,LockActivity.class);
//            lockScreenActivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(in);
//            context.startActivities(new Intent[]{in,lockScreenActivity},new Bundle());
            if (preferences.getBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, false)) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Looper.prepare();
                        showLockScreen(true);
                        SamsungKNOX.setPolicy(context, true);
                        Looper.loop();
                    }
                }).start();
            }
        } else {
            //TODO: Add Exceptional Functions here
            Log.e(TAG, "lockDevice: Device Admin is not enabled");
        }
    }


    /*
    * This method is used to show overlay over the screen of phone
    * if true is passed , then the overlay will be shown
    * if false, then it will be hidden
    * Note: It uses OverlayPermission (android 6 and above )
    * */
    private void showLockScreen(boolean show) {
        int theme = android.R.style.Theme;
        try {
            PackageManager packageManager = context.getPackageManager();
            ApplicationInfo info = packageManager.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            theme = info.theme;
        } catch (Exception e) {
            Log.e("showLockScreen", " " + e.toString());
        }
        LockScreen lockScreen = LockScreen.getInstance(theme);
        if (show) {
            Log.e(TAG, "showLockScreen: Lock Called");
            editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG, true);
            editor.commit();
            lockScreen.show();
        } else {
            Log.e(TAG, "showLockScreen: Unlock Called");
            editor.putBoolean(AppConstant.SCREEN_LOCK_FLAG, false);
            editor.commit();

            lockScreen.remove();
        }
    }


    /**
     * Used to Wake up the sleeping device by acquiring WakeLock of Android
     **/
    public void unlockDevice() {
        Log.d(TAG, "unlockDevice: Unlocked");
        KeyguardManager km = (KeyguardManager) context
                .getSystemService(Context.KEYGUARD_SERVICE);
        final KeyguardManager.KeyguardLock kl = km
                .newKeyguardLock("MyKeyguardLock");
        kl.disableKeyguard();
        PowerManager pm = (PowerManager) context
                .getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK
                | PowerManager.ACQUIRE_CAUSES_WAKEUP
                | PowerManager.ON_AFTER_RELEASE, "MyWakeLock");
        wakeLock.acquire();
        if (preferences.getBoolean(AppConstant.IS_OVERLAY_PERMISSION_GRANTED, false)) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Looper.prepare();
                    showLockScreen(false);
                    SamsungKNOX.setPolicy(context, false);
                    Looper.loop();
                }
            }).start();
        }
    }


    /*
    *Send Acknowledgement To the Server that the command is received
     * This starts off a network thread, with the object passed.
    * */
    public void acknowledgeCommand(AckDTO obj) {
        //start the network thread
        new AckCommand(obj).start();
    }

    void fetchLocation() {
        final LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            if (preferences.getBoolean(AppConstant.SCREEN_ON_STATUS, false)) {
                context.startActivity(new Intent(context, EnableLocationServiceActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("CommandID", commandID));
            } else {
                Log.e(TAG, "<<< run: Gps is Turned Off >>>");
                LocationDTO locDTO = new LocationDTO();
                locDTO.setMessageCommandId(commandID);
                locDTO.setCommandKey("LOC");
                locDTO.setMAC(Utils.getMACAddress().replace(":", ""));
                locDTO.setResponse(new Response(0 + "", 0 + "", "Gps is turned off."));
                new SendLocResponse(locDTO).start();
            }
            Intent locationIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            Utils.showBigNotification("Turn on GPS",
                    context, locationIntent, 600, true, true);
            //TODO uncomment conditions
//            if (!applicationInForeground(context))                            {
//                context.startActivity(new Intent(context, EnableLocationServiceActivity.class) .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("CommandID", commandID));
//
//            } else {
//                Intent locationIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//                Utils.showBigNotification("Turn on GPS",
//                        context, locationIntent, 600,true,true);
//                //TODO: add the onActivity Callback here and exceptional ack
//            }
        } else {
            new Thread(new Runnable() {

                @Override
                public void run() {
                    Looper.prepare();
                    Log.d(TAG, "run: Prepare to Send location");
                    if (AndPermission.hasPermission(context, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) {
                        SingleShotLocationProvider.requestSingleUpdate(context,
                                new SingleShotLocationProvider.LocationCallback() {
                                    @Override
                                    public void onNewLocationAvailable(SingleShotLocationProvider.GPSCoordinates location) {
                                        LocationDTO locDTO = new LocationDTO();
                                        locDTO.setMessageCommandId(commandID);
                                        locDTO.setCommandKey("LOC");
                                        locDTO.setMAC(Utils.getMACAddress().replace(":", ""));
                                        locDTO.setResponse(new Response(location.latitude + "", location.longitude + "", "Location Found Successfully"));
                                        new SendLocResponse(locDTO).start();
                                        Log.d(TAG, "my location is " + location.latitude + " " + location.longitude);
                                    }
                                });
                    } else {
                        Log.e(TAG, "<<<run:Location Permission not granted>>>");
                        LocationDTO locDTO = new LocationDTO();
                        locDTO.setMessageCommandId(commandID);
                        locDTO.setCommandKey("LOC");
                        locDTO.setMAC(Utils.getMACAddress().replace(":", ""));
                        locDTO.setResponse(new Response(0 + "", 0 + "", "Location Permission is not                             granted."));
                        new SendLocResponse(locDTO).start();

                    }

                    Looper.loop();
                }
            }).start();
        }
    }

    //To Check if app is in Foreground
    private boolean applicationInForeground(Context context) {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(context.getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(context.getPackageName())) {
                isInBackground = false;
            }
        }
        Log.d(TAG, "applicationInForeground: " + isInBackground);
        return isInBackground;
    }

    //Check if gps provider is enabled
    private void checkIfProviderIsEnabled() {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;

        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
        }

        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ex) {
        }

        if (!gps_enabled && !network_enabled) {
            // notify user
            Intent locationIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            Utils.showBigNotification("Please turn on GPS",
                    context, locationIntent, 600, true, true);
//            AlertDialog.Builder dialog = new AlertDialog.Builder(context);
//            dialog.setMessage(context.getResources().getString(R.string.gps_network_not_enabled));
//            dialog.setPositiveButton(context.getResources().getString(R.string.open_location_settings), new DialogInterface.OnClickListener() {
//                @Override
//                public void onClick(DialogInterface paramDialogInterface, int paramInt) {
//                    // TODO Auto-generated method stub
//                    Intent myIntent = new Intent( Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//                    context.startActivity(myIntent);
//                    //get gps
//                }
//            });
//            dialog.setNegativeButton(context.getString(R.string.Cancel), new DialogInterface.OnClickListener() {
//
//                @Override
//                public void onClick(DialogInterface paramDialogInterface, int paramInt) {
//                    // TODO Auto-generated method stub
//
//                }
//            });
//            dialog.show();
        }

    }
}
