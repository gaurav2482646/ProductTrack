package com.kochartech.antitheft.xius.dto;

/**
 * Created by gauravjeet on 2/11/17.
 */

//Contains the Login Details
    /*
    * This class is a combination of 3 class.
    * AppDTO + DeviceDTO + UserDTO
    * */

public class RegisterDTO
{
    private AppDTO app;

    private DeviceDTO device;

    private UserDTO user;

    public AppDTO getAppDTO ()
    {
        return app;
    }

    public void setAppDTO (AppDTO app)
    {
        this.app = app;
    }

    public DeviceDTO getDeviceDTO ()
    {
        return device;
    }

    public void setDeviceDTO (DeviceDTO device)
    {
        this.device = device;
    }

    public UserDTO getUserDTO ()
    {
        return user;
    }

    public void setUserDTO (UserDTO user)
    {
        this.user = user;
    }

    @Override
    public String toString()
    {
        return "RegisterDTO [app = "+app+", device = "+device+", user = "+user+"]";
    }
}