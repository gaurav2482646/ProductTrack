package com.kochartech.antitheft.xius.util;

import android.app.enterprise.EnterpriseDeviceManager;
import android.app.enterprise.RestrictionPolicy;
import android.app.enterprise.license.EnterpriseLicenseManager;
import android.content.Context;
import android.util.Log;

import com.kochartech.antitheft.xius.R;

/**
 * Created by gauravjeet on 10/10/17.
 */
public class SamsungKNOX {

    private static String TAG = SamsungKNOX.class.getSimpleName();

    //Used to activate samsung knox license
    public void activateSamsunglicense(Context context) {
        try {
            if (Utils.isDeviceSamsung(context)) {

                Log.d(TAG, "inside the activate samsung license");
                EnterpriseLicenseManager mgr = EnterpriseLicenseManager.getInstance(context);
                mgr.activateLicense(context.getResources().getString(R.string.license_key));
            } else {
                Log.d(TAG, "device is not samsung brand");
            }
        } catch (Exception e) {
            Log.e(TAG, "exception: " + e.toString());
        }

    }
    // Call this to toggle various feature of Samsung Device
    // Modify this as required
    public static void setPolicy(Context context, boolean b){
        if (Utils.isDeviceSamsung(context)) {
        Log.d(TAG, "setPolicy: Called");
        EnterpriseDeviceManager mEDM;
        mEDM = new EnterpriseDeviceManager(context);
        RestrictionPolicy rp = mEDM.getRestrictionPolicy();
        rp.allowFactoryReset(!b);
        Log.d(TAG, "factory reset ");
        rp.allowPowerOff(!b);
        Log.d(TAG, "power off is disabled");
        mEDM.setAdminRemovable(!b);
        Log.d(TAG, "uninstall is disabled");
        rp.setUsbDebuggingEnabled(!b);
        rp.allowAirplaneMode(!b);}

    }
}