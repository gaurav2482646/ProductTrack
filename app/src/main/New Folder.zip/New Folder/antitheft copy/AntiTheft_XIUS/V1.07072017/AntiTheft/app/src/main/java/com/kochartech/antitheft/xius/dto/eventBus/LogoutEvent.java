package com.kochartech.antitheft.xius.dto.eventBus;

/**
 * Created by gauravjeet on 26/12/17.
 */

public class LogoutEvent {
    public boolean isLogout;

    public LogoutEvent(boolean isLogout) {
        this.isLogout = isLogout;
    }
}
