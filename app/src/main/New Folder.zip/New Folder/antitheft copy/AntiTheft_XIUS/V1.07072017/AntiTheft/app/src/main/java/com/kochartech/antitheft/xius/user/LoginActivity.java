package com.kochartech.antitheft.xius.user;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.kochartech.antitheft.xius.AppConstant;
import com.kochartech.antitheft.xius.DisplayActivity;
import com.kochartech.antitheft.xius.R;
import com.kochartech.antitheft.xius.StartupOperations;
import com.kochartech.antitheft.xius.camera.OnPictureCapturedListener;
import com.kochartech.antitheft.xius.deviceadmin.KDeviceAdminReceiver;
import com.kochartech.antitheft.xius.dto.AppDTO;
import com.kochartech.antitheft.xius.dto.ExistingDeviceDTO;
import com.kochartech.antitheft.xius.dto.UserDTO;
import com.kochartech.antitheft.xius.user.home.HomeActivity;
import com.kochartech.antitheft.xius.util.DualSimInfo;
import com.kochartech.antitheft.xius.util.PreferenceHelper;
import com.kochartech.antitheft.xius.util.SamsungKNOX;
import com.kochartech.antitheft.xius.util.SendGridMailAsyncTask;
import com.kochartech.antitheft.xius.util.TelephonyInfo;
import com.kochartech.antitheft.xius.util.Utils;
import com.yanzhenjie.alertdialog.AlertDialog;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;
import com.yanzhenjie.permission.Rationale;
import com.yanzhenjie.permission.RationaleListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static android.Manifest.permission.READ_PHONE_STATE;

//import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

//import com.kochartech.antitheft.xius.util.*;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity implements OnPictureCapturedListener, BillingClientStateListener, PurchasesUpdatedListener {
    private BillingClient mBillingClient;

    private UserSessionManager userSessionManager;
    private static final int REQUEST_READ_PHONE_STATE = 0;
    private static final int USER_NAME_LENGTH_LOWER_LIMIT = 6;
    private static final int USER_NAME_LENGTH_UPPER_LIMIT = 10;
    private static final int LICENSE_LENGTH = 10;
    private static final String LICENSE_LENGTH_KEY = "license_length_key";
    private static final String USER_NAME_LENGTH_UPPER_LIMIT_KEY = "username_length_upper_limit_key";
    private static final String USER_NAME_LENGTH_LOWER_LIMIT_KEY = "username_length_lower_limit_key";
    private static final String TAG = "Login";
    private static final int REQUEST_CODE_DEVICE_ADMIN = 200;
    private static final String RESPONSE_MESSAGE = "message";
    private static final int REQUEST_PREM = 400;
    private static final int DENIED_PERMISSION_ACTIVITY_CODE = 300;
    ArrayList<String> permissions = new ArrayList<>();
    boolean isPermissionGranted;
    String userName;
    String password;
    String license;
    DualSimInfo dualSimInfo;
    Typeface fonts1;
    private SharedPreferences sharedPreferences = PreferenceHelper.getSharedPreference();
    private SharedPreferences.Editor editor = PreferenceHelper.getSharedPreferenceEditor();
    // UI references.
    private EditText mUserNameView;
    private EditText mPasswordView;
    private EditText mLicenseKey;
    private View mProgressView;
    private View mLoginFormView;
    private TextView mforgetPasswordTextview;
    //    private FirebaseRemoteConfig firebaseRemoteConfig;
    //Admin Fields
    private DevicePolicyManager mDPM;
    private ComponentName mAdminName;
    private boolean isdialogPermissionRationaleShown;
    private PreferenceHelper preferenceHelper;
    //Local Broadcast Receiver For Samsung Knox Activation
    LocalElmActivationReceiver localElmActivationReceiver;
    private boolean clientReady;

    private PermissionListener permissionListener = new PermissionListener() {
        @Override
        public void onSucceed(int i, @NonNull List<String> list) {
            switch (i) {
                case REQUEST_PREM: {
                    if (dualSimInfo.getImsi() != null) {
                        if (Utils.isTimeAutomaticEnabled(LoginActivity.this)) {
                            showProgress(true);
                            volleyLoginUserRequest();
                        } else {
                            Utils.displayWrongDateNotification(LoginActivity.this);
                        }
                        break;
                    } else {
                        dialogSimNotAvailable();
                    }
                }
            }
        }

        @Override
        public void onFailed(int i, @NonNull List<String> list) {
            switch (i) {
                case REQUEST_PREM: {
                    Toast.makeText(LoginActivity.this, "Permissions required to continue !", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
            if (AndPermission.hasAlwaysDeniedPermission(LoginActivity.this, list)) {
                AndPermission.defaultSettingDialog(LoginActivity.this, DENIED_PERMISSION_ACTIVITY_CODE)
                        .setTitle("Permissions Disabled")
                        .setMessage("Please go to App Settings to Enable the Permissions Manaually")
                        .setPositiveButton("Ok")
                        .setNegativeButton("NO",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                        .show();

            }
        }
    };
    private RationaleListener rationaleListener = new RationaleListener() {
        @Override
        public void showRequestPermissionRationale(int requestCode, final Rationale rationale) {
            AlertDialog.newBuilder(LoginActivity.this)
                    .setTitle("Permissions Required !")
                    .setMessage("Please enable all the permissions")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            rationale.resume();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            rationale.cancel();
                        }
                    }).show();
        }
    };
    private boolean hasPurchasedLicence;
    private String purchaseToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_login_new);
        setContentView(R.layout.activity_login);
        mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        mAdminName = new ComponentName(this, KDeviceAdminReceiver.class);
        // Set up the login form.
        mUserNameView = (EditText) findViewById(R.id.username1);
        mforgetPasswordTextview = (TextView) findViewById(R.id.tvForgetPassword);
//        getSupportActionBar().setTitle("AntiTheft");
//        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
//        Log.d(TAG, "Current Battery Level " + Utils.getBatteryLevel());
        preferenceHelper = new PreferenceHelper(this);
        isdialogPermissionRationaleShown = sharedPreferences.getBoolean(AppConstant.IS_DIALOG_PERMISSION_RATIONALE_SHOWN, false);
        mPasswordView = (EditText) findViewById(R.id.password);
        fonts1 = Typeface.createFromAsset(this.getAssets(),
                "fonts/Lato-Light.ttf");
//        mBillingClient = BillingClient.newBuilder(this).setListener(this).build();
//        mBillingClient.startConnection(this);
       /* mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });*/

//        mLicenseKey = (EditText) findViewById(R.id.license_key);
//        mLicenseKey.setFilters(
//                new InputFilter[]{new InputFilter.LengthFilter(LICENSE_LENGTH)});
//
        mUserNameView.setText("gaurav2482646@gmail.com");
        mPasswordView.setText("111111");
//        mLicenseKey.setText("zGh33vRL");

        dualSimInfo = new DualSimInfo(LoginActivity.this);
        Button mEmailSignInButton = (Button) findViewById(R.id.email_sign_in_button);
        mEmailSignInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!isdialogPermissionRationaleShown) {
                        dialogPermissionRationale();
                    } else {
                        if (Utils.isNetworkAvailable(LoginActivity.this)) {
                            attemptLogin();
                        } else {
                            showToast(getString(R.string.check_internet));
                        }
                    }
                } else {
                    if (Utils.isNetworkAvailable(LoginActivity.this)) {
                        attemptLogin();
                    } else {
                        showToast(getString(R.string.check_internet));
                    }

                }

            }
        });
        mforgetPasswordTextview.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "ForgetPasswordCalled");
                //todo call the forget password method here
                startActivity(new Intent(LoginActivity.this, ForgetPasswordActivity.class));
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

            }
        });
        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);

//        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
//                .setDeveloperModeEnabled(true)
//                .build();
//        firebaseRemoteConfig.setConfigSettings(configSettings);
//        Map<String, Object> configMap = new HashMap<>();
//        configMap.put(LICENSE_LENGTH_KEY, LICENSE_LENGTH);
//        firebaseRemoteConfig.setDefaults(configMap);
//        fetchConfig();

    }

    @Override
    protected void onResume() {
        super.onResume();
//        Utils.getSimNumber(this,1);
//        Log.d(TAG,"sim " + new DualSimInfo(this).getIMEI(1) + "carrier "+ new DualSimInfo(this).getCarrierName(1));
    }

    void dialogSimNotAvailable() {

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage(R.string.insert_sim)
                .setCancelable(false)
                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });


        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("Insert Sim");
        alert.show();
    }

    void dialogDeviceAlreadyRegistered() {

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage(R.string.device_with_another_user)
                .setCancelable(false)
                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });


        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("Device Already Activated");
        alert.show();
    }

    void dialogPermissionRationale() {

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        //builder.setMessage(R.string.dialog_message) .setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage("Certain permissions are needed to continue with registration.")
                .setCancelable(false)
                .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if (Utils.isNetworkAvailable(LoginActivity.this)) {
                            isdialogPermissionRationaleShown = true;
                            editor.putBoolean(AppConstant.IS_DIALOG_PERMISSION_RATIONALE_SHOWN, true);
                            editor.apply();
                            attemptLogin();
                        } else {
                            showToast(getString(R.string.check_internet));
                        }
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.cancel();
                    }
                });

        //Creating dialog box
        android.support.v7.app.AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("AntiTheft Alert");
        alert.show();
    }

//    public void fetchConfig() {
//        long cacheExpiration = 3600;
//        if (firebaseRemoteConfig.getInfo().getConfigSettings().isDeveloperModeEnabled()) {
//            cacheExpiration = 0;
//        }
//        firebaseRemoteConfig.fetch(cacheExpiration)
//                .addOnSuccessListener(new OnSuccessListener<Void>() {
//                    @Override
//                    public void onSuccess(Void aVoid) {
//                        applyRetrievedLengthLimit();
//                    }
//                })
//                .addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        applyRetrievedLengthLimit();
//
//                    }
//                })
//        ;
//
//    }
//
//    public void applyRetrievedLengthLimit() {
//        Long licenseKeyLength = firebaseRemoteConfig.getLong(LICENSE_LENGTH_KEY);
//        mLicenseKey.setFilters(new InputFilter[]{new InputFilter.LengthFilter(licenseKeyLength.intValue())});
//    }

    private boolean mayRequestContacts() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (checkSelfPermission(READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        if (shouldShowRequestPermissionRationale(READ_PHONE_STATE)) {
            Snackbar.make(mUserNameView, R.string.permission_rationale, Snackbar.LENGTH_INDEFINITE)
                    .setAction(android.R.string.ok, new View.OnClickListener() {
                        @Override
                        @TargetApi(Build.VERSION_CODES.M)
                        public void onClick(View v) {
                            requestPermissions(new String[]{READ_PHONE_STATE}, REQUEST_READ_PHONE_STATE);
                        }
                    });
        } else {
            requestPermissions(new String[]{READ_PHONE_STATE}, REQUEST_READ_PHONE_STATE);
        }
        return false;
    }

    /**
     * Callback received when a permissions request has been completed.
     */
//    @Override
//    public void onRequestPermissionsResult(int requestCode,
//                                           @NonNull String[] permissions,
//                                           @NonNull int[] grantResults) {
//        /*if (requestCode == REQUEST_READ_PHONE_STATE) {
//            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//            }
//        }*/
//
//    }
    private void attemptLogin() {
        // Reset errors.
        mUserNameView.setError(null);
        mPasswordView.setError(null);
//        mLicenseKey.setError(null);


        // Store values at the time of the login attempt.
        userName = mUserNameView.getText().toString();
        password = mPasswordView.getText().toString();
//        license = mLicenseKey.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid email address.

        if (!isValidEmail(userName)) {
            mUserNameView.setError(getString(R.string.error_invalid_email));
            focusView = mUserNameView;
            cancel = true;
        } else if (!isUserNameValid(userName)) {
            mUserNameView.setError(getString(R.string.error_field_required));
            focusView = mUserNameView;
            cancel = true;
        }
        // Check for a valid password, if the user entered one.

        else if (TextUtils.isEmpty(password)) {
            mPasswordView.setError(getString(R.string.error_field_required));
            focusView = mPasswordView;
            cancel = true;
        } else if (!isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;

            // Check License
//        } else if (TextUtils.isEmpty(license)) {
//            mUserNameView.setError(getString(R.string.error_field_required));
//            focusView = mLicenseKey;
//            cancel = true;
//        } else if (!isLicenseValid(license)) {
//            mLicenseKey.setError(getString(R.string.error_invalid_license));
//            focusView = mLicenseKey;
//            cancel = true;
        }


        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {

            AndPermission.with(LoginActivity.this)
                    .requestCode(REQUEST_PREM)
                    .permission(AppConstant.REQUIRED_PERMISSIONS)
                    .callback(permissionListener)
                    .rationale(rationaleListener)
                    .start();

        }
    }

    private boolean isUserNameValid(String userName) {

        return userName.length() >= 6 && userName.length() < 50;
    }

    private boolean isPasswordValid(String password) {

        return password.length() >= 6;
    }

    private boolean isLicenseValid(String license) {
        return license.length() == 8;
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    public void volleyLoginUserRequest() {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();
        final String VALID_USER = "0";
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("emailAddress", userName.trim());
        params.put("password", password);
        Toast.makeText(this, params.toString(), Toast.LENGTH_SHORT).show();
//        params.put("SerialKey", license);

        Log.v(TAG, "Request Login User: " + params.toString());
        final JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                AppConstant.LOGIN_URL, new JSONObject(params),
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        Log.d(TAG, jsonObject.toString());
//                        Toast.makeText(LoginActivity.this, jsonObject.toString(), Toast.LENGTH_LONG).show();

                        try {
                            if (jsonObject.getString("code").equals(VALID_USER)) {
                                Gson gson = new Gson();
                                JSONObject jsonObject1 = new JSONObject(jsonObject.getString("user"));
                                Log.d(TAG, "onResponse: USER DETAILS :" + jsonObject1);
                                UserDTO userDTO = gson.fromJson(String.valueOf(jsonObject.getString("user")), UserDTO.class);
                                preferenceHelper.saveInt(AppConstant.USER_ID, userDTO.getUserID());
                                preferenceHelper.saveString(AppConstant.USER_NAME, userDTO.getName());
                                preferenceHelper.saveString(AppConstant.USER_EMAIL, userDTO.getEmailAddress());
                                preferenceHelper.saveString(AppConstant.PHONE_NUMBER, userDTO.getMobileNumber());
                                preferenceHelper.saveString(AppConstant.PASSWORD, password);
                                preferenceHelper.saveString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, userDTO.getAlternateNumber());
                                Log.d(TAG, "USER DTO : " + userDTO.toString());
                                //JSONObject jsonObjectData = jsonObject.getJSONObject("data");
//                                Log.d(TAG, "onResponse Overall: " + jsonObject.toString());
//                                Log.d(TAG, "onResponse Data Vali: " + jsonObjectData.toString());
//                                String userId = jsonObjectData.getString(AppConstant.USER_ID);
//                                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
//                                SharedPreferences.Editor editor = sharedPreferences.edit();
//                                editor.putString(AppConstant.ALTERNATE_PHONE_NUMBER_ONE, jsonObjectData.getString("alternateNumberOne"));
//editor.putString(AppConstant.ALTERNATE_PHONE_NUMBER_TWO, jsonObjectData.getString("alternateNumberTwo"));
//                                editor.putString(AppConstant.USER_ID, userId);
//                                editor.putBoolean(AppConstant.IS_USER_REGISTERED, true);
//                                editor.putString(AppConstant.PASSWORD, password);
//                                editor.apply();
//                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
//                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                                startActivity(intent);
//                                finish();
//                                finishAffinity();
//                                Log.d(TAG, "UserId " + userId);
//                                volleyRegisterDeviceRequest(userId);
                                getExistingDevice();

                            } else {
                                showProgress(false);
                                String message = jsonObject.getString(RESPONSE_MESSAGE);
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            showProgress(false);
                            Toast.makeText(LoginActivity.this, "Some error occurred, try again", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                VolleyLog.d(TAG, "Error: " + error.getMessage());
                Log.d(TAG, "onErrorResponse: " + error.getMessage());
                showProgress(false);
                mRequestQueue.stop();
                if (error.getMessage() == null) {
                    Toast.makeText(LoginActivity.this, "Some error occurred, please try again", Toast.LENGTH_SHORT).show();
                } else if (error.getMessage() != null) {
                    Toast.makeText(LoginActivity.this, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        }) {

            /**
             * Passing some request headers
             * */
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }
        };
        mRequestQueue.add(jsonObjReq);

    }


    public void volleyRegisterDeviceRequest(String userId) {
        final RequestQueue mRequestQueue;
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();

        HashMap<String, String> params = getRegisterDeviceMap(userId);


        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST,
                AppConstant.DEVICE_REGISTRATION_URL, new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        Log.d(TAG, jsonObject.toString());
                        mRequestQueue.stop();
                        try {
                            if (jsonObject.getString("code").equals("0")) {
                                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putBoolean(AppConstant.IS_USER_REGISTERED, true);
                                editor.apply();
                                if (!mDPM.isAdminActive(mAdminName)) {
                                    Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mAdminName);
                                    intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Click on Activate button to secure your application.");
                                    startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN);
                                } else {
                                    Intent intent = new Intent(LoginActivity.this, DisplayActivity.class);
                                    startActivity(intent);
                                }
                                startService(new Intent(LoginActivity.this, StartupOperations.class));
                            } else {
                                showProgress(false);
                                String message = jsonObject.getString(RESPONSE_MESSAGE);
                                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                Log.d(TAG, "onErrorResponse: " + error.getMessage());
                Toast.makeText(LoginActivity.this, "Error " + error.getMessage(), Toast.LENGTH_SHORT).show();
                mRequestQueue.stop();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }


        };
        mRequestQueue.add(jsonObjReq);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        switch (requestCode) {

            case (DENIED_PERMISSION_ACTIVITY_CODE): {
                if (AndPermission.hasPermission(LoginActivity.this, AppConstant.REQUIRED_PERMISSIONS)) {
                    Toast.makeText(this, "Permission Granted, Continue with work.", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(this, "Permission Not Denied", Toast.LENGTH_SHORT).show();
                }
                break;

            }
            case (REQUEST_CODE_DEVICE_ADMIN): {
                if (resultCode == RESULT_OK) {
                    if (Utils.isDeviceSamsung(this)) {

                        if (!sharedPreferences.getBoolean(AppConstant.ELM_LICENSE_STATUS, false)) {
                            localElmActivationReceiver = new LocalElmActivationReceiver();
                            IntentFilter intentFilter = new IntentFilter(AppConstant.LOCAL_ELM_RECEIVER_ACTION);
                            registerReceiver(localElmActivationReceiver, intentFilter);
                            new SamsungKNOX().activateSamsunglicense(this);
                            Toast.makeText(this, R.string.please_wait_knox_activate, Toast.LENGTH_SHORT).show();
                            showProgress(true);
                        } else {
                            Intent intent = new Intent(LoginActivity.this, DisplayActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    } else {
                        Intent intent = new Intent(LoginActivity.this, DisplayActivity.class);
                        startActivity(intent);
                        finish();
                    }
                } else if (resultCode == RESULT_CANCELED) {
                    Toast.makeText(this, R.string.enable_device_admin, Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;

            }
        }

    }

    public DualSimInfo getDualSimInfo() {
        return dualSimInfo;
    }

    //Return a Map Object of device details
    private HashMap<String, String> getRegisterDeviceMap(String userId) {

        try {
            TelephonyInfo telephonyInfo = TelephonyInfo.getInstance(this);
            HashMap<String, String> hashMap = new HashMap<>();
            boolean isDualSim;
            String simOne = null;
            String simTwo = null;
            DualSimInfo dualSimInfo = new DualSimInfo(this);
            isDualSim = dualSimInfo.isDualSim();
            if (isDualSim) {
                simOne = dualSimInfo.getIMSI(0);
                simTwo = dualSimInfo.getIMSI(1);
                if (simOne == null || simTwo == null) {
                    if (telephonyInfo.isSIM1Ready()) {
                        simOne = telephonyInfo.getImsiSIM1();
                    }
                    if (telephonyInfo.isSIM2Ready()) {
                        simTwo = telephonyInfo.getImsiSIM2();
                    }
                }
                editor.putString(AppConstant.SIM_NUMBER_ONE, simOne);
                editor.putString(AppConstant.SIM_NUMBER_TWO, simTwo);
                editor.apply();
                hashMap.put(AppConstant.SIM_NUMBER_ONE, simOne == null ? "0" : simOne);
                hashMap.put(AppConstant.SIM_NUMBER_TWO, simTwo == null ? "0" : simTwo);

            } else {
                TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

                simOne = telephonyManager.getSubscriberId();
                if (simOne == null) {
                    if (telephonyInfo.isSIM1Ready()) {
                        simOne = telephonyInfo.getImsiSIM1();
                    }
                }
                editor.putString(AppConstant.SIM_NUMBER_ONE, simOne);
                editor.apply();
                hashMap.put(AppConstant.SIM_NUMBER_ONE, simOne == null ? "0" : simOne);
            }
            Calendar calendar = Calendar.getInstance();
            Date date = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String regId = sharedPreferences.getString(AppConstant.REGISTRATION_ID_FCM, "");


            hashMap.put(AppConstant.BRAND, Build.MANUFACTURER);
            hashMap.put(AppConstant.IMEI, dualSimInfo.getIMEI(0));
            hashMap.put(AppConstant.INSTALL_DATE, dateFormat.format(date));
            hashMap.put(AppConstant.MAC_ADDRESS, Utils.getMACAddress().replace(":", ""));
            hashMap.put(AppConstant.MODEL, Build.MODEL);
            hashMap.put(AppConstant.REGISTRATION_ID_FCM, regId);
            hashMap.put(AppConstant.APP_VERSION, getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
            hashMap.put(AppConstant.APP_NAME, Utils.getApplicationName(this));


            hashMap.put(AppConstant.USER_ID, userId);
            Log.d(TAG, "json " + hashMap.toString());

            return hashMap;

        } catch (Exception ex) {
            Log.e(TAG, "ex create json " + ex.toString());
        }
        return null;
    }

    public final boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target.toString().trim()) && android.util.Patterns.EMAIL_ADDRESS.matcher(target.toString().trim()).matches();
    }

    /*This is the Code For Clicking Picture Incase Of Wrong Login And Then Send It To The Mail Of User
    * */
    @Override
    public void onDoneCapturingAllPhotos(TreeMap<String, byte[]> picturesTaken) {
        if (picturesTaken != null && !picturesTaken.isEmpty()) {
            showToast("Done capturing all photos!");
            //TODO: add the line -- , Environment.getExternalStorageDirectory() + "/1_pic.jpg" below
//            new SendMailAsyncTask().execute(getApplicationContext(),Environment.getExternalStorageDirectory() + "/1_pic.jpg","Sending mail");
            try {
                if (Utils.isNetworkAvailable(LoginActivity.this)) {
                    Log.d(TAG, "onDoneCapturingAllPhotos: Sending Mail");
                    new SendGridMailAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getApplicationContext(), Environment.getExternalStorageDirectory() + "/1_pic.jpg", "Sending mail");
                } else {
                    Log.d(TAG, "onDoneCapturingAllPhotos: Network Not Available,Mail Not Sent");
                }
            } catch (NullPointerException ex) {
                ex.printStackTrace();
                Log.d(TAG, "onDoneCapturingAllPhotos: " + ex.toString());
            }

            return;
        }
        showToast("No camera detected!");
    }

    @Override
    public void onCaptureDone(final String pictureUrl, final byte[] pictureData) {
        if (pictureData != null && pictureUrl != null) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    final Bitmap bitmap = BitmapFactory.decodeByteArray(pictureData, 0, pictureData.length);
                    final int nh = (int) (bitmap.getHeight() * (512.0 / bitmap.getWidth()));
                    final Bitmap scaled = Bitmap.createScaledBitmap(bitmap, 512, nh, true);
                    if (pictureUrl.contains("0_pic.jpg")) {
//                    uploadBackPhoto.setImageBitmap(scaled);
                    } else if (pictureUrl.contains("1_pic.jpg")) {
//                    uploadFrontPhoto.setImageBitmap(scaled);
                    }
                }
            });

            showToast("Picture saved to " + pictureUrl);

        }
    }

    /**
     * Shows a {@link Toast} on the UI thread.
     *
     * @param text The message to show
     */

    private void showToast(final String text) {
        runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              Toast.makeText(LoginActivity.this.getApplicationContext(), text, Toast.LENGTH_SHORT).show();
                          }
                      }
        );
    }

    @Override
    public void onBillingSetupFinished(int responseCode) {
        if (responseCode == BillingClient.BillingResponse.OK) {
            // The billing client is ready. You can query purchases here.
            Log.d(TAG, "onBillingSetupFinished: Now Start Query Purchase ");
            clientReady = true;
//            queryPurchase();
            queryPurchasedItems();

        }
    }

    private void queryPurchasedItems() {
        Log.i(TAG, "queryPurchasedItems Called");
        Purchase.PurchasesResult purchasesResult = mBillingClient.queryPurchases(BillingClient.SkuType.INAPP);
        List<Purchase> purchaseList = purchasesResult.getPurchasesList();
        if (purchaseList.isEmpty()) {
            hasPurchasedLicence = false;
            Log.i(TAG, "queryPurchasedItems: User has purchased nothing");
        }
        for (Purchase purchase : purchaseList) {
            Log.i(TAG, "queryPurchasedItems: " + purchase.getOriginalJson());
            hasPurchasedLicence = true;
            purchaseToken = purchase.getPurchaseToken();

        }


    }

    @Override
    public void onBillingServiceDisconnected() {
        clientReady = false;
    }

    @Override
    public void onPurchasesUpdated(int responseCode, @Nullable List<Purchase> purchases) {
        if (responseCode == BillingClient.BillingResponse.OK
                && purchases != null) {
            for (Purchase purchase : purchases) {
                purchaseToken = purchase.getPurchaseToken();
                Log.i(TAG, "onPurchasesUpdated: " + purchase.getOriginalJson());
            }
        } else if (responseCode == BillingClient.BillingResponse.USER_CANCELED) {
            // Handle an error caused by a user cancelling the purchase flow.
            Log.i(TAG, "onPurchasesUpdated: Billing Was cancelled");
        } else {
            // Handle any other error codes.
            Log.i(TAG, "onPurchasesUpdated:Any other error");
        }
    }

    //Local Elm Receiver to get the events of activation by ElmReceiver.java receiver
    private class LocalElmActivationReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            boolean isActivated = intent.getBooleanExtra(AppConstant.LOCAL_ELM_RECEIVER_EXTRA_BOOLEAN, false);
            if (isActivated) {
                Intent intent1 = new Intent(context, DisplayActivity.class);
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent1);
                finish();
            }

        }
    }

    public void getExistingDevice() {
        final RequestQueue mRequestQueue;
        userSessionManager = new UserSessionManager(this);
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();
        showProgress(true);
        final String ALREADY_REGISTERED = "0";
        final String NEW_DEVICE = "1";

        try {
            Log.d(TAG, "getExistingDeviceRequest: " + getExistingDeviceDTO().toString());
            JsonObjectRequest jsonObjReqExistDevice = new JsonObjectRequest(Request.Method.POST,
                    AppConstant.GET_EXISTING_DEVICE_URL, getExistingDeviceDTO(),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject jsonObjectExistDevice) {
                            Log.d(TAG, jsonObjectExistDevice.toString());
                            mRequestQueue.stop();
                            try {
                                // NEW DEVICE(Device is not associated with any user)
                                if (jsonObjectExistDevice.getString("code").equals(NEW_DEVICE)) {
                                    preferenceHelper.setDeviceUnRegistered();
                                    Toast.makeText(LoginActivity.this, "New Device", Toast.LENGTH_SHORT).show();
                                    Toast.makeText(LoginActivity.this, jsonObjectExistDevice.getString(RESPONSE_MESSAGE), Toast.LENGTH_SHORT).show();
                                    userSessionManager.createLoginSession(false);
                                    //TODO START LOGIN SESSION HERE

                                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
//                                    intent.putExtra("isNewDevice", true);
                                    startActivity(intent);
                                    showProgress(false);

                                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                                    finishAffinity();
                                }
                                //Device is Already Registered with some user
                                else {
                                    //TODO Compare the user id with the existing device
                                    Log.d(TAG, "Already Registered: " + jsonObjectExistDevice.toString());
                                    Toast.makeText(LoginActivity.this, jsonObjectExistDevice.getString(RESPONSE_MESSAGE), Toast.LENGTH_SHORT).show();
                                    Gson gson = new Gson();
                                    UserDTO userDTO = gson.fromJson(jsonObjectExistDevice.get("user").toString(), UserDTO.class);
                                    AppDTO appDTO = gson.fromJson(jsonObjectExistDevice.get("app").toString(), AppDTO.class);

                                    //Check if Registered device is of the  current user
                                    if (preferenceHelper.getInt(AppConstant.USER_ID, 0) == userDTO.getUserID()) {
                                        //Check if the billing client is ready to query purchased items.
//                                        if (clientReady) {
//                                            queryPurchasedItems();
//                                        } else {
//                                            mBillingClient.startConnection(LoginActivity.this);
//                                        }
//                                        //Check if the user has purchased the license
//                                        if (hasPurchasedLicence) {
//                                            //purchase token is used to consume the purchase
//                                            preferenceHelper.saveString(AppConstant.BILLING_PURCHASE_TOKEN, purchaseToken);
//                                        }
                                        //TODO UNCOMMENT THE CODE
//                                        preferenceHelper.saveInt(AppConstant.VALIDITY_AT_LOGIN, appDTO.getValidity());
                                        //preferenceHelper.saveLong(AppConstant.DAYS_ELAPSED, appDTO.getValidity());
                                        preferenceHelper.saveInt(AppConstant.VALIDITY_AT_LOGIN, appDTO.getValidity());
                                        //We will Use it to check the validity at login
//                                        preferenceHelper.saveInt(AppConstant.DAYS_ELAPSED, 1);
                                        Date now = new Date();
                                        preferenceHelper.saveLong(AppConstant.LOGIN_TIME, now.getTime());
                                        preferenceHelper.saveBoolean(AppConstant.IS_TRIAL, appDTO.getIsTrial());
//                                        int validity = appDTO.getValidity();
//                                        preferenceHelper.saveInt(AppConstant.VALIDITY_AT_LOGIN, 1);

//                                        int validity = 1;
                                        int validity = appDTO.getValidity();
                                        if (validity < 1) {
                                            preferenceHelper.setAppExpired();
                                        } else {
                                            preferenceHelper.setDeviceRegistered();
                                        }
                                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                        intent.putExtra(HomeActivity.IS_EXPIRED, preferenceHelper.isAppExpired());
                                        userSessionManager.createLoginSession(true);
                                        Utils.storeSimSerial(LoginActivity.this);
                                        //TODO START LOGIN SESSION HERE
                                        startService(new Intent(LoginActivity.this, StartupOperations.class));
                                        startActivity(intent);
                                        finishAffinity();
                                    }
                                    //Device is of Another user, prompt the user with dialog
                                    else {
                                        dialogDeviceAlreadyRegistered();
                                        showProgress(false);
                                    }
                                    String message = jsonObjectExistDevice.toString();
//                                    Toast.makeText(LoginActivity.this, "Device registered with other user", Toast.LENGTH_SHORT).show();
//                                    Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
//

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                showProgress(false);
                                Toast.makeText(LoginActivity.this, "Parsing Error", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.d(TAG, "Error: " + error.getMessage());
                    showProgress(false);

                    Log.d(TAG, "onErrorResponse: " + error.getMessage());
                    Toast.makeText(LoginActivity.this, "Please connect to internet", Toast.LENGTH_SHORT).show();
                    mRequestQueue.stop();
                }
            }) {


                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("Content-Type", "application/json; charset=utf-8");
                    return headers;
                }


            };
            mRequestQueue.add(jsonObjReqExistDevice);
        } catch (Exception e) {
            e.printStackTrace();
            showProgress(false);

            Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private JSONObject getExistingDeviceDTO() throws PackageManager.NameNotFoundException, JSONException {
        ExistingDeviceDTO existingDeviceDTO = new ExistingDeviceDTO();

        existingDeviceDTO.setMacAddress(Utils.getMACAddress().replace(":", ""));
        Gson gson = new Gson();
        return new JSONObject(gson.toJson(existingDeviceDTO));
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            if (localElmActivationReceiver != null) {
                unregisterReceiver(localElmActivationReceiver);
            }
        } catch (Exception e) {
            localElmActivationReceiver = null;
            e.printStackTrace();
        }
    }

}

